
const {useState,useEffect,useRef,useMemo} = React;

/* ================= Helpers ================= */
const uid = () => Date.now().toString(36)+Math.random().toString(36).slice(2,7);
const fmt = (n) => Number(n||0).toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2});
const money = (n) => fmt(n)+' د.إ';
const ownersLine = (proj) => {
  if(!proj) return '';
  const names = [proj.owner||'', ...(proj.additionalOwners||[]).filter(o=>o && o.name).map(o=>o.name)].filter(Boolean);
  if(names.length<=1) return names.join('');
  const isArabicText = /[\u0600-\u06FF]/.test(names.join(''));
  return names.join(isArabicText ? ' و ' : ', ');
};
const todayISO = () => new Intl.DateTimeFormat('en-CA',{timeZone:'Asia/Dubai',year:'numeric',month:'2-digit',day:'2-digit'}).format(new Date());
const advanceDate = (dateStr, frequency) => {
  const [y,m,day]=(dateStr||todayISO()).split('-').map(Number);
  const months=frequency==='شهري'?1:frequency==='ربع سنوي'?3:frequency==='نصف سنوي'?6:12;
  const first=new Date(Date.UTC(y,m-1+months,1));
  const max=new Date(Date.UTC(first.getUTCFullYear(),first.getUTCMonth()+1,0)).getUTCDate();
  first.setUTCDate(Math.min(day,max));return first.toISOString().slice(0,10);
};
const monthKey = dateStr => (dateStr||'').slice(0,7);
const daysUntil = dateStr => dateStr?Math.round((Date.parse(dateStr+'T00:00:00Z')-Date.parse(todayISO()+'T00:00:00Z'))/86400000):null;
const expiryStatus = (dateStr, warnDays=60) => {
  const d = daysUntil(dateStr);
  if(d===null) return 'gray';
  if(d<0) return 'bad';
  if(d<=warnDays) return 'soon';
  return 'ok';
};
const expiryLabel = (dateStr, warnDays=60) => {
  const d = daysUntil(dateStr);
  if(d===null) return 'غير محدد';
  if(d<0) return 'منتهية منذ '+Math.abs(d)+' يوم';
  if(d<=warnDays) return 'تنتهي خلال '+d+' يوم';
  return 'سارية';
};
/* عتبات التنبيه لكل نوع وثيقة */
const WARN_PASSPORT = 210;  // الجواز: 7 شهور
const WARN_IQAMA = 30;      // الإقامة: شهر
const WARN_DEFAULT = 60;    // بطاقة العمل / رخصة السيارة
const monthNamesAr = ['يناير','فبراير','مارس','أبريل','مايو','يونيو','يوليو','أغسطس','سبتمبر','أكتوبر','نوفمبر','ديسمبر'];
const monthNamesEn = ['January','February','March','April','May','June','July','August','September','October','November','December'];
const fmtMonth = (key) => { const [y,m]=key.split('-'); return monthNamesAr[parseInt(m,10)-1]+' '+y; };
const fmtMonthEn = (key) => { const [y,m]=key.split('-'); return monthNamesEn[parseInt(m,10)-1]+' '+y; };
const last6Months = () => {
  const arr=[]; const now=new Date();
  for(let i=5;i>=0;i--){
    const d=new Date(now.getFullYear(), now.getMonth()-i, 1);
    arr.push(d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0'));
  }
  return arr;
};

const currentYM = () => todayISO().slice(0,7);

/* ================= تفقيط المبالغ بالعربية ================= */
const _ONES=['','واحد','اثنان','ثلاثة','أربعة','خمسة','ستة','سبعة','ثمانية','تسعة','عشرة','أحد عشر','اثنا عشر','ثلاثة عشر','أربعة عشر','خمسة عشر','ستة عشر','سبعة عشر','ثمانية عشر','تسعة عشر'];
const _TENS=['','عشرة','عشرون','ثلاثون','أربعون','خمسون','ستون','سبعون','ثمانون','تسعون'];
const _HUNDS=['','مائة','مائتان','ثلاثمائة','أربعمائة','خمسمائة','ستمائة','سبعمائة','ثمانمائة','تسعمائة'];
function _threeWords(n){
  n = Math.floor(n); const parts=[];
  const h=Math.floor(n/100), r=n%100;
  if(h) parts.push(_HUNDS[h]);
  if(r){
    if(r<20) parts.push(_ONES[r]);
    else{ const o=r%10, t=Math.floor(r/10); parts.push(o?(_ONES[o]+' و'+_TENS[t]):_TENS[t]); }
  }
  return parts.join(' و');
}
function _scaleWords(n, one, two, few, many){
  if(n===0) return '';
  if(n===1) return one;
  if(n===2) return two;
  if(n<=10) return _threeWords(n)+' '+few;
  return _threeWords(n)+' '+many;
}
function numToArabic(n){
  n = Math.floor(Math.abs(n));
  if(n===0) return 'صفر';
  const parts=[];
  const mil=Math.floor(n/1000000), th=Math.floor((n%1000000)/1000), rest=n%1000;
  if(mil) parts.push(_scaleWords(mil,'مليون','مليونان','ملايين','مليوناً'));
  if(th) parts.push(_scaleWords(th,'ألف','ألفان','آلاف','ألفاً'));
  if(rest) parts.push(_threeWords(rest));
  return parts.join(' و');
}
function tafqeetEn(amount){
  const ones=['zero','one','two','three','four','five','six','seven','eight','nine','ten','eleven','twelve','thirteen','fourteen','fifteen','sixteen','seventeen','eighteen','nineteen'];
  const tens=['','','twenty','thirty','forty','fifty','sixty','seventy','eighty','ninety'];
  const w=(n)=>{
    n=Math.floor(n);
    if(n<20) return ones[n];
    if(n<100) return tens[Math.floor(n/10)]+(n%10?'-'+ones[n%10]:'');
    if(n<1000) return ones[Math.floor(n/100)]+' hundred'+(n%100?' '+w(n%100):'');
    if(n<1000000) return w(Math.floor(n/1000))+' thousand'+(n%1000?' '+w(n%1000):'');
    return w(Math.floor(n/1000000))+' million'+(n%1000000?' '+w(n%1000000):'');
  };
  const dh=Math.floor(amount);
  const fl=Math.round((amount-dh)*100);
  const cap=(s)=>s.charAt(0).toUpperCase()+s.slice(1);
  let s='AED '+cap(w(dh))+(dh===1?' dirham':' dirhams');
  if(fl>0) s+=' and '+w(fl)+(fl===1?' fils':' fils');
  return s+' only';
}
function tafqeet(amount){
  const dirhams=Math.floor(amount);
  const fils=Math.round((amount-dirhams)*100);
  let s = numToArabic(dirhams)+' درهم';
  if(fils>0) s += ' و'+numToArabic(fils)+' فلساً';
  return s+' لا غير';
}



/* ================= الدفعات الجزئية ================= */
const collectedOf = (p)=> isArchived(p) ? 0 : (p.status==='مدفوعة' ? (p.amount||0) : (p.status==='مدفوعة جزئياً' ? (p.collectedAmount||0) : 0));
// الدفعة الملغاة (فسخ عقد): لا تُحتسب كذمة مستحقة ولا كإيراد — تبقى للتوثيق فقط
const remainderOf = (p)=> (isArchived(p) || p.status==='ملغاة') ? 0 : Math.max(0, (p.amount||0) - collectedOf(p));
// المبلغ المفوتر الصافي: صفر للمؤرشفة والملغاة (شيك مرتجع / فسخ عقد) — تُستثنى من كل التقارير المالية والضريبية
const billedOf = (p)=> (isArchived(p) || p.status==='ملغاة') ? 0 : (p.amount||0);
const billedVatOf = (p)=> billedOf(p) * vatRateOf(p);
/* --- العقد الشامل: قيمة التصميم + قيمة الإشراف معاً --- */
const isComboContract = (c)=> ((c&&c.type)||'').indexOf('شامل')>-1;
const contractSupTotal = (c)=> (c.supervisionMonthly||0)*(c.supervisionMonths||0);
const contractTotalOf = (c)=> c.type==='إشراف' ? contractSupTotal(c)
  : isComboContract(c) ? (c.designValue||0) + contractSupTotal(c)
  : (c.value||0);
const isConsultancy = (c)=> !c.category || c.category==='خدمات استشارية';
const contractCommission = (c)=>{
  if(!c || c.category==='خدمات استشارية' || !c.category) return 0;
  if(c.commissionType==='نسبة %') return (c.value||0)*(c.commissionPct||0)/100;
  if(c.commissionType==='مبلغ ثابت') return (c.commissionAmount||0);
  return 0;
};
const contractHasSupervision = (c)=> (c.type==='إشراف' || isComboContract(c)) && (c.supervisionMonthly||0)>0;
const projectReadyForSupervision = (p)=>{
  const t = (p&&p.timeline) || {};
  return (t.permit && t.permit.status==='مكتملة') || (t.supervision && t.supervision.status!=='لم تبدأ');
};
const daysSince = (d)=> d ? Math.floor((new Date() - new Date(d))/86400000) : null;

const safeAttachmentUrl=value=>{const s=String(value||'').trim();return /^https?:\/\//i.test(s)||/^data:(?:image\/(?:png|jpeg|webp)|application\/pdf);base64,[a-z0-9+/=\s]+$/i.test(s)?s:'#';};
const ENTITY_AR = {projects:'مشروع', contracts:'عقد', payments:'دفعة', govFees:'رسم حكومي', officeExpenses:'مصروف مكتب', projectCosts:'تكلفة مشروع', treasury:'حركة خزينة', otherIncome:'إيراد آخر', employees:'موظف', overtime:'أوفرتايم', advances:'سلفة', leaves:'إجازة', timesheets:'ساعة عمل', cars:'سيارة', decisions:'قرار', settings:'الإعدادات'};
/* ================= الضوابط المالية: Soft Delete + Immutable Documents ================= */
const isArchived = (r)=> r && (r.archived===true || r.cancelled===true);
const paymentIssued = (p)=> p && (p.invoiceNo || p.receiptNo);
const FINANCIAL_BUNDLE_RULES={"officeExpenses":{"fields":["amount","date","account","bankName","bankRef","vatable","payStatus","kind","month","category","vendor","vendorInvoiceNo","attachment","attachment_name","note","chequeNo","chequeDueDate"],"numbers":["amount"]},"projectCosts":{"fields":["projectId","amount","date","account","bankName","vatable","category","chequeNo","chequeDueDate","payStatus"],"numbers":["amount"]},"treasury":{"fields":["amount","date","type","account","toAccount","kind","month"],"numbers":["amount"]},"otherIncome":{"fields":["amount","category","vatable","account","date","payer","note"],"numbers":["amount"]},"advances":{"fields":["employeeId","type","mode","amount","monthlyInstallment","startMonth","date"],"numbers":["amount","monthlyInstallment"]},"govFees":{"fields":["projectId","amount","date","account","payerType","paidStatus","reimburseStatus","receiptNo","department","description","descriptionEn","note"],"numbers":["amount"]},"employees":{"fields":["baseSalary","grossSalary","hireDate"],"numbers":["baseSalary","grossSalary"]},"overtime":{"fields":["employeeId","hours","rate","date"],"numbers":["hours","rate"]},"leaves":{"fields":["employeeId","type","fromDate","toDate","days"],"numbers":["days"]},"recurringBills":{"fields":["amount","frequency","account","bankName","nextDueDate","active"],"numbers":["amount"]}};
function financialBundleControl(key,before,after,kind='update',context={}){
 if(key==='attendance'){
  if(kind==='delete')return {error:'لا يُحذف سجل الحضور نهائيًا.'};
  const paid=new Set([...(context.officeExpenses||[]),...(context.treasury||[])].filter(x=>x.kind==='رواتب'||x.kind==='دفعة راتب').map(x=>x.month));
  const dates=new Set([...Object.keys(before?.map||{}),...Object.keys(after?.map||{})]);
  return {correction:[...dates].some(day=>before?.map?.[day]!==after?.map?.[day]&&paid.has(day.slice(0,7)))};
 }
 const spec=FINANCIAL_BUNDLE_RULES[key];if(!spec)return {correction:false};
 if(kind==='delete')return {error:'لا يمكن حذف هذا السجل نهائيًا. الأرشفة لا تلغي أثر حركة مالية فعلية.'};
 const changed=k=>JSON.stringify(before?.[k])!==JSON.stringify(after?.[k]);
 const archived=r=>r?.archived===true||r?.cancelled===true;
 const posted=r=>!r?false:key==='officeExpenses'?r.payStatus!=='معلق':key==='govFees'?(r.paidStatus==='مدفوع'||r.reimburseStatus==='مسترد'||!!r.receiptNo):true;
 if(!after)return {error:'السجل غير موجود.'};
 for(const field of spec.fields.filter(f=>!spec.numbers.includes(f)))if(after[field]!=null&&typeof after[field]!=='string')return {error:'قيمة نصية غير صالحة: '+field};
 const required=spec.numbers.filter(f=>!['grossSalary','monthlyInstallment'].includes(f));
 if(required.some(f=>typeof after[f]!=='number'))return {error:'بيانات رقمية مطلوبة مفقودة.'};
 for(const field of spec.numbers){const v=after[field];if(v!==undefined&&(typeof v!=='number'||!Number.isFinite(v)))return {error:'قيمة رقمية غير صالحة: '+field};}
 if(['treasury','advances','govFees','recurringBills','otherIncome'].includes(key)&&(typeof after.amount!=='number'||after.amount<0))return {error:'أدخل مبلغًا غير سالب.'};
 if(['officeExpenses','projectCosts'].includes(key)&&typeof after.amount!=='number')return {error:'مبلغ المصروف مطلوب.'};
 if(['employees','overtime','leaves'].includes(key)&&spec.numbers.some(f=>typeof after[f]==='number'&&after[f]<0))return {error:'هذه القيمة لا تقبل رقمًا سالبًا.'};
 if(key==='advances'&&after.mode==='مقسّط'&&(!(after.monthlyInstallment>0)||after.monthlyInstallment>after.amount))return {error:'القسط يجب أن يكون موجبًا ولا يتجاوز إجمالي السلفة.'};
 if(key==='treasury'&&(!['قبض','صرف','تحويل'].includes(after.type)||!['البنك','الخزينة'].includes(after.account)||(after.type==='تحويل'&&(!['البنك','الخزينة'].includes(after.toAccount)||after.toAccount===after.account))))return {error:'راجع نوع الحركة وحسابَي التحويل؛ لا يمكن التحويل إلى الحساب نفسه.'};
 if(['archived','cancelled'].some(f=>after[f]!==undefined&&typeof after[f]!=='boolean'))return {error:'علامة الأرشفة غير صالحة.'};
 if(!archived(before)&&archived(after)&&posted(before||after)&&!['employees','recurringBills'].includes(key))return {error:'لا يمكن إلغاء الأثر المالي بالأرشفة. يلزم تصحيح موثق أو حركة مالية مستقلة.'};
 const needs=!!before&&((spec.fields.some(changed)&&posted(before))||archived(before)!==archived(after));
 if(!before&&archived(after))return {error:'لا يمكن إنشاء سجل مؤرشف.'};
 return {correction:needs||(!before&&['officeExpenses','projectCosts'].includes(key)&&after.amount<0),engineerAllowed:key==='govFees'&&!posted(before)&&!posted(after)};
}

function paymentControl(before,after,kind='update'){
  const archived=r=>r?.archived===true||r?.cancelled===true;
  const issued=r=>!!(r?.invoiceNo||r?.receiptNo);
  const net=r=>archived(r)?0:r?.status==='مدفوعة'?(r.amount||0):r?.status==='مدفوعة جزئياً'?(r.collectedAmount||0):0;
  const account=r=>r?.account||(r?.method==='نقداً'?'الخزينة':'البنك');
  const changed=k=>JSON.stringify(before?.[k])!==JSON.stringify(after?.[k]);
  if(kind==='delete')return {error:'لا يُسمح بحذف الدفعات نهائيًا. استخدم الأرشفة للدفعة غير المحصلة بسبب مسجل.'};
  if(!after||typeof after.amount!=='number'||!Number.isFinite(after.amount)||after.amount<0)return {error:'مبلغ الدفعة غير صالح.'};
  if(!['مدفوعة','مدفوعة جزئياً','معلقة','متأخرة','ملغاة'].includes(after.status))return {error:'حالة الدفعة غير صالحة.'};
  // الدفعة الملغاة (فسخ عقد) لا يجوز أن تكون محصّلة
  if(after.status==='ملغاة'&&net(after)>0)return {error:'لا يمكن إلغاء دفعة محصّلة. الإلغاء للدفعات غير المحصّلة بسبب فسخ العقد فقط.'};
  if(after.status==='مدفوعة جزئياً'&&(typeof after.collectedAmount!=='number'||!Number.isFinite(after.collectedAmount)||after.collectedAmount<=0||after.collectedAmount>after.amount))return {error:'التحصيل الجزئي يجب أن يكون موجبًا ولا يتجاوز قيمة الدفعة.'};
  if(['archived','cancelled'].some(k=>after[k]!==undefined&&typeof after[k]!=='boolean'))return {error:'علامة الأرشفة أو الإلغاء غير صالحة.'};
  const oldNet=net(before),newNet=net(after),archiveChanged=archived(before)!==archived(after);
  if(archived(after)&&(oldNet>0||newNet>0||(['مدفوعة','مدفوعة جزئياً'].includes(after.status)&&((after.status==='مدفوعة'?after.amount:after.collectedAmount)>0))))return {error:'لا يمكن أرشفة أو إلغاء دفعة محصلة. القبض الفعلي يحتاج مسارًا ماليًا مستقلًا، وليس إخفاء الدفعة.'};
  if(newNet>0&&(!before||oldNet===0)&&(!after.paidDate||!['نقداً','شيك','تحويل بنكي','بطاقة'].includes(after.method)||!['البنك','الخزينة'].includes(account(after))))return {error:'أكمل تاريخ الاستلام وطريقة الدفع وحساب القبض.'};
  if(after.receiptNo&&before?.receiptNo!==after.receiptNo&&newNet<=0)return {error:'لا يمكن إصدار سند قبض لدفعة غير محصلة.'};
  if(!before){if(archived(after))return {error:'أنشئ الدفعة كمسودة نشطة أولًا.'};return {correction:false,oldNet:0,newNet};}
  const structure=['projectId','contractId','phase','taxable','amount','label','month','date','dueDate'];
  const structural=(issued(before)||oldNet>0)&&structure.some(changed);
  const documents=['invoiceNo','receiptNo'].some(k=>before[k]&&changed(k))||(before.docSnapshot&&changed('docSnapshot'));
  const normalIncrease=newNet>oldNet&&after.amount===before.amount&&after.taxable===before.taxable&&account(before)===account(after)&&(before.method||'')===(after.method||'');
  const collection=oldNet>0&&(['status','collectedAmount','paidDate','method','refNo'].some(changed)||account(before)!==account(after))&&!normalIncrease;
  return {correction:!!(archiveChanged||structural||documents||collection),oldNet,newNet,archiveChanged};
}

const protectedFromHardDelete = (entity, r)=> {
  if(FINANCIAL_BUNDLE_RULES[entity])return true;
  if(entity==='projects' || entity==='contracts') return true;
  if(entity==='payments') return true;
  if(entity==='govFees' && r && (r.receiptNo || r.paidStatus==='مدفوع')) return true;
  return false;
};

const vatRateOf = (p)=> (p.taxable==='غير خاضعة') ? 0 : 0.05;
const grossFactor = (p)=> 1 + vatRateOf(p);
const expVatRate = (e)=> e.vatable==='غير خاضع' ? 0 : 0.05;
const expGross = (e)=> (e.amount||0) * (1 + expVatRate(e));
/* ==== الإيرادات الأخرى (غير التشغيلية): نفس منطق الخضوع للضريبة ==== */
const incVatRate = (r)=> r.vatable==='غير خاضع' ? 0 : 0.05;
const incGross = (r)=> (r.amount||0) * (1 + incVatRate(r));   // المبلغ شامل الضريبة (ما يدخل الحساب فعلاً)
const incVat = (r)=> (r.amount||0) * incVatRate(r);
/* ==== الدين علينا: أي مصروف مدفوع من بنك غير WIO NITAQ يُعتبر ديناً على المكتب ==== */
const OWN_BANK = 'WIO NITAQ';
const isDebtExpense = (e)=>{
  if(!e || e.account==='الخزينة') return false;            // نقدي = فلوس المكتب، مش دين
  if(e.payStatus==='معلق') return false;                   // معلق لسه ماتدفعش → مش دين
  const bn = (e.bankName||'').trim().toUpperCase();
  if(!bn) return false;                                     // بنك غير محدد → لا يُحتسب دين
  return bn !== OWN_BANK.toUpperCase();                     // مدفوع من بنك غير WIO NITAQ = دين علينا
};
const expDebt = (e)=> isDebtExpense(e) ? expGross(e) : 0;   // شامل الضريبة = ما خرج فعلاً (مطابق للخزينة)
/* المدفوع من حساب المكتب نفسه WIO NITAQ */
const isOwnBankPaid = (e)=> e && e.payStatus!=='معلق' && (e.bankName||'').trim().toUpperCase()===OWN_BANK.toUpperCase();
const expOwnBank = (e)=> isOwnBankPaid(e) ? expGross(e) : 0; // شامل الضريبة

/* ================= بيانات الشركة الرسمية (شهادة التسجيل الضريبي) ================= */
const COMPANY = {
  nameAr:'نطاق للاستشارات الهندسية ذ.م.م.ش.ش.و',
  nameEn:'NITAQ ENGINEERING CONSULTANCY L.L.C. SP',
  trn:'105454200400003',
  license:'940231',
  address:'Showroom No. 03, Industrial Area 18, Sharjah, UAE',
  phone:'+971 56 629 9449',
  phone2:'+971 54 524 6000',
  email:'INFO@NITAQ.AE',
  tagline:'نصنع الحيز ليبقى الأثر',
  vatRegDate:'2026-07-01', // تاريخ التسجيل الفعلي حسب شهادة الهيئة الاتحادية للضرائب (Effective Registration Date)
};

const NITAQ_LOGO = 'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAaQAAAG9CAYAAABalQJmAACIb0lEQVR42u2dd7hsRbH2fzUz++TDIWckSDZhBhOoKBivgmJO1xwxi/qZc8YsRlQwJwxgBERURLwkkSQ55wMnnz0z9f3R1ew+iwlrZq81adf7PPPMDjNr9equrrequroaHA7HBlDVmr0frKqH2s8V7xmHw+FwDJKMqva+h6quUtXP2O9TY/QMEknV4XA4HONJRhVT5lur6rkacJmqbmN/r4zBM0irnx0Oh8MxXl6F2M9/NDJab+/3i4Q16oRq7zup6kd9VB0Oh2M8CSmuG30tIaOGqjZV9aH2v+qIe3cVVV2iqifZMxww6u12OBwOR2syeosp8ml7b9j7waOs2NM1I1X9kbW5rqrfTp/P4XA4HONBRgebVzRtXlFKSE8ecUKKz/Bha+9ae/+tryM5HA7HeJBRzKi7h6reliGh9OenjCohJWT0ksQzqtvPF6nqRtGL8hF3jDrclXfMVTKqiEhDVbcFTgA2BppAZYyeoSoidVV9FPDlFu1fCMzz0XaMC3yzn2MukpGEN10EHAvsADQ6zIfGiJJRQ1X3BH6YGJepJzS/zd8dDickh2NEyCiG3r4BHADUk7+1/NqIenebAr8ANm9DqDWf4w4nJIdjhMlIROrA54FnAtOMUeg62Wu0yMhoDyOjVoTqXpHDCcnhGGUysk2jrzYyylMSSEfoGdSI5lvAw7t4d05IDickh2OEyeh9wNtMkeetTycj8AwVEVGbs98ADrNnqHVpt5OSY2zgWXaOuUBGNRGZVtV3Ae+m+5rRSBGSkVHT0s6/DTyHEKbz+etwQnI4xknGEzJ6fw6voiUnjAAZTREyAp/e5zM4HE5IDscQPaOqkdF7gffQfvF/JD2khIxievpTnIwcTkgOx/iRUcXWjD4BvHmWilyG8Axxn9FGwE+Ax/TxDBV8DcnhhORwDI2MKgCmzD8NvGHcvIqEjDYGfgM8pM9n8KQGhxOSwzEsMrIQV01Vvwm8oCAyag7wGWrm2W0O/AHYZxbP4GTkcEJyOIZARmJktClhveVg8u8zGglCSmrT3R04Hth9loTqITvHWMH3ITkmgozsfXPgOCOjXvYZdb3FgDyjhqo+yDyj3Zl9areTkcMJyeEYAoSwR+dhFL9mVJqHZIfrTZlndJiR0c70nxHoHpLDCcnhGBoThQoGVSOjZgGKPItSqn0n2YDTqvoaQtXujQp4Bknmt89xhxOSwzEErC5JpuslkFElcKk0bNPu5434tMBncA/JMVbwpAaHG1g5+KNozyiWAlLVLwOvYOb4iCIJxNO+HU5IDoejPRnZ+7aEit2PZeYIjDLIwwnJ4YTkcDhaE4R5R8cSDgcsKjXd4Rh7+BqSY1LQBFZER6SEaxfmJNn7NpSTgEFJfeBwOCE5HDndjgZw+xg1uV7y/PNQncMJyeEYNOK6DHC1ewfuITmckByOoTpI9n7FGCjj2NZ1A76fw+GE5HAMUOneMkbeRsOHzeFwQnJMLiHdWjIhFUlM63zYHA4nJMfkYk2JHk3RWDlGbXU4nJAcjj49pXHAch8uh8MJyTG5mB4jYlrlw+VwOCE5Jg8x7HWDvVcZ/VDYygHdx6tAOJyQHI4hENJV5nmMsocU27Z2QPdb6OLhcEJyOAZPSLcyPskCgyIk95AcTkgOxxCwgvFJpx4UIc1zsXA4ITkcA4KdGAshXLd2TJq9ekCeXNMlxOGE5HAMEPHQO0o43bUkDCrLrurS4XBCcjgmyAkr4ZprBtT2+SU+g8PhhORwTADKJqQYClzsXe1wQnI4hoMy1kyKXOcZdNr3fBcJhxOSwzFYSImeRzVzj3FCzUXD4YTkcAwHd5Tg1Yyzl+H7kBxOSA7HkFDGERTjXO1ggYuEwwnJ4RgObi/hmtuPcX/4GpLDCcnhGDDi+s6KAq8Zw37bjHG/+D4khxOSwzEkrCjhmkWW34kkV3YFhXgfD9k5nJAcjiGhjAoI8zJeWBEY1NlNGw3oPg6HE5LDkcH6jIdQBMpInW4OiCj8+AmHE5LDMSRMl3DNWontLJuQPGTncEJyOIbsIY36PFkLNIyQyqz47cdPOJyQHI4hoYxq30V6MZF81lHu2U3qhORwQnI4Js9DKiOstpbBHCboITuHE5LDMUEeUhkhtdRDUp/jDocLq8MJaVjXnGYwhwn6HHc4ITkcQ4KO+DU1IblBEpK6aDickBwOJ6R2HtJ0if0Q17282rfDCcnhcJLriHrJhBQRs+yaqurVGhxOSA7HmJNHGViXEFKZba4CiIiH7BxOSA6H464QkTrlpKhn4SE7hxOSwzFJ/FEgEamqVhIvqXRCUlUnJYcTksMxBJQRmpKS5l2ZHlKa1OCE5HBCcjjcQxo6pvBD+hxOSA7HxHhI45wQMB+vZ+dwQnI4JoaQxhk1ZkJ2nvbtcEJyOAaIpnfBBvCQncMJyeEYMMQ9pJb9MQ9PanA4ITkcQ4GvId3VQ6q5WDickBwORycMonSQE5LDCcnhcHTFIKp9pyE7T2pwOCE5HI6WGETpoCq+huRwQnI4HG2gAyAkYSbj0AnJ4YTkcAxR2Y/6NaH8NaTYbl9DcjghORxDIKJ64iGMOiGtGVDf+NqRwwnJ4RgCxmlj7NoB3cc3xjqckByOIXpKTkhOSA4nJIdjqBin8NSqAd3H15AcTkgOh8t0RwxqDWm+i4XDJ6/D4R7SKBCSp307nJAcjiHA15DuCl9DcjghORxDQLPEaxZNdqsG5NUtcLFwOCE5HMPzkIpU8mWlkq8eUJ8scrFwOCE5HJPhIZWFQRGSe0gOJySHY4ge0qhfc5CE5Fl2Dickh8PREYPKsnMPyeGE5HAM0UMah1p2DSckh8MJyeGYS/CQncMJyeEYAU/JAUu8CxxOSA6Hk9sowEN2Dickh2NC0Bjz9jshOZyQHI4hoIyqB0UTUvS4miW2OYWvITmckBwOR0dMD4iQ5nlXO5yQHI7JQFlrSPWElMpcp3IPyeGE5HBMEHmUgWZCSGXC15AcTkgOhyO3h1Qm/MRYhxOSwzEkrwOKXZcpa42nDqzzIXM4nJAckwlt8/MoEtJ0QkhlhhrFxcLhhORwTAaKVujagpDKRC3jPTocTkgOx5hifknE1CSE7RwOhxOSYwJRRuhrqqS2Nim3CoSkHpKIeH0/hxOSwzFAlLFeUtbG0vqAPKSaqk4BqKqvJzmckByOMUZZG0vTkF2Z3ksVT/12OCE5HO51dfGQBpHU4ITkcEJyOIYAHYdrqqqISANYPYA+qeH17BxOSA7HwDGoCtr9u1shuSDOvRUlEmnElBOSwwnJ4Rg8GozHfps49wbhIaWE5EkNDickh2OAhDROB+qVSZ6RfKqUl7rucDghORwZaOJxrCn42tUJmOc+1x1OSA7HgLHSXilJFeVpjCvcQ3I4ITkcQ/CQ1pTgIY075lFe+SOHwwnJ4WiDO0rwkMYdVcY/7OhwQnI4xshFCnt76sD6kryvcSYkT/t2OCE5HINApnBo0Vl2ZRLSIGrZCb6G5HBCcjgGy0v2Pg77kCLJrR/QfZyQHE5IDscQlf04YLpkgnZCcjghORwj4CmNA9aV3OZISLUx7BuHE5LDMfae0ThllK0eUJ94tW+HE5LDMRAmChl2OoZyPV121zghOZyQHA6X6zxYP6D7eKjO4RPX4XB0xNqSCSNed753tcMJyeEYf5SRRp6WOhoEPMvO4YTkcAwBOuLXS7FuQH0yNYBncTickBwOCIkNY6h0V9l72Ws8i1xCHE5IDscAkCkdVHSIrUyyGFTIzmvZOZyQHI5J4LsSr712QM+w0IfR4YTkcDghtUJ6wm2ZpCcZQvI1JIcTksPhaInVA7qPZ9k5nJAcDkdH3D4gr2WBd7XDCcnhcLRCevzEIAjJkxocTkgOxwSRh891h8OFdI5pP1VR1UoB16kke3OcQOY2IXnIzuGE5OgdIqIi0jRCqcziOs1ITE5IsxuSCfDAlk4QuTqckBwD8oxEVadUdQ8RaRoxVfu83q4JuVXngLc0jpUalHKPXI994mtIDickR69OjSjwbeACVT1WVfcWkUbe8FskL1U9BLhYVY9X1YeISENEdI54S80Rv16WkBoDIFIP2TmckBy5vZmKeTI7Ak815fRs4F+q+jLzlrQHb+n59v444K+q+mFVXWj3mPTD2sbNQ2oM4D7uITmckBz5vSPzgJ5l1mwDqNvPR6nqT1V1E/OWaq28JfN+mqq6K7C/Kbtpe3878CdVvYeI1C2EN2njP44huwaDqfi9wFxwX0NyOCE5OnpHEkNqwHOTsYmeTB04BDhZVfcTkXpCQBsoZLvGk4CNTdlNmaKuA/sBp6nqy+1+zXbk5hgYppmp+F06ITkcTkiOXOOgqgcCe5uFn45NzQjl3kZKb0iSFVJCaarqPOB/W4xvzQhqCfAVVf2uqt5NROo9hgLHguNL8rzK8pDWDsCzq/o0czghle9dVE0pVyxDrTaOytVI5fmm/FqtKdQIi+vzgE+r6h9V9e4Jocy38XwEcA/7bKWFUlIjt+cC/1TVl6hqNUmcmAQjRcdongwqZOeE5HBCKlGBVywRoGFKuWleQ92Uq4wDMcVwHbAJ8D8J+bQbr0gojwbOtGSFrURknV3nDUZq2sHaj97SlsDXgBNV9eA0zXzMw3i+htTCoJmD+9EcY4axzLYyJR43fT4e2NO8ggpwHnCOiPweaETrf4Qfp2oEcxiwURvPph2hLCUkK7xSVT8OXEfIqtMcFnH0ltS8qkeo6veAj4rIudH7HPG+mwQ0Gdwx5r5W6HAU7RnZ+7aqepy2x19U9aH22dqIPouYNzKlqn+ydtc1P5qqOq2zRyP5eYWqfkxVd4htHCPZiHuwTuyjL1shfv87RctR7FeTgZMKam+nsb1aVReO25g65hYqRUyqQSrw8KbbAScCTzYLc9o8hgYzac4PA06xjLL6iIbvKuaB7AMcYM/SSzujtxT3sjRnKQcx6eGtwOmq+qox20w7dmnflhU5PYA+mWdj63BMFiGZVV+NexoGkUhgZBRfXwP2sIlcIaQ2V+0V05xjqOkrqnqYrSuN6prS25hZH+pX6VSZ/ZpgmvSwNfBFVd0/1tXz6VIa1g+IrD2xwTE5hBQz2SyRoJFYeWkiQVmKq2LrRi8mrJNM0/kUzGpiLR9lXtXIKFYjx6aqPhB4ohHoKLQtel1Na9OCjKXtKMgzSiIMawc012ve845RRm4BTRe4VfVQ4CGEUNNK4N/AX0Tkt+HfxS6GJ6G6ZcA7yLdoHydhnbBJ9HAReWskgtHQSaKq+mFgvin/UVH6cR/UNcBfrbFzObmhLHmJ2ZDrkn4vk5DmZe7rcIwfIcX0alW9F/BF4OGZjzzZPncS8EYROatgUor3fyGwkynvvOGHGIZ6vqp+TERuMS9vaBNSVWu2rvVO4EAjzVGyXhvWnj+KyMpYZ8+nS2kY1D4k95AcZeq1WevVSs6bNFX1YLOWH85MnbVm8rMCjyQU8nx5kWs2dq35wOsTC69XK3Qr4IF9fL/oQasaGf0v8EHrw1FTFLF/fp1XTiZ9rpXcz9MDeIbUQ3I4itZrlSISoCo5b7IH8GPCvpdGYm1Vkp9jIsEiQiLB4bEQ6GwVuP341MQ7qvShUBR42jAVbOJpPomQmNFk9NZmYqbfVcDvE49pLkNKvu6aAUVDvJ6doxxBDk7LvNmc39ZRMWdSuj9KSBmt0zlUVk28piMtu222KdcxVPTKWVq4Amw+THc2vGmsjlAZtrfWxRv4uYjckWZTzmGUZcBkCanMfp4yY3EUZc4xvp5R3Pv3cuAv8ey1fsuQdfpCPJ/nQczs98mbSCD2+a/YcQd9he8SD20f4KEJ6UWiajJz4mYjx4Qe5kSsmGL/H0L4cFSy6loRd9M8YscQPeoSnsFDdo5Cych0+0HAV4AHASdZdKzZz9lr3UrUQKgcXUmUVd7rKqE+289UdWPzDnolhPj5lzNTYicqzkpCfjF02K4waVxHumKYXq29b5cQ6qh5HrFs0VmEjbEVRiMjcVS8xnFv/1IfSkexnKRThLVwCPvp5hGiY8cnZ6/l9pYqbe4ihDpwSwkVD/rxLiKB7A581rK0Kj08qRj7pkVHqwkxXkE4UfVehPWl4zOfiR6TJt/5fqJ4B8tGYWAE+DDwWWY28I6iwv++iKxPvLq5jnHeUJqmeC8cgUiBY0K8I5Org4H7m66PHniDsFf0NFV9deotdXNK2hFEVES7ECoi9CvEsQjo81X18T2G7mLbHglskyGXG4BHisj3ReTfIvILEXkC4QC6XzOzKz1WdqgBRxOOW6gOK4XZqpGvF5HXA68BVjCzV2oUrOgKcDvww2ER94hi8YR4SPN9KB1FRVOMI16a6NnUgItlyL6gqr9S1d3ynL3WzWOZopiUZAU+YIfH9Rq6ezYz60RRaX5SRC5T1XnmDsZSRqeJyJMIe3u+C9wI3AH8CHg1s6v3VpRlIdbWLxqBnpcQt86yj2eTDRc35v5aRK4aJnGPoCIve+2lOaDnWOR61FGEDjNi2Y5wUkArLknLkD3RnIE3qOpUp6SHboRUhGsfG3Y/4Jl5QndJevT2wKOSdlSBm4Dv28PEc5Aa0fsyRfonEXk+4ViK+4rIM0RkdfRShho/CV5SwzbHnkcoqvpTOq+B5VE4aa2yRp/jBPA5n3JtFXrZ15eSrz9V8n0ccwPRSXk8sMxIR9rwRzS2lwGfJhS8PigJ421wbl2liwDfANxc4KR4m5XAb3bxksT+/2hCYkSqYP8hItcE3b6hBZ8hpoqI3CYil9pDyyith8R0eBG5WUSeBhxOKMMU197ytjXuZXov8P+Y2SfW7MHyjt7RL0Xk9GgQ+LwbXPhjQPfx4qqOIhCXGJ6S08BJ1/X3BX6rqj9Q1X0TA72iqlJpoyybpiyvBP5SQDgoZt3tDTzfiKGTl6T2mee0UMzHdQv5GTFF9q3YQ4/c4nxakFZEPkdIIDmVDTcad1NkFSPp94nIhwgLjL9gJguxG7lF72oaeJdb0EPBoMh/akAen2NSQwUbFkt4bA+GjiSGMsAzgD+r6m9V9cB44nclh5v/eWYydYoQ5Deo6uJ2XlKsm6aquxHy2uPDVAgbCE80cunaFiOikV4HiW20EN7ZhBDeW4HlzCwONtuMT4zRvsX6br6InC0iTyWcQHtpDnKLpPYtETnHvaOhWpzuITlGHZEzXmi6pd7n9xuEtdmDgD+o6vdUdctKB0UZS0CcTMhQm2LmEDxNlGK6QbVbQxqErL1ndPCSIkkdTIg7NhIr/izgmlj1YJJGOebrE7JXPgE8GPg5M+ccNVoQSRX4noj8xTzadTHJQ0R+bN7S+43IW60vxX69lZB04p7RgA3OAXks6SF9Dke/3lHcDrQEOCRDMP0YRzHyVgeeBRzV7WJxfeLlhEy1GjOL76nnUkn+1sgxCd/UwUuK3sDzWzzwqSKyDpjIcjbRmzNCuUhEDgEOBc5kwwoV8UC35cA7jMg0XiOuo4nIchF5D6HKxU8yVnKDUGW6AnxCRK5m5swpx3A8pLINgnkDIkDHhHpHpncPJewv7WlvaRtDKU3muqXSLZxEWM9ZLyLPMBY7xizqOiHj7WLgbODKROE1u7Di3sCzsl5SUhfpocB9Egs+fuYXkz6hsot8IvIzQujyI4SD3GIJmCrwvk4JHkmK+Zki8nRCzPenzJwntQA4DfjcCJ0TVaTnMS4YVIjUPSTHbLwjzJF4S8FzLOqji3tukP28hapuq6qbqeoSVV2oqhur6m6qerQGNFS1qXdFw97Pt+9J8rAVe/+cfWY6ucY1qrpRti1zQBBqyc87q+orVfUYVT0ib19Eckt+30tVP6Oq31XV3dO+n4S+UtVfm8zUdXaYtvfjs2NRcHsPL6i93Z7j86nh53D0IasvK1hWo35fq6qP67VR1TyKS1WPyEyEdqT07OS6kZSWqOr1SWPjNY4p+Yj0kbZOWimRXok57efZXGeE+yl62MeOGSG9KDMvyiKkb0yK8eEY6LyKjsJSVb3U5LQoWY3XuUpVqz0JZiadutWrYtliHyUcsVDrEAZS4PCkgGd67tFWzKxfRWV5hoX45px1lwnjVVV1qp9jIWz8NI6TXWcS69UtH7PQ4so4RGWJkL0vyNzX4cgTGYtFVL8H7MxMxZyi5oCafm/0ddG4r6fFq0lIVKgBbwYuoXUB0XjfBwH7ZxTiMzKTpkrYI/NH+33OpiQnVSmmZ5Oabdep23UmMYnh9jFr76qEOMoki0Vx/rqqdeQko7iGfzyhBFCjYKcg5gn8FEo458UUnIrIHUZK7SZZTOd+oy3e11V1Z0J1hkhEUVn+m1DzDc8Cc0wQIaUe0iBIwmvZOXpBrGf5EkJ90G4HtPYj/zVCktyfSyEkQ6z08AvgBGY2eG7wsPYey5dDqMywIPlsJJ9fd6sS63AkWD5m7V1BuZtjsyE7fM+Zo5t3ZE7CEuAIk8+i+SLuXz01FnQuhZAylRTeRQi5VTJWYAzl1Qjp5AAvyIQuopf0NxcRRw+4OaOIx8GjG0S1hsVu1Dl6IKW4vn8b/VVlyGMoCXBUNJBKy7ZJ6uH9CziO1mtJUWE8SlUPA3ZlZsEsxhavIlSLwEvatLdmYiaeJSvEhIVa5vf4t2qabj+BGMeQ3SAIaSlePsiR36nATkn4H+CfhH1ssz0mJyIWdL4YOCV6TJUBTbgPJS5f+jDx/vchnF+UHpMeP/cnEVnrqaotSaiWFo+1hId6krBQz/we/9aI30mvM0Hds3IM2zuIkN0iJyRHj06FiMhVhLX9o5ndMTmt5PIoEVmJVd+pDeCBKiJylqr+ipDS3SpLQ2i/i/x4s+QrzPETTNN+MAumbn+fIpxqen/gnmYJLyWsGcTqGGsJJYduA/5LKEd0o4isSa4jhPIg4+6Jri1YkZddcmdQWW8Ly4yKOCbTUzIdvgJ4kaqeBXyMcPpwvxl3MQp2A3B0rJEHxZwG2/WZ7IZfJZyfIR0amXpHVcJawOnWKXOWjDJE0bC/bUeolPsAYH9gO0Ix2rxYA9yqqv8ATgJOEJFLCMUTJ4WYisJim5yNUTtXq0fMZ+YICoejJ0/JdMJnVfUM4CjgHsyE3noxdBrGPd8RkVts72p9YA+UbJo9K+eO9LpVafi9fX/OhhnSZ7d+fLyq/lxVb+7Qd9MtXuvtvd6mpNNyK7nzhPTe47TOlFRq2Kegygex0sPpSSURKXJe2PsCVb0pU0qlSMRrrlLVrYt+Dsec0kexushiVf1SC52dRxabqrpaVXfIyuKg3PeYz/6VHkIUAvx4LntFlhQST8B9IfB/wG/M09yMmdLtMX0yepa1Fq8pNqzWHj8fr7EMeALwa1U9UVUfkVR2mOvrDrUBRBMaA3qOZcn8cjh69ZbiSderRORVwJOAcxK90u1A0FiB55sx1XvgEYckC2zLpE5dowuD3qaqd7Pvz6m4d8YreoKq/iNT+6legiXdtOvWk/scadV9x8JLTWpu3bsgbyPK6HlJP5ThIc1T1SsG4CE1VXXfuTinHOVEveznRar6xsTLb1dHMur221V1+1ZyOBChjMdMiMiNhBTwTl5SZNBTROTKeILsHPSKtrBimL8mlFiKnlCFDc+kKmyY7LpxE7MAhwP/UNX9oqc2Jl25PpGjIqyv+fYqY15gY3trD9GDfsY2vi9xD8lRhOwmW3tWi8ingfsBR9r8Sw/gI5FzAT4vIle30u3DsJKOThrWafL8fC5NnCR9u6GqTyFsBv5fU6xxEXBgIVZmUjvvAfxJVZ9vbauNwfpDnZlDDItASkhSwuRuAreULWL2vgyHozjZTc9du0pE3gA8EPhhYuTGjOAp4Hrgk+mhosMipKY14nTCJqtWuewxHfBWQjG/6DHNBTJqmuv7KSPjXa1/okc0DERvaSHwbVV9r2XDjPqm2gahOkhRmEdJ2WlJP64o0UNKsdDVqKMEbyklpnNE5JnAAcAfTNfXCJtgnyciyzMRgjtRG2SjTfE2VPWrwH4trM2Y134CcFMMX004GdVsoXAbQnn3A9gwQWHYiBZOE3iPqm4sIq+3RIvmiKZA1wsipCifU5SXLh3DircOwEOShJA8ZOcoXMcTto1U7Pc/A39W1b0ISVgXishNtnWipaNRG3CbYyOOA64h7J1Jz2WPoaIfGIFNumcUyWg34JfAnqZIBxmey6s0K6boD1fVVSLyTksBrY9g1xYdsltAUpi0hL4FuKlkDyled6mrTkfJxNQ0/VYhnPxwfqLzOuYEVAbcUDWv5zbuGpKLi9CXm5uX/m+SyWgf4EQjo4ZZ4qNovcZ4cB14h6q+2dpfG8G2NhOiLELBTyXGWxnJJBAqaAyCkDZ2D8kxaGKKexq7JagN0wr/fuIVpRPmOyKybij56YMjo6op8/sBvwO2p/iDr8ompU+o6jNHjJSivBS9hjSIfUgrBtRHi11VOgbphCQHi3bV58MgpMiQpwJnJQqkQjg58+iSLcVRIKOGqt7HyGjLMSGjlJRiXcGvq+qD4ma5EWpjkSE7zRhOZZNp2Vg6yfPLMd4YOCFZ2K4mItNGPnF3r5h3dJkp7YkL1yVJHbsDfwI2HzMyysrNYuAYVd3cnmtU1r3WEWr1FUG+DIiQBpW8s9mA7+dwjC4hZSbDdwiLufPNO/pEu/z0CSAjCW+6ESFHf7MxJaNUdhrAbsB37flGZV1iPTMVv2crS/H7tQG0mRL7MF53yxgO93p2DickNkgBv41QNXY18EERucz+P4nJDHFN7EvAPhR/Pv1Qnsme42DgDaNQzcGUbNNkaixsFXtfUfKcjOSzBeFcJIfDCWlD3aECfALYV0Q+micLY0y9o5jE8D7gOcykdk8E0RoBfERV7zHM0J0RfjweYs2Y9ePqZE6WWT5oC3wvksMJ6a7Kw153iMi5Y37OTDcyaqjq/sA7mSkDNCmIGzvnAV+2wwJlyO2B4kN2Zc+V2xnMqbEbU0JdPoejR71YaWW4VkagYRLruE1gpwuhZNLGwLHMbPydNMs0lhh6OPDyWPNuRAhp1I03TQhp7QD6p8LMXiSHYyh60VLBmyNHSDFPfVI9UCPaDxOqUtSZ3COk49rNe1V1Z5ISIkMipKJkSjPXLQurKXbvVKdn2crVomOIZKSquu0wD+ibix0fQ3UHAK80BVmb4EeOax+bAR+L6zkuCblJYs0ACWnzAZGsw7EBGREKM88n1Cs91aJHd5KSE1LJpAR8iJliqZOOGLp7uqo+dczOUBo21lBsuaNO2NS72zEE1Cwa9l7g3sDdgJ1T49UJqUTviHC870MYncrdg0C0uj+hqkuZyaZ0dMZKwobeQXhIW7mH5BiCTpxW1UOAI5g56nyL9HNOSOW4pajqIuA9c8g7SmWqDtwdONwsIpezduxtG1TNgBlU5fTNvecdA9SJsULNloQTZWMh7buc6OyKogSFnHhH+1jnz7WwVTxD6c2qumU8vMtFY/i6wQnJMQQDvWLbQX4C7MDM2VwAS1Jv3QmplDHQBcA7mLsFLONpwMuAtw3J+PHioa3HBWYKrDa9SxxlG6d2yvT/I2wLyVaoWeQeUnlMVDNFeBBh0W4uekdZL+kVqrrjACs4pFlrjtZYGveCuOfqKFEfxgo1jwPebWSUzTRe6oRUHuKZH68dsoWu5qE0k1djwG2K+5IWAW/KWOiDwKoh3HO2WDkgD2lL/KA+R/lk1FDV7YBvme6ptDAc3UMqaQAqtkC9O7AfM+cGDRpxwbBq94+vakISg0Lcm/Rc2wTXHOBm2bVjKEZ3DIiQNgc28lnrKEsXhjddSFg32qoFIZHI4p2oefcVqnybwKHG+vUh9G88zmI18CvgNOAWs4gfADzZ2jaozLe4lrQJIePuzU5Iubw6LXE81MZjM1W9yj0kR8FkFLPnhHDMzr5ddOGmqbHkhFTQICSnph7WwRoo2zOqEk6hfZOInNeinfcCvgA8YoCkFL2kF6nqZ4BrzZssy1PTjLcxDgo3EsXtA5STLeIYmNxG7/lOMpzE+pKO0skorht9jpBp3M0wn59VFo7iQiE7Afdk8AVU4xHwfwaeKCLnqWpNVavJqyYi5wJPAM5JPLpB9E3TLKEXDbCk0O1jKEfLB3ivx6nqTqq6iYg0RKRuBS9jFX6N4ZcoP8mran8XT4pwpHxiZPRuwjp6JzKKxs4GSQ3uIRXnBTSBZzJzaF1twPdfA7zEBGLKjojPWjBTIrJSVV8NnJxY5mUrlXj9F6nqZ4GVAzhupOikhoUD6J9BkGjM+jzcXher6unAWcAZwKXAbcBaEZnu1ZPNhGyy/a+t3ifVE8uQdaufW/VNV+Nu1IpRx71GlsTwCuB95D+AtOaEVMKY2PseDD5EFNeN/iAi/7VwWMsinVa6Q0TkVFU9B7gvM0kQZRNSA9iFcLrsTxLiLgsrC2x72YSU9ep0QDIrhCPodyMcHAlh7W01cI2qXgtcB9xsr1VGVjcDN9n7LSKyKpGxniuTZNYVZRbzr8jxnq0u0AzRFtbGkkPe/baloapHAB9hJizcc186IRVgHZhlsCnw6IwVOgjEwf9ttFToHIoTVQX4W0JIZYduU8F8oYj8WFUbJRsHRdeFG0RW2qoByk16TEeambnAXpsC9+rw/XXmla9V1WlgvRHU9cCN9rqNcDT7Cvv8HfZaY+S7HFg5qcfP2NrcPDNmFgCL7bWIUKFgKWENZTEzFQti+D3Nko21MG8F/iwiF4zK85numwd8Dnh50v6+iN0JqZiJHTOXti04TNQL1lraed723jbg9kXSe6Sq7iEiF5Zs6a0oeCy2G0AfrRyC3FRovT9E2bAOY/So4ufnc9eTZ++e436RvFbb865V1bV2/ZWmdO8gZIfebp+/I5KXveqZ1zr73DpTiI2kvfFdEkWfPSgz3RoxZc81jw1Da/MSUtnYDJQl9vsC+3kj+99i063z7Hrz7DXfPjt/FkbgHar6JRF5uxFecxghz7gsoKrbAN8DDqCAQgBOSMVZmg9MJnBlCPff1jykbsKpRlxbD5g8Y9huIfA/wMcpN7Gi6D09WwxgDNeMkDxLDi+01e/a5m9R6U/Za3GBfRpJLhJTs0UbKxlCqrQhpHmD0ukZ4uzFUz9CVS8Tka8aKTUGKSBxWcDOevs24RiJaRvXfiMaTkgFT+D9E6U7SEKK93qaiHxIVZvd5Umr1t5heXNPVtVPEuLOZSU3FD1Jl7RRxkVi/ZjJPD3KkHYgrH7bIRmSKwLNgsa5Wz/V+pRrAT6mqr8DrhzkmlISpnsF8Bnz+Bp9kFF2bVbB076LnJybDen+0cvYW1UfbN7PVBthmmfK/xmEhexBHw1RTbzJPUpOAS96gg5ifBtzYK6k4bOs19Lrq5IhOmXDclmtXprjNZs2ZduXviTz6ncONQmhwf83qG0UluIfM+k+DHyZEHrsN0wX27yVqs6PJwI4IRXjeo8C5gFHqepG5k5PtdiHtF5VdwY+OsR2N6ytT8t4eEVjXcHPuMxFfeRJTlqQQDdSkIKIYpCIhYtfoKp7D6hwccWK8b4WeDshRFfE/N2UpK6iE1JxVu2mPYYvivaSFLgPcIKq7mN7SBrJq66q+xNKCu3AcKpJpDjYsnOKPitJW4SHisB8F3XHCJFwkxAme/uA9E7TQv2vTnSHzPIZIKyJ3Rlq9TWkWbqxSYhs2YgI6UOAv6nqycBfCYv729nfHx6Fa4hkFN37BwM7ichFsRjjiA/3Apd4xwh6SU9T1Q+WmbWarBs9CNixIGM2JmAtS3SnOCEV56GMSjuahIXCx9nrLpbOCLQ3buZ9FHARXuDT4ejLazFD6a3Ai0ucR/G629n9iqpEE4lt/qgp0kkgpKkBuc552hJTSrMvHbExf7yLzl0mqMPRqwH6dFW9O+Uf77K+JHmvOSEVb/HXR0ipxF332deoeCKxHQ9Q1W1jho2LkcPR8zxSQsWHVw0g466sazshFTpKIusZz/N3hm3ZbQPs6bLoHpJj1qT0XFXduqSMuyiXa0sipns4IRVDRHGTKcwcHeBKpTch38+9ozv7YrpkS9QxucbdloQKKGXq9TuYqatXpJ7byQmpWIGA0Sj7Mo54RD8VoicU631eOvr0kgBeYsZd0Rus49xcRTmRoEVOSMUP1vXeFX1Not1UdbFtupvrnsG6pG+coB29GMUK3B94DICqlpFBvZJQFJeC5XNzJ6TiCek4e696l/RESNsRNvSmfxvFds6z8GyZRBGLgzocvSLWuHuORRzKqG23mnIiQZs5IRVPSP8hZNp5/D+/oq8TygjtNAbyuBGwsa0bSkky5ITk6BfRED5EVbcqOOIQ5XMNHrIbfUKygb8R+GNirTjy4z4lhAGK9pAWMnNIX1lGx7QTkmMWctokVKV/ZoakikIasisSnvZdmBQE97gqInXg5BFWrKOIKH/7WV+OMpEvTUILZRHS+oSQXIYc/XgyChxma0iF7O+zqEDF5ufaMuXTCakYREV6DCHsUnOF0pP3cbd4ZEbBYYZGAZMnJhjMo/wjKNYyPmciOUYP0SPaF7hXwRtlJTGaSrdQHcVYENcAP8mQlKM7tgL2Ktj7aDCTtVaUwVFWRfd0H1LdxcExC8Ralc8t2ZsvkuSWqeoCEWk4IRXfuZ8yK8JTd/Mr4wXA7iUQ0poC2wj9HdHcC9YVSKKOua2HHq+qi0ooy1XGGudG0dhzQirOS2qYl3Qm8DNzn91L6j55Yh/tULDXXqSHlCWmsrDaCckxS1RM9vcAHmZkVKSeX1vw/IdQ7XuRE1IZ5n6oI/U24DZmyno4uuPuCZEURUjrB0QkszVmYsi3TjkbDx1z09h7cQlVUMrIsluCnYnkhFSsYmmGN7kSeF1irTg6W3QA94kHjBUUYmgW6G3E9mxaIlkMZNHYMafm1AFWcLXIYymK3oekhFD4UiekckipYScsHgN80zrb95Z0V8Q7UuyprPUSJs/W7r04xmRONQgFVx9nBl5R60jTBbczRpA8ZFcimrYP4I3AmUZKnj3VGZsDi4scgxI8pGU+TI4xQ9GlhMrwkJyQSvaSFGiKyO3AY4GLCXuTnJTaK/sF5iVRkDWXJjUU5dFsNgAPyWVk9KDJq9nmlT2dedhrx1G3P1RV94rrlAVcd3UJfXvnnHdCKo+Umha6uxk4GLjcSamjUAqwc1GEZOt5RVlzsT1bJwZHmX3hKJ9YtAXRxJOfp5NXI5GBmLHW6pU9nbky5LGMtSIXAE8uMNtuZZmGac1ltFRSiqngl6rq/sDxhNMR6973G6Bpk3inAj0kKH7tbqsJVM6tiLfb30bpGVoRTdZTkOTVzehoh7WE84BWZzzv2wkH190B3GCfWQc8BNg/MbaG6SU9SUQ+BtRVVWZpUN1RUoRkYyekwXpKV6rqo4EfAAcwUy7evdQZJTLrSgixGrdNuumCJ82SmAk4AR5SkQvdw/QCepEXNbJYz4bZr7cDVxuhXA9cwUxoaiWhcPINwE3AzSLSdcO1qu4O/B9hbaQ5pHke++VBqrqniFzA7Dfsl3UQ6eZOSIP1lKoicoOqHgR8HDjc/u3ENINNClbK0yVN8DIxqG0C15ri3chkb17ymm/vNfNcR5W4po0obgZuAa4x8khrGC63/92Rkop5MhF1EcktK222JaR/q4rIRar6e+CpDG89KWbbTQFPAC5g9nsj15Q0p7ZwQho8KVWAaRF5vaqeDHyQEMKDEMarTIjl2i9iSKxZgJArxSc1iCnoMhVM2fuQGvYMRwKfIawxxJBpuh5SGQN5bJqCXCsis86oTNKjKy08qzvDgW1CXppex671TSOkUcCBqvqZAgyeO0pqnxPSEEipaQJbEZFfqOqJwMuBVwC7pBYbM5V7h6kMdEBeQrzmJhZua84y1i0lWXNLgbsBl5QYuhtU6SC1yhArJ2V+mcFXbSPDmvk5Ozc1qWow23GtmAF6ywh0SyTXBwGbichNs5xbq0tq5yZOSEMkJgvh3QF8QlWjJfUS4MGZcaknglWGtaoZizNOytRCHkRoIQrlwgKEvgxCUsI+qb2AS0rslzWDkkOz4iem5qIZCM2S+ysrZ+mcFKAhItN23P07GW5SQxot2JRwLMWvmF0FmdUlzf2NnJCGO3liFd6KiNwCfB34uqo+Eng08DxgG1pXmNaEPLIDKx1IRzOWU5ZwWp0wud6EcG3iWldL6pZFFFNRO1uGRwu4XsyM3C3pvzIU+aAIaaqFQu0Ukpo4JATTKQsv7inUFv2iba67DyEkuj8zIdJhIiZVPMwIaTYEWVbVmY2dkIZPSsrMqY4VC6OcBJykqu8B7k/IyNsReBQhLXqKmb0ORWC9CeyNwHnA2YQF39sJi97XMrNYvA1wBmGtp4zDvxZQ7BEPRRJGVD5lb45dNSDxW9vJo+iycC8t/jZ0funwu3aYf7nH0g6RjIbc1oTMsC2AbW1uzDOD5RkJEVRHRd0Qqn/PA6ZnEbYrax/lQiekESMmE/pq9KCA0+2Fqi40D2JLI6pdbUJUCdVyNyescSw0pZ7uHl8D3Gqv9YR1ikuB/9hrHbBORFZ2mZBlp6+mHtKonScVFcvjVfUDIrKugD0drXDHgJ5nT1W9tz3XWpOXVcCtIrK628L9hHhIC80y38Tm1RaEsGysqVgzotmRUI1+h+R/CwjZiLUuXskoILbjHsA2InKFrbeN3Hg6IY0eOTWSCRMXaZu292ENIYX1/DYTrJp4UGmZk3reBXirwRfJQBNPqGnXrpQsj6Oa/h49gb2BKVUtKxuu7EoekVhfxsypog0b5/XAanu2Rka53spMevVN9n4z4ZiVYa9BTRlBLDJC2cwIZiMjnK3tf9nxnG8G3CIz6vpFnGdx7bU6YnIc07+XAftY5GMkMyedkEabnO4MqbSJd0s6IYzMGm2IJrtm1DKjyDKvsverJoprwVwdDuurGvBwETlBVReoap27rufNZh1mkMp9kc+ytsRCh/nWygMZl32EBwHHjWrjnJDGh5w6xruTvQ9tnZ82ZCMpUalqXMRtJvdbb//bywiprMyhUd+DpUbOh6vqyd127CfFLCXHc1bbpC2X/Tx5/tbqf6McvpMuv7f7/DgRS7998nBVXUxYR+rlWQcinzW7yVzdiDmp6LiJrwW5NVso05qFM/YmFIfdAXg6M+HAQSiSUUN89oOAv6vqn4ALCYkglxOyEZuE9bh6j/uUpq3fVw3weWQMx8DRH2KFhj2BvUTkjB6/H+VzeVntU9VareS6XI5RZKuwmLuUEFPegrDZc2tTRksIVbfvQ8gYWtzCaixLaY2DMozra/exVyT0tYRw21rgelW9krDWspKwLhRDQU3CustaNkzciArjyU4MjjKdEODDqnoCvZURip+9Z0nyOQ9YUlPVAwkbptaaBVhrc8M0tqpt3N1Wn2+3Q1o7hC/SkNJU5vrpxE43cUpGYaQ/Nzvcv12V4Hiv2L5sCme68J8+wzw2LEufPSsl/k6bvqhkwgfZMi6tNshmN7PWCJlBOxihbJT5/BQzNcsW0j10W088hDIV5RqKXdQvaz1GknGM4xPXY5Yayd+rAIvW4SjaSwJ4jL1GQT4lIcpFNeCJzBT6dMxNZEkyS3plrzVGUr+aUAwTigkLaoneRrre0GoPTKc1v07PNmoZWo7Jw2wOECxrHakGLKwR9j3U8TN6Jgl5yvJLG+U6LEKsABeIyNoC68Q1B9zflEiADkdRKHJjfVGYAhbX7IfagCxhh6OTQv9PMmF8bdPhmFskuXAkd+s65qQwKvCHJKTgcDjmDuYDSysUWzvM4egVMTnlP8A/YeaYjoKu7XA4Rh81YJkvnjqGjZjQ8C2rgF4r6JpQXmVih8NRDNKs6MWzPc7W4ZgtcVQIlcS/YX8rMly3LhF6h8MxmmimhFTxSesYEuomdx8UkeV2aGGRa5rrvIsdjrFBxcsGOYZJRlPAqcBXrYRVUd56JLUVbmw5HGODeb6G5BgGGoRFzBuAF4rIOijlpNL1TkgOx+h7RjZXL3QPyTEMMqoSztd5oohcUuBG2Cw8ZOdwjDbivL8MOME9JMcgMW1kdDPwKBE5w9aNmiXezz0kh2O0CUmA74mIHz3hGJhXpIQ1o/8A+4nI2apaS0/ILdH6At8A7nCMKhmtBr6vquKVGhxlE1Gski7AN4H9ReS/5hmVdVx3lOn/EKrYOxyO0dQPVeCjInIxlmXnZVocRVs9KRFVgD8CjxGRF4vIzbZmVJrcJSHAKwmJEw6HY7QQs2yPJ5zPVAGalRZWpcPRDwk1TcjSM5xOJhw491gR+aOqVlRVBnEopHlgDeDHiTXmcDhGg4xqhNOWX0RyurUnNTh61vXMHHpYT0goHgx4A/Az4EAReaSI/EpENGbSlZDa3Q0/ZaY8kRtdDsdwMW164krTETcaGTWxf+Q5O8fhJJQmJkR5iQbNdcAFhDWiU0TkyqynMgivKIXVxauIyGmqehTwCpsMXkzY4RiODmna/LsUOEBErk4iGURC8jOQHKnnkx7LXk3IJ5WT5UZCPzLh+m20dCIJ2Y/NkrPouj6TteUI4AH2amTI1OFwlIsYoqsCJwAva0VGWQ/JMdlEQ+ZduOupsdJGmK4lrAddCpwB/B1Ynno9tigpgA6ZhFIvSVW1KSK3q+rjgKOBJ0SyzJDvoKMEfspsefI+m/93+qzmHEsKbEM/slS0PPV7rWZizK4A3i0iR0Z90UpP1MxijC/HZE3K6OXkEaj1wCXARcAthBjvXwmp0ytEZEUL9yNee+AhuR5JSUTkZuCJqvp84PXAfUfYcChaEU/62plkjAopQbk6ekeMlPwCeIeInG+Ga9szz2rAAkbzjHVHMZgGbjMLZbn9XAcuB84BLiYkIqwGbmxFPIkHFI8Wb4rIyHhCeUnJfv6Oqv4YuBdwKHBPmwOb2Xyo9GB1Sg9/S7MPp+w1L3nvpkgdvaPBTOLNOvt9vf3eiqzjloVpZrYurAfWJN9vd5/s/6XFq5LIQZFjHWVqgclSlZkQWTby0epnyUQKKhl5XZTwRI27Jgi1epY7gBOBT4nIqdGA7aYzxCzGl7Nh3a9mZrCaHTpQ2TAm325iVTKDkze81O8ASQvlkmZbpWErbSGgSuvq062eM3vdPK6/dhhM7eDpxOeKSQbrgGvsdROhLM8NNukaRkC3AysJYbaOApEQjyZhLYaQHVeOG9JmUqhqJAfpIQTSCyFJYvhN2cSelyGmrKXf6n7apl2d7jvpRNdICKSezNtILnUjlvT3dnMyS0jT4yT7Nn9riXFV7SKf7WQmJaWFRkiV5LrNNt7pnZX2ReTCpE25ToJ2i2yOIQmztSI+nRTi6dIHWct1bLw9x9CU/KgTe3PU5q/pGu0lnC/J5HSMNzqNoU6ap1MSSQ1jjHzulTy0s/3cuMyZgmV4trKqo7qu7HA4HA6Hw+FwOBwOh8PhcDgcDofD4XA4HA6Hw+FwOBwOh8PhcDgcDofD4XA4HA6Hw+FwOBwOh8PhcDgcDofD4XA4HA6Hw+FwOBwOh8PhcDgcDofD4XA4HA6Hw+FwOBwOh8PhcDgcDofD4XA4HA6Hw+FwOBwOh8PhcDgcDofD4XA4HI6hQbwLHA6HY7Shqn3pahFRJySHw+Fw9Es8FdPNAijQ6JdYVLVi18OupYCOKlE5ITkcDsfwyacj6dhn5wNTwDygmpBWJJsmUAcawDSwtss1I1kp0BwFkpKcHRcb3c/1ddzcxjLd6DL7YpBufb/3cpQvB31a0f22Z6LneEkEhPVZM/P/KrA1sA9wN2BTe+0AbAlsAiyz13ygliGkaWA1sAa4A7gJuAq4GrgeuBb4L3CRiKxuIwfSqm3uITkcjoEoSSeT0klIgg0ijcz/tgTuD9wDeAhwL2ArYGmJTVoP3AJcCpwDnAFcBPxLRNZkyJFBk5N0sppEpKmqOwDfts/OM5exmriIjeSVuoDLgH8Arxgll7CoCayqGwO/ADayZ4/x3npibar9vQosAY4VkQ+rajUrnLNsU1VEGqp6GPAWYIXds2JjFBEtoIq1eT7wVhE5OY53N0vaZGI34Ot2rVpGHpoZ+aqwYUwc+4wmn419l/ZbKzlNr5deM7US1Z6tmfyehkbI3ENb3E97mC/Z60iLa8T7V4EFwL+AF1tfDo0QkvF8LfASk5t5iRVPItPNpK9jX06ZYnu2iKxzcrurN5TOc1VdYAT0cOBAI6Kt21yikchQKv/SQR4187NmrlFpI8NN86T+BfwK+KeInJe0u2b6u3RiquX4zFLgkX1e/57ADSLyTnuo+gTJ3DzgYaZk8uLeJRsWuwEP6PG7uwMn9+gtTwGPcLUzq/GaAtYNWWGqqm4CfMAMyH6wD/AU4IeJoTPXiagqInEtB1V9EPBc06P3bEEijRbGVXUWeqCTs5EaUM2EB3a01yHASlU9DfgB8GsRuSH19sokpjyE1EyErBelFR/47ap6toj8SFVrNlCTgCqwyjwf7dI3Dft82ZN1NTMLm93GNrapH+Fq2r0W5Hh2x4b9VrGwybD7rCoidVV9lZHRdB9KMMrQG1X1p0BzrnpJGSKqq+pGwGFGRPu3IKBKolNrA2xqNtqQ9abUdNqB9rpSVX8OfFNEzjEjpkJgpsKJKU9HVJKQTK+TKIbvvqOql4nIP4sOVw2ZkKrJM0oXcq6YAi8TU5mQFjna1K9Q5312x13nRGWYfWYKpWFK8+U2htU+5CGO/4OAx4jICbb2MKe8pESn1VV1M+DFhBDobhnjXIZAQHnns7RwJiAkVxwOvE5VfwJ8RkT+Hp+bgpdiKgN4UAhrFceq6ma21lGZADlMY7wjMzcG9B3H7D2lYfZ7xZTIiwkZXLMxTuKzvM3C8nOJiCrJ+u1CVX09cCbwMSOjGF1KDTjpYV5m1+j7ffXqyUhicKfP8HTgVFX9lqruKSINW08vTJ8PghhiXHk34CeqOpW4uGMtj31O3jKJvzqgZ6+5VzQrmZkuURbyhJYaqrop8MYCiDEqrUcAB5hyrk78QAYiatrzPhU4C/iMEXwkgUoPczIloHqiO6sFvKInW2fDhJ+8+js+Q91+fyFwuqq+T1UXW2JMrSjFMghU7WEOAL4LPAuoqmpjzOPNo9b2QZJEI/ESZYjP26tRNUzvJIay1jC8BJ+KKdGXAtszsw5UxFgcoaonD4tsB0xGDVXdAvgU8LxEYVd77M+YmdrKyLuOsHfoRsKeotvtbzcS1q/XJ31dtWtsCmxrr+2BzZjZx1TL6K7Y3rzzt8bMGthS4N3AQar6chE5O+5nm41OH6SLHbPsngFcKCLvmcDMu3FEP2QyBSwc0+cdZrg4KqqlwyBF846alln3igKNibi94ABgPwvrTMpacbb/xMjoycBngZ3YMFutF+Mkei/Rg/kvcDrwR+Bi4EoRuaqAdu8I7ExIM380cD9CRl0tY6RVc+qLlJgeDPxFVd8uIl+0+1X6TXioDWFC1oF3q+p/ReS7E5Z5N2wPRgd0/esIe7CWsmFmXzN5ZfcgwV336aT/a9c3dTZcZI2E2CCk0O6VU7HGz5wDXElY10yznerJMzSSidpqDLPlWrTLfetJH00B5wOiqoOu2FBJ9qvtVLB31LRrHS4if1HViVqbTKz/pqq+Efh4os9qPcyfZsaLugD4EXAScEqL6g39RAE28MBE5ArgCsL2ji+q6iIjpicATwa2adG+vMQUvaUvqOpDgBeJyPrCDZK4UKWqe2tAU4tBU1UbqrpOVQ+we9TGSDDF3rdR1RU5+6Zu7z+JLn/BbYrrckfYfaZzjENs08vKaNOAxuJxfTzvc9NxnEtQVVHVBap6nvVFI+ecbeSc101VXaOq97J7VSak36IuXKyqxyR90uhB79WTn9er6o9U9clZ3RcTJexVKar97a6pqhup6vNU9YTMWNZ71OlxDv5dVXfqV6cMQ2CiIphHSHLY2/ZDVHEMw0Oq9KnYJP15wK+a3X99H3LXNgFkAO2upH03YKUaFd/jgb0z3mFLy9reXw/8OQnRdPOSFgCvnJS9SEk1i02B44DnMLO4n2fuNBNPdDXweeAeInKYiPwy6r6o/2KihL0KWYvLXtNksGrPdoeIfFdEHkfYL/UzZrLs8mYSR2+pDuwL/ElVH2DeeK1UZVRU6MAGajPg+6q6jBDbngiLatLDiCJy58Jl/HmQL2a3cFrv9lwlvppp3w0YMYHo1T3IxTTwHeBbOeUkroU8R1W3ispvAshoY+CXFubqJUQXSb8K/BS4r4i8TkQujqRgctcY5HqbyWCWnEREThGRQwlrgX9lJuEhLzFGUtoFOEFVH9qrs1EpQ2HlfICYDn5v4Fs2WcSrSM/KM9I5+ty9fLY254QjxPNVVR9MKF/TbQG7bvP+D8By8wwu5a61EVvpigahvuOr23mi4xLeDG86n7DG89AeyShmsN0IPFdEniYiF5l3X4mkMHRrdIacNNlX9WdCGv+7LQrRS0mouK60OfBLVb1fL1sBKgVP+l49r7go+FRV/aQN0LgIsI4QAXRLDCh6fMfZE5xTpB0Vq/36lpwWb5yDXzSFdQfwTWaK4OaZ+y9V1Y3NQpYx7LO4efirwGP68IxqhCSCfUXkWFP2FRGpD+tohxzk1EzIQ0XkA8CjCNl/vVTgiJ/d1CJgm9p1u8pBGSGyJiF1Ma/CjqT0JlV9jQnwpFqxozgx3auabMSw077AU+meRRUzJM8Afp+seX2NcGxBtUsfRmt6a+CVY+olxX1GHwaeTwhd1nLKVjSqvwc8XkQus0zi5qgSUQtiikVhayLyV/OqT050dS/Oxu7Aj8zTrHYjpUoJk12A9xLSIiXHA6QLaJ9S1Ud6koOjRMy1atSxtMvbmVnjyYOjbDtG1UjtRsJaUp4+jJ7Uq2z9pTEuXpKFrOqq+mjrs0YPZBTJ/kMi8hwRWROvN3aWc/CM69b+q4GDCAkPNSPoPIhrSo8GPmz9UBm0hyTAJiJyBPB/zMQUu30nnrf0k1gnacRJyde63EsddeUaCWhv4GC616yL/7+ecJxEJJ9IYl8GVub0kpRQKeA5FvqqjEF/xY3DmxLOgEt1Ux5Dpwp8QET+X8yoHPfNwbH2qIisB55GOC9pqg9P6fXmbHTU65WSJ/1zTbjzHHMQXf1NgR+bUIxy5l1eQXVl6300RH0iCrzKjL1ml+ePc/QYEVkRkyEs5FcRkUuZSQvuNp9jyP7VdjDdOGTcxXWj9wHb0T01PiWjGvANEXl3sgajEyJEcfyVcKTGyTkdjTjfYor8l1V1sXntMkhCiueinA88MxHebgMU2fSewNEZy8VRjrJteLdNrHfUVNXtCeW68npHK4CvZZIhYCYD9suJotYuc7lJqKTx5FH3kpL6dA8FXkP+igXRMzoReM2kkVELUlprOv1i8p+nVjG9vgfwXltLGyghxWO+F1gK4avInzoY445PAr5qjR/F0F1Z6fAOR5He0cst6tDI4R0J8H0Ruci8hWYaurFrnkZIB+9lf8obx0H+jcQ/SP6ErNhnlwNPN2XNuCQv9ElKVTtB9tmEE497SV5rENYV72VeUnVghGTvdcvUOIqQpZO3mGr83EtU9T0TlHnnZw85BqFY07WQl/XgHa0l1DprR1wV+9+ROY2yaEE/WFUPip7IqHpHhBTnA8hfaDT22xtF5FbTdRMdcYjVF0TkDMI+pbxeUpSVRcA74gb3fgipH0+gmgxYPJDvVYTdv3ljj5FR36uqzxjBzLt+yGUUQ49zJRw6lzbGpgfwbcnM2TzdLP3fA+fa91vN0fi3k4Gzyb+WBPAma9NIeg+mW47oYW7HUN33ReTnc6lItOniCuHojTPpLXSnwFMsce0uOQKVkia9JI2PJWbqhHOQrsz5AJII/NdVdZ9+aiO5t+OYSwSceEdLCEdP53nmuF70xU5rH3EdSETWAV8g30bZmJH3KFXd10L51RHqr6iL7keoTpBnc370jJYDb4l9PtfmkRktH+Cu1fg7yVmDUO/wha04qDKglsfY41WE4oTr6G3X9xLgN6q6Y8LOTkgOJ6T23tGLyJcpFteW/gmclEO5xmy5H5KvnFD0wKrAm0Zx7iRrbVM5vxI9yiNF5Boy621zBE0j81+bl9RL5AvgxXba7AaVPColTfZmi0GPscdTCbuf81oVMRliW+CnVoh1VGreaZ/9M0rK1gvaTp53tBh4A/nOiYqRiC+KyHRCaJ2Ud1VEVhAy7vJ6SVioZu9WoZoh99fWhLOB8vRXDH/eDHx2jnpHaeRrGvhojzqqSah197SMfJSmjLTNQ8Qkhx8BHyZ/KYr4ufsDn4017zwdvBCvzT29yfOODiGcENotmSEq18sJG9LzKtdYeeHrwA103ygbPbEa8NoR8lSr1l/7E0od5dl3FL2jr4jI8m4EPge8pApwAnAR+deS4qGWj8vqoLIIqdFFmKvAuwi7fvO6ejHz7gWq+takrImHi2YpVK7HJ8o7mp94R90UZfz/t0VkdV7lmnhJywlFV/PIUVzQfqaqbstobHqPeud/cs7PmH23GvjhXDeIkzXFlYSK6HkN3HisxWNUdcu08GpZ1b6bXR4iMuSzCcc552XW+LmPqephI5B55x6aY9S8oycA96V76nL8/+3AN/owTuJnv2oKuttG2bigvTHwqnjczLAVqiVJPTqngR69o3NF5N/MLOzPZcQ1xe/m8MhTWVDC/rhdU11aGZYgJMz6DEI8Nk+4IF2j+kaSeTcuntIoeiNzLdwwsUZEsr0iz7hGWTxWRK6KZYJ6mMMxUelywiF+kiPSERMgXq6q2zFT+HUYfRV1xiNMMfaCH7pBehf9cRlwak45IHFKnpUaA0NzmSORiMi5hBTAvOfVpJl3P8u6fGMyeA5H0co1pi4/jO77jqIluwb4yizmTpTnLxIOcqvmmLtxQfsFnUrIDMKjtPf7M7MckLctf3Wp28C5qFlyw1k96LnoIe/SalCKRi3nwzRUdUpEfkNY7MxbXih+bmcjpcXM7CIfZYIZRfd+rll5k2gUxNppbwTm0z1bLBLBL80g7Cv0lNQ3+zdhYTvPcTMxtPdKqyShQzImoxws68GjrBIOq7t0hCMew5xT/7T3PBGryD07q+rSmP5ddumgPIhnbnwB+Dz5ywvFzLuHAp/3zLtZW4qO8fSOKqbU9yYszucpEySEM20+Z/NlNnMmbsH4dE4vIxqT2xOO9m4OQwaT9edH5JwHkXz+IyI3W7awRzw27JtTTK7ybAWIn9kF2CmOwdAJKSY52MR6A3AcvWfevUhV3zTgzDsvHeQYpbDJmwh1wvIcMVEB/gz8nVkuzNt3K4T1g1PJd9R11DtvsM2RAw25J/daAuzTo2G23CWurS68jRAGzqt3mubRb1SWdaz9XDcW2jPhfg7h+OS8Z7jHz31SVQ+d46fN+sbYcgyJkfWOLGy2B2FxOE+WU5SRzxWZ6WaezpE55TB6STsRNsnnDfMUjRr5qzPEfj190uSoQKwGLuijfzYvWxlV+hBotQm2ykIPV9BbzTsFvjXAzLtJ8ZDmqjU3SQbIK4GFdD9iIv7/IvKVCcodsrFr/Q44h94yZl+lqlMM9pjzeJ+dCAcX5pmb8f/nOyG11N1iEarzE088L/Ysm5C0zweLqaTXAs8zxm2SL/NOgaXAD1R1yRhl3jlG34scVe+ooapb9ehlCGEj7EpmKhXMWiHZtdYSqjfkrVPZJBzG+cR4jQHLwJ503z+VxXU+hVoijt21fXDAHiMbrklq3v0FeD3515NiGGAPwhHo8xi9JAcdwes7aY8n4tx9BbBJDu8oKvxbgKNsXhSZ9RkNwB8Q9hXmUfSxmsTrbIPqoLyO2E+7Jp5jXky76HXs0zv6+O72I0tIRkp1Swf/GqHmXa+ZdwcDHxnT8kKO8TYKBuEdiRHAZkZIeYuCAnxdRG6h4BpsiZd0E/At8oXt4tw8ANh3gJvcY19t7gbcSGDxSBOSoW5hiXcCv6G38ubTwBuTg/1qPuaOSfKOkiMmtib/RthVhArdUM4emjg/v0TItsrjJcV2vH0IVRt8y8NoYN7ID0i03kxIX0DI3siTeSfMVB8+VlUfVtIZSg0mY2HTLb7x8o7ivqNlhGSGPN5RDOf9UESu6LVMUC9z1ozIywmFk3spJ/QYYNxKgTkKjlqMtIUQD72yEMOTgRvJl3kXLbMq8B0rL9QckYP9HI5ZTgtpEpJ+dunBO1oHfGEAa6p3ppUzc5xDt6KrSki/focP7xx3/UsWSilg9jUtyeFiQjr4SvKV1k/LC/0whu0KnJCeQOAYtHck5h1tRDievJcD5Y4XkTNtTpVWwipmt4rIX4GTyXeibJyrT1bVBzNzGqnDCWkkTcJ4sN9pFqboZdNsnbBo+nWzLH09yTGuqJoMP42QIZa37E6dmdNNBzHnY13JI3MabpFUp4Aj4kZ5H+45g7W9EFI/Aqyz8CK6kdIxwMfIn3mXHuz3OhGZLijJoTKg75Ttgc2ViZ8eXTKu3lHDtjO8Pud4N8wo+yvwFwZ0fk9yj98B5/bgJTWBJ6jqvQcUYl/t86V4Ue3jOzf2oiBHKcwU9ygdQdjv0Gs6+MdV9dGeeecYx2iGeQ6HAfci33Hbce5+YQhHPVTsSIIvk7/YZtO8pFeVrHtiW27t4z5LXRRbIhocW/XRp5eXbbGXYkXYhGyY5fQiQnHIPOngMfNuPnCcqj6opMy7YVtX7iFN8IQ3eT28BwUhwIXA8QWWCerBqVMBfkLYvZ/HS4rrRs9R1e1LrLYSZf7qHvRg/M59R9BQHyVC2raP/jm7Hw9J+xjwskgJK1NyGHAV+WveNQibsH6gqlsw+BMrR1H5OyGNegxk5qiDxwAPoPvx5HFcBThGRFab4SaqWhnEy9pQE5GbLZqR10uqE6pwvyRDUmXI/H8S4s67X2pfJ6S7yKckx8HvVLaHNHIdn9S8uxo4hJlyFXkssJh5961kr1M/zygulI4BehvVxDvqJucx1ft64As2Z6ZFpDngVyyz83HC0QRV8p8I/RLLJizDS4ptuIJw0m0v2NrFsS0WAXv1wBsVM0BWxD/kWUdp9nCDgSnopObdGar6IuDHibUjXUipTlg8/bKIvNKqDfdao6qfZ/UTJofvCY6VEZEUUb0v8Lic3lE83fQ0YDNV3cYUb5P81fPjz+k+Iu0wv+K10wy5CjMh9b8Dj0/a1klJNYDtgOeLyBeMjMtIxqj3cN34zNuo6nwRWRc9A59ad2JjQtX5vLqwQgibXhPla6wX9pPMu5+p6geBdxuxdDvjJCZDvEJVzxKRo+w69V5u30eTRzHNfq5l2emYtvuIDNl0iwRgBLY/M+FqpfUePmnzu7Tot/R/6d9SQmpFbkszbev2zE3gcFU9GlhdkvJfSTguYz+67+mK3t19CVXCz07Ic64j9sP+pnt72R93sYjcZBGvxiRkmjUsdvleQijueUY2tRyTtg58SlXPEJF/xU4ZgHJxcnH04h3tAzyF/PuOIubba1wV3K7AC4v2kuJ6hxm0pxgh5clajMbArqp6jkvoXfTaflEn59C/8TtXpL+PfSmdmHlnD/QC4HjyZ95VCEkOv1PVXZnJZBpbHTaCJOmY/UR/G6EAZa8nvGrm1ezxpT2+Ol2rn2dX4PW2lqQFryXFa13Xxzx4jofq7jSaxIh9IfDQHiJB8TM/Tci+tKSGga6VZITjecB/yVfNIVpimwHfZiYTqSwlXXMSGCuyHuZEr5qBdJ8+vaMoZ+mr0uNLenx1ula/XtLdgUNsH1WRGXdRN/yZUCkgz3lMcd7eT1U3Zeak3DltNFkf3AO4NzMJNXlkcy3w71YslWcQRnpCx41/InIr8CxCMck86eAxdPcQ4EgL2VVL3v8wSn3plt6IcpIZWu8CFvThHU0Con46PB5zXrC+QETOAm7qoT11YEdCCj74eWtxw/bzenBG4jj+Cbg2VrAv00MaipJLCrGeARxKyCzKUxcrJjm8SlXfbckNtRKe0ZX/EG2WMfKOKibL9yZUue/HO5oUQmoA9wGeaH1TK7Kf7cefZhRlHjl6QbJcMDctpg0PinxyH0bTCWYY3HlY5MQJeXLa7G+Al9F7Idb3qeohVvOu2oXleyUYJyRHL3gtIWspb9mfBiHLdBxevcwFAd5QAgFE/XcC3Y+AT7+jwKNUde8MsY06gVRVtVZg9CctZ7VTTsMpbltYDfwwawhMpNVlZDIlIt8mnMuSp+ZdLC/UBL6qqrt2OSysH3Ip25rypIYxNwoS72g74Jk9hIXiRJ8ak1deuYtz8mGq+rCoWAvq7rjp9i/AZeRL444p9POB15tClhGXKbHkg4aI1C3LsDrba4Y3nQJe0YN3FPv3xyJyc/awyNoET/pYQPXNhH0Dj6V7Onjc/7AZ8HtV3Q+4OSqJFs/Y63OWTUieLDEZYaqmefdLmKnY3W2+CfBL4Azy1Y0biq2YtPfVwJbkWwSPx8a8UUROVS1GvUTFLCJrbL/TB3PO6ZgA8UJV/ZiIXNJGR4yMgWM/vxrYFPiUiKyOiTN9ZgzGLQnPISQz5JHT1MP8Qc8PYu/7aEBDu6Np788u2JLpezDsfYmqnm1tq+d4jml7/6V9/043N3lfpqrLM8/dDvGex5bRL2aloKpvz7Q/T5teMQpj1Wvowd4f1cPzRvl9bhzTUbVkVXUrVb05p2w17XWrqm4+RmP4mh7mY/qcDygyTJboiB1U9TaTk2YP8+enIyxPcZ5sr6q/Stp+lqo+NNsHPcppxfTqJT3wQ/zM2d1iqGMb4uhiATXNQlhpcc4bclqPNUKc+0mq+n5LcqgW0C9eXNXRMTxl1urLzEvPs64R15eOsRDIQlWdGuHXPDOgvk/YA5TXm4vP+c4iDxpM6mJeBfyoh/bEUOIhqvqMUTvSxpK7Gqq6JyGb7YkWIZomJIn8WVU/qKoLYzJYj3LatOjTLnbdSs4xBPhoz0ZwYjncO6elln7mOaNkdSeWwkEJU/diBb0wXifxkJb24SEdM4Ie0svnmIf0nFG0aJNK2Zur6nUmU3mjEqtUdeciPYeylaW9f7qH8YtjOJ14SdUC+15U9e6quroH/RA/d72qbhs9hxGaH3up6pUt+jiVq3+o6v3Tfsh57Xv12Ff1xDub366fyuq8kZoUZilMicjvCNUc8tagitbSF1V1n7hHKfEseo0Zl73G42tI49tHYlbnSwgVpfNkLEUP6icictmormN0sJS/SNiakZdY1KIX7yw6kkJYE7kE+Hwf+mEr4HPm3VaGuVk2KTe1G6FqzQ7ctZRPXMeZBh5k3tIrrUK7tjPW4plaVjnjGEIh1bzJDDES8y4RWdfuO5W5Munj0eUi8h3gw+TPvINQVv1HqrpVUoC1nxM4nTAc7Sa62n6O1/QwySum0D89ThUDkjDZJabYhHwnP0eiONjq+zUL9Oxj1YX3EOqr1XoI3dWBQ1X1czG8P4zxSORoE+C3hFTsdoQvhGzHeEbcl1T1Z6q6k4UfN3gG82hiJvI36S2RIRLiL0TkV51qhk5MpYaciIVY30PYe5CHlOIk2A34rQ12JCknGEchEQWz0p9POHahF+/oOBE5O/Gwxg1HJootb+meBcBbzSMpRC9F78YO/nxjjxGQWDvztar6jmGRUpIttxL4hbV/nuk47UCocX/XU4G/qephliKuRkwVQuWQJuFI+kPtmnnIKBruy4HXRNLspGznTqxmZmNdg7DH40zyFWKNVtA+wHesU2uMXtkQT1AYT++oqapLgNfn9KQ18Sq+ZNeQMZuLDQsvnUvYICn0FiZ7vK2bFXbqc9x3KCI/M88tj8Ga6ogG8CFVPcJIqTIMUrLDGN8EPIpQK66WkEM7oo86bhvgh6p6tKpuacTUBKZU9UuEkHKeSjYpIVWAN4vINYnx1Tch9XJAn47BRIiW0B3AwYQNcXlq3sXMuycSzqa5tQ9CGsXjJ9zLG753pMDTgLuR7xiEuHfndEJxUCn52JTSpqMp7E/Y3Krk9JKawDLgpSVsTI1hwFcRzjzKG7pLyfIjqvrBOCbDSBgyYv0z4cj1j2eiPZ10XDTaX2De0oGqujVwHPBKZvaE5UEkrp+JyDfyHO8zF+tjpZbQjcCzCWUs8ij0WMblw0ZKqyZA+btXNXzvqNqDd5SO2ZHRwBrXeWhkehbwK3pLuVbCMedLbT5LQW1SC0+tNG9gbQ/zRBKl/05V/QYhRbqRXZMZoI5bJSJvI4Tjrkk8Oc3hLd2dkBjxTzPeGz3IWlw3ugx4pXmxXce2rH1IMg6TwZIcTiMsJFfIV58u9tn7CHtFennesvpFu7jkjtH2jp5O2BuS95C4ioVifmMTfZwLfEYv6SPmJUlOL6kBbGGeDBQYPs8UaX5pD7oh1RHTwP8Cp6jqvsmaTG1QxBSJ2p7lOPOWjrO+6hYijZ7hFLA9+U4qTsmoagR4kBn+5KkIUZnL2iApxPot4K3kW09KFcOoEW9fJUDmikMygsZSrAX21h6fQ4DPishq8zDGefN6w4j5DOA3PXpJEA7wW8pMXboidUNNRI4xUooKOq+nFDPY9gP+qqqfVNWN0lpyg9izZGtKdfOWrhaRpwAvB26n+1JFDKH2Um0+EtetRkYX272bw1RG47QuEQfrE4Td43kXMidFkc/VM3aGzURxkh4E3JeZ4qh5vKNLCNsQZMK84o/3IJPRwt8aeJmRcqFrNYnB+nVC+K5Kb9l31cTrfRNwjqq+SlUXxWQB85hKJ6fEW6qIyFeBA4Gz6L5u10tVjGikrwSeJiLnxYoRw56c47QnQpmJ478C+E+PnpLDCbhf76hGWIvMq+Sid/R1S8qpTMJR2klV/X8CJ5I/4y6G916nqsso4QTXZP/iNwghuLhml1c/RJKMB/t90YjpPaq6t3lMkZzi8RCxcoQUJGixgkQ1tkdEzhCR+9LiCIhZRCAin7xARE6yfqv3cpHKHJn8eUhJbZI/BricfJl3kwBPahied/QY4KE5vaP4mVuAb06gd4Qpr0/2YJXH8N7dgP+NFRfKaFcS2n8qcDMzC/95EUN+MVngvcDpqvprVX2Gqt4tOR6iaaG2uOY0Fb2opABvp1c1/Z5dq2nXnlbVLVX1kVbseb8CuCDqkJuBJ4vIz/oho9hJZZKWjtFkiLvHr1XVQ8xSW0qxp3W68ndE76gCvKUHuYix+W+IyI15UmjHDE3rkz+ap/QA8lUCiMR8uB0hcbud/aMF64foKf3KKmV/A3hYYhTkJdBIokqokPAEe92uqr8HLgJ+RkgIuLkfpZ71dmyNbVPgKcD9gEcSSgoV7XysJBSwvnM8e92s3Qsh9ZLvP5aKN8m8O9PODjmWmeyacfD2fE/RGHhHppAeDDycfNlLMRyyFvjCJBo3ydlE06r6ReDoHqI8MRz2AhE50vq4UUIb43rzRap6IGHN63UJCVTIX/IpjmFcd1lGyLaEUKtvPfAPVf07sAL4LyGz8hI6V13Y0jywvQg19rYkrBftmCHNZiJXUpDe2cm8viNE5GMm7z15SrWSlNw4Z/3E7JrvWen2d9HbzuRhEIbMwpuda6niwybtGIp5C/nXKuOeju+JyFVjVES1n7knhOSidxDKdeWJUMSF+Teo6reAFWV4SYnRWgHWi8jhqvo7Qvmj3ZjZVJpXyQsbFmtuJH+bZwbLw5PPr6P73scFhLJm7eZ6M/HUCvdyrf0fVdVHA68QkUttrbSZR2YrJU12nYCJURWRd5ul1ksJkXHzYOrMLQxNNs1yVysM+oScylYTL+DL41gmqEdURWQ9oep23nWymGRwN+DZZa0lJfohVsWuiMjxwAMJZ/yk9d0aPcpathxZ9J6mmalFN58Qeuv0WpTcP/1u7KdaH32Tllzr9FyRiOuE9dHTVPV5cV0sT8WKsjbGTkI4IZ47/2rgHxSTeTen9305gndEKN45n3yh4Khcf217dWTC1o5aeYMA3wGuJn9yUZxbb1HVBYPw/JN159tF5O2Eoxx+wkwYVuhc2LQbQVUI+5lqzGQU5n1VM9/tR4fHJIzotVWT5+rUv1FXbkGo/fk1Vd00LonMVkH2UstuksIHTVMgqwmx3WuZfebdKBJSlbmFoRhLMcxm59QcxoZpst28oybwqTngHaVrSXcAn+rDS9oZeE6nc30Kbm/c31MVkbNE5OnA/oTirLdnyKQ+S/mTHl79IiWh6FHdSKik8RSLGNXpXr0irSL+EsLa0sExLDubA/rmqoeUPd74iYTFxeYsnm+67Cb38Z0acwvD8i7iXHuleUe9HE9+koicOge8ozQ6USEkFV3fgyEY+/ONqjpvUGNtadUNS8uuishfReR55jG9C7iKmZCcsGEIbNi6MhJQI5HT6OH80yJEe4vIO0TkOBF5kRHuqXQvQXSXunhWdFbbhfDyENK03bCZ49VgNEvqzNYCqonImRZqqSUD2OyhXxolhhGiUNdzjk/6GmfjQTv0c6fXoLWrmGW4FHhuQkbd2hnH5nNzKUph0QkRkZuAryWhr26yHfXV3sDTB+Ulpe1OCqlWROQiEfkgsAdwCCFV/NZMCEzYcH0mlWEteJ60ukckoEgO/0fIHnwIsK+IfElEbrFnis/1N+ARhEIC12W8oXZGb5x371TVk1T17j0VxY0ularurb3jBfbdiQkHWc0xVPUz2j++V0a/xEmnqm/vo02vHbexim1V1cf08bzPTPtswO39SB/t/ZeqzoubIueKG5tsAt1BVVf20W//VNX5g6gX1+UZapm/bamqj7J1ld+q6oouz1FX1ekWr3qLV7vPdcJ/VPWnqvpeVd3T1t820C1ZuUt1hapub2cnRUyrarPL86iqXqOqh2YrUuSZlKuZORckzZ9PXynmM7M5apIQM+/eYOGAR7NhdeI0dptdgIzHCF9SchuvAM63e05lPIjsfiq1Mb1ijMdkOaHUU50Nq0RnY+lxHCr2HQblGSZHTGxB2BV/prWj2sLDjVGL6D3VgI+IyPpeClROipcUw+Wq+jlChYSYUp0W/UxlXBKPYwFwbxH557DS5O2esZxRxf52I2HT/YkmH7sSTg3YA3gcsC2w0N63opiQ+irzZG4k7GU7HTgNuBK4TESWtzC+G4Q19HqrqFEkKxG5GnihHbXxKULGYQyNV9uErtfZ8z1IRH6a7huTnJMqZmxIC0LKJj0sEJEVE2q13bm3wU74TMNDlTaEFMlgIPF/VV2YKLz0/vUMcQozRzaP85gsyCindLNfKq9iE2z9sGQn+bXKXYtapmNTScZnFXMYcc6p6qKknyqZ+ZUSEswcmzC08e4iB3GM2+7NUdVtTGlvmZDSAmATQnr3wqQfGskcv8mIJ8rTWkJC1jVZ4slGWOIc6mX/ViRbC79NEdac/p+RbHZPVhyvKvBOEfnwpO6pG6hADTMM4Jh78uZ9MLl9EBMhMi8Zt3ul11LVHVX1h5kwXT0J5b0tG/oj49UUKhCTUIG4jEkyiH6Za2M1Ts87qjLj8200iYrWKdx5z2NKP6+9ej6zIaYkpPcc4IOEkkKYB/caETmq3+KrDofD4XD0ZDwkSXEbq+qnVfUMVT24nWfkcDgcDkeZxFRLfl6QeH4Oh8PhcAzFW6q6Z+RwOByOkSEm7wWHw+FwOBwOh8PhcDgcDofD4XA4HA6Hw+FwOBwOh8PhcDgcDofD4XA4HA6Hw+FwOBwOh8PhcDgcDofD4XA4HA6Hw+FwlAEveJcTydHD6oemldK/FQA/ztjhcELKo4x7v/iEKG5VFSehwfSvqlaclBwjajDFs3wa7fSB6cqKGa7NSZ+3sU/iKbGOwXX+ElXdLTk33r3LYvt3Z1Xd0nvC4XB0tAxMGS+115LM70tb/G+xvcu4P7u976mqJ6rq5ar6dVVdZAdPOSkV079vUdUrVfUCVT3Q/uaHeTlGSUYfpqpfVtX3qepmWaM0oyterqpPmFT9kDzr3VT1Zap6qKpOFXHtWqebmst5L+AY4DagAUwzE+qr2s91+71p/18LbA68DfjHGIdhKvZMhwB7AucDBwH7i8gJpjTdVe1TqEWkqapbAy8CbgK2Bp4H/BHwEKljlHTArsBLgauBbwO3mO7TzOceAXwcOAX4HVCfwJB/fNYHAF8B/mPPe9Nsn7WW4zPzjVwANrZBaNorElMkJLWfVwNbAJva38fVUogdey0wBewMrAJuzPzf0RcnqZis3ALsbvJy2ZjLjGPC5NTe7wAuNlltdPjcKuAqM7B0wvtkhRH0TcYH5XlICdab17MQ+I6xYSUZlGbSQE1e84Ezks+MHUSkYUrzGHvm+wLHi8i/zBLwxff++1bNS7pDVV8LvMIE/MhxlhnHRHtKVWaiQu1QNd03b44YVTGxoZBnreW84ZR19PdF5N/9KJ8ezGbp53tlXdM+Xwe+2e8zDeK5irzuIK4tIndmIYnIWUZIEyEzJbiSYznORfZlvMYQxyJGhqa7eD5ierUy6vJXwD0qCYdUihjLvIQkRkib2rpJJacF20xvag2Ji9WNJNVXgIqINDKfr4R2955SmKQkNrMPbs+QbVu0fJqtPB9VnWfXq4tIvcW9en2uvvbcdHmuWe3l6ZSy2um+ba5TTWSgme2LVCit76dsoq9vM15xD1gj8/cN2tpLO3t8/lb3qiSfb5SgLLqNhZYkQ5K3/9qlQ3eQ/Wredne5Rsv29TsmOb4XZbqSVb7WnlrSrwIsAuapKoCoarNbe0rQWS2fqZ1e7dSvme9Wra21xCucitygweKst/huu2e482+9ENKdCsFu2PNESLyNDR7QrtXIKP6GiEwnnZB7Q6qqVq2z4zVr8RlEZH0ciDTZopuwiMj6Hp8r24b51obpVvefxXNFoVyfVZY9Xjs7DjE8oSYw6X07XjvbH8lCZ/z+VBzbpO8bnUKnbSystB+mTEbW5m1nl+ePkQEyMnMnkdrnCw8ttmhLJSHsKItpe2QWz1k1PaA25xot5K3TvLhLH7S4x5TN6dyy30JmFtr91nS6Rr9jkuN7qecjLeQztkmBxUBNRFbPYsynEjLpV2dt8ExZWbGxn2fjvj7P2Njf19vnpoEFFqJc2W4eJxGRVMeLiKzL3rOWd7yYWRvqO0SjqpsCj7dO+ANwjVnPiwjZa48lZLPUgBWqejHwaxE5qUdXsGHZWwcC+wHb2T3XqerVwL+Ak0Xk8mTwnw1sA/zB1ogqycAJIcNmC+CPIvKPjIW/GfBEu8cfgSusDVslz7WdKenbVfVc4AQROT0z+bqFuBqqui3wSOChSV81gFtV9RTgnyJyuvVrNY+VGD+nqhsBjyZkz+xuhFQH1qvqlcA/7flXtDISknFeCjwTWAL8SUTOsTF+ivXHRqp6O/BJEfm3qt4DeBghWeQ3IrI+s1n28cCOwEXAicnfD7C+vT+wDFitqhcCfwF+ISKr85BS8vw14GDgIcAeZuU2VPVG4HTgdBH5v0QmHgY8EPiPiPy2qBCKjd3GNs77AnsBS22cV6vqf609Z4vI+aYHe3nOJcATbG7saEplnc2Pi+zafxSRNe1kKBnr+xIyy5YDvwSWW/u3M1l6BLCtKa0Vqvov4McickGOa08BT7W27gwsMDn8tS0frEs+G98fbPP+DuCbIrKq0/xKvndv4DHA9cD3Wnw+GgV3WRtS1ScREr/WAwcQ1kK3UdU3EbKTxd5/3sLzuTN8rao72PyIfbaYkKV3CSGL7Q8iclWi1A8DNgP+IiL/16Iv9jM9cYM9U8Nk5QHWpw8CNgHWquqtwF+BY0TkpuzYJFmxTyJkXt8MPJiQlLQIeKGNzZTppDj/svP4IJtbqOpNwPEmD/U8Liyqel9Vvd5eD0v/16M7jKrupapXqepaVX2q/e1RqvoLVb1CVW+wvT7/VdVL7P2/qvrZbnt/MnsCXml7Wm6ya15v171AVS9S1ctU9W+q+ia75nxVPVMD3pJY3fF6U9YOVdX3x8kd98qo6gNU9XZVXWEDhuXmn2Z/u1FVL7VnukRVL1TV821PQyXPc9n93qyq/2d9eL2qXqeqV9u1L7Zr/tX2S9wzsYK6KkFVPURV/27jcJld7yK75gX2twtV9c+q+uI2/R7HeRdVvdX66/mquqmq/k5VV6rqbap6s6qeqqo72udfbZ89L9njUUna9gv7/8/s961V9Vgb27V2r6uTtl+kqieo6l7d5DVp84G21+xG69erbKwusue+RFX/qarvN2MHVT3a2nV8EV5R7E9VfY3J59Umw9faPq3LrR1X2pj/XVU/r6p79PCch6jqP+y6UYausOtdloz9H1X1MUmbskq4Zu9vsD64UVXvbn97kY3vTap6jV0zzu84x1/Yqs3xXqq6sap+1+bdddbWW1V1laquNnnaNfl8bM/7rT03GSl265c4h19l3zs33VOT/P9Z1o5zVHXXTJ+eq6p3mGxfY7rkAlWdNplfoar/Stoome/XVPV1qnqGjfW1NkdutmdeYc99rqq+0Z53YaKzXptpa3z/tP3/fJtPi1X1k9b/tyb640ZVvcXu+y8z9Dbot+SaP1PVdabvrrU2nJe09ya7/nbJPN5IVb9mMnat3e8mVV1uPx+nqjuqquTxkOqEfUWShnJUtZ01polXlS2xMU1IiWwAV6nqo4CvmVv5d+BE4Bz7fR/gceYFHAosEZEXt1Lc0RW1th0JPN+Y+zbgNOAfwNn2LLvatR8EvBm4m4gcrqqX2/9ua/NMl5olcEvmOeNz3WjtvlVVXwV8mJAC+nPgb8BZ1if7meW7PfAys3zf3OKaqeAuJOx9ONjat8r66xTg32aR3BO4DyET8GHAw1X1/SLyo1bWcxqfV9UjgNcDa+z1L/OGzrM27WRW0cOAHYAPq+pDgVebdZW1QBvWT6vMMv6KWY4/Nit6U+AUEbnCPn8b8F/gyiTEkF7vBuvfy42wfmPP+x/gG2bRXwNsBexv/bsr8ANVPVRE/tumD6LHcDjwfrv3SkJ26N+Ac+0ZtjQvZT/gOcADVfXZhO0AyxOZmFWITlU3AY6yvhKz1k8x2T3L2rITsBtwb2vP44BHqur7ROTHrbyB5DnfarK21tp8qj3rheYN38Pmxb1NPo9R1Y+LyKfMIGq1vrAWuBW4ArhFVd8JvMHm+bdt/l1s3vKBwJPN8v+Mqq6yNqdjI9YXrzV5Ww6cAPzKxudA87QfbPL0GBG52dZqsOe60WSm3mpetcFywpaDq7p8vsZdM8o+y8wWlwebx34D8EHzlqKHpElUJT7nYtOB+5uXeqXJ83nA5aYfdrOoxSNMTncWkdeah3GVyWwr3Gr3vdz6/BjTIWcA37Oxuca8sYeZ97IY+K6qHiYif0/GJvbJd0wm15iueRRwu+nd+KzTFgmKz/gqk9ObzSP6tV3rQPv7viYrT83r1VxoluJ9Zmn97WlsfbmqfsQstXNV9emtrBhj1s/b/W9U1UNbWf0Je3/YWP8SVf25qj6wQ5vuq6rfN8b+tKr+1qyQ17TwkGqq+gdj9bckHkvqRV5jffQze74zzEVtde/NrX2XmqWyf5vnioT0TWvbtap6fJfn2k9Vf2VtuSapfFBpMyavsDZcbOPx2HZelareR1W/Y+2+TVU/k+n/eM2dzIo/36yn21T19S2uFy3GF5gFfaKFdTewylX1W2Yh/9K8paaqfsLCl63aeaBZetdaeyupx5Vp60vNir3OZPFptt7X6rrbmFd7tVnv3zNL8YezCdNZ2+bbuN1g7T5WVffu8t2nmdd2no3JUzpYtofbdc9T1d9YOKflXLXr/sO8geUWespeN47d681jOUdVv2Ey9+PoRbSZd6eaB3quqm7RYrwXq+pJJj8faHONU8woiG2O7TnCPIr/quo2PXhI/2tt+n1m7qce0vU2r3Zvd13ztG6P3nyOMf+F6bZLrP927/C9Q1T1bJtPbzddcJ2qvqyNh/R+m9unml5S0yV3a3P9g+36V6rqyeaFdYre7Ge67o9xja/FZ5bYtS5U1Y+1+P9D7PuPz5vUEBfGGsCzTJAXJBknkli1dfvcOmPaH4jIdWxY2aFq7Pps+/zzRORvNkDVhInjHpV3mEezFHiaqv7C4qAxThqtv0OAZ5hVcArwpriGwIY7qmOc/kxVfR3wRfPAbkkYvhXiQnIjs7YW48tVsxb3MYvhJSJyVqLc0+e62YjvT/bdFwN/Ti2z5LkOs3W3W4H/A55tcfFqC49Uzap5gVkc9wferar/BO5IY8zWhzsBr7P23gg8Q0SuNiGstuizsy3U8hmzdJ+jqr9Pqlak+9EaJhdLLX59ZIboUqsrylc7y3Sejc3uts73ERF5Z4bE1dpZEZE/quox5vU92CzKS+K6V+KR7Aa8nbCx71bgWSJyUYvnj5b7dcB7bP0rrg/cNttwnbXlg8D9zLM/SkQ+2uL5yIzHT1T1AsKWhCXAPVX1uDSaYTJ0gHktN5m38lIRua2NDDXtuueaFX0N8FZVPUVE/tnC06wmY/RU8yxfbHO3lll7rtm8e695zVvZGuCxdp04t7YibMJvAkcnGV0NG4czVfUgEVmT9F8lmYuVPta7NfHue1pLT5JO6nbvdRaxWcBMZZtmCy/wveaV3GTrS29uI9PY3P6Zqp4PfMuiK9faveoddHfD1onuD/wIeJmI1G1smslzVUTktxZGfzehMs1+InJiWpHGnjWOxYKkjUtUdX3aR/a8W1mEAeCryVjGxIy/qeoTLRkpFyE1rJNvI5TQ2ThJgawlhBVz9Js2qbY01zMlJE0WyhcDH7IGbZB1FTvT/r5CVX8FvNEWw7YUkeuMwOLnNgZeafe/GHi9LXi2XdRX1Zot3h0O/MQEar0NcCth1Q5CHJVr0/rqY0ZG7Z6rKiLXqOpvTbDupapL7VnTxIwl9v+1tkj7v0ZG86wPNdMWUdV5InKrhWd+ZKGrZ4rIUSaE9WRCvNCSAdYArzEyitduZp/Tvt8AjgB2sQX9V6vqidb37Yj8y9nMOLteNpOz0kERrLfw30lGspU2GXhROR1LKEO0sYXALknkML6/JAnXPN/IaIqQ2t9o5+mLyKdV9f72/I1+M+0SYnygJcWsBH4nIh9t93wtZPjfqvoiYJERhiQbutVk6C0m17fbON/WZW5MiciFqvpGC9GsA95lRoi2UdI1k9G3RDJqsT1i2pTbSWZcPdIMuGOZqfyiSTZbhbAhn0TBxX5b0yaRI36v1zFJ53A7wpJWesDGsG79Pm39NR2zFjML+3Hu3QN4oY352cDbu21zsXE5X1VfaQZn1e5T7fBM6+39UuDwSEYtxibOm6OtXfeycNyJLZ41PhcpGabPmhgIUzZv78xaJUlDtzFcG8cyT3JCtBTn2XrF74CTLZvshCQm+Et7/cL+dpwxf1ZYMGa9Cvi2TZy2DG//v9CUcsXWcUi8DbW4947Wzi90IyPrvDgw15mFudiItJMgV9oMviYK8yLgZ12eK7rBp9hnaokVIYnCfCihvhvA+0TkFmv7ehFpWnZO+mrG9HTLvjraxu0xpmgbiRJcajHpKeC7InJml2uriNTtfQ3wMVPk9wDuY4qhkllXm28x8QttnJodCGfKXtLGKIrVP75h4ypdUlNvMxKqWCZSmtXUUNXtTW7q9vznmcxMt8vIsuvG9h2ZyML0LJMZnmGK9ybgA2m2XRfPqm7jeV5CRqkn3gQeDuxtbf2KiFxvct9pbkzbZ/5sa6DzgPur6n0zyibK/jozbE4yhVlrlTUV22b3vsi+u1VS9SQt1XWrycMro+xZmDwq9Hbjr21+zmN4Q/cNnt3+X08M2GaH7z8pkZ33m+EqOcZlyubqMdbnzQ6ENG3PtRnw9WTs242Nisg6W0urmmfVqR8rNierHcbhOjNUFgGv6zaWtZyEhE2YD1lK9FQygHn2BzUzP8d04Fu7pDyrTYDLLWRTs869JPO5fYGNbBH6pKh08lhFNvlPNGt5WYfOjwPfKaRXA/5sjN+JEONzrU7SJjfODHTTLPAlNqhnqermiQWYDR9ohszWA2fawvhuwHYicnnciGbK+G5mNZ9hlvSCFiEckhBIIwkD/Bu4wBY2H2HecLY/NgHOs4nUKS05Ev1UB8Kab0ZMx3JUyYLxtKpeYX24UeZeDQtJbGeK79cxnNeDzJxjSRX3MWOp57WjZFH7wab0f98q5TZHuK/Vhuj4LAdYX10PHG9tb+RroooZNU82Gb2fyVTW8IhK+LTomeW4/s32vU3t2dclYcaVqvonS5o5UFU/BXxURG5KPcsOstJIIju9huy0zRxP9x81u1ynyczeveyacByvu5vMn5J6tnmI067zK+C5FhKvdtG7q4E/x/vnCEneYPN3SQ5umN9q3ibLKber6o+BtwKPV9VPG4/c0mos826MrSVuFxbS6JjX32Gw1lon/ivZmdzoIiQxs2yTTCfF/9/DJsxZSbiiFyG82lzafRNrV9sQc6ODECpwdQ/3X2Eu+zzz0O6M49s1drX7VS2e37D/z8uEJ1pZaWusTXcQ9khsZ9k28fObGQFdS8gInE7CJZqJL08lzx4V0LT9fZ2FUtM+q5tAi3lI0LnWlWRerazXKeByC9d2qygcZSruAVmYmXAQMsk2Av4d143ybLxOJto62/N0vw6eMDkm/87mHdeB3/Wg0LOeWzvZ3sHm7sUisryHasxNe9YLzPC4t63hkchkHOt1dr9z7Tt5rn+LfW9hRqFG2f+sydVBwLOAh6jq182bXd+BtDVZQujZTsgho/Uc49NuXkb52ZiQxThta24kSxld22jXuNQM1a26EO9802+X2Pe6yWT0UNX0dKd+iRtr57VpQxzLTxsBP9FyBx6qqp+3HIN6OpZ5Q3bxplORRJL8/w1ekZTaKOVmoiwv7aG0S8MUZfxuVoA2MeV6cU63OnVTK+Yu35hhemkjsI0Oz7WesNm32ybi+L+1JpTTmcXzpk3U7e3aC6z/Fxlx1eJ42HtasSGu5UWvY7XdZ1GmDYuZSeefZ8p5mf19SfJalNxnvrVloX1+vSmW9S2szKikbs1BSJVOk9ieI5JrL8gej5JajbvY88wmKeFmk4d+CQkjpI2sv64poW7ZInvOy9MTPnsg3rVmVLQbnyi/K82y7mVsovWuLcJ6K2wt45M2N7cD/h/wY1V9uBmerdqzLpkDjR5Cd42M/Laas8rMOnknTHXw9knm7nozEnsNL8YIxHIb22YHD6lpcrqyh2vHvlvfZe5GHdNSNpJQ/1qLQL3DyHF74COEbRn7pmOZx0NKFxjjgpX2OXGigKzpsYMaiZVcbWFlroqTr49DsTQzQaTD4GoHDykK6u19KKUa7ReLNyHsu/lwJmxQyXwuWoaShNY0sWZvz4xBLLdzi61hxJCotLiHJteqtwjfrW/RH5GgV+WccJ08g7q19fYcn81OrKyBIsl4zbdXL9dMwy/0ERpq9dzdCLn3i244Pxcxi3UuM1yabYg3Kr1VPRJzDJFOdQi7NoCPW1r9CwmVH/YAjlLVL4jIl1rsk5mmfXJSt2UF6RKyX0u+4qrz2ujWeP04j9fPYswlY4TSwVBeSbIHKse163RO8Mi2IV3KuEsfJmui31DVE2wsH2vh9KNtLL+gqpW8hDTFhucf9YtoOc/v41pZ4kgRzx7ZuYeQQRrHX8RMUkSneOx0l/BircP3u5F0dgDXmOu8n7npNxalq+w9ei4LgZvMIi0SMcmh2aNCaDdBmi2IL4/Sq7YgJCwMtR7YJFlX60nh25HrOov+wSzkleZ57qCqVxXR+UloLiq9XXqZG0nIpUYomZV6qNLCc5A++kI6hbbsOaq2gfp9qvojwqGf9wfeaZltX814SrcYcczv4qW0khXpMl71HMTeSuayodXlFm7bhZmkpV714RRh3blO57XXdIyKCF32/PnMWF5L2Fj/E8KWk0cC71XV9SLy1UrOmynFHDaVVoGu9igs0Xqvtejwf9gg72uLxOT0lOJmyb0sPt7sMLhRIbYLA/R7Lkh2IitQNeG9MH2udINnjle1hTWftvsaUzA7A/ewrJdazmtXco5Z3v7IE/fvR/7mdfA8zrZQxo6ExIxcx6Yn6dSbmszcGXLq88jqSyyMMQU8OoaReySfSosxiW250JTofS2zUvO0M7ne7oSqGA1CNY2szKZVsKXHOd31e3FN2Dyh8wk1Jc80w/Yltl0ilZv/2jytJrpCOj+qCqECRgW4rU1dNe0S0svuSay22ThbtSzVf9vn7t9DQg3MZOhGMlvVYd5UaJ+kkSfU3e17jZyeVHYsqyJykYi8hlAtYhXwPFVdlkfwY+hlmmIrG2uPSjuuY7RK6/yTWRxbEzbaNpkpB99JsUQr8qXMpDDWOoR/6m36IGaBzevDBW+VSh7vcZIR0rbAo2JqdZuU7DtfzJQE+l9VfUrmuIdIqGcR1gaWAIfEv+e8dlNVH6yqL47pm22eKe9kSEN82sWj6AV38Vgzz38+Yc3s+fZskkNZ12wcDiWsa6zuJ3KQpE+vJmQOriSUANqGkElVzUtGlqbfzCjA2Kbf24TfDniaPWeeyEjcUvFMQlLMcmYyHDWjgPs5/6eaRF86ESJJ8dG4r+/zpgy3JmQops97rcnSRsAuecjXnnNXu8Z1bYyLJnfNZO1kiDW76LgLbFzuBzwwKe7btd+svc82fbO+Q6hU6C+qNT+nwxDnbb0TWac6IikSHZ/1i2ZcbAbsm0eIGslNSZIaWr3ukuDQgYj6saY26OA4Ca1q98+srS9W1fvHvP60M5KSHTX7ft02FT4ucfMrfYQMK8wkHvRDSFkrPhLIPwn7NaaBl6nq4mSXdUuSjXtMrOrxe4EvqOqzknOH7tyMRtgHtRY4zBYX62lhyRbXj9deTNiH8xXC3hZtoQyrPXjW0cpqdPlMr32bpgCTeDJxsf6H9r9HqeozzTIW8xQrGbmpWr9NW9++0BRKbRaGWjSIfmyKZRvgrcmkrXbximo2B56gqo9Nzp2K4bYKIR3/H/a3l6rq3eI+ow4yNGWy8EDgadbvp4jIZS1Srit0P0W1U7iu5Xfjs2T0SOyTm5Lw7dLMV281UlkA/E8k4DY1MKs21+6eENv5yXP1o9yj99joEAYVwn7OqwmJRO9T1WU55/a0qj7EDKLbrJ3dCKnXZYSpnCHPZhdD/c59f6lRnPRD1cZrVZSHPBM83e27Ntkg2WzxylrT7dzefkJbbUOH9qCftPDEUuBIVX20tamRZO7EzaN1I9XXEMpkNJM2SZcYc6WNmx4TLqo9PhMtiFZNWdUJG1CVsJfo06q6xAQ3kms12WQWN53dH/iyWbXXEvYZpYufUTi+moSLPq+qe6dnUCXXriQEvgnwffPabjYLvNVzSQ9edZ7JXslp2WettFaVFKKy/jFhk/dGwDtiTbBEvlO5aZiSPIiQxroZG6bJ98NGcaPyacAPzFt9vKp+RlUXpLvZ07GIa582Hk8EPg58TlVflBwNH9u+jpDRFLdNHKWqu8SwVBsZmlbVfcx6XUjInvt4GyNTktBQr1GPrJGZ1hp8dNQjiQxWrE/uY/N8hcn3netdIrKScLQN1pdPt83emjWeE93wTluPWZfxArPy12nzdnbLw7pWOjCZ22vMqJtPSKn/rqpunWNu72O6blkSMZrudT0rx1ybykFI2USndpGAg80IbDWW9yJse1gL3JiXkKL1uqcdLbCXqu6hqrur6m5WBn5XVb27vXZS1Z2TgnsyS9aOyRB3yeiKu+ftMKzXGePuYKT0cVV9nKruYFbvImv3s8w6fo8N6ustlr+wjbURQ4adJl01sch7mZRw1xp5qff3D+ALFjZ5DPATVT0gIddGYoEsU9VXECpGL7DvvFtELk6s8XRS3EZIpa0RNigebQUca5lrN02QnkrYkPcA+/yXW1RrTi2nvIkI3WLdTXpLhEk3MNazY5rZlf5mU0Jbm0f5U1V9rqrey4pL1kyen6iqR5ryvxvwKUL5m6X0nmyRXcOoAB+10PNS80p+adXwyY6FjfVuVnj0IzaZV9i6YFaGqiZD77Jr7wwca8VC57eRoVeaDC2xsXmziFzDhtUx0tpvMfW734XztIbjfNs8+W0rZLs0ee66nb/0BhvTayKBxMPtjDS/Yd7DAuCjdrTD0qzxbOP6RcL5V4sIZ6+d02bjrdC+UksrA35du3XFZG7/xozCZYTkpZ+r6pPazO2NrEbll804/bk947wuYe5+wqnNjJeoXSJojRbeXCTVD5nhd6SqbpkZy3jiQpWw6f3MvMdPQMheeXMSm0+9HM1YoqsJmTmvMWslblSMiqfao+KOazhrW30vGeCLVfV5plj2I9QyezZhH8NyI5XtjZGbhBLv7xaR39sk7Nam9R0Iq5GQZq+D3zJNNVEon7UK1Ifbcx2jqufYwuiV1p+7EJIzdrR+niaUXfltu5M17dq/T47L2B74nIV2ziQcKVAzgr8/YQNy9AQ/ISLv77Brftqs8umcfaAdlFqty/pSO6yxa65rt4Zjm0WfaQRzqIVvn2CWdyxeuYl5RBVTgu8Qke8aQU314Lm1syCx6h4vIxwv8HRCJY1jrMjpv+2+0zav9iSkP29qc+1q4F0icka2pE4M/YnI91S1YeO8mz3vK0yOLjG53s0s1lgN+g5CkeI/dtiIWrc29Jr2nW6wTkmumsjwiy2cepYZmjsRElCW2Li8J/Eym8mY3mB9+X0bt/cCz1TV85g54mQ7u9bWds+/Au/qsDG5zkyKtXbREWvZcL9kW0NERN5j4/IGG9ejTBedaWMeN8jHxKt5wJEi8iFVPSkxCDrNq15DylHPrcnBDauZ2QTfat7ubP37DMKxLX8xIt3VwqQb23U+lvfE2JoxuLDhrv20nEzc6xJDe3H9YGWGYSs2ibZkpkxNXmxh7ah1GOCqiFxCyNh4knkUuxB2M29l7bzSSPI04CdWCDJuVOuU6bWleRxTLby+mgn2yh5CVOn3au36IylY+HFVPd2Mgvsyc+5Pw5TBGiPdqwkZZF8QkUu7HEccJ/NPTTG9jlD77N7mBaUCHfdYXWTX/kOHemKxftxmzOzz6YSFFgJcRev9DMvs/0t6lJmlFo5b0GbdMiqF9cBrVfVYQlWAPYycN2PDs4P+AxxnhXErycL8qhZt7pWUxDy2t6nq74EX2Rg8yMa5msy1VTbO/zBZ/k6HYqPpOP/QToR9s3kF97FF9Uja64yErjIF/cVYyLgFGcW+nGfzYl2Plvh8I/plyffEKvQfRqjC/kxC8dV4VMZaMy4vJlR8/3sLAo6G1l/sgMF32rPuYgo96qw15lVeSai9+VkzCrKVLCSRpa3ovv1lvumKhXkMEbvf+1X1r0ZKe5vx96Bk3q2zuX0a4aTcX1mpr6gT2+nSjewzm2aKu2qOsZnPTMkt6WAobsGGey/T+nTrgWfb8SXPN0Njz4QsVxO2PXxARP6qqtIxC806bb6xs7YJr6Q7nJvJe4VQrmJti2tVCaVMcu28t4X2e9j3/mOTr2XHZv9uAxeJpA7cEesoJQubywjFYrcFXmthqGoSwxdmjrS+0o6PSCv4LjYl3iCUolmd89jkRfZcABfEat9tnqua7Gje2xTJ3olXcbOFkC4XkavT7+To3/RZdyak+cZjs2PI6982Zv9JEiOaHcZrL5so/21XszDph61NYawk1L7LhgB2NcG/zurx5Try3Qqobg7cKCLXdhmT9Mj6mslCPD5ghYjcnD6frbMcTSiS+SYRObpd4coeYneShsXsbJxdmalpGNcnzjLD4OJYTLeXI8zt573MG9qLmaodKy0J4kIrOkyOY8Y3N8+lbnNzfc5n3cqs59vtfs0Wn9mecIjbPU353W4hupOs3l2niuXps+5h8+w+pmjr5nH9y9p8UztlnTznFqYDVtscX9+iircmz3WTGcd5+iKVvXjQ5u5GamtMaf8rzo3kSJ17mkFweXyGFvK/CyGV/dw88pd8b2fgZiuW204nLbU+WWNjWO8y3vuYkbXIvvNv4I82ll3ld2ygqgtUdanFWTdYEGwnAJl9N/ezg67OtrLwPR/TPqDnrOT9XD/HzOf5Tg/7kEZdZuabvCyLC8c5ZSYmFmxvhwBeamdxkTdVO+dYSM7PVnvZ/9TDOFeGNc7ZfXT9zoUenrXa5x6yocztMZtnPY1lbRad0DU80cbqufNQv17KD7X6XmIFPcgWB5vAt0TkE/EAqmh1ppeKbn3iOr/QnuU6LO2zxXHXbdudqRGW+7l6/V6S1iud+r8fSyM9a6bNteMBgN1i6D2Pc9IP2kVmtJdnS/pKW4QstgV+alboSSLyKitioB1kpkLYBzJtJLRlEt6Cgvbp5R0LknNlCr52M28/dxu7fr5n49No08bc7cvxrOTtw3Sudjmjqq/+yDm3N7hmtzlWxtj0+rlkLNNszL5kbVzYV1R1nh1vfZkdi3xQG8t2gzRm+//LVPU/djzx84q0dB0jKzfx+PL3qurNdnz0S7vITJqSfLAdBX69qr5rHC1Xh8NRrnLZyUIol6nqOap6hKru0uF797S08HNMKX07uyHSMbEyEw2Zxar6ewvXXqyqH1LVvTt8b3dVfY+qXq6qt6nqyaq6scuMw1EMJmISJaeg3ouwmW9PQgLErYSMs0sJ2TRKyGq7OyEJYZld4gTCseerezgvxjEZMrM5YaPhowlJDDcSDnq81H6uEkJzdycsym5DCM2dTjhS/gqXGYfDCSmrYGIW2jLgfwnZT7syk2EX9/o0CdlE1xEylX4oIsdHy9kVy9zylJK1pUOBwwjZWDFtNz08ch1h/8RVwI+Ab1sG6eRkBzkcTkjFW73283zCCbDbGCnFQoR3EFKkLxWRC6JigtxnhTgmTGbYMOnhvoRU1i0J6alVwn6Vq82I+VcvqdYOhyM//j9tKsMHJmGmuAAAAABJRU5ErkJggg==';

/* ================= الفترات الضريبية الربع سنوية (وفق شهادة الهيئة) ================= */
const quarterOfYM = (ym)=>{ const parts=ym.split('-'); const y=parseInt(parts[0],10), m=parseInt(parts[1],10); return y+'-Q'+(Math.floor((m-1)/3)+1); };
const quarterMonths = (qk)=>{ const parts=qk.split('-Q'); const y=parseInt(parts[0],10), q=parseInt(parts[1],10); const s=(q-1)*3+1; return [0,1,2].map(i=> y+'-'+String(s+i).padStart(2,'0')); };
const quarterLabel = (qk)=>{ const ms=quarterMonths(qk); return fmtMonth(ms[0])+' — '+fmtMonth(ms[2]); };
const quarterDueDate = (qk)=>{ const parts=qk.split('-Q'); let y=parseInt(parts[0],10); const q=parseInt(parts[1],10); let m=q*3+1; if(m>12){m-=12;y++;} return y+'-'+String(m).padStart(2,'0')+'-28'; };
const quarterEndDate = (qk)=>{ const ms=quarterMonths(qk); const parts=ms[2].split('-'); const y=parseInt(parts[0],10), m=parseInt(parts[1],10); return y+'-'+String(m).padStart(2,'0')+'-'+new Date(y,m,0).getDate(); };
const listQuarters = ()=>{
  const cur = quarterOfYM(currentYM());
  const cparts=cur.split('-Q'); const cy=parseInt(cparts[0],10), cq=parseInt(cparts[1],10);
  const regQ = quarterOfYM((COMPANY.vatRegDate||'2026-07-01').slice(0,7));
  const rparts=regQ.split('-Q'); let y=parseInt(rparts[0],10), q=parseInt(rparts[1],10);
  const arr=[];
  while(y<cy || (y===cy && q<=cq)){ arr.push(y+'-Q'+q); q++; if(q>4){q=1;y++;} }
  if(arr.length===0) arr.push(cur);
  return arr;
};

/* ================= هيكل الـ ERP: مراحل المشروع والاعتمادات ================= */
const TIMELINE_STAGES = [
  {key:'design', label:'تصميم'},
  {key:'detailed', label:'مخططات تفصيلية'},
  {key:'tender', label:'مناقصات'},
  {key:'approvals', label:'الاعتمادات الحكومية'},
  {key:'permit', label:'إجازة البناء'},
  {key:'supervision', label:'الإشراف'},
  {key:'handover', label:'التسليم'},
];
const STAGE_STATUSES = ['لم تبدأ','جارية','مكتملة'];
const APPROVAL_ITEMS = ['تخطيط ومساحة','كهرباء','مياه','غاز','اتصالات','دفاع مدني','بلدية','دائرة الإسكان (اختياري)','إجازة البناء'];
const EMIRATES = ['الشارقة','دبي','أبوظبي','عجمان','أم القيوين','رأس الخيمة','الفجيرة'];
const PROJECT_TYPES = ['فيلا سكنية','مبنى سكني','مبنى تجاري','مستودع','مجمع سكني','سكن عمال','مبنى إداري','أخرى'];
const CONTRACT_TYPES = ['تصميم واعتماد','إشراف','تصميم + اعتماد + إشراف (شامل)','تعديل مخططات','أعمال إضافية','أخرى'];
const DECISION_CATEGORIES = ['اعتماد المالك','تعديل تصميمي','أمر تغيير (Variation)','مهمة','اجتماع / موعد','ملاحظة دائرة حكومية','ملاحظة موقع / مخاطرة','مالية','ملخص اجتماع','أخرى'];
const DECISION_STATUSES = ['مفتوح','منفذ','مؤجل','ملغى'];
const CONTRACT_CATEGORIES = ['خدمات استشارية','مقاول رئيسي','مقاول باطن'];
const SUBCONTRACT_TYPES = ['مسابح','مصاعد','حجر','تكييف','ألمنيوم','كهرباء','سباكة','لاندسكيب','أخرى'];

/* ================= Constants ================= */
const GOV_DEPARTMENTS = [
  'دائرة التخطيط والمساحة',
  'هيئة كهرباء ومياه وغاز (سيوا)',
  'الاتصالات',
  'الدفاع المدني',
  'البلدية',
  'أخرى',
];
const OFFICE_CATEGORIES = ['إيجار','اتصالات وإنترنت','رخص وتجديدات حكومية','صيانة','قرطاسية ومكتبية','برامج واشتراكات','ضيافة','أخرى'];
const OTHER_INCOME_CATEGORIES = ['بيع أصول','إيجار فرعي','عمولة / استشارة سريعة','استرداد','فوائد بنكية','أخرى'];
const OFFICE_VENDORS = ['Etisalat','du','SEWA','Autodesk','Microsoft','Adobe'];
const PROJECT_COST_CATEGORIES = ['طباعة مخططات','مواصلات وزيارات موقع','فحوصات ومختبرات','استشاري خارجي / تعهيد','تصديقات ومعاملات','أخرى'];

/* ================= Seed Data ================= */
const seedData = () => ({"projects":[],"contracts":[],"decisions":[],"auditLog":[],"staffDir":[],"payments":[],"recurringBills":[],"govFees":[],"officeExpenses":[],"projectCosts":[],"treasury":[],"otherIncome":[],"employees":[],"overtime":[],"advances":[],"leaves":[],"timesheets":[],"cars":[],"attendance":{},"fccState":{},"settings":{"projectsRoot":"","bankName":"","iban":"","accountName":""}}); // Real office data is loaded from authenticated Supabase.

/* ================= Migration (from old data model) ================= */
function migrateData(parsed){
  const out = {...parsed};
  if(!Object.prototype.hasOwnProperty.call(parsed, 'recurringBills')) out.recurringBills = [];
  if(Array.isArray(parsed.projects)){
    out.projects = parsed.projects.map((p,idx)=>({
      designFee: p.designFee!==undefined ? p.designFee : (p.budget||0),
      supervisionMonthly: p.supervisionMonthly||0,
      supervisionMonths: p.supervisionMonths||0,
      owner: p.owner!==undefined ? p.owner : (p.client||''),
      plotNumber: p.plotNumber||'',
      landType: p.landType || (p.grantNumber ? 'منحة' : 'ملك'),
      ownershipNumber: p.ownershipNumber||'',
      projectNo: p.projectNo || (105+idx),
      emirate: p.emirate||'الشارقة',
      area: p.area||'',
      projectType: p.projectType||'',
      owningEntity: p.owningEntity||'',
      engineer: p.engineer||'',
      timeline: p.timeline||{},
      approvals: p.approvals||{},
      ...p,
    }));
  }
  if(Array.isArray(parsed.invoices) && !Array.isArray(parsed.payments)){
    out.payments = parsed.invoices.map(i=>({
      id:i.id, projectId:i.projectId, phase:'تصميم',
      label:'فاتورة سابقة رقم '+(i.number||'—'),
      amount:i.amount, date:i.date, dueDate:i.dueDate, status:i.status, _ts:i._ts||0,
    }));
  }
  if(Array.isArray(parsed.expenses) && !Array.isArray(parsed.officeExpenses) && !Array.isArray(parsed.projectCosts)){
    out.officeExpenses = parsed.expenses.filter(e=>!e.projectId).map(e=>({...e, category: OFFICE_CATEGORIES.includes(e.category)?e.category:'أخرى'}));
    out.projectCosts = parsed.expenses.filter(e=>e.projectId).map(e=>({...e, category: PROJECT_COST_CATEGORIES.includes(e.category)?e.category:'أخرى'}));
  }
  if(!Array.isArray(out.govFees)) out.govFees = [];
  if(!Array.isArray(out.treasury)) out.treasury = [];
  if(Array.isArray(out.contracts)) out.contracts = out.contracts.map(c=>({category:'خدمات استشارية', ...c}));
  if(!Array.isArray(out.contracts)){
    out.contracts = [];
    (out.projects||[]).forEach(p=>{
      if((p.designFee||0)>0) out.contracts.push({id:'mig-d-'+p.id, projectId:p.id, type:'تصميم واعتماد', description:'أتعاب التصميم واعتماد المخططات', value:p.designFee, date:p.startDate||todayISO(), status: p.status==='منتهٍ'?'منتهٍ':'سارٍ', _ts:1});
      if((p.supervisionMonthly||0)>0) out.contracts.push({id:'mig-s-'+p.id, projectId:p.id, type:'إشراف', description:'الإشراف الهندسي الشهري', supervisionMonthly:p.supervisionMonthly, supervisionMonths:p.supervisionMonths||0, value:(p.supervisionMonthly||0)*(p.supervisionMonths||0), date:p.startDate||todayISO(), status: p.status==='منتهٍ'?'منتهٍ':'سارٍ', _ts:2});
    });
    if(Array.isArray(out.payments)){
      out.payments = out.payments.map(pay=>{
        if(pay.contractId) return pay;
        if(pay.phase==='تصميم') return {...pay, contractId:'mig-d-'+pay.projectId};
        if(pay.phase==='إشراف') return {...pay, contractId:'mig-s-'+pay.projectId};
        return pay;
      });
    }
  }
  if(!Array.isArray(out.decisions)) out.decisions = [];
  if(!Array.isArray(out.auditLog)) out.auditLog = [];
  if(!Array.isArray(out.staffDir)) out.staffDir = [];
  if(typeof out.fccState !== 'object' || out.fccState===null || Array.isArray(out.fccState)) out.fccState = {};
  out.settings = Object.assign({projectsRoot:'D:\\Projects', bankName:'', iban:'', accountName:''}, out.settings||{});
  out.govFees = out.govFees.map(g=>({account:'البنك', ...g}));
  if(Array.isArray(out.officeExpenses)) out.officeExpenses = out.officeExpenses.map(e=>({account:'البنك', ...e}));
  if(Array.isArray(out.projectCosts)) out.projectCosts = out.projectCosts.map(e=>({account:'البنك', ...e}));
  if(!Array.isArray(out.leaves)) out.leaves = [];
  if(!Array.isArray(out.timesheets)) out.timesheets = [];
  if(!Array.isArray(out.otherIncome)) out.otherIncome = [];
  delete out.invoices; delete out.expenses;
  return out;
}

/* ================= Icons ================= */
const I = {
  dash:(p)=>(<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" {...p}><rect x="3" y="3" width="8" height="8" rx="1"/><rect x="13" y="3" width="8" height="5" rx="1"/><rect x="13" y="11" width="8" height="10" rx="1"/><rect x="3" y="14" width="8" height="7" rx="1"/></svg>),
  compass:(p)=>(<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" {...p}><circle cx="12" cy="12" r="9"/><path d="M15 9l-2 6-6 2 2-6 6-2z"/></svg>),
  receipt:(p)=>(<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" {...p}><path d="M6 3h12v18l-3-2-3 2-3-2-3 2V3z"/><path d="M9 8h6M9 12h6"/></svg>),
  landmark:(p)=>(<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" {...p}><path d="M3 9l9-5 9 5H3z"/><path d="M5 9v9M9.5 9v9M14.5 9v9M19 9v9"/><path d="M3 18h18v2.5H3z"/></svg>),
  coin:(p)=>(<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" {...p}><circle cx="12" cy="12" r="8"/><path d="M9 12h6M12 9v6"/></svg>),
  helmet:(p)=>(<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" {...p}><path d="M4 15a8 8 0 0 1 16 0"/><path d="M10 7.5V5h4v2.5"/><path d="M2.5 15h19v3h-19z"/></svg>),
  percent:(p)=>(<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" {...p}><circle cx="7" cy="7" r="2.5"/><circle cx="17" cy="17" r="2.5"/><path d="M18 6L6 18"/></svg>),
  chart:(p)=>(<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" {...p}><path d="M4 20V10M12 20V4M20 20v-7"/></svg>),
  users:(p)=>(<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" {...p}><circle cx="9" cy="8" r="3.2"/><path d="M2.5 20c1-3.5 3.5-5.5 6.5-5.5s5.5 2 6.5 5.5"/><circle cx="17.5" cy="8.5" r="2.5"/><path d="M15.8 14.7c2.3.3 4 2.1 4.7 5.3"/></svg>),
  calendar:(p)=>(<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" {...p}><rect x="3" y="5" width="18" height="16" rx="1.5"/><path d="M3 10h18M8 3v4M16 3v4"/><path d="M8 14l2 2 4-4"/></svg>),
  clock:(p)=>(<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" {...p}><circle cx="12" cy="13" r="8"/><path d="M12 9v4l3 2M9 2h6"/></svg>),
  handCoin:(p)=>(<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" {...p}><circle cx="12" cy="7" r="3"/><path d="M4 21c1-4 3.5-6 8-6s7 2 8 6"/></svg>),
  wallet:(p)=>(<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" {...p}><rect x="3" y="6" width="18" height="13" rx="1.5"/><path d="M3 10h18"/><circle cx="16" cy="14" r="1.3" fill="currentColor" stroke="none"/></svg>),
  car:(p)=>(<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" {...p}><path d="M4 16l1.5-5.5A2 2 0 0 1 7.4 9h9.2a2 2 0 0 1 1.9 1.5L20 16"/><rect x="2.5" y="16" width="19" height="4" rx="1"/><circle cx="7" cy="20" r="1.4"/><circle cx="17" cy="20" r="1.4"/></svg>),
  safe:(p)=>(<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" {...p}><rect x="3" y="4" width="18" height="16" rx="1.5"/><circle cx="12" cy="12" r="4"/><path d="M12 8v1.5M12 14.5V16M8 12h1.5M14.5 12H16"/></svg>),
  scale:(p)=>(<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" {...p}><path d="M12 3v18M8 21h8"/><path d="M12 5l6 2-2.5 6a3.5 3.5 0 0 0 5 0L18 7M12 5L6 7l2.5 6a3.5 3.5 0 0 1-5 0L6 7"/></svg>),
  target:(p)=>(<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" {...p}><circle cx="12" cy="12" r="9"/><circle cx="12" cy="12" r="5"/><circle cx="12" cy="12" r="1.4" fill="currentColor" stroke="none"/></svg>),
  spark:(p)=>(<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" {...p}><path d="M12 2l1.8 6.2L20 10l-6.2 1.8L12 18l-1.8-6.2L4 10l6.2-1.8L12 2z"/><path d="M19 15l.8 2.7L22.5 18.5l-2.7.8L19 22l-.8-2.7-2.7-.8 2.7-.8L19 15z"/></svg>),
  gear:(p)=>(<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" {...p}><circle cx="12" cy="12" r="3.2"/><path d="M12 2.5v3M12 18.5v3M2.5 12h3M18.5 12h3M5.3 5.3l2.1 2.1M16.6 16.6l2.1 2.1M18.7 5.3l-2.1 2.1M7.4 16.6l-2.1 2.1"/></svg>),
  docfile:(p)=>(<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" {...p}><path d="M6 2h9l4 4v16H6V2z"/><path d="M15 2v4h4M9 12h6M9 16h6"/></svg>),
  plus:(p)=>(<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" {...p}><path d="M12 5v14M5 12h14"/></svg>),
  edit:(p)=>(<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" {...p}><path d="M4 20l.9-3.6L16.5 5 19 7.5 7.4 19 4 20z"/></svg>),
  trash:(p)=>(<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" {...p}><path d="M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13"/></svg>),
  bell:(p)=>(<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" {...p}><path d="M6 10a6 6 0 0 1 12 0c0 4 1.5 5.5 1.5 5.5H4.5S6 14 6 10z"/><path d="M10 19a2 2 0 0 0 4 0"/></svg>),
  print:(p)=>(<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" {...p}><path d="M6 9V3h12v6M6 18H4a1 1 0 0 1-1-1v-5a1 1 0 0 1 1-1h16a1 1 0 0 1 1 1v5a1 1 0 0 1-1 1h-2"/><rect x="6" y="14" width="12" height="7"/></svg>),
};

/* ================= Nav config ================= */
const NAV = [
  {group:'نظرة عامة', items:[
    {key:'fcc', label:'مركز القيادة المالية', icon:I.target},
    {key:'dashboard', label:'لوحة التحكم', icon:I.dash},
  ]},
  {group:'المشاريع والإيرادات', items:[
    {key:'projects', label:'المشاريع (ملف المشروع)', icon:I.compass},
    {key:'contracts', label:'العقود', icon:I.docfile},
    {key:'payments', label:'الدفعات الاستشارية', icon:I.receipt},
    {key:'revenue', label:'الإيرادات', icon:I.chart},
    {key:'govFees', label:'الرسوم الحكومية', icon:I.landmark},
    {key:'decisions', label:'القرارات والوقائع', icon:I.bell},
  ]},
  {group:'المصروفات', items:[
    {key:'officeExpenses', label:'مصروفات المكتب', icon:I.coin},
    {key:'projectCosts', label:'تكاليف المشاريع', icon:I.helmet},
    {key:'recurringBills', label:'الفواتير الدورية', icon:I.bell},
  ]},
  {group:'الخزينة والذمم', items:[
    {key:'treasury', label:'الخزينة والبنك', icon:I.safe},
    {key:'dues', label:'الذمم — مدينون ودائنون', icon:I.scale},
  ]},
  {group:'الضريبة والتقارير', items:[
    {key:'vat', label:'ضريبة القيمة المضافة', icon:I.percent},
    {key:'statement', label:'كشف حساب مشروع', icon:I.docfile},
    {key:'reports', label:'التقارير المالية', icon:I.chart},
    {key:'analytics', label:'التحليلات الذكية', icon:I.spark},
  ]},
  {group:'الموارد البشرية', items:[
    {key:'employees', label:'الموظفون', icon:I.users},
    {key:'attendance', label:'الحضور والانصراف', icon:I.calendar},
    {key:'overtime', label:'الأوفرتايم', icon:I.clock},
    {key:'advances', label:'السلف والخصومات', icon:I.handCoin},
    {key:'leaves', label:'الإجازات', icon:I.calendar},
    {key:'timesheets', label:'تتبّع الوقت', icon:I.clock},
    {key:'payroll', label:'الرواتب', icon:I.wallet},
    {key:'docAlerts', label:'تنبيهات الوثائق', icon:I.bell},
  ]},
  {group:'الأصول والنظام', items:[
    {key:'cars', label:'سيارات الشركة', icon:I.car},
    {key:'settings', label:'الإعدادات', icon:I.gear},
    {key:'audit', label:'سجل التدقيق', icon:I.docfile},
    {key:'users', label:'المستخدمون والصلاحيات', icon:I.users},
  ]},
];

/* ================= بحث عام داخل الجداول ================= */
function rowSearchText(row, data){
  let s = Object.values(row).filter(v=> typeof v==='string' || typeof v==='number').join(' ');
  if(row.projectId){ const p = data.projects.find(x=>x.id===row.projectId); if(p) s += ' '+(p.projectNo||'')+' '+(p.name||'')+' '+(p.owner||'')+' '+(p.plotNumber||'')+' '+(p.ownershipNumber||'')+' '+((p.additionalOwners||[]).map(o=>o.name||'').join(' ')); }
  if(row.employeeId){ const e = data.employees.find(x=>x.id===row.employeeId); if(e) s += ' '+(e.name||''); }
  if(row.contractId){ const c = (data.contracts||[]).find(x=>x.id===row.contractId); if(c) s += ' '+(c.type||'')+' '+(c.description||''); }
  return String(s).toLowerCase();
}

/* ================= طبقة السحابة (Supabase) ================= */
const SB_CDN = ['../vendor/supabase-2.45.3.min.js'];
function loadScript(srcs){
  return new Promise((resolve, reject)=>{
    const tryNext = (i)=>{
      if(i>=srcs.length){ reject(new Error('cdn failed')); return; }
      const s = document.createElement('script');
      s.src = srcs[i];
      s.onload = ()=>resolve();
      s.onerror = ()=>tryNext(i+1);
      document.head.appendChild(s);
    };
    tryNext(0);
  });
}
// إعداد الربط السحابي الافتراضي للشركة — بحيث يتصل أي جهاز جديد تلقائياً من غير أي خطوة إضافية
const DEFAULT_SB_CONFIG = { url: 'https://kitsnfpgcrsxizzimgwx.supabase.co', key: 'sb_publishable_p3siT7m9YcUNnbRIjiCq0w_l-MVdplw' };
function getSbConfig(){
  try{
    const raw = JSON.parse(window.localStorage.getItem('nitaq-sb')||'null');
    if(raw && raw.disabled) return null; // المستخدم ألغى الربط يدوياً من هذا الجهاز تحديداً
    if(raw && raw.url && raw.key) return raw; // المستخدم حط إعداد مخصص خاص به
  }catch(e){}
  return DEFAULT_SB_CONFIG; // الإعداد الافتراضي للشركة
}
function setSbConfig(cfg){
  try{ window.localStorage.setItem('nitaq-sb', JSON.stringify(cfg)); }catch(e){}
}
const CLOUD_ENTITIES = ['projects','contracts','payments','govFees','officeExpenses','projectCosts','recurringBills','treasury','otherIncome','employees','overtime','advances','leaves','timesheets','cars','decisions','auditLog'];
const ENGINEER_VIEWS = ['projects','contracts','decisions','govFees','cars'];

function recordsToData(rows){
  const d = {projects:[],contracts:[],payments:[],govFees:[],officeExpenses:[],projectCosts:[],recurringBills:[],treasury:[],otherIncome:[],employees:[],overtime:[],advances:[],leaves:[],timesheets:[],cars:[],decisions:[],auditLog:[],staffDir:[],attendance:{},fccState:{},settings:{projectsRoot:'D:\\Projects', bankName:'', iban:'', accountName:''}};
  rows.forEach(r=>{
    if(r.entity==='settings'){ d.settings = {...d.settings, ...r.data}; return; }
    if(r.entity==='attendance'){ if(r.data && r.data.empId) d.attendance[r.data.empId] = r.data.map||{}; return; }
    if(r.entity==='fccState'){ d.fccState = (r.data && r.data.map)||{}; return; }
    if(r.entity==='staffDir'){ d.staffDir.push({id:r.id, ...r.data}); return; }
    if(CLOUD_ENTITIES.includes(r.entity)) d[r.entity].push(r.data);
  });
  return d;
}
function dataToRows(data){
  const rows = [];
  CLOUD_ENTITIES.forEach(entity=>{
    (data[entity]||[]).forEach(rec=>{ if(rec && rec.id) rows.push({id:String(rec.id), entity, data:rec}); });
  });
  Object.entries(data.attendance||{}).forEach(([empId, map])=>{
    rows.push({id:'att-'+empId, entity:'attendance', data:{empId, map}});
  });
  (data.employees||[]).forEach(e=>{ rows.push({id:'sd-'+e.id, entity:'staffDir', data:{empId:e.id, name:e.name||''}}); });
  rows.push({id:'fccState', entity:'fccState', data:{map:data.fccState||{}}});
  rows.push({id:'settings', entity:'settings', data:data.settings||{}});
  return rows;
}

/* ================= طبقة التخزين: تعمل داخل Claude وخارجه ================= */
/* NITAQ persistence safety, step 02. Production storage keys are unchanged. */
const NITAQ_PERSIST = (()=>{
  const arrays=['projects','contracts','payments','govFees','officeExpenses','projectCosts','recurringBills','treasury','otherIncome','employees','overtime','advances','leaves','timesheets','cars','decisions','auditLog','staffDir'];
  const objects=['attendance','fccState','settings'];
  const plain=v=>v!==null&&typeof v==='object'&&!Array.isArray(v);
  let known=false, baseline=null, rawRead=null, memory=null, revision=0, tail=Promise.resolve();
  let state={ready:false,locked:false,pending:false,kind:'loading',message:'جارٍ التحقق من البيانات المحفوظة…'};
  let resolveLocal;
  const localGate=new Promise(resolve=>{resolveLocal=resolve;});
  const listeners=new Set();
  function publish(p){state={...state,...p};for(const fn of listeners)fn({...state});}
  function fail(error,kind='save'){publish({locked:true,kind,message:(error&&error.message)||String(error)});}
  function parse(raw){
    if(typeof raw==='string'&&raw.length>20*1024*1024)throw Error('حجم محتوى البيانات أكبر من الحد المسموح.');
    if(typeof raw!=='string'||!raw.trim())throw Error('البيانات المحفوظة فارغة أو تالفة. لم يتم استبدالها.');
    return JSON.parse(raw,(key,value)=>{if(key==='__proto__'||key==='constructor'||key==='prototype')throw Error('مفتاح غير آمن في البيانات.');return value;});
  }
  function inactiveContractNumber(entity,row,field,value){
    if(entity!=='contracts'||!(value===''||value===null||value===undefined))return false;
    if(row.archived===true&&['designValue','supervisionMonthly','supervisionMonths','commissionPct','commissionAmount','value'].includes(field))return true;
    const consultancy=!row.category||row.category==='خدمات استشارية';
    const contractor=row.category==='مقاول رئيسي'||row.category==='مقاول باطن';
    const combo=(row.type||'').includes('شامل');
    if(field==='designValue')return !consultancy||!combo;
    if(field==='supervisionMonthly'||field==='supervisionMonths')return !consultancy||!(row.type==='إشراف'||combo);
    if(field==='commissionPct')return !(contractor&&row.commissionType==='نسبة %');
    if(field==='commissionAmount')return !(contractor&&row.commissionType==='مبلغ ثابت');
    if(field==='value')return consultancy&&(row.type==='إشراف'||combo);
    return false;
  }
  function contractRestoreProblem(row,data){
    const consultancy=!row.category||row.category==='خدمات استشارية';
    const combo=(row.type||'').includes('شامل');
    const fields=consultancy&&(row.type==='إشراف'||combo)?['supervisionMonthly','supervisionMonths']:['value'];
    if(consultancy&&combo)fields.push('designValue');
    if(!consultancy&&row.commissionType==='نسبة %')fields.push('commissionPct');
    if(!consultancy&&row.commissionType==='مبلغ ثابت')fields.push('commissionAmount');
    if(fields.some(key=>typeof row[key]!=='number'||!Number.isFinite(row[key])))return 'هذا العقد المؤرشف يحتوي قيمًا أو مددًا غير مكتملة. راجع بياناته وأكملها من المستندات قبل إعادة تفعيله.';
    if(!row.projectId||!(data.projects||[]).some(p=>String(p.id)===String(row.projectId)))return 'راجع ربط العقد بمشروع موجود قبل إعادة تفعيله.';
    return '';
  }
  function validate(d){
    if(!plain(d)||![...arrays,'invoices','expenses'].some(k=>Object.prototype.hasOwnProperty.call(d,k)))throw Error('المحتوى ليس بيانات نظام معروفة.');
    for(const key of [...arrays,'invoices','expenses']){
      if(!Object.prototype.hasOwnProperty.call(d,key))continue;
      if(!Array.isArray(d[key]))throw Error('قائمة '+key+' تالفة؛ لم يتم تفريغها.');
      const seen=new Set();
      for(const row of d[key]){
        if(!plain(row)||!((typeof row.id==='string'&&row.id.trim())||(typeof row.id==='number'&&Number.isSafeInteger(row.id))))throw Error('سجل أو معرف غير صالح في '+key);
        if(seen.has(String(row.id)))throw Error('معرف مكرر في '+key);seen.add(String(row.id));
      }
    }
    const numericFields=new Set(['amount','collectedAmount','baseSalary','grossSalary','hours','rate','value','designValue','designFee','supervisionMonthly','supervisionMonths','commissionPct','commissionAmount','budgetAmount','monthlyInstallment','days']);
    for(const entity of [...arrays,'invoices','expenses'])for(const row of d[entity]||[])for(const [field,value] of Object.entries(row))if(numericFields.has(field)&&!inactiveContractNumber(entity,row,field,value)&&(typeof value!=='number'||!Number.isFinite(value)))throw Error('رقم تالف في '+entity+'/'+row.id+'/'+field);
    for(const key of objects)if(Object.prototype.hasOwnProperty.call(d,key)&&!plain(d[key]))throw Error('الحقل '+key+' تالف.');
    if(d.attendance)for(const map of Object.values(d.attendance))if(!plain(map))throw Error('خريطة الحضور تالفة.');
    return d;
  }
  function prepare(raw){
    validate(raw);
    const result=migrateData(JSON.parse(JSON.stringify(raw)));
    for(const key of arrays)if(!Object.prototype.hasOwnProperty.call(result,key))result[key]=[];
    for(const key of objects)if(!Object.prototype.hasOwnProperty.call(result,key))result[key]={};
    return validate(result);
  }
  // IndexedDB is the selected browser backend. Legacy localStorage is read only
  // until a write has committed and its exact content has been verified.
  let accountingDatabasePromise;
  function accountingDatabase(){
    if(!accountingDatabasePromise){
      accountingDatabasePromise=new Promise((resolve,reject)=>{
        const request=indexedDB.open('nitaq-accounting-persistence-v1',1);
        request.onupgradeneeded=()=>request.result.createObjectStore('records');
        request.onerror=()=>reject(request.error||Error('تعذر فتح مخزن بيانات الحسابات.'));
        request.onblocked=()=>reject(Error('أغلق نوافذ الحسابات القديمة ثم أعد المحاولة.'));
        request.onsuccess=()=>{
          const database=request.result;
          database.onversionchange=()=>{database.close();accountingDatabasePromise=null;};
          resolve(database);
        };
      }).catch(error=>{accountingDatabasePromise=null;throw error;});
    }
    return accountingDatabasePromise;
  }
  async function accountingDatabaseGet(key){
    const database=await accountingDatabase();
    return new Promise((resolve,reject)=>{
      const transaction=database.transaction('records','readonly');
      const request=transaction.objectStore('records').get(key);
      transaction.oncomplete=()=>resolve(request.result);
      transaction.onerror=()=>reject(transaction.error||request.error);
      transaction.onabort=()=>reject(transaction.error||Error('تعذرت قراءة بيانات الحسابات.'));
    });
  }
  async function rawGet(key){
    if(window.storage&&typeof window.storage.get==='function'){
      const result=await window.storage.get(key,false);
      if(result==null)return null;
      if(typeof result.value!=='string')throw Error('رد التخزين غير صالح.');
      return result.value;
    }
    const value=await accountingDatabaseGet(key);
    if(value!==undefined){
      if(typeof value!=='string')throw Error('بيانات التخزين غير صالحة.');
      return value;
    }
    return window.localStorage.getItem(key);
  }
  async function rawSet(key,text){
    if(window.storage&&typeof window.storage.get==='function'){
      if(typeof window.storage.set!=='function')throw Error('التخزين لا يسمح بالكتابة.');
      await window.storage.set(key,text,false);
      return;
    }
    const legacy=window.localStorage.getItem(key);
    const database=await accountingDatabase();
    await new Promise((resolve,reject)=>{
      const transaction=database.transaction('records','readwrite');
      const request=transaction.objectStore('records').put(text,key);
      transaction.oncomplete=resolve;
      transaction.onerror=()=>reject(transaction.error||request.error);
      transaction.onabort=()=>reject(transaction.error||Error('تعذر حفظ بيانات الحسابات.'));
    });
    if(await accountingDatabaseGet(key)!==text)throw Error('تعذر تأكيد حفظ الحسابات؛ النسخة القديمة محفوظة.');
    // Remove only a verified migrated key, leaving unrelated browser data intact.
    if(legacy!==null&&window.localStorage.getItem(key)===legacy){
      window.localStorage.removeItem(key);
    }
  }
  function serial(work){const result=tail.then(work);tail=result.catch(()=>{});return result;}
  async function verifyCurrent(){
    if(!known)throw Error('قراءة التخزين لم تكتمل؛ الحفظ ممنوع.');
    if(await rawGet('nitaq-data')!==baseline)throw Error('تغيرت البيانات من نافذة أخرى. نزّل نسخة إنقاذ ثم أعد فتح النظام.');
  }
  const store={
    async get(key){
      const raw=await rawGet(key);
      if(key==='nitaq-data'){
        rawRead=raw;
        if(raw!==null)validate(parse(raw));
        baseline=raw;known=true;
      }
      return raw;
    },
    set(key,text){return serial(async()=>{
      if(state.locked&&state.kind!=='import')throw Error('الحفظ متوقف لحماية البيانات.');
      validate(parse(text));
      if(key==='nitaq-data')await verifyCurrent();
      await rawSet(key,text);
      const actual=await rawGet(key);
      if(actual!==text)throw Error('تعذر تأكيد الحفظ بعد الكتابة. نزّل نسخة إنقاذ.');
      if(key==='nitaq-data'){baseline=text;rawRead=text;}
      return {ok:true};
    }).catch(e=>{fail(e);throw e;});}
  };
  async function health(){if(!state.ready||state.locked)return;try{await serial(verifyCurrent);}catch(e){fail(e,'conflict');}}
  function download(text,name,type){
    const url=URL.createObjectURL(new Blob([text],{type}));const a=document.createElement('a');
    a.href=url;a.download=name;document.body.appendChild(a);a.click();a.remove();setTimeout(()=>URL.revokeObjectURL(url),30000);
  }
  function rescue(){
    if(state.ready&&memory)return download(JSON.stringify(memory,null,2),'nitaq-rescue-'+Date.now()+'.json','application/json');
    if(rawRead!==null)return download(rawRead,'nitaq-unreadable-storage-'+Date.now()+'.txt','text/plain');
    return download(JSON.stringify({error:state.message,dataRead:false},null,2),'nitaq-storage-error-'+Date.now()+'.json','application/json');
  }
  const maxImportBytes=20*1024*1024;
  function prepareImport(raw){
    validate(raw);
    const required=['projects','employees','attendance'];
    for(const key of required)if(!Object.prototype.hasOwnProperty.call(raw,key))throw Error('الملف نسخة جزئية: الحقل '+key+' مفقود.');
    if(!Array.isArray(raw.payments)&&!Array.isArray(raw.invoices))throw Error('قائمة الدفعات مفقودة.');
    if(!(Array.isArray(raw.officeExpenses)&&Array.isArray(raw.projectCosts))&&!Array.isArray(raw.expenses))throw Error('قوائم المصروفات مفقودة.');
    const legacy=Array.isArray(raw.invoices)||Array.isArray(raw.expenses);
    if(!legacy)for(const key of [...arrays.filter(k=>!['recurringBills','otherIncome','timesheets'].includes(k)),...objects])if(!Object.prototype.hasOwnProperty.call(raw,key))throw Error('نسخة حديثة جزئية: '+key+' مفقود.');
    const d=prepare(raw),warnings=[];
    const numeric=new Set(['amount','collectedAmount','baseSalary','grossSalary','hours','rate','value','designValue','designFee','supervisionMonthly','supervisionMonths','commissionPct','commissionAmount','budgetAmount','monthlyInstallment','days']);
    const allIds=new Set();
    const validRef=v=>(typeof v==='string'&&v.trim())||(typeof v==='number'&&Number.isSafeInteger(v));
    const archived=r=>r.archived===true||r.cancelled===true;
    const lookup={};for(const key of arrays)lookup[key]=new Map(d[key].map(r=>[String(r.id),r]));
    function issue(entity,row,field,message){if(archived(row))warnings.push({entity,id:row.id,field,message});else throw Error(message+' ('+entity+'/'+row.id+')');}
    for(const entity of arrays)for(const row of d[entity]){
      const id=String(row.id);if(allIds.has(id))throw Error('معرف مستخدم في أكثر من قائمة: '+id);allIds.add(id);
      for(const [key,value] of Object.entries(row)){
        if(numeric.has(key)&&!inactiveContractNumber(entity,row,key,value)&&(typeof value!=='number'||!Number.isFinite(value)))throw Error('رقم غير صالح في '+entity+'/'+id+'/'+key);
        if(['archived','cancelled'].includes(key)&&typeof value!=='boolean')throw Error('قيمة الأرشفة غير صالحة في '+entity+'/'+id);
        if(['timeline','approvals','docSnapshot'].includes(key)&&!plain(value))throw Error('حقل مركب غير صالح في '+entity+'/'+id+'/'+key);
      }
      if(['contracts','payments','govFees','projectCosts'].includes(entity)&&!validRef(row.projectId))issue(entity,row,'projectId','معرف المشروع مفقود');
      if(entity==='payments'&&['تصميم','إشراف'].includes(row.phase)&&!validRef(row.contractId))issue(entity,row,'contractId','عقد الدفعة مفقود');
      if(['overtime','advances','leaves'].includes(entity)&&!validRef(row.employeeId))issue(entity,row,'employeeId','معرف الموظف مفقود');
      for(const [field,target] of Object.entries({projectId:'projects',contractId:'contracts',employeeId:'employees'})){
        if(!Object.prototype.hasOwnProperty.call(row,field)||row[field]===''||row[field]===null)continue;
        if(!validRef(row[field])||!lookup[target].has(String(row[field])))issue(entity,row,field,'علاقة مفقودة: '+field);
      }
      if(['payments','govFees','officeExpenses','projectCosts','treasury','recurringBills','advances'].includes(entity)&&typeof row.amount!=='number')throw Error('مبلغ مفقود أو غير صالح: '+entity+'/'+id);
      if(entity==='payments'){
        if(typeof row.amount!=='number'||!Number.isFinite(row.amount)||row.amount<0)throw Error('مبلغ دفعة غير صالح: '+id);
        if(row.collectedAmount!==undefined&&(row.collectedAmount<0||row.collectedAmount>row.amount))throw Error('التحصيل يتجاوز المبلغ أو سالب: '+id);
        const contract=lookup.contracts.get(String(row.contractId));
        if(contract&&String(contract.projectId)!==String(row.projectId))issue(entity,row,'contractId','العقد والدفعة يتبعان مشروعين مختلفين');
      }
    }
    for(const [empId,map] of Object.entries(d.attendance)){
      if(Object.values(map).some(v=>typeof v!=='string'))throw Error('قيمة حضور غير صالحة: '+empId);
      if(!lookup.employees.has(String(empId))&&!d.staffDir.some(r=>String(r.empId)===String(empId)))warnings.push({entity:'attendance',id:empId,message:'حضور تاريخي دون موظف في الدليل الحالي'});
    }
    return {data:d,warnings};
  }
  function beginReplacement(){
    if(!state.ready||state.locked)throw Error('النظام غير جاهز للاستبدال.');
    publish({locked:true,pending:true,kind:'import',message:'جارٍ حفظ نسخة ما قبل الاستبدال والتحقق منها…'});
  }
  function replaceStored(next,previous){return serial(async()=>{
    if(state.kind!=='import'||!state.locked)throw Error('لم تبدأ عملية استبدال آمنة.');
    validate(next);validate(previous);await verifyCurrent();
    const backupKey='nitaq-before-replace:'+Date.now()+':'+Math.random().toString(36).slice(2);
    const backupText=JSON.stringify(previous);
    await rawSet(backupKey,backupText);
    if(await rawGet(backupKey)!==backupText)throw Error('فشل التحقق من نسخة ما قبل الاستبدال؛ لم نستبدل البيانات.');
    await rawSet('nitaq-last-replace-backup',backupKey);
    if(await rawGet('nitaq-last-replace-backup')!==backupKey)throw Error('فشل حفظ مرجع نسخة الاسترجاع؛ لم نستبدل البيانات.');
    const text=JSON.stringify(next);
    await rawSet('nitaq-data',text);
    if(await rawGet('nitaq-data')!==text)throw Error('فشل تأكيد حفظ البيانات الجديدة. نسخة ما قبل الاستبدال محفوظة.');
    baseline=text;rawRead=text;memory=next;revision++;
    return {backupKey};
  }).catch(e=>{fail(e,'import-failed');throw e;});}
  function finishReplacement(next){memory=next;publish({locked:false,pending:false,kind:'saved',message:'✓ تم الاستبدال محليًا وحفظ نسخة الاسترجاع؛ لم تُرفع بيانات للسحابة'});}
  async function downloadPrevious(){
    try{
      const key=await rawGet('nitaq-last-replace-backup');
      if(!key)throw Error('لا توجد نسخة تلقائية سابقة للاستبدال على هذا الجهاز.');
      const raw=await rawGet(key);validate(parse(raw));
      download(raw,'nitaq-before-replace-'+Date.now()+'.json','application/json');
    }catch(e){alert(e.message||'تعذر قراءة نسخة الاسترجاع.');}
  }

  window.addEventListener('beforeunload',e=>{if(state.pending||(state.locked&&state.ready)){e.preventDefault();e.returnValue='';}});
  window.addEventListener('storage',e=>{if(e.key==='nitaq-data'||e.key===null)health();});
  window.addEventListener('focus',health);
  return {
    readAux(key){if(!key.startsWith('nitaq-sync:'))throw Error('Invalid auxiliary key');return serial(()=>rawGet(key));},
    writeAux(key,text){if(!key.startsWith('nitaq-sync:'))throw Error('Invalid auxiliary key');return serial(async()=>{if(state.locked)throw Error('التخزين متوقف لحماية البيانات.');await rawSet(key,text);if(await rawGet(key)!==text)throw Error('تعذر تأكيد حفظ طابور المزامنة.');});},
    store,parse,validate,contractRestoreProblem,prepare,prepareImport,maxImportBytes,beginReplacement,replaceStored,finishReplacement,downloadPrevious,fail,rescue,localGate,health,
    get status(){return {...state};},get revision(){return revision;},
    get blocked(){return !state.ready||state.locked;},
    subscribe(fn){listeners.add(fn);fn({...state});return ()=>listeners.delete(fn);},
    finishLocal(){resolveLocal();},
    loaded(d){validate(d);memory=d;publish({ready:true,locked:false,pending:false,kind:'ready',message:'تمت قراءة البيانات بأمان'});},
    remember(d){memory=d;},
    changed(d){memory=d;revision++;publish({pending:true,kind:'saving',message:'تغييرات لم تُحفظ بعد…'});},
    saved(ticket){if(!state.locked)publish({pending:revision!==ticket,kind:revision===ticket?'saved':'saving',message:revision===ticket?'✓ تم الحفظ المحلي والتحقق منه':'تغييرات أحدث قيد الحفظ…'});}
  };
})();
const store = NITAQ_PERSIST.store;
/* NITAQ sync client v1. No credentials are written to the journal. */
function createNitaqSyncClient(io){
  const clone=x=>JSON.parse(JSON.stringify(x));
  const canon=x=>JSON.stringify(x,(_,v)=>v&&typeof v==='object'&&!Array.isArray(v)?Object.fromEntries(Object.keys(v).sort().map(k=>[k,v[k]])):v);
  let session=null,generation=0,listeners=new Set();
  const emit=()=>{const s=stats();for(const f of listeners)f(s);};
  function stats(){const s=session;return {ready:!!s&&s.ready&&!s.stopped,fatal:!!s?.fatal,pending:s?.jobs.length||0,blocked:s?.jobs.filter(j=>j.status==='blocked').length||0,busy:!!s?.busy,volatile:!!s?.writes,message:s?.message||'',jobs:clone(s?.jobs||[])};}
  function current(s){return session===s&&!s.stopped;}
  function validRow(r){if(!r||typeof r.id!=='string'||!r.id||typeof r.entity!=='string'||!r.data||typeof r.data!=='object'||Array.isArray(r.data)||!r.updated_at)throw Error('سجل سحابي غير صالح.');if(r.data.id!==undefined&&String(r.data.id)!==r.id)throw Error('معرف السجل السحابي لا يطابق محتواه.');return r;}
  async function scan(client){
    const rows=[],seen=new Set();let last=null,total=null;
    for(let n=0;n<10000;n++){
      let q=client.from('nitaq_records').select('*',last===null?{count:'exact'}:undefined).order('id',{ascending:true}).limit(1000);
      if(last!==null)q=q.gt('id',last);
      const result=await q;if(result.error)throw result.error;
      if(!Array.isArray(result.data))throw Error('رد تحميل السحابة غير صالح.');
      if(total===null){if(!Number.isSafeInteger(result.count)||result.count<0)throw Error('تعذر تأكيد عدد السجلات السحابية.');total=result.count;}
      if(!result.data.length){if(rows.length!==total)throw Error('تغير عدد السجلات أثناء التحميل.');return rows;}
      for(const raw of result.data){const r=validRow(raw);if(seen.has(r.id))throw Error('سجل مكرر أثناء التحميل.');seen.add(r.id);rows.push(clone(r));}
      const next=rows[rows.length-1].id;if(next===last||rows.length>total)throw Error('تحميل سحابي غير متسق.');last=next;
      if(rows.length===total)return rows;
    }
    throw Error('تجاوز التحميل حد الصفحات المسموح.');
  }
  async function loadStable(client){let previous=null,lastError;
    for(let i=0;i<4;i++)try{const rows=await scan(client),signature=canon(rows);if(signature===previous)return rows;previous=signature;lastError=Error('البيانات تتغير أثناء التحميل؛ لم نعتمد نسخة جزئية.');}catch(e){previous=null;lastError=e;}
    throw lastError||Error('تعذر تأكيد اكتمال التحميل.');
  }
  function rowMap(rows){return new Map(rows.map(r=>[r.id,clone(r)]));}
  function overlay(s){const rows=new Map(s.base);for(const j of s.jobs){if(j.kind==='delete')rows.delete(j.id);else rows.set(j.id,{id:j.id,entity:j.entity,data:clone(j.data)});}return [...rows.values()];}
  function snapshot(s){if(current(s)&&s.ready&&io.onSnapshot)io.onSnapshot(overlay(s));}
  function journal(s){return JSON.stringify({version:1,url:s.url,userId:s.userId,jobs:s.jobs});}
  function fatal(s,error){s.fatal=true;s.message='توقف حفظ طابور المزامنة؛ نزّل نسخة إنقاذ.';emit();io.onFatal?.(error);}
  function persist(s){
    s.writes++;emit();const task=s.tail.then(async()=>{await io.write(s.key,journal(s));});
    s.tail=task.catch(e=>{fatal(s,e);}).finally(()=>{s.writes--;emit();});return task;
  }
  function validateJobs(doc,s){
    if(!doc||doc.version!==1||doc.url!==s.url||doc.userId!==s.userId||!Array.isArray(doc.jobs))throw Error('طابور المزامنة لا يطابق المستخدم أو المشروع.');
    const tokens=new Set();for(const j of doc.jobs){
      if(!j||!Object.prototype.hasOwnProperty.call(j,'expected')||typeof j.token!=='string'||!j.token||tokens.has(j.token)||typeof j.id!=='string'||!j.id||typeof j.entity!=='string'||!['upsert','delete'].includes(j.kind)||!['pending','blocked'].includes(j.status))throw Error('طابور المزامنة تالف؛ لم يتم تفريغه.');
      if(j.kind==='upsert'&&(!j.data||typeof j.data!=='object'||Array.isArray(j.data)||(j.data.id!==undefined&&String(j.data.id)!==j.id)))throw Error('بيانات عملية مزامنة تالفة.');
      if(j.expected?.after&&(!tokens.has(j.expected.after)||doc.jobs.find(p=>p.token===j.expected.after)?.id!==j.id))throw Error('اعتماد مفقود في طابور المزامنة.');
      if(j.expected&&!j.expected.after){validRow(j.expected);if(j.expected.id!==j.id||j.expected.entity!==j.entity)throw Error('نسخة أساس المزامنة غير متسقة.');}
      tokens.add(j.token);
    }
  }
  async function attach({client,url,userId}){
    if(session&&current(session)&&session.url===url&&session.userId===userId){session.client=client;return refresh();}
    await detach();const token=++generation;
    const s={client,url,userId,key:'nitaq-sync:outbox:'+encodeURIComponent(url)+':'+encodeURIComponent(userId),jobs:[],base:new Map(),mapVersion:0,ready:false,stopped:false,fatal:false,busy:false,writes:0,tail:Promise.resolve(),message:'جارٍ تحميل السحابة وطابور العمليات…',retryTimer:null,release:null};
    session=s;emit();
    try{
      s.release=await io.acquire(s.key);if(token!==generation||!current(s)){s.release();throw Error('تغيرت جلسة المستخدم.');}
      const caps=await client.rpc('nitaq_sync_capabilities_v1');if(caps.error)throw caps.error;
      if(caps.data?.protocol!==1||caps.data?.expected_mode!=='row_snapshot')throw Error('تأسيس المزامنة غير متوافق.');
      const raw=await io.read(s.key);if(raw!==null){const d=JSON.parse(raw);validateJobs(d,s);s.jobs=clone(d.jobs);}
      if(caps.data.financial_bundle!==1)throw Error('يلزم تركيب الحزمة المالية المجمعة على Supabase قبل فتح هذه النسخة.');
      if(caps.data.financial_controls!==1)throw Error('يلزم تركيب ضوابط الدفعات على Supabase قبل فتح هذه النسخة.');
      const rows=await loadStable(client);if(token!==generation||!current(s))throw Error('تغيرت جلسة المستخدم.');
      s.base=rowMap(rows);s.ready=true;s.message=s.jobs.length?'توجد عمليات محفوظة تنتظر المزامنة':'✓ تم تحميل السحابة والتحقق من اكتمالها';emit();snapshot(s);return overlay(s);
    }catch(e){if(current(s)){s.message=e.message||String(e);s.stopped=true;s.release?.();emit();}throw e;}
  }
  async function detach(){
    const s=session;++generation;if(!s)return;s.stopped=true;s.ready=false;io.cancel?.(s.retryTimer);emit();
    await s.tail;if(s.fatal){s.release?.();throw Error('تعذر حفظ الطابور؛ نزّل نسخة الإنقاذ والعمليات قبل تغيير الحساب.');}s.release?.();if(session===s)session=null;emit();
  }
  function enqueue(kind,id,entity,data){
    const s=session;if(!s||!current(s)||!s.ready||s.fatal)throw Error('لم تجهز هوية المزامنة؛ التعديل متوقف.');
    const prior=[...s.jobs].reverse().find(j=>j.id===String(id));
    const expected=prior?{after:prior.token}:(s.base.get(String(id))?clone(s.base.get(String(id))):null);
    const job={token:io.uid(),kind,id:String(id),entity,data:kind==='upsert'?clone(data):null,expected,status:'pending'};
    if(!job.id||typeof entity!=='string')throw Error('عملية مزامنة غير صالحة.');
    s.jobs.push(job);s.mapVersion++;s.message='جارٍ حفظ العملية قبل إرسالها…';emit();
    const task=persist(s);task.then(()=>flush()).catch(()=>{});return task;
  }
  function findEntity(id){const s=session;if(!s)return null;return [...s.jobs].reverse().find(j=>j.id===String(id))?.entity||s.base.get(String(id))?.entity||null;}
  function pending(id){return !!session?.jobs.some(j=>j.id===String(id));}
  function blockedError(e){return /NITAQ_(CONFLICT|BAD_|ID_|OPERATION_|DATA_|DELETE_|UPDATE_|INSERT_)/.test(e.message||'')||e.code==='42501'||e.code==='22023';}
  async function flush(){
    const s=session;if(!s||!current(s)||!s.ready||s.fatal||s.busy||io.canSend&&!io.canSend())return;
    io.cancel?.(s.retryTimer);s.retryTimer=null;s.busy=true;emit();
    try{
      await s.tail;
      while(current(s)&&!s.fatal&&(!io.canSend||io.canSend())){
        const job=s.jobs.find(j=>j.status==='pending'&&!j.expected?.after);if(!job)break;
        try{
          const response=await s.client.rpc('nitaq_sync_apply_v1',{p_operation_id:job.token,p_kind:job.kind,p_id:job.id,p_entity:job.entity,p_data:job.data,p_expected:job.expected});
          if(response.error)throw response.error;
          if(!current(s))break;
          const r=response.data;if(!r||r.ok!==true||r.operation_id!==job.token||r.id!==job.id||r.kind!==job.kind||r.entity!==job.entity)throw Error('تأكيد العملية من الخادم غير صالح.');
          if(job.kind==='upsert'){validRow(r.row);if(r.row.id!==job.id||r.row.entity!==job.entity)throw Error('تأكيد الخادم يخص سجلًا آخر.');s.base.set(job.id,clone(r.row));}else s.base.delete(job.id);
          s.mapVersion++;s.jobs=s.jobs.filter(j=>j.token!==job.token);
          for(const next of s.jobs)if(next.expected?.after===job.token)next.expected=job.kind==='upsert'?clone(r.row):null;
          await persist(s);snapshot(s);
        }catch(error){
          if(!current(s)||s.fatal)break;
          job.error={code:error.code||'',message:error.message||String(error)};
          if(blockedError(error)){job.status='blocked';s.message='تعديل متعارض أو مرفوض يحتاج مراجعة؛ لم نستبدل بيانات الخادم.';await persist(s);continue;}
          s.message='⚠ تعذر الاتصال؛ العمليات محفوظة وستُعاد المحاولة';emit();
          s.retryTimer=io.schedule?.(()=>flush(),15000);break;
        }
      }
    }finally{if(current(s)){s.busy=false;if(!s.jobs.length&&!s.fatal)s.message='✓ جميع العمليات مؤكدة من الخادم';else if(!s.fatal&&s.jobs.some(j=>j.status==='blocked'))s.message='⚠ توجد عمليات تحتاج مراجعة؛ لم نعلن اكتمال المزامنة';emit();}}
  }
  async function retry(){const s=session;if(!s||!current(s)||s.fatal)return;for(const j of s.jobs)if(j.status==='blocked'&&!/NITAQ_CONFLICT/.test(j.error?.message||'')){j.status='pending';delete j.error;}await persist(s);return flush();}
  async function refresh(){const s=session;if(!s||!current(s)||!s.ready)throw Error('المزامنة غير جاهزة.');const version=s.mapVersion;const rows=await loadStable(s.client);if(current(s)){if(version===s.mapVersion&&!s.busy){s.base=rowMap(rows);s.mapVersion++;snapshot(s);}emit();return overlay(s);}throw Error('تغيرت جلسة المستخدم.');}
  function remote(payload){
    const s=session;if(!s||!current(s)||!s.ready)return;
    const id=payload.eventType==='DELETE'?payload.old?.id:payload.new?.id;if(!id||pending(id))return;
    s.mapVersion++;if(payload.eventType==='DELETE')s.base.delete(String(id));else s.base.set(String(id),clone(validRow(payload.new)));
    snapshot(s);
  }
  return {attach,detach,enqueue,flush,retry,refresh,remote,pending,findEntity,loadStable,
    get state(){return stats();},get identity(){return session&&current(session)&&session.ready?{url:session.url,userId:session.userId}:null;},
    subscribe(f){listeners.add(f);f(stats());return()=>listeners.delete(f);},
    exportPending(){return session?journal(session):JSON.stringify({version:1,jobs:[]});}
  };
}

function createNitaqScopedTransport(rootClient,cfg,userId,request=fetch){
  async function send(route,method,body,query,countExact=false){
    const auth=await rootClient.auth.getSession();if(auth.error)throw auth.error;
    const session=auth.data?.session;
    if(!session?.access_token||session.user?.id!==userId)throw Object.assign(Error('تغير حساب المستخدم؛ لم نرسل العملية.'),{code:'42501'});
    const url=new URL(cfg.url.replace(/\/$/,'')+'/rest/v1/'+route);
    if(query)for(const [k,v] of Object.entries(query))url.searchParams.set(k,String(v));
    // Capture the token in this request; changing the browser session cannot replace it mid-request.
    const response=await request(url.toString(),{method,headers:{apikey:cfg.key,Authorization:'Bearer '+session.access_token,'Content-Type':'application/json',...(countExact?{Prefer:'count=exact'}:{})},...(body===undefined?{}:{body:JSON.stringify(body)})});
    const data=await response.json();if(!response.ok)return {data:null,error:{code:data?.code||String(response.status),message:data?.message||'فشل طلب المزامنة'}};
    const range=response.headers.get('content-range'),total=range?.split('/').pop();
    return {data,error:null,count:total&&total!=='*'?Number(total):null};
  }
  return {
    rpc:(name,args)=>{if(!['nitaq_sync_apply_v1','nitaq_sync_capabilities_v1'].includes(name))throw Error('RPC غير مسموح.');return send('rpc/'+name,'POST',args||{});},
    from:table=>{
      if(table!=='nitaq_records')throw Error('جدول غير مسموح في عميل المزامنة.');
      const query={};let countExact=false;const builder={
        select(columns,opts){query.select=columns;countExact=opts?.count==='exact';return builder;},order(field,opts){query.order=field+(opts?.ascending===false?'.desc':'.asc');return builder;},
        limit(n){query.limit=n;return builder;},gt(field,value){query[field]='gt.'+value;return builder;},
        then(resolve,reject){return send(table,'GET',undefined,query,countExact).then(resolve,reject);}
      };return builder;
    }
  };
}

const NITAQ_SYNC=createNitaqSyncClient({
  read:key=>NITAQ_PERSIST.readAux(key),write:(key,text)=>NITAQ_PERSIST.writeAux(key,text),
  uid:()=>window.crypto?.randomUUID?window.crypto.randomUUID():uid(),
  canSend:()=>!NITAQ_PERSIST.blocked,
  schedule:(fn,ms)=>setTimeout(()=>Promise.resolve(fn()).catch(e=>NITAQ_PERSIST.fail(e,'sync')),ms),cancel:id=>clearTimeout(id),
  onFatal:e=>NITAQ_PERSIST.fail(e,'sync'),
  acquire:key=>new Promise((resolve,reject)=>{
    if(!window.navigator?.locks){reject(Error('المزامنة الآمنة تحتاج متصفحًا يدعم قفل التبويب. افتح النظام في Chrome أو Edge حديث عبر HTTPS أو محليًا.'));return;}
    window.navigator.locks.request(key,{ifAvailable:true},async lock=>{
      if(!lock){reject(Error('النظام مفتوح للمستخدم نفسه في تبويب آخر. أغلق التبويب الآخر ثم أعد المحاولة.'));return;}
      await new Promise(release=>resolve(release));
    }).catch(reject);
  }),
  onSnapshot:rows=>window.dispatchEvent(new CustomEvent('nitaq-sync-snapshot',{detail:rows}))
});
window.addEventListener('beforeunload',e=>{const q=NITAQ_SYNC.state;if(q.pending||q.volatile){e.preventDefault();e.returnValue='';}});

/* ================= Generic Modal Form (يدعم الحقول الشرطية) ================= */
function FormModal({title, fields, initial, onCancel, onSave, data, lockedFields=[], lockedNotice, graceNotice, adminOverrideNotice}){
  const [values, setValues] = useState(()=>{
    const v = {...initial};
    fields.forEach(f=>{ if(v[f.name]===undefined) v[f.name] = f.type==='ownerList' ? [] : ''; });
    fields.forEach(f=>{ if(f.type==='ownerList' && !Array.isArray(v[f.name])) v[f.name] = []; });
    fields.forEach(f=>{ if(f.initCompute && (v[f.name]===''||v[f.name]===undefined)) v[f.name] = f.initCompute(v); });
    return v;
  });
  const set = (name,val) => setValues(v=>{
    const nx = {...v, [name]:val};
    const f = fields.find(ff=>ff.name===name);
    if(f && f.sync){ Object.assign(nx, f.sync(nx)); }
    return nx;
  });
  const visible = fields.filter(f=> !f.showIf || f.showIf(values));
  const submit = (e) => {
    e.preventDefault();
    const clean = {...values};
    fields.forEach(f=>{
      if(f.ephemeral){ delete clean[f.name]; return; }
      if(lockedFields.includes(f.name)){ clean[f.name] = initial[f.name]; return; }
      if(f.showIf && !f.showIf(values)){ clean[f.name] = (f.type==='number' ? 0 : (f.type==='ownerList' ? [] : '')); return; }
      if(f.type==='number') clean[f.name] = parseFloat(clean[f.name])||0;
      if(f.type==='ownerList') clean[f.name] = (clean[f.name]||[]).filter(o=> (o.name||'').trim()!=='');
    });
    onSave(clean);
  };
  return (
    <div className="overlay" onMouseDown={(e)=>{ if(e.target===e.currentTarget) onCancel(); }}>
      <div className="modal">
        <div className="modal-head">
          <h3>{title}</h3>
          <button className="close-x" onClick={onCancel}>✕</button>
        </div>
        <form onSubmit={submit}>
          <div className="modal-body">
            {lockedNotice && <div style={{padding:'9px 12px', background:'#FEF9F0', borderInlineStart:'3px solid var(--brass)', fontSize:11.5, marginBottom:14, color:'var(--ink-soft)', lineHeight:1.7}}>{lockedNotice}</div>}
            {graceNotice && <div style={{padding:'9px 12px', background:'var(--teal-soft)', borderInlineStart:'3px solid var(--teal)', fontSize:11.5, marginBottom:14, color:'var(--ink)', lineHeight:1.7}}>⏳ {graceNotice}</div>}
            {adminOverrideNotice && <div style={{padding:'9px 12px', background:'var(--blue-soft)', borderInlineStart:'3px solid var(--blue)', fontSize:11.5, marginBottom:14, color:'var(--ink)', lineHeight:1.7}}>🛠 {adminOverrideNotice}</div>}
            {visible.map(f=>{
              const locked = lockedFields.includes(f.name);
              return (
              <div className="field" key={f.name}>
                <label>{f.label}{(typeof f.required==='function' ? f.required(values) : f.required) && ' *'}{locked && <span style={{color:'var(--brass)', marginInlineStart:6, fontSize:10}}>🔒</span>}</label>
                {f.type==='select' ? (
                  <select required={typeof f.required==='function' ? f.required(values) : f.required} disabled={locked} value={values[f.name]||''}
                    onChange={e=>{
                      if(f.allowAddNew && e.target.value==='__ADDNEW__'){
                        const n = prompt(f.addNewPrompt || 'اسم التصنيف الجديد:');
                        if(n===null) return;
                        const nn = n.trim();
                        if(!nn){ alert('التصنيف لا يمكن أن يكون فارغاً'); return; }
                        const opts = (typeof f.options==='function' ? f.options(data, values) : f.options);
                        if(opts.some(o=>String(o.value).trim()===nn)){ alert('هذا التصنيف موجود بالفعل — تم اختياره من القائمة'); }
                        set(f.name, nn); return;
                      }
                      set(f.name, e.target.value);
                    }} style={locked?{background:'#F2F0EA', cursor:'not-allowed'}:{}}>
                    <option value="">اختر...</option>
                    {(typeof f.options==='function' ? f.options(data, values) : f.options).map(o=>(
                      <option key={o.value} value={o.value}>{o.label}</option>
                    ))}
                    {f.allowAddNew && values[f.name] && !(typeof f.options==='function' ? f.options(data, values) : f.options).some(o=>o.value===values[f.name]) && (
                      <option value={values[f.name]}>{values[f.name]} (جديد)</option>
                    )}
                    {f.allowAddNew && <option value="__ADDNEW__">{f.addNewLabel || '➕ إضافة تصنيف جديد...'}</option>}
                  </select>
                ) : f.type==='textarea' ? (
                  <textarea rows="3" disabled={locked} value={values[f.name]||''} onChange={e=>set(f.name,e.target.value)} style={locked?{background:'#F2F0EA', cursor:'not-allowed'}:{}} />
                ) : f.type==='ownerList' ? (
                  <div>
                    {(values[f.name]||[]).map((row,idx)=>(
                      <div key={idx} style={{display:'flex', gap:8, marginBottom:8, alignItems:'flex-start', flexWrap:'wrap'}}>
                        {(f.subFields||[]).map(sf=>(
                          <input key={sf.name} type="text" placeholder={sf.label} disabled={locked}
                            value={row[sf.name]||''}
                            style={{flex: sf.name==='name'?'1 1 160px':'1 1 120px', minWidth:110}}
                            onChange={e=>{
                              const arr = [...(values[f.name]||[])];
                              arr[idx] = {...arr[idx], [sf.name]:e.target.value};
                              set(f.name, arr);
                            }} />
                        ))}
                        {!locked && (
                          <button type="button" className="btn ghost small" title="حذف هذا المالك"
                            onClick={()=>{
                              const arr = (values[f.name]||[]).filter((_,i)=>i!==idx);
                              set(f.name, arr);
                            }}
                            style={{color:'var(--rust)', flex:'0 0 auto'}}>✕</button>
                        )}
                      </div>
                    ))}
                    {!locked && (
                      <button type="button" className="btn outline small"
                        onClick={()=>{
                          const arr = [...(values[f.name]||[]), {}];
                          set(f.name, arr);
                        }}>
                        <I.plus/> إضافة مالك
                      </button>
                    )}
                  </div>
                ) : f.type==='file' ? (
                  <div>
                    {values[f.name] ? (
                      <div style={{border:'1px solid var(--line-strong)', borderRadius:6, padding:8, display:'flex', alignItems:'center', gap:10, flexWrap:'wrap'}}>
                        {String(values[f.name]).startsWith('data:image')
                          ? <img src={values[f.name]} alt="مرفق" style={{height:56, borderRadius:4, border:'1px solid var(--line)'}} />
                          : <span style={{fontSize:20}}>📄</span>}
                        <a href={values[f.name]} target="_blank" rel="noopener" download={values[f.name+'_name']||'فاتورة'} style={{fontSize:12, color:'var(--teal)', fontWeight:700}}>
                          {values[f.name+'_name'] || 'عرض / تنزيل المرفق'}
                        </a>
                        {!locked && <button type="button" className="btn ghost small" style={{color:'var(--rust)'}} onClick={()=>{ set(f.name,''); set(f.name+'_name',''); }}>✕ إزالة</button>}
                      </div>
                    ) : (
                      <input type="file" accept="image/*,application/pdf" disabled={locked}
                        onChange={e=>{
                          const file = e.target.files && e.target.files[0];
                          if(!file) return;
                          if(file.size > 1024*1024){ alert('الملف أكبر من 1 ميجابايت. اختاري صورة أصغر أو اضغطيها أولاً.'); e.target.value=''; return; }
                          const reader = new FileReader();
                          reader.onload = ()=>{ set(f.name, reader.result); set(f.name+'_name', file.name); };
                          reader.readAsDataURL(file);
                        }} />
                    )}
                  </div>
                ) : (
                  <input type={f.type||'text'} required={typeof f.required==='function' ? f.required(values) : f.required} disabled={locked} step={f.type==='number' ? '0.01' : undefined}
                    value={values[f.name]===undefined?'':values[f.name]} onChange={e=>set(f.name,e.target.value)} style={locked?{background:'#F2F0EA', cursor:'not-allowed'}:{}} />
                )}
                {f.hint && <div style={{fontSize:11, color:'var(--ink-faint)', marginTop:4}}>{f.hint}</div>}
              </div>
            );})}
          </div>
          <div className="modal-foot">
            <button type="button" className="btn outline" onClick={onCancel}>إلغاء</button>
            <button type="submit" className="btn brass">حفظ</button>
          </div>
        </form>
      </div>
    </div>
  );
}

/* ================= Generic Entity View ================= */
function EntityView({config, records, data, onAdd, onUpdate, onDelete, headExtra, rowActions, onRowClick, role}){
  const [modal, setModal] = useState(null);
  const [q, setQ] = useState('');
  const [showArchived, setShowArchived] = useState(false);
  const sorted = useMemo(()=> [...records].sort(config.sortFn || ((a,b)=> (b._ts||0)-(a._ts||0))), [records, config]);
  const query = q.trim().toLowerCase();
  const archivedCount = sorted.filter(r=>isArchived(r)).length;
  const activeRecords = showArchived ? sorted : sorted.filter(r=>!isArchived(r));
  const filtered = query ? activeRecords.filter(r=> rowSearchText(r, data).includes(query)) : activeRecords;

  return (
    <div>
      <div className="toolbar">
        <div className="section-title" style={{marginBottom:0, flex:1}}>
          <h3>{config.title}</h3>
          <div className="rule"></div>
        </div>
        <input className="searchbox" placeholder={'بحث في '+config.title+'...'} value={q} onChange={e=>setQ(e.target.value)} />
        {archivedCount>0 && (
          <button className="btn ghost small" onClick={()=>setShowArchived(!showArchived)} style={{color:showArchived?'var(--brass)':'var(--ink-faint)'}}>
            {showArchived ? '✓ عرض المؤرشف' : '📦 '+archivedCount+' مؤرشف'}
          </button>
        )}
        {headExtra}
        <button className="btn brass" onClick={()=>setModal({mode:'add'})}>
          <I.plus/> إضافة {config.singular}
        </button>
      </div>
      <div className="card" style={{padding:0}}>
        <div style={{overflowX:'auto'}}>
        <table>
          <thead>
            <tr>
              {config.columns.map(c=>(<th key={c.key}>{c.label}</th>))}
              <th style={{width:120}}></th>
            </tr>
          </thead>
          <tbody>
            {filtered.length===0 && (
              <tr className="empty-row"><td colSpan={config.columns.length+1}>{query ? 'لا نتائج مطابقة للبحث "'+q+'"' : 'لا توجد بيانات بعد — ابدأ بالإضافة'}</td></tr>
            )}
            {filtered.map(row=>(
              <tr key={row.id} onClick={onRowClick ? ()=>onRowClick(row) : undefined} style={{...(onRowClick?{cursor:'pointer'}:{}), ...(isArchived(row)?{opacity:0.5, background:'#F8F6F0'}:{})}}>
                {config.columns.map(c=>{
                  const val = c.render ? c.render(row,data) : row[c.key];
                  return c.truncate
                    ? <td key={c.key} className="cell-clip" title={typeof val==='string' ? val : (row[c.key]||'')}>{val}</td>
                    : <td key={c.key}>{val}</td>;
                })}
                <td onClick={e=>e.stopPropagation()}>
                  <div style={{display:'flex',gap:4}}>
                    {rowActions && rowActions(row)}
                    <button className="btn ghost small" onClick={()=>setModal({mode:'edit', record:row})}><I.edit/></button>
                    {config.allowAdminOverride && role==='owner' && (
                      <button className="btn ghost small" title="تصحيح إداري (مالك فقط) — يفتح كل الحقول للتعديل لمرة واحدة ويُسجَّل في سجل التدقيق"
                        style={{color:'var(--blue)'}}
                        onClick={()=>{
                          const reason = prompt('سبب التصحيح الإداري — إلزامي (يُسجل باسمك في سجل التدقيق):');
                          if(reason===null) return;
                          if(!reason.trim()){ alert('لا يمكن فتح التصحيح الإداري بدون سبب مسجل'); return; }
                          setModal({mode:'adminEdit', record:row, reason:reason.trim()});
                        }}>🛠</button>
                    )}
                    {config.entityKey && protectedFromHardDelete(config.entityKey, row) ? (
                      isArchived(row) ? (
                        <button className="btn ghost small" title="مؤرشف — اضغط لإلغاء الأرشفة" style={{color:'var(--brass)'}}
                          onClick={()=>{ if(confirm('إلغاء أرشفة هذا السجل وإعادته للاستخدام؟')) onUpdate(row.id, {archived:false, cancelled:false, archiveReason:'', archivedAt:''}); }}>📁</button>
                      ) : (
                        <button className="btn ghost small" title="أرشفة / إلغاء (لا يمكن الحذف النهائي)" style={{color:'var(--rust)'}}
                          onClick={()=>{
                            if(config.archiveGuard){
                              const err = config.archiveGuard(row, data);
                              if(err){ alert(err); return; }
                            }
                            const reason = prompt('سبب الأرشفة/الإلغاء — إلزامي (يُسجل في سجل التدقيق):');
                            if(reason===null) return;
                            if(!reason.trim()){ alert('لا يمكن الأرشفة بدون سبب مسجل'); return; }
                            onUpdate(row.id, {archived:true, archiveReason:reason.trim(), archivedAt:todayISO()});
                          }}>📦</button>
                      )
                    ) : (
                      <button className="btn ghost small danger" onClick={()=>{ if(confirm('تأكيد الحذف؟')) onDelete(row.id); }}><I.trash/></button>
                    )}
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
          {config.footRow && filtered.length>0 && (
            <tfoot>{config.footRow(filtered, data)}</tfoot>
          )}
        </table>
        </div>
      </div>
      {modal && (
        <FormModal
          title={(modal.mode==='add' ? 'إضافة ' : modal.mode==='adminEdit' ? '🛠 تصحيح إداري — ' : 'تعديل ') + config.singular}
          fields={config.fields}
          initial={modal.record || config.defaults || {}}
          data={data}
          lockedFields={modal.mode==='edit' && config.lockedFor ? config.lockedFor(modal.record) : []}
          lockedNotice={modal.mode==='edit' && config.lockedFor && config.lockedFor(modal.record).length>0 ? config.lockedNotice : null}
          graceNotice={modal.mode==='edit' && config.graceNoticeFor ? config.graceNoticeFor(modal.record) : null}
          adminOverrideNotice={modal.mode==='adminEdit' ? 'هذا تعديل إداري كامل الصلاحية خارج القيود المعتادة (متاح للمالك فقط). كل الحقول مفتوحة، والتغييرات هتتسجل في سجل التدقيق مع السبب اللي كتبته.' : null}
          onCancel={()=>setModal(null)}
          onSave={(vals)=>{
            if(config.validate){
              const err = config.validate(vals, data, modal.mode, modal.record);
              if(err){ alert(err); return; }
            }
            if(modal.mode==='add') onAdd({...vals, id:uid(), _ts:Date.now()});
            else if(modal.mode==='adminEdit'){if(onUpdate(modal.record.id, {...vals, lastCorrectionReason:modal.reason, lastCorrectionAt:new Date().toISOString()})===false)return;}
            else if(onUpdate(modal.record.id, vals)===false)return;
            setModal(null);
          }}
        />
      )}
    </div>
  );
}

/* ================= Entity Configs ================= */
function buildConfigs(data){
  const r2 = (x)=> Math.round((parseFloat(x)||0)*100)/100;
  const payF = (v)=> (v.taxable==='غير خاضعة') ? 1 : 1.05;
  const expF = (v)=> v.vatable==='غير خاضع' ? 1 : 1.05;
  const employeeOptions = (d)=> (d.employees&&d.employees.length ? d.employees.map(e=>({value:e.id,label:e.name})) : (d.staffDir||[]).map(s=>({value:s.empId,label:s.name})));
  const projectOptions = (d)=> d.projects.map(p=>({value:p.id, label:(p.projectNo?p.projectNo+' — ':'')+p.name}));
  const empName = (id,d)=> (d.employees.find(e=>e.id===id)||{}).name || '—';
  const projName = (id,d)=>{ const p=(d.projects||[]).find(x=>x.id===id); return p ? (p.projectNo?p.projectNo+' — ':'')+p.name : '—'; };
  const contractValue = (p,d)=>{
    const cons = (d.contracts||[]).filter(c=>c.projectId===p.id && c.status!=='ملغى' && !isArchived(c) && (isConsultancy(c)));
    if(cons.length>0) return cons.reduce((s,c)=> s + contractTotalOf(c), 0);
    return (p.designFee||0) + (p.supervisionMonthly||0)*(p.supervisionMonths||0);
  };
  const nextProjectNo = (d)=> Math.max(104, ...d.projects.map(p=>p.projectNo||0)) + 1;

  return {
    projects:{
      title:'المشاريع', singular:'مشروع', entityKey:'projects',
      archiveGuard:(row, d)=>{
        const out = d.payments.filter(i=>i.projectId===row.id).reduce((s,i)=>s+remainderOf(i)*grossFactor(i),0);
        const amanat = d.govFees.filter(g=>!isArchived(g) && g.projectId===row.id && g.payerType!=='المالك مباشرة' && g.paidStatus==='مدفوع' && g.reimburseStatus!=='مسترد').reduce((s,g)=>s+g.amount,0);
        const comm = (d.contracts||[]).filter(c=>!isArchived(c) && c.projectId===row.id && c.category && c.category!=='خدمات استشارية').reduce((s,c)=>{
          const cm = contractCommission(c);
          const inv = d.payments.filter(i=>i.contractId===c.id).reduce((x,i)=>x+billedOf(i),0);
          return s + Math.max(0, cm-inv);
        },0);
        const probs = [];
        if(out>1) probs.push('ذمم غير محصّلة: '+money(out));
        if(amanat>1) probs.push('أمانات لم تُسترد: '+money(amanat));
        if(comm>1) probs.push('عمولات غير مفوترة: '+money(comm));
        return probs.length ? 'لا يمكن أرشفة المشروع — بنود مالية مفتوحة:\n• '+probs.join('\n• ')+'\n\nاستخدم "قائمة إقفال المشروع" داخل ملف المشروع لمراجعتها.' : null;
      },
      fields:[
        {name:'projectNo', label:'رقم المشروع', type:'number', required:true, hint:'ترقيم تلقائي تسلسلي يبدأ من 105 — كل الفواتير والسندات ستحمل هذا الرقم'},
        {name:'name', label:'اسم المشروع', required:true},
        {name:'owner', label:'اسم المالك', required:true},
        {name:'owningEntity', label:'الجهة المالكة (إن وجدت)'},
        {name:'ownerTrn', label:'الرقم الضريبي للمالك (TRN) — اختياري', hint:'يظهر على الفاتورة الضريبية إذا كان المالك مسجلاً بالضريبة'},
        {name:'additionalOwners', label:'ملاك إضافيون (شركاء في الملكية) — اختياري', type:'ownerList',
          subFields:[{name:'name', label:'اسم المالك'}, {name:'entity', label:'الجهة (إن وجدت)'}, {name:'trn', label:'TRN — اختياري'}],
          hint:'المالك الأساسي يُكتب في الحقول أعلاه — استخدم "+ إضافة مالك" هنا لإضافة شركاء آخرين في ملكية المشروع'},
        {name:'landType', label:'نوع الأرض', type:'select', options:[{value:'ملك',label:'ملك'},{value:'منحة',label:'منحة'}], required:true, hint:'أرض الملك لها رقمان (حكومي + ملك) — أرض المنحة لها الرقم الحكومي فقط'},
        {name:'plotNumber', label:'الرقم الحكومي (اختياري)'},
        {name:'ownershipNumber', label:'رقم الأرض (ملك) — اختياري', showIf:v=>v.landType==='ملك'},
        {name:'emirate', label:'الإمارة', type:'select', options:EMIRATES.map(e=>({value:e,label:e})), required:true},
        {name:'area', label:'المنطقة'},
        {name:'projectType', label:'نوع المشروع', type:'select', allowAddNew:true,
          options:(d)=>{
            const used = [...new Set((d.projects||[]).map(p=>p.projectType).filter(Boolean))];
            const all = [...PROJECT_TYPES, ...used.filter(t=>!PROJECT_TYPES.includes(t))];
            return all.map(t=>({value:t,label:t}));
          }, required:true, hint:'لا تجد النوع؟ اختر "➕ إضافة تصنيف جديد" من آخر القائمة — وهيفضل متاح لباقي المشاريع بعد كده'},
        {name:'engineer', label:'المهندس المسؤول'},
        {name:'status', label:'حالة المشروع', type:'select', options:[{value:'جارٍ',label:'جارٍ'},{value:'منتهٍ',label:'منتهٍ (اكتمل العقد)'},{value:'مفسوخ',label:'مفسوخ (أنهى المالك العقد قبل اكتماله)'},{value:'متوقف',label:'متوقف'}], required:true},
        {name:'terminationReason', label:'سبب فسخ العقد', type:'textarea', showIf:v=>v.status==='مفسوخ', hint:'مثال: أنهى المالك العقد في مرحلة التصميم / توقف المشروع نهائياً من جهة المالك — يُحفظ للتوثيق'},
        {name:'startDate', label:'تاريخ فتح المشروع', type:'date', required:true},
        {name:'budgetAmount', label:'ميزانية التكاليف المباشرة (د.إ) — اختياري', type:'number', hint:'سقف تقديري لتكاليف المشروع المباشرة — النظام ينبهك عند تجاوزه'},
        {name:'estHours', label:'الساعات المقدّرة للمشروع — اختياري', type:'number', hint:'عدد الساعات المتوقع أن يستغرقها المشروع — يقارنها النظام بالساعات الفعلية لتحسين التسعير'},
        {name:'folderName', label:'اسم مجلد المشروع (اختياري)', hint:'الافتراضي: رقم المشروع - اسمه، مثال: 105 - Villa Ahmed'},
        {name:'quickNotes', label:'ملاحظات سريعة للفريق', type:'textarea', hint:'ملاحظات يومية سريعة تظهر أعلى ملف المشروع — للتذكيرات والتنبيهات الجارية'},
      ],
      columns:[
        {key:'projectNo', label:'رقم', render:r=><b style={{fontSize:14, color:'var(--brass)'}}>{r.projectNo}</b>},
        {key:'name', label:'اسم المشروع'},
        {key:'owner', label:'المالك', render:r=> <span>{r.owner||'—'}{(r.additionalOwners||[]).filter(o=>o.name).length>0 && <span className="badge neutral" style={{marginInlineStart:6, fontSize:9}}>+{(r.additionalOwners||[]).filter(o=>o.name).length}</span>}</span>},
        {key:'projectType', label:'النوع', render:r=>r.projectType||'—'},
        {key:'area', label:'المنطقة', render:r=> (r.emirate||'')+(r.area?' — '+r.area:'')},
        {key:'contract', label:'قيمة العقود', render:(r,d)=><b>{money(contractValue(r,d))}</b>},
        {key:'status', label:'الحالة', render:r=>{
          const cls = r.status==='جارٍ'?'neutral':r.status==='منتهٍ'?'ok':'bad';
          return <span className={"badge "+cls}>{r.status}</span>;
        }},
      ],
      defaults:{status:'جارٍ', startDate:todayISO(), emirate:'الشارقة', projectNo:nextProjectNo(data), landType:'ملك'},
    },
    contracts:{
      title:'عقود المشروع', singular:'عقد', entityKey:'contracts',
      archiveGuard:(row, d)=>{
        const open = d.payments.filter(i=>!isArchived(i) && i.contractId===row.id && remainderOf(i)>0);
        return open.length ? 'العقد له '+open.length+' دفعة نشطة غير محصّلة بالكامل — حصّلها أو ألغِها أولاً ثم ألغِ العقد.' : null;
      },
      fields:[
        {name:'projectId', label:'المشروع', type:'select', options:projectOptions, required:true},
        {name:'category', label:'فئة العقد', type:'select', options:CONTRACT_CATEGORIES.map(c=>({value:c,label:c})), required:true, hint:'عقود الخدمات الاستشارية هي إيراد المكتب — عقود المقاولين للمتابعة والإشراف فقط'},
        {name:'type', label:'نطاق الخدمات الاستشارية', type:'select', allowAddNew:true,
          options:(d)=>{
            const used = [...new Set((d.contracts||[]).map(c=>c.type).filter(Boolean))];
            return [...CONTRACT_TYPES, ...used.filter(t=>!CONTRACT_TYPES.includes(t))].map(t=>({value:t,label:t}));
          }, showIf:v=>v.category==='خدمات استشارية'||!v.category, required:true, hint:'لا تجد النطاق؟ اختر "➕ إضافة تصنيف جديد" من آخر القائمة. ملاحظة: الأنواع المضافة تُعامل كعقد بقيمة واحدة (خيارات التصميم/الإشراف/الشامل محجوزة للأنواع الأساسية)'},
        {name:'subType', label:'تخصص مقاول الباطن', type:'select', options:SUBCONTRACT_TYPES.map(t=>({value:t,label:t})), showIf:v=>v.category==='مقاول باطن', required:true},
        {name:'contractor', label:'اسم المقاول', showIf:v=>v.category==='مقاول رئيسي'||v.category==='مقاول باطن', required:true},
        {name:'commissionType', label:'عمولة الاستشاري من هذا العقد', type:'select', options:[{value:'بدون',label:'بدون عمولة'},{value:'نسبة %',label:'نسبة % من قيمة العقد'},{value:'مبلغ ثابت',label:'مبلغ ثابت'}], showIf:v=>v.category==='مقاول رئيسي'||v.category==='مقاول باطن', required:true, hint:'قيمة عقد المقاول لا تدخل إيرادات المكتب — العمولة فقط هي الدخل، وتتحول لدفعة استشارية بزر التوليد'},
        {name:'commissionPct', label:'نسبة العمولة %', type:'number', showIf:v=>(v.category==='مقاول رئيسي'||v.category==='مقاول باطن')&&v.commissionType==='نسبة %', required:true},
        {name:'commissionAmount', label:'قيمة العمولة (د.إ)', type:'number', showIf:v=>(v.category==='مقاول رئيسي'||v.category==='مقاول باطن')&&v.commissionType==='مبلغ ثابت', required:true},
        {name:'description', label:'وصف العقد', required:true},
        {name:'designValue', label:'قيمة التصميم والاعتماد (د.إ)', type:'number', showIf:v=>(v.category==='خدمات استشارية'||!v.category)&&(v.type||'').indexOf('شامل')>-1, required:true},
        {name:'supervisionMonthly', label:'قيمة الإشراف الشهري (د.إ)', type:'number', showIf:v=>(v.category==='خدمات استشارية'||!v.category)&&(v.type==='إشراف'||(v.type||'').indexOf('شامل')>-1), required:true},
        {name:'supervisionMonths', label:'مدة الإشراف (بالشهور)', type:'number', showIf:v=>(v.category==='خدمات استشارية'||!v.category)&&(v.type==='إشراف'||(v.type||'').indexOf('شامل')>-1), required:true},
        {name:'value', label:'قيمة العقد (د.إ)', type:'number', showIf:v=>!((v.category==='خدمات استشارية'||!v.category)&&(v.type==='إشراف'||(v.type||'').indexOf('شامل')>-1)), required:true},
        {name:'note', label:'ملاحظات للفريق', type:'textarea'},
        {name:'date', label:'تاريخ العقد', type:'date', required:true},
        {name:'status', label:'الحالة', type:'select', options:[{value:'سارٍ',label:'سارٍ'},{value:'منتهٍ',label:'منتهٍ'},{value:'ملغى',label:'ملغى'}], required:true},
      ],
      columns:[
        {key:'project', label:'المشروع', render:(r,d)=>projName(r.projectId,d)},
        {key:'category', label:'الفئة', render:r=>{
          const cat = r.category||'خدمات استشارية';
          return <span className={"badge "+(cat==='خدمات استشارية'?'neutral':cat==='مقاول رئيسي'?'soon':'gray')}>{cat}</span>;
        }},
        {key:'detail', label:'التفاصيل', render:r=>{
          const cat = r.category||'خدمات استشارية';
          if(cat==='خدمات استشارية'){
            if(r.type==='إشراف') return (r.type||'')+' — '+money(r.supervisionMonthly)+' × '+(r.supervisionMonths||0)+' شهر';
            if(isComboContract(r)) return 'شامل — تصميم '+money(r.designValue||0)+' + إشراف '+money(r.supervisionMonthly)+' × '+(r.supervisionMonths||0)+' شهر';
            return r.type||'';
          }
          return (cat==='مقاول باطن' ? (r.subType||'')+' — ' : '')+(r.contractor||'');
        }},
        {key:'description', label:'الوصف'},
        {key:'note', label:'ملاحظات', render:r=> r.note ? <span title={r.note} style={{fontSize:11.5}}>{r.note.slice(0,35)}{r.note.length>35?'…':''}</span> : '—'},
        {key:'value', label:'القيمة', render:r=><b>{money((r.category==='خدمات استشارية'||!r.category) ? contractTotalOf(r) : (r.value||0))}</b>},
        {key:'fin', label:'مفوتر / محصّل', render:(r,d)=>{
          if(r.category && r.category!=='خدمات استشارية') return '—';
          const total = contractTotalOf(r);
          if(total<=0) return '—';
          const inv = (d.payments||[]).filter(i=>i.contractId===r.id).reduce((s,i)=>s+billedOf(i),0);
          const col = (d.payments||[]).filter(i=>i.contractId===r.id).reduce((s,i)=>s+collectedOf(i),0);
          return (
            <span style={{fontSize:11.5}}>
              فُوتر {Math.round(inv/total*100)}% · حُصّل {Math.round(col/total*100)}%
              <div className="progress" style={{width:70, marginTop:3}}><div style={{width:Math.min(100, col/total*100)+'%'}}></div></div>
            </span>
          );
        }},
        {key:'commission', label:'عمولة الاستشاري', render:(r,d)=>{
          const cm = contractCommission(r);
          if(cm<=0) return '—';
          const invoiced = (d.payments||[]).filter(i=>i.contractId===r.id).reduce((s,i)=>s+billedOf(i),0);
          return <span>{money(cm)} {invoiced>=cm*0.999 ? <span className="badge ok">مفوترة</span> : invoiced>0 ? <span className="badge soon">جزئياً</span> : <span className="badge gray">لم تُفوتر</span>}</span>;
        }},
        {key:'date', label:'التاريخ'},
        {key:'status', label:'الحالة', render:r=><span className={"badge "+(r.status==='سارٍ'?'ok':r.status==='منتهٍ'?'gray':'bad')}>{r.status}</span>},
      ],
      defaults:{date:todayISO(), status:'سارٍ', category:'خدمات استشارية', type:'تصميم واعتماد', commissionType:'بدون'},
    },
    decisions:{
      title:'القرارات والوقائع', singular:'قرار',
      fields:[
        {name:'projectId', label:'المشروع', type:'select', options:projectOptions, required:true},
        {name:'date', label:'التاريخ', type:'date', required:true},
        {name:'category', label:'التصنيف', type:'select', options:DECISION_CATEGORIES.map(c=>({value:c,label:c})), required:true},
        {name:'description', label:'الوصف', type:'textarea', required:true},
        {name:'responsible', label:'المسؤول'},
        {name:'status', label:'الحالة', type:'select', options:DECISION_STATUSES.map(s=>({value:s,label:s})), required:true},
        {name:'estCost', label:'التكلفة التقديرية (د.إ)', type:'number', showIf:v=>v.category==='أمر تغيير (Variation)', hint:'اتركها صفراً إذا لم تُقدَّر بعد'},
        {name:'ref', label:'مرجع المرفق', hint:'مثال: الصورة في جروب واتساب بتاريخ كذا، أو مسار ملف في مجلد المشروع'},
      ],
      columns:[
        {key:'date', label:'التاريخ'},
        {key:'project', label:'المشروع', render:(r,d)=>projName(r.projectId,d)},
        {key:'category', label:'التصنيف', render:r=><span className={"badge "+(r.category==='اعتماد المالك'?'ok':r.category==='مهمة'?'soon':(r.category||'').indexOf('تغيير')>-1?'bad':'gray')}>{r.category}</span>},
        {key:'description', label:'الوصف'},
        {key:'responsible', label:'المسؤول', render:r=>r.responsible||'—'},
        {key:'source', label:'المصدر', render:r=><span className="badge gray">{r.source||'يدوي'}</span>},
        {key:'status', label:'الحالة', render:r=><span className={"badge "+(r.status==='منفذ'?'ok':r.status==='مفتوح'?'soon':r.status==='ملغى'?'bad':'neutral')}>{r.status}</span>},
      ],
      defaults:{date:todayISO(), status:'مفتوح', category:'اعتماد المالك', source:'يدوي'},
    },
    payments:{
      title:'الدفعات الاستشارية', singular:'دفعة', entityKey:'payments',
      archiveGuard:(row)=>{
        const col = collectedOf(row);
        if(col>0) return 'لا يمكن أرشفة دفعة محصلة. تصحيح الإدخال يحتاج المالك وسببًا مسجلًا؛ رد الأموال الفعلي يحتاج حركة مالية مستقلة.';
        if(row.invoiceNo && row.date){
          const invQ = quarterOfYM(monthKey(row.date));
          const curQ = quarterOfYM(currentYM());
          if(invQ && curQ && invQ < curQ) return 'هذه الفاتورة تعود لفترة ضريبية سابقة ('+quarterLabel(invQ)+') غالباً قُدّم إقرارها للهيئة.\nإلغاؤها الآن يجعل أرقام النظام مخالفة للإقرار المقدَّم.\nالمسار المتوافق مع الهيئة: إشعار دائن ضريبي يُعكس في الفترة الحالية، أو إفصاح طوعي إن كان الفارق كبيراً — راجع مستشارك الضريبي.';
        }
        return null;
      },
      lockedFor:(r)=> (paymentIssued(r) || collectedOf(r)>0) ? ['projectId','contractId','phase','taxable','amount','label','month','date','dueDate'] : [],
      lockedNotice:'بيانات المستند أو التحصيل مقفلة. التصحيح متاح للمالك بسبب مسجل على الخادم، دون استثناء زمني.',
      allowAdminOverride:true,
      validate:(v, d, mode, record)=>{
        if(v.contractId && v.phase==='إشراف'){
          const dup = (d.payments||[]).find(p=> !isArchived(p) && p.contractId===v.contractId && p.phase==='إشراف' && p.month===v.month && p.id!==(record&&record.id));
          if(dup) return 'يوجد بالفعل دفعة إشراف مسجلة لنفس الشهر ('+fmtMonth(v.month)+') على هذا العقد — راجع قائمة الدفعات قبل الإضافة لتفادي الفوترة المزدوجة لنفس الشهر.';
        }
        if(v.contractId && v.phase==='تصميم'){
          const c = (d.contracts||[]).find(x=>x.id===v.contractId);
          if(c){
            const designTotal = c.type==='إشراف' ? 0 : (isComboContract(c) ? (c.designValue||0) : (c.value||0));
            if(designTotal>0){
              const already = (d.payments||[]).filter(p=> !isArchived(p) && p.status!=='ملغاة' && p.contractId===v.contractId && p.phase==='تصميم' && p.id!==(record&&record.id)).reduce((s,p)=>s+(p.amount||0),0);
              if(already + (v.amount||0) > designTotal*1.001){
                return 'مجموع دفعات التصميم على هذا العقد سيتجاوز قيمة التصميم في العقد ('+money(designTotal)+').\nالمُدخل من قبل: '+money(already)+' + هذه الدفعة: '+money(v.amount||0)+'.\nراجع القيم قبل الحفظ.';
              }
            }
          }
        }
        return null;
      },
      fields:[
        {name:'projectId', label:'المشروع', type:'select', options:projectOptions, required:true},
        {name:'contractId', label:'العقد', type:'select', options:(d,v)=> (d.contracts||[]).filter(c=> c.projectId===(v&&v.projectId) && isConsultancy(c)
            && (v.phase==='إشراف' ? contractHasSupervision(c) : v.phase==='تصميم' ? c.type!=='إشراف' : true)
          ).map(c=>({value:c.id, label:(c.type||'')+' — '+(c.description||'')})), showIf:v=>!!v.projectId, required:(v)=> v.phase==='تصميم'||v.phase==='إشراف', hint:'إلزامي لدفعات التصميم والإشراف — بدونه لا تُحسب نسب العقد (فُوتر/حُصّل) ولا يعمل توليد الإشراف بشكل سليم. القائمة مفلترة تلقائياً حسب نوع الدفعة المختار.'},
        {name:'phase', label:'نوع الدفعة', type:'select', options:[
          {value:'تصميم', label:'تصميم / اعتماد المخططات'},
          {value:'إشراف', label:'إشراف ميداني شهري'},
          {value:'أخرى', label:'رسوم أخرى خاضعة للضريبة (فحوصات، خدمات خارجية...)'},
        ], required:true, hint:'"تصميم" هو نفس الاختيار لكل أقساط التصميم (الأولى، الثانية...) — مش بيتغيّر حسب رقم القسط. الفرق بين الأقساط بيتحدد في خانة "وصف الدفعة" تحت.',
          sync:(v)=>({amountGross: v.amount==='' ? '' : r2((parseFloat(v.amount)||0) * payF(v))})},
        {name:'label', label:'وصف الدفعة', showIf:v=>v.phase!=='إشراف', required:(v)=>v.phase==='تصميم', hint:'هنا بتحدد رقم القسط بنفسك: اكتب مثلاً "الدفعة الأولى — توقيع العقد 50%" ثم في القسط التاني اكتب "الدفعة الثانية — الاعتماد النهائي 50%". نوع الدفعة (تصميم) بيفضل واحد، الفرق بيبان هنا بس.'},
        {name:'month', label:'شهر الإشراف', type:'month', showIf:v=>v.phase==='إشراف', required:true},
        {name:'taxable', label:'الخضوع لضريبة القيمة المضافة', type:'select', options:[{value:'خاضعة',label:'خاضعة للضريبة (5%)'},{value:'غير خاضعة',label:'غير خاضعة / معفاة'}], required:true, hint:'الافتراضي "خاضعة" لكل الدفعات. اختر "غير خاضعة" فقط لو الدفعة معفاة فعلياً — مثل مبالغ مدفوعة نيابة عن المالك بإيصال باسمه.',
          sync:(v)=>({amountGross: v.amount==='' ? '' : r2((parseFloat(v.amount)||0) * payF(v))})},
        {name:'amount', label:'المبلغ قبل الضريبة (د.إ)', type:'number', required:true,
          sync:(v)=>({amountGross: v.amount==='' ? '' : r2((parseFloat(v.amount)||0) * payF(v))})},
        {name:'amountGross', label:'المبلغ شامل الضريبة (د.إ)', type:'number', ephemeral:true,
          sync:(v)=>({amount: v.amountGross==='' ? '' : r2((parseFloat(v.amountGross)||0) / payF(v))}),
          initCompute:(v)=> (v.amount===''||v.amount===undefined) ? '' : r2((parseFloat(v.amount)||0) * payF(v)),
          hint:'اكتب المبلغ المتفق عليه شاملاً — يُحسب الصافي تلقائياً بالقسمة على 1.05 (وفق معادلة الهيئة). التعديل في أي من الخانتين يحدّث الأخرى'},
        {name:'date', label:'تاريخ الإصدار', type:'date', required:true},
        {name:'dueDate', label:'تاريخ الاستحقاق', type:'date', required:true},
        {name:'status', label:'حالة السداد', type:'select', options:[{value:'مدفوعة',label:'مدفوعة بالكامل'},{value:'مدفوعة جزئياً',label:'مدفوعة جزئياً'},{value:'معلقة',label:'معلقة'},{value:'متأخرة',label:'متأخرة'},{value:'ملغاة',label:'ملغاة (فسخ عقد — تسقط ولا تُحتسب)'}], required:true},
        {name:'cancelReason', label:'سبب الإلغاء', type:'textarea', showIf:v=>v.status==='ملغاة', required:true, hint:'مثال: فُسخ العقد من المالك قبل تنفيذ العمل / ارتجع الشيك ولم تُستحق الخدمة. يُحفظ للتوثيق والتدقيق'},
        {name:'collectedAmount', label:'المبلغ المحصّل قبل الضريبة (د.إ)', type:'number', showIf:v=>v.status==='مدفوعة جزئياً', required:true, hint:'الجزء الذي دفعه المالك فعلاً من قيمة الدفعة'},
        {name:'paidDate', label:'تاريخ استلام الدفعة', type:'date', showIf:v=>v.status==='مدفوعة'||v.status==='مدفوعة جزئياً', required:true},
        {name:'method', label:'طريقة الدفع', type:'select', options:[{value:'نقداً',label:'نقداً'},{value:'شيك',label:'شيك'},{value:'تحويل بنكي',label:'تحويل بنكي'},{value:'بطاقة',label:'بطاقة (دفع إلكتروني)'}], showIf:v=>v.status==='مدفوعة'||v.status==='مدفوعة جزئياً',
          sync:(v)=>({account: v.method==='نقداً' ? 'الخزينة' : 'البنك'})},
        {name:'account', label:'الحساب المستلِم', type:'select', options:[{value:'البنك',label:'البنك'},{value:'الخزينة',label:'الخزينة (نقدي)'}], showIf:v=>v.status==='مدفوعة'||v.status==='مدفوعة جزئياً', required:true, hint:'يُحدَّد تلقائياً من طريقة الدفع (تحويل/شيك/بطاقة ← البنك، نقداً ← الخزينة) — ويمكن تعديله يدوياً. الدفعات القديمة تُعتبر "البنك" افتراضياً'},
        {name:'refNo', label:'رقم الشيك / مرجع التحويل أو العملية', showIf:v=>(v.status==='مدفوعة'||v.status==='مدفوعة جزئياً') && v.method && v.method!=='نقداً'},
        {name:'chequeDueDate', label:'تاريخ صرف الشيك المتوقع', type:'date', showIf:v=>(v.status==='مدفوعة'||v.status==='مدفوعة جزئياً') && v.method==='شيك', hint:'لو الشيك مؤجل ولسه ما اتصرفش من البنك — النظام هينبهك قبل تاريخه بـ10 أيام'},
        {name:'note', label:'ملاحظات (تظهر على الإيصال)'},
      ],
      columns:[
        {key:'project', label:'المشروع', render:r=>projName(r.projectId, data)},
        {key:'phase', label:'النوع', render:r=>(
          <span className={"badge "+(r.phase==='إشراف'?'neutral':r.phase==='أخرى'?'soon':'gray')}>{r.phase==='إشراف'?'إشراف':r.phase==='أخرى'?'رسوم أخرى':'تصميم واعتماد'}</span>
        )},
        {key:'label', label:'البند', render:r=> r.phase==='إشراف' ? ('إشراف '+(r.month?fmtMonth(r.month):'')) : (r.label||'—')},
        {key:'amount', label:'المبلغ', render:r=>money(r.amount)},
        {key:'vat', label:'ض.ق.م', render:r=> vatRateOf(r)===0 ? <span className="badge gray">معفاة</span> : money(r.amount*0.05)},
        {key:'total', label:'الإجمالي', render:r=><b>{money(r.amount*grossFactor(r))}</b>},
        {key:'dueDate', label:'الاستحقاق'},
        {key:'paidDate', label:'تاريخ الاستلام', render:r=> (r.status==='مدفوعة'||r.status==='مدفوعة جزئياً') ? (r.paidDate||r.date) : '—'},
        {key:'status', label:'الحالة', render:r=>{
          if(r.status==='مدفوعة جزئياً') return (
            <span>
              <span className="badge neutral">مدفوعة جزئياً</span>
              <div style={{fontSize:10.5, color:'var(--ink-faint)', marginTop:3}}>محصّل {money(collectedOf(r)*grossFactor(r))} · متبقٍ {money(remainderOf(r)*grossFactor(r))}</div>
            </span>
          );
          if(r.status==='ملغاة') return (
            <span>
              <span className="badge gray" style={{textDecoration:'line-through'}}>ملغاة</span>
              {r.cancelReason && <div style={{fontSize:10.5, color:'var(--ink-faint)', marginTop:3}} title={r.cancelReason}>فسخ عقد — {r.cancelReason.slice(0,30)}{r.cancelReason.length>30?'…':''}</div>}
            </span>
          );
          const cls = r.status==='مدفوعة'?'ok':r.status==='متأخرة'?'bad':'soon';
          return <span className={"badge "+cls}>{r.status}</span>;
        }},
      ],
      defaults:{date:todayISO(), dueDate:todayISO(), status:'معلقة', phase:'تصميم', taxable:'خاضعة'},
    },
    govFees:{
      title:'الرسوم الحكومية', singular:'رسم حكومي', entityKey:'govFees',
      archiveGuard:(row)=> (row.payerType!=='المالك مباشرة' && row.paidStatus==='مدفوع')
        ? 'هذا الرسم مدفوع من خزينة المكتب — إلغاؤه يُخفي الخصم من الخزينة رغم خروج المال فعلياً.\nإن كان القيد خاطئاً: عدّل حالة السداد إلى "غير مدفوع" أولاً ثم ألغِ.'
        : null,
      fields:[
        {name:'projectId', label:'المشروع', type:'select', options:projectOptions, required:true},
        {name:'department', label:'الدائرة الحكومية', type:'select', allowAddNew:true, addNewPrompt:'اسم الدائرة الحكومية الجديدة:',
          options:(d)=>{
            const used = [...new Set((d.govFees||[]).map(g=>g.department).filter(Boolean))];
            const all = [...GOV_DEPARTMENTS, ...used.filter(x=>!GOV_DEPARTMENTS.includes(x))];
            return all.map(x=>({value:x,label:x}));
          }, required:true, addNewLabel:'➕ إضافة دائرة جديدة...', hint:'لا تجد الدائرة؟ اختر "➕ إضافة دائرة جديدة" من آخر القائمة'},
        {name:'description', label:'تفصيل الرسم', required:true, hint:'مثال: رسوم اعتماد المخطط الهندسي / رسوم توصيل مؤقت'},
        {name:'descriptionEn', label:'تفصيل الرسم بالإنجليزي (اختياري)', hint:'يظهر في كشف الحساب الإنجليزي بدل العربي. اتركيه فارغاً لعرض النص العربي في كلتا اللغتين'},
        {name:'amount', label:'المبلغ (د.إ)', type:'number', required:true},
        {name:'date', label:'التاريخ', type:'date', required:true},
        {name:'receiptNo', label:'رقم الإيصال / المعاملة'},
        {name:'payerType', label:'طريقة السداد', type:'select', options:[{value:'المكتب',label:'من خزينة المكتب (أمانة تُسترد من المالك)'},{value:'المالك مباشرة',label:'دفع مباشر من المالك (رابط دفع / بوابة الدائرة)'}], required:true, hint:'الدفع المباشر من المالك لا يمس خزينة المكتب ولا يُنشئ أمانة — يُسجل للتوثيق فقط'},
        {name:'account', label:'الدفع من حساب', type:'select', options:[{value:'البنك',label:'البنك'},{value:'الخزينة',label:'الخزينة (نقدي)'}], showIf:v=>v.payerType!=='المالك مباشرة', required:true, hint:'يُخصم من هذا الحساب عند السداد للدائرة، ويُعاد إليه عند الاسترداد من المالك'},
        {name:'paidStatus', label:'السداد للدائرة', type:'select', options:[{value:'مدفوع',label:'مدفوع للدائرة'},{value:'غير مدفوع',label:'غير مدفوع بعد'}], required:true},
        {name:'reimburseStatus', label:'الاسترداد من العميل', type:'select', options:[{value:'مسترد',label:'مسترد من العميل'},{value:'غير مسترد',label:'غير مسترد بعد'}], showIf:v=>v.payerType!=='المالك مباشرة', required:true},
        {name:'note', label:'ملاحظات للفريق', type:'textarea', hint:'مثال: رابط الدفع أُرسل للمالك بتاريخ كذا وبانتظار السداد'},
      ],
      columns:[
        {key:'project', label:'المشروع', render:r=>projName(r.projectId, data)},
        {key:'department', label:'الدائرة'},
        {key:'description', label:'التفصيل'},
        {key:'amount', label:'المبلغ', render:r=>money(r.amount)},
        {key:'receiptNo', label:'الإيصال', render:r=>r.receiptNo||'—'},
        {key:'payerType', label:'السداد', render:r=><span className={"badge "+(r.payerType==='المالك مباشرة'?'neutral':'gray')}>{r.payerType==='المالك مباشرة'?'المالك مباشرة':'المكتب (أمانة)'}</span>},
        {key:'paidStatus', label:'للدائرة', render:r=><span className={"badge "+(r.paidStatus==='مدفوع'?'ok':'soon')}>{r.paidStatus}</span>},
        {key:'reimburseStatus', label:'من العميل', render:r=> r.payerType==='المالك مباشرة' ? <span className="badge gray">لا ينطبق</span> : <span className={"badge "+(r.reimburseStatus==='مسترد'?'ok':'bad')}>{r.reimburseStatus}</span>},
        {key:'note', label:'ملاحظات', render:r=> r.note ? <span title={r.note} style={{fontSize:11.5}}>{r.note.slice(0,40)}{r.note.length>40?'…':''}</span> : '—'},
      ],
      defaults:{date:todayISO(), paidStatus:'غير مدفوع', reimburseStatus:'غير مسترد', account:'البنك', payerType:'المكتب'},
    },
    officeExpenses:{
      title:'مصروفات المكتب', singular:'مصروف مكتب',
      sortFn:(a,b)=> (b.date||'').localeCompare(a.date||''),
      fields:[
        {name:'category', label:'التصنيف', type:'select', allowAddNew:true,
          options:(d)=>{
            const used = [...new Set((d.officeExpenses||[]).map(e=>e.category).filter(Boolean))];
            const all = [...OFFICE_CATEGORIES, ...used.filter(c=>!OFFICE_CATEGORIES.includes(c))];
            return all.map(c=>({value:c,label:c}));
          }, required:true, hint:'لا تجد التصنيف؟ اختر "➕ إضافة تصنيف جديد" من آخر القائمة'},
        {name:'vendor', label:'المورّد (اختياري)', type:'select', allowAddNew:true,
          options:(d)=>{
            const used = [...new Set((d.officeExpenses||[]).map(e=>e.vendor).filter(Boolean))];
            const all = [...OFFICE_VENDORS, ...used.filter(v=>!OFFICE_VENDORS.includes(v))];
            return all.map(v=>({value:v,label:v}));
          }, hint:'الجهة اللي اتدفعلها (مثلاً Etisalat، SEWA، صاحب العقار) — يفيد لتجميع مصروفات كل مورّد وللتدقيق الضريبي. لا تجده؟ اختر "➕ إضافة مورّد جديد"'},
        {name:'vendorInvoiceNo', label:'رقم فاتورة المورّد (اختياري)', hint:'رقم الفاتورة الضريبية كما يظهر في فاتورة المورّد — مطلوب عند تدقيق الهيئة الاتحادية لضريبة المدخلات'},
        {name:'amount', label:'المبلغ قبل الضريبة (د.إ)', type:'number', required:true,
          sync:(v)=>({amountGross: v.amount==='' ? '' : r2((parseFloat(v.amount)||0) * expF(v))})},
        {name:'amountGross', label:'المبلغ شامل الضريبة (د.إ)', type:'number', ephemeral:true,
          sync:(v)=>({amount: v.amountGross==='' ? '' : r2((parseFloat(v.amountGross)||0) / expF(v))}),
          initCompute:(v)=> (v.amount===''||v.amount===undefined) ? '' : Math.round((parseFloat(v.amount)||0)*(v.vatable==='غير خاضع'?1:1.05)*100)/100,
          hint:'اكتب المبلغ كما في فاتورة المورد (شاملاً) — يُحسب الصافي تلقائياً'},
        {name:'payStatus', label:'حالة السداد', type:'select', options:[{value:'مدفوع',label:'مدفوع'},{value:'معلق',label:'معلق — لم يُسدد بعد'}], required:true, hint:'المصروف المعلق لا يُخصم من الخزينة حتى يتحول إلى مدفوع'},
        {name:'vatable', label:'خاضع لضريبة القيمة المضافة؟', type:'select', options:[{value:'خاضع',label:'خاضع 5% (لديك فاتورة ضريبية من المورد)'},{value:'غير خاضع',label:'غير خاضع / معفى / بدون فاتورة ضريبية'}], required:true, hint:'ضريبة المدخلات لا تُسترد إلا بفاتورة ضريبية سارية باسم المكتب — اختر "غير خاضع" إن لم توجد',
          sync:(v)=>({amountGross: v.amount==='' ? '' : r2((parseFloat(v.amount)||0) * expF(v))})},
        {name:'account', label:'الدفع من حساب', type:'select', options:[{value:'البنك',label:'البنك'},{value:'الخزينة',label:'الخزينة (نقدي)'},{value:'شيك',label:'شيك صادر'}], required:true},
        {name:'bankName', label:'اسم البنك', showIf:v=>v.account==='البنك'||v.account==='شيك', hint:'اكتب WIO NITAQ لو الدفع من حساب المكتب — أي بنك تاني (زي ADCB) هيتحسب "دين علينا" تلقائياً. اكتب الاسم بنفس الصيغة في كل مرة عشان الفلتر والإجماليات تطلع صح'},
        {name:'bankRef', label:'الرقم المرجعي للعملية البنكية (اختياري)', showIf:v=>v.account==='البنك', hint:'رقم الحوالة / رقم العملية كما يظهر في كشف الحساب البنكي — يفيد عند المطابقة لاحقاً'},
        {name:'chequeNo', label:'رقم الشيك', showIf:v=>v.account==='شيك', required:true},
        {name:'chequeDueDate', label:'تاريخ صرف الشيك المتوقع', type:'date', showIf:v=>v.account==='شيك', required:true, hint:'التاريخ اللي المفروض المورد/الجهة يصرف فيه الشيك — النظام هينبهك قبله بـ10 أيام'},
        {name:'date', label:'التاريخ', type:'date', required:true},
        {name:'attachment', label:'صورة الفاتورة (اختياري)', type:'file', hint:'ارفعي صورة أو PDF للفاتورة الضريبية (أقل من 1 ميجا) — تُحفظ مع المصروف للتدقيق لاحقاً'},
        {name:'note', label:'ملاحظات', type:'textarea'},
      ],
      columns:[
        {key:'date', label:'التاريخ'},
        {key:'category', label:'التصنيف'},
        {key:'vendor', label:'المورّد', render:r=> r.vendor || <span style={{color:'var(--ink-faint)'}}>—</span>},
        {key:'amount', label:'قبل الضريبة', render:r=>money(r.amount)},
        {key:'vat', label:'الضريبة (5%)', render:r=> expVatRate(r)>0
          ? money((r.amount||0)*expVatRate(r))
          : <span style={{color:'var(--ink-faint)'}}>—</span>},
        {key:'gross', label:'شامل الضريبة', render:r=><b>{money(expGross(r))}</b>},
        {key:'debt', label:'دين علينا', render:r=> isDebtExpense(r)
          ? <b style={{color:'var(--rust)'}}>{money(expDebt(r))}</b>
          : <span style={{color:'var(--ink-faint)'}}>—</span>},
        {key:'payStatus', label:'السداد', render:r=> (r.payStatus==='معلق') ? <span className="badge soon">معلق</span> : <span className="badge ok">مدفوع</span>},
        {key:'account', label:'الحساب', render:r=> r.account||'—'},
        {key:'payDetails', label:'تفاصيل الدفع', truncate:true, render:r=>{
          if(r.account==='شيك') return 'شيك '+(r.chequeNo||'—')+' — استحقاق '+(r.chequeDueDate||'—');
          if(r.account==='البنك') return [r.bankName, r.bankRef].filter(Boolean).join(' — ') || '—';
          return '—';
        }},
        {key:'attachment', label:'فاتورة', render:r=> r.attachment
          ? <a href={safeAttachmentUrl(r.attachment)} target="_blank" rel="noopener" title={r.attachment_name||'عرض المرفق'} style={{textDecoration:'none', fontSize:16}}>📎</a>
          : <span style={{color:'var(--ink-faint)'}}>—</span>},
        {key:'note', label:'ملاحظات', truncate:true, render:r=>r.note||'—'},
      ],
      defaults:{date:todayISO(), account:'البنك', payStatus:'معلق', vatable:'خاضع'},
      footRow:(rows)=>{
        const totAmt = rows.reduce((s,e)=>s+(e.amount||0),0);
        const totVat = rows.reduce((s,e)=>s+(e.amount||0)*expVatRate(e),0);
        const totGross = rows.reduce((s,e)=>s+expGross(e),0);
        const totDebt = rows.reduce((s,e)=>s+expDebt(e),0);
        return (
          <tr style={{background:'#F4F1E8', borderTop:'2px solid var(--line-strong)', fontWeight:800}}>
            <td style={{fontWeight:800}}>الإجمالي</td>
            <td></td>
            <td></td>
            <td><b>{money(totAmt)}</b></td>
            <td><b>{money(totVat)}</b></td>
            <td><b>{money(totGross)}</b></td>
            <td><b style={{color:'var(--rust)'}}>{money(totDebt)}</b></td>
            <td colSpan={6}></td>
          </tr>
        );
      },
    },
    projectCosts:{
      title:'تكاليف المشاريع', singular:'تكلفة مشروع',
      fields:[
        {name:'projectId', label:'المشروع', type:'select', options:projectOptions, required:true},
        {name:'category', label:'التصنيف', type:'select', options:PROJECT_COST_CATEGORIES.map(c=>({value:c,label:c})), required:true},
        {name:'amount', label:'المبلغ قبل الضريبة (د.إ)', type:'number', required:true},
        {name:'vatable', label:'خاضع لضريبة القيمة المضافة؟', type:'select', options:[{value:'خاضع',label:'خاضع 5% (لديك فاتورة ضريبية)'},{value:'غير خاضع',label:'غير خاضع / معفى'}], required:true},
        {name:'account', label:'الدفع من حساب', type:'select', options:[{value:'البنك',label:'البنك'},{value:'الخزينة',label:'الخزينة (نقدي)'},{value:'شيك',label:'شيك صادر'}], required:true},
        {name:'chequeNo', label:'رقم الشيك', showIf:v=>v.account==='شيك', required:true},
        {name:'chequeDueDate', label:'تاريخ صرف الشيك المتوقع', type:'date', showIf:v=>v.account==='شيك', required:true, hint:'التاريخ اللي المفروض المورد/المقاول يصرف فيه الشيك — النظام هينبهك قبله بـ10 أيام'},
        {name:'date', label:'التاريخ', type:'date', required:true},
        {name:'note', label:'ملاحظات', type:'textarea'},
      ],
      columns:[
        {key:'date', label:'التاريخ'},
        {key:'project', label:'المشروع', render:r=>projName(r.projectId, data)},
        {key:'category', label:'التصنيف'},
        {key:'amount', label:'المبلغ', render:r=>money(r.amount)},
        {key:'chequeDueDate', label:'استحقاق الشيك', render:r=> r.account==='شيك' ? ((r.chequeNo||'—')+' — '+(r.chequeDueDate||'—')) : '—'},
        {key:'note', label:'ملاحظات', truncate:true, render:r=>r.note||'—'},
      ],
      defaults:{date:todayISO(), account:'البنك', vatable:'خاضع'},
    },
    recurringBills:{
      title:'الفواتير الدورية', singular:'فاتورة دورية',
      fields:[
        {name:'provider', label:'اسم الجهة / الخدمة', required:true, hint:'مثال: اتصالات، دو، سيوا، مالك العقار (إيجار)...'},
        {name:'category', label:'نوع الخدمة', type:'select', allowAddNew:true,
          options:(d)=>{
            const base = ['اتصالات (هاتف/فاكس)','إنترنت','كهرباء وماء (سيوا)','إيجار المكتب','اشتراك برمجي','تأمين','أخرى'];
            const used = [...new Set((d.recurringBills||[]).map(b=>b.category).filter(Boolean))];
            return [...base, ...used.filter(c=>!base.includes(c))].map(c=>({value:c,label:c}));
          }, required:true},
        {name:'amount', label:'المبلغ المعتاد (د.إ)', type:'number', required:true, hint:'آخر مبلغ مدفوع أو المتوسط — يمكن تعديله لاحقاً عند كل سداد فعلي'},
        {name:'frequency', label:'دورية السداد', type:'select', options:[{value:'شهري',label:'شهري'},{value:'ربع سنوي',label:'ربع سنوي (كل 3 أشهر)'},{value:'نصف سنوي',label:'نصف سنوي (كل 6 أشهر)'},{value:'سنوي',label:'سنوي'}], required:true},
        {name:'nextDueDate', label:'تاريخ الاستحقاق القادم', type:'date', required:true},
        {name:'reminderDays', label:'التنبيه قبل الاستحقاق بكم يوم', type:'number', required:true},
        {name:'account', label:'تُسدد من حساب', type:'select', options:[{value:'البنك',label:'البنك'},{value:'الخزينة',label:'الخزينة (نقدي)'}], required:true},
        {name:'active', label:'الحالة', type:'select', options:[{value:'نشط',label:'نشط — يُنبّه عند الاستحقاق'},{value:'متوقف',label:'متوقف مؤقتاً / أُلغي الاشتراك'}], required:true},
        {name:'note', label:'ملاحظات', type:'textarea'},
      ],
      columns:[
        {key:'provider', label:'الجهة / الخدمة'},
        {key:'category', label:'النوع'},
        {key:'amount', label:'المبلغ المعتاد', render:r=>money(r.amount)},
        {key:'frequency', label:'الدورية'},
        {key:'nextDueDate', label:'الاستحقاق القادم'},
        {key:'active', label:'الحالة', render:r=> r.active==='متوقف' ? <span className="badge gray">متوقف</span> : <span className="badge ok">نشط</span>},
      ],
      defaults:{nextDueDate:todayISO(), frequency:'شهري', reminderDays:5, account:'البنك', active:'نشط'},
    },
    treasury:{
      title:'حركات يدوية (رصيد افتتاحي، إيداع، سحب نثري، تحويل بين الحسابات)', singular:'حركة',
      fields:[
        {name:'type', label:'نوع الحركة', type:'select', options:[{value:'قبض',label:'قبض / إيداع'},{value:'صرف',label:'صرف / سحب'},{value:'تحويل',label:'تحويل بين الحسابات'}], required:true},
        {name:'account', label:'الحساب', type:'select', options:[{value:'البنك',label:'البنك'},{value:'الخزينة',label:'الخزينة (نقدي)'}], required:true},
        {name:'toAccount', label:'تحويل إلى حساب', type:'select', options:[{value:'البنك',label:'البنك'},{value:'الخزينة',label:'الخزينة (نقدي)'}], showIf:v=>v.type==='تحويل', required:true},
        {name:'amount', label:'المبلغ (د.إ)', type:'number', required:true},
        {name:'date', label:'التاريخ', type:'date', required:true},
        {name:'note', label:'البيان', required:true},
      ],
      columns:[
        {key:'date', label:'التاريخ'},
        {key:'type', label:'النوع', render:r=><span className={"badge "+(r.type==='قبض'?'ok':r.type==='صرف'?'bad':'neutral')}>{r.type}</span>},
        {key:'account', label:'الحساب', render:r=> r.type==='تحويل' ? (r.account+' ← '+(r.toAccount||'')) : r.account},
        {key:'amount', label:'المبلغ', render:r=>money(r.amount)},
        {key:'note', label:'البيان'},
      ],
      defaults:{date:todayISO(), type:'قبض', account:'البنك'},
    },
    otherIncome:{
      title:'الإيرادات الأخرى', singular:'إيراد آخر',
      sortFn:(a,b)=> (b.date||'').localeCompare(a.date||''),
      fields:[
        {name:'category', label:'مصدر الإيراد', type:'select', allowAddNew:true, addNewLabel:'➕ إضافة مصدر جديد...', addNewPrompt:'اسم مصدر الإيراد الجديد:',
          options:(d)=>{
            const used = [...new Set((d.otherIncome||[]).map(r=>r.category).filter(Boolean))];
            const all = [...OTHER_INCOME_CATEGORIES, ...used.filter(c=>!OTHER_INCOME_CATEGORIES.includes(c))];
            return all.map(c=>({value:c,label:c}));
          }, required:true, hint:'لا تجد المصدر؟ اختر "➕ إضافة مصدر جديد" من آخر القائمة'},
        {name:'amount', label:'المبلغ قبل الضريبة (د.إ)', type:'number', required:true},
        {name:'vatable', label:'خاضع لضريبة القيمة المضافة؟', type:'select', options:[{value:'خاضع',label:'خاضع 5%'},{value:'غير خاضع',label:'غير خاضع / معفى'}], required:true, hint:'بيع أصل مستعمل غالباً معفى؛ العمولة والاستشارة خاضعة. اختر حسب طبيعة الإيراد'},
        {name:'account', label:'الحساب المستلِم', type:'select', options:[{value:'البنك',label:'البنك'},{value:'الخزينة',label:'الخزينة (نقدي)'}], required:true, hint:'يُضاف إلى رصيد هذا الحساب'},
        {name:'date', label:'التاريخ', type:'date', required:true},
        {name:'payer', label:'الجهة الدافعة (اختياري)', hint:'مين دفع الإيراد ده — يفيد للتوثيق'},
        {name:'note', label:'البيان', type:'textarea'},
      ],
      columns:[
        {key:'date', label:'التاريخ'},
        {key:'category', label:'المصدر'},
        {key:'amount', label:'قبل الضريبة', render:r=>money(r.amount)},
        {key:'vat', label:'الضريبة (5%)', render:r=> incVatRate(r)>0 ? money(incVat(r)) : <span style={{color:'var(--ink-faint)'}}>معفى</span>},
        {key:'gross', label:'شامل الضريبة', render:r=><b>{money(incGross(r))}</b>},
        {key:'account', label:'الحساب'},
        {key:'payer', label:'الجهة الدافعة', render:r=>r.payer||'—'},
        {key:'note', label:'البيان', truncate:true, render:r=>r.note||'—'},
      ],
      defaults:{date:todayISO(), account:'البنك', vatable:'غير خاضع'},
      footRow:(rows)=>{
        const totAmt = rows.reduce((s,r)=>s+(r.amount||0),0);
        const totVat = rows.reduce((s,r)=>s+incVat(r),0);
        const totGross = rows.reduce((s,r)=>s+incGross(r),0);
        return (
          <tr style={{background:'#F4F1E8', borderTop:'2px solid var(--line-strong)', fontWeight:800}}>
            <td style={{fontWeight:800}}>الإجمالي</td>
            <td></td>
            <td><b>{money(totAmt)}</b></td>
            <td><b>{money(totVat)}</b></td>
            <td><b>{money(totGross)}</b></td>
            <td colSpan={3}></td>
          </tr>
        );
      },
    },
    employees:{
      title:'الموظفون', singular:'موظف',
      fields:[
        {name:'name', label:'الاسم', required:true},
        {name:'position', label:'الوظيفة', required:true},
        {name:'baseSalary', label:'الراتب الأساسي (د.إ)', type:'number', required:true, hint:'يُحسب عليه خصم الغياب والأوفرتايم ومكافأة نهاية الخدمة'},
        {name:'grossSalary', label:'إجمالي الراتب (د.إ)', type:'number', hint:'الراتب الكامل شامل البدلات — يُحسب عليه الصافي وحماية الأجور. اتركه فارغاً ليساوي الأساسي'},
        {name:'hireDate', label:'تاريخ التعيين', type:'date', required:true},
        {name:'phone', label:'رقم الهاتف'},
        {name:'iban', label:'رقم الآيبان (للـ WPS)'},
        {name:'payMode', label:'طريقة صرف الراتب', type:'select', options:[{value:'WPS',label:'عبر WPS (حماية الأجور) — دفعة واحدة'},{value:'خارج WPS',label:'خارج WPS — على دفعات'}], hint:'الموظف خارج WPS لا يظهر في ملف WPS ويُصرف راتبه على دفعات من زر «صرف» في كشف الرواتب'},
        {name:'iqamaNumber', label:'رقم الإقامة'},
        {name:'iqamaExpiry', label:'تاريخ انتهاء الإقامة', type:'date'},
        {name:'passportExpiry', label:'تاريخ انتهاء جواز السفر', type:'date'},
        {name:'workCardExpiry', label:'تاريخ انتهاء بطاقة العمل', type:'date'},
        {name:'note', label:'ملاحظات', type:'textarea'},
      ],
      columns:[
        {key:'name', label:'الاسم'},
        {key:'position', label:'الوظيفة'},
        {key:'baseSalary', label:'الراتب', render:r=>money(r.baseSalary)},
        {key:'payMode', label:'صرف الراتب', render:r=> isWpsEmp(r) ? <span className="badge ok">WPS</span> : <span className="badge soon">خارج WPS</span>},
        {key:'iqamaNumber', label:'رقم الإقامة'},
        {key:'iqamaExpiry', label:'الإقامة', render:r=>(
          <span className={"badge "+expiryStatus(r.iqamaExpiry, WARN_IQAMA)}>{r.iqamaExpiry||'—'}</span>
        )},
        {key:'passportExpiry', label:'الجواز', render:r=> r.passportExpiry ? (
          <span className={"badge "+expiryStatus(r.passportExpiry, WARN_PASSPORT)}>{r.passportExpiry}</span>
        ) : '—'},
        {key:'workCardExpiry', label:'بطاقة العمل', render:r=> r.workCardExpiry ? (
          <span className={"badge "+expiryStatus(r.workCardExpiry, WARN_DEFAULT)}>{r.workCardExpiry}</span>
        ) : '—'},
      ],
      defaults:{hireDate:todayISO(), payMode:'WPS'},
    },
    overtime:{
      title:'الأوفرتايم', singular:'سجل أوفرتايم',
      fields:[
        {name:'employeeId', label:'الموظف', type:'select', options:employeeOptions, required:true},
        {name:'date', label:'التاريخ', type:'date', required:true},
        {name:'hours', label:'عدد الساعات', type:'number', required:true},
        {name:'rate', label:'أجر الساعة (د.إ)', type:'number', required:true},
        {name:'note', label:'ملاحظات', type:'textarea'},
      ],
      columns:[
        {key:'date', label:'التاريخ'},
        {key:'employee', label:'الموظف', render:r=>empName(r.employeeId,data)},
        {key:'hours', label:'الساعات'},
        {key:'rate', label:'أجر الساعة', render:r=>money(r.rate)},
        {key:'total', label:'الإجمالي', render:r=><b>{money((r.hours||0)*(r.rate||0))}</b>},
      ],
      defaults:{date:todayISO(), rate:30},
    },
    advances:{
      title:'السلف والخصومات', singular:'سلفة / خصم',
      fields:[
        {name:'employeeId', label:'الموظف', type:'select', options:employeeOptions, required:true},
        {name:'type', label:'النوع', type:'select', options:[{value:'سلفة',label:'سلفة'},{value:'خصم',label:'خصم'}], required:true},
        {name:'mode', label:'طريقة الخصم', type:'select', options:[{value:'مقطوع',label:'مقطوع (مرة واحدة)'},{value:'مقسّط',label:'مقسّط (على شهور)'}], showIf:v=>v.type==='سلفة', hint:'المقطوع يُخصم كامل في شهره — المقسّط يُخصم قسط شهري حتى السداد'},
        {name:'amount', label:'المبلغ الإجمالي (د.إ)', type:'number', required:true},
        {name:'monthlyInstallment', label:'القسط الشهري (د.إ)', type:'number', showIf:v=>v.type==='سلفة' && v.mode==='مقسّط', required:true, hint:'القيمة التي تُخصم كل شهر من الراتب'},
        {name:'startMonth', label:'يبدأ الخصم من شهر', type:'month', showIf:v=>v.type==='سلفة' && v.mode==='مقسّط', hint:'أول شهر يبدأ فيه الخصم — افتراضياً شهر التاريخ'},
        {name:'date', label:'التاريخ', type:'date', required:true},
        {name:'account', label:'صُرفت من حساب', type:'select', options:[{value:'الخزينة',label:'الخزينة (نقدي)'},{value:'البنك',label:'البنك'}], showIf:v=>v.type==='سلفة', required:true, hint:'السلفة تُخصم من هذا الحساب في تاريخها — ثم تُسترد بخصمها من الراتب'},
        {name:'note', label:'السبب / ملاحظات', type:'textarea'},
      ],
      columns:[
        {key:'date', label:'التاريخ'},
        {key:'employee', label:'الموظف', render:r=>empName(r.employeeId,data)},
        {key:'type', label:'النوع', render:r=><span className={"badge "+(r.type==='سلفة'?'neutral':'bad')}>{r.type}{r.type==='سلفة'&&r.mode==='مقسّط'?' مقسّطة':''}</span>},
        {key:'amount', label:'الإجمالي', render:r=>money(r.amount)},
        {key:'installment', label:'القسط/المتبقّي', render:r=>{
          if(r.type!=='سلفة'||r.mode!=='مقسّط') return '—';
          const rem = advanceRemaining(r, data);
          return <span>{money(r.monthlyInstallment||0)}/شهر · <b style={{color:rem>0?'var(--rust)':'var(--teal)'}}>متبقّي {money(rem)}</b></span>;
        }},
        {key:'note', label:'السبب'},
      ],
      defaults:{date:todayISO(), type:'سلفة', account:'الخزينة'},
    },
    leaves:{
      title:'الإجازات', singular:'إجازة',
      fields:[
        {name:'employeeId', label:'الموظف', type:'select', options:employeeOptions, required:true},
        {name:'type', label:'نوع الإجازة', type:'select', options:[{value:'سنوية',label:'سنوية'},{value:'مرضية',label:'مرضية'},{value:'بدون راتب',label:'بدون راتب'},{value:'طارئة',label:'طارئة'}], required:true},
        {name:'fromDate', label:'من تاريخ', type:'date', required:true},
        {name:'toDate', label:'إلى تاريخ', type:'date', required:true},
        {name:'days', label:'عدد الأيام', type:'number', required:true, hint:'أيام الإجازة الفعلية (أيام العمل)'},
        {name:'note', label:'ملاحظات', type:'textarea'},
      ],
      columns:[
        {key:'employee', label:'الموظف', render:r=>empName(r.employeeId,data)},
        {key:'type', label:'النوع', render:r=><span className={"badge "+(r.type==='سنوية'?'ok':r.type==='بدون راتب'?'bad':'neutral')}>{r.type}</span>},
        {key:'fromDate', label:'من'},
        {key:'toDate', label:'إلى'},
        {key:'days', label:'الأيام', render:r=><b>{r.days||0}</b>},
        {key:'note', label:'ملاحظات'},
      ],
      defaults:{fromDate:todayISO(), toDate:todayISO(), type:'سنوية'},
    },
    timesheets:{
      title:'تتبّع الوقت', singular:'ساعة عمل',
      sortFn:(a,b)=> (b.date||'').localeCompare(a.date||''),
      fields:[
        {name:'employeeId', label:'المهندس / الموظف', type:'select', options:employeeOptions, required:true},
        {name:'projectId', label:'المشروع', type:'select', options:projectOptions, required:true},
        {name:'phase', label:'المرحلة', type:'select', allowAddNew:true,
          options:(d)=>{
            const base = ['تصميم','مخططات تفصيلية','إشراف','اعتمادات','أخرى'];
            const used = [...new Set((d.timesheets||[]).map(t=>t.phase).filter(Boolean))];
            return [...base, ...used.filter(x=>!base.includes(x))].map(x=>({value:x,label:x}));
          }, required:true, hint:'لا تجد المرحلة؟ اختر "➕ إضافة تصنيف جديد" من آخر القائمة'},
        {name:'date', label:'التاريخ', type:'date', required:true},
        {name:'hours', label:'عدد الساعات', type:'number', required:true, hint:'ساعات العمل الفعلية على هذا المشروع في هذا اليوم'},
        {name:'task', label:'وصف المهمة', hint:'مثال: رسم مساقط الدور الأرضي، مراجعة ملاحظات البلدية...'},
      ],
      columns:[
        {key:'date', label:'التاريخ'},
        {key:'employee', label:'المهندس', render:r=>empName(r.employeeId,data)},
        {key:'project', label:'المشروع', render:r=>projName(r.projectId,data)},
        {key:'phase', label:'المرحلة', render:r=><span className="badge gray">{r.phase||'—'}</span>},
        {key:'hours', label:'الساعات', render:r=><b>{Number(r.hours)||0}</b>},
        {key:'cost', label:'التكلفة', render:(r,d)=>{
          const e = (d.employees||[]).find(x=>x.id===r.employeeId);
          return <span style={{color:'var(--rust)'}}>{money((Number(r.hours)||0)*hourlyRate(e, monthKey(r.date)))}</span>;
        }},
        {key:'billed', label:'الفوترة', render:r=> r.billed ? <span className="badge ok">مفوترة</span> : <span className="badge gray">—</span>},
        {key:'task', label:'المهمة', truncate:true, render:r=>r.task||'—'},
      ],
      defaults:{date:todayISO(), phase:'تصميم'},
      footRow:(rows, d)=>{
        const totH = rows.reduce((s,r)=>s+(Number(r.hours)||0),0);
        const totC = rows.reduce((s,r)=>{ const e=(d.employees||[]).find(x=>x.id===r.employeeId); return s+(Number(r.hours)||0)*hourlyRate(e, monthKey(r.date)); },0);
        return (
          <tr style={{background:'#F4F1E8', borderTop:'2px solid var(--line-strong)', fontWeight:800}}>
            <td colSpan={4}>الإجمالي</td>
            <td><b>{totH} ساعة</b></td>
            <td><b style={{color:'var(--rust)'}}>{money(totC)}</b></td>
            <td></td>
          </tr>
        );
      },
    },
    cars:{
      title:'سيارات الشركة', singular:'سيارة',
      fields:[
        {name:'model', label:'الموديل', required:true},
        {name:'plate', label:'رقم اللوحة', required:true},
        {name:'licenseExpiry', label:'تاريخ انتهاء الرخصة', type:'date', required:true},
        {name:'assignedTo', label:'مخصصة لـ (موظف)', type:'select', options:employeeOptions},
        {name:'note', label:'ملاحظات', type:'textarea'},
      ],
      columns:[
        {key:'model', label:'الموديل'},
        {key:'plate', label:'رقم اللوحة'},
        {key:'assignedTo', label:'مخصصة لـ', render:r=> r.assignedTo ? empName(r.assignedTo,data) : '—'},
        {key:'licenseExpiry', label:'انتهاء الرخصة', render:r=>(
          <span className={"badge "+expiryStatus(r.licenseExpiry)}>{r.licenseExpiry} · {expiryLabel(r.licenseExpiry)}</span>
        )},
      ],
      defaults:{licenseExpiry:todayISO()},
    },
  };
}

/* ================= أقساط السلف المقسّطة ================= */
// عدد الشهور من startMonth (شامل) حتى ym (شامل)؛ سالب/صفر لو ym قبل البداية
function monthsElapsed(startYM, ym){
  if(!startYM || !ym) return 0;
  const [sy,sm] = startYM.split('-').map(Number);
  const [ey,em] = ym.split('-').map(Number);
  return (ey-sy)*12 + (em-sm) + 1; // +1 لأن شهر البداية نفسه يُحتسب
}
// هل صُرفت رواتب هذا الشهر فعلاً؟ (صرف جماعي kind='رواتب' أو دفعة راتب لموظف خارج WPS)
function payrollPaidForMonth(data, ym){
  return (data.officeExpenses||[]).some(e=>(e.kind==='رواتب'||e.kind===SALARY_PART_KIND) && e.month===ym)
      || (data.treasury||[]).some(t=>t.kind==='رواتب' && t.month===ym);
}
/* ==== صرف الرواتب على دفعات (للموظفين خارج WPS) ====
   الاستحقاق: صافي الشهر كاملاً مصروف على شهره (computePayroll) — والصرف: قيود مستقلة كلٌّ بتاريخه.
   - الصرف الجماعي kind='رواتب' (واحد لكل شهر — محروس على السيرفر بجدول nitaq_payroll_month_v1):
     الجديد يحمل lines=[{employeeId,amount}] لموظفي WPS فقط؛ القديم بلا lines = صرف كامل لكل الموظفين.
   - دفعة راتب فردية kind=SALARY_PART_KIND لموظف خارج WPS (employeeId + month) — تتكرر في نفس الشهر.
     حد المجموع ≤ الصافي محروس في الواجهة (authorizeBundle). */
const SALARY_PART_KIND = 'دفعة راتب';
// قيود صرف الرواتب داخل مصروفات المكتب — تُستبعد من قائمة الدخل لأن الرواتب تُحتسب من computePayroll (منعاً للخصم المزدوج)
const isSalaryExp = (e)=> e && (e.kind==='رواتب' || e.kind===SALARY_PART_KIND);
const officeExpNoPayroll = (data)=> (data.officeExpenses||[]).filter(e=>!isArchived(e) && !isSalaryExp(e));
const isWpsEmp = (emp)=> !emp || emp.payMode!=='خارج WPS';
function salaryPaymentsForEmp(data, empId, ym, net){
  const list = [];
  [...(data.officeExpenses||[]), ...(data.treasury||[])]
    .filter(x=>x.kind==='رواتب' && x.month===ym && !isArchived(x))
    .forEach(run=>{
      if(Array.isArray(run.lines)){
        run.lines.filter(l=>l && l.employeeId===empId).forEach(l=>list.push({date:run.date, amount:Number(l.amount)||0, account:run.account, via:'صرف الرواتب (WPS)'}));
      } else {
        list.push({date:run.date, amount:net, account:run.account, via:'صرف الرواتب', legacy:true});   // قيد قديم = صرف كامل للجميع
      }
    });
  (data.officeExpenses||[])
    .filter(e=>e.kind===SALARY_PART_KIND && e.month===ym && e.employeeId===empId && !isArchived(e))
    .forEach(e=>list.push({id:e.id, date:e.date, amount:Number(e.amount)||0, account:e.account, bankName:e.bankName, via:'دفعة راتب'}));
  return list.sort((a,b)=>(a.date||'').localeCompare(b.date||''));
}
function salaryPaidForEmp(data, empId, ym, net){
  const list = salaryPaymentsForEmp(data, empId, ym, net);
  if(list.some(x=>x.legacy)) return net;
  return list.reduce((s,x)=>s+x.amount,0);
}
// قائمة الشهور المصروفة فعلاً من بداية السلفة حتى شهر معيّن، مرتّبة
function paidMonthsForAdvance(a, data, upToYM){
  const start = a.startMonth || monthKey(a.date);
  const set = new Set();
  (data.officeExpenses||[]).forEach(e=>{ if((e.kind==='رواتب'||e.kind===SALARY_PART_KIND)&&e.month) set.add(e.month); });
  (data.treasury||[]).forEach(t=>{ if(t.kind==='رواتب'&&t.month) set.add(t.month); });
  return [...set].filter(mm=> mm>=start && (!upToYM || mm<=upToYM)).sort();
}
// القسط المعروض في كشف شهر ym: يُحسب حسب ترتيب هذا الشهر بين (الشهور المصروفة فعلاً + شهر العرض الحالي)
// فيظهر القسط الصحيح عند عرض/صرف الشهر الحالي، ويبقى المتبقّي مرتبطاً بالصرف الفعلي للشهور السابقة
function installmentForMonth(a, ym, data){
  if(!a || a.type!=='سلفة' || a.mode!=='مقسّط') return 0;
  const total = Number(a.amount)||0;
  const monthly = Number(a.monthlyInstallment)||0;
  if(total<=0 || monthly<=0) return 0;
  const start = a.startMonth || monthKey(a.date);
  if(ym < start) return 0;                                   // قبل بداية الخطة
  // الشهور المصروفة فعلاً قبل هذا الشهر (حصراً) + هذا الشهر نفسه (المعروض/الجاري صرفه)
  const paidBefore = paidMonthsForAdvance(a, data, ym).filter(mm=>mm<ym);
  const order = paidBefore.length;                           // عدد الأقساط المخصومة فعلاً قبله
  const already = monthly*order;
  if(already >= total) return 0;                             // سُدّدت بالكامل قبل هذا الشهر
  return Math.min(monthly, total - already);                 // قسط هذا الشهر (آخر قسط قد يكون أصغر)
}
// المتبقّي = الإجمالي − مجموع الأقساط المخصومة في الشهور المصروفة فعلاً
function advanceRemaining(a, data){
  if(!a || a.type!=='سلفة' || a.mode!=='مقسّط') return 0;
  const total = Number(a.amount)||0;
  const paidMonths = paidMonthsForAdvance(a, data, null);
  const paid = Math.min(total, (Number(a.monthlyInstallment)||0)*paidMonths.length);
  return Math.max(0, total - paid);
}

/* ================= حساب الرواتب لشهر محدد (يُستخدم في الكشف والتقارير) ================= */
/* ==== سجل المرتب: كل شهر يتحسب بالمرتب اللي كان ساري فيه ====
   emp.salaryHistory = [{from:'YYYY-MM', baseSalary, grossSalary}] — بدون سجل = المرتب الحالي لكل الشهور (القديم). */
function salaryFor(emp, ym){
  const cur = {base:Number(emp&&emp.baseSalary)||0, gross:Number(emp&&emp.grossSalary)>0 ? Number(emp.grossSalary) : (Number(emp&&emp.baseSalary)||0)};
  const h = (emp && Array.isArray(emp.salaryHistory)) ? emp.salaryHistory : [];
  if(!h.length || !ym) return cur;
  const sorted = [...h].sort((a,b)=>(a.from||'').localeCompare(b.from||''));
  let hit = null; for(const x of sorted){ if((x.from||'') <= ym) hit = x; }
  if(!hit) hit = sorted[0];
  const base = Number(hit.baseSalary)||0;
  return {base, gross: Number(hit.grossSalary)>0 ? Number(hit.grossSalary) : base};
}
// يبني سجل المرتب عند تغيير المرتب: القديم يفضل للشهور قبل fromYM، والجديد من fromYM
function withSalaryChange(before, after, fromYM){
  const oldEntry = {from:'0000-00', baseSalary:Number(before.baseSalary)||0, grossSalary:Number(before.grossSalary)||0};
  let h = (Array.isArray(before.salaryHistory) && before.salaryHistory.length) ? [...before.salaryHistory] : [oldEntry];
  h = h.filter(x=>(x.from||'') < fromYM);
  if(!h.length) h = [oldEntry];
  h.push({from:fromYM, baseSalary:Number(after.baseSalary)||0, grossSalary:Number(after.grossSalary)||0});
  return h.sort((a,b)=>(a.from||'').localeCompare(b.from||''));
}
// الموظف داخل كشف شهر ym: من شهر تعيينه، وحتى شهر أرشفته (المؤرشف بلا تاريخ أرشفة يُستبعد)
function empActiveInMonth(emp, ym){
  if(!emp) return false;
  if(emp.hireDate && emp.hireDate.slice(0,7) > ym) return false;
  if(isArchived(emp)){ if(!emp.archivedAt) return false; if(emp.archivedAt.slice(0,7) < ym) return false; }
  return true;
}
// نسبة أول شهر: عدد الأيام من يوم التعيين حتى آخر الشهر ÷ أيام الشهر
function hireProration(emp, ym){
  if(!emp || !emp.hireDate || emp.hireDate.slice(0,7)!==ym) return {factor:1, days:null};
  const [y,m] = ym.split('-').map(Number);
  const dim = new Date(y, m, 0).getDate();
  const day = parseInt(emp.hireDate.slice(8,10),10) || 1;
  const days = Math.max(0, dim - day + 1);
  return {factor: days/dim, days, dim};
}
function computePayroll(data, ym){
  const rows = (data.employees||[]).filter(emp=>empActiveInMonth(emp, ym)).map(emp=>{
    const pr = hireProration(emp, ym);
    const attMap = data.attendance[emp.id] || {};
    const absentDays = Object.entries(attMap).filter(([d,s])=> d.startsWith(ym) && s==='absent').length;
    const sal = salaryFor(emp, ym);                         // المرتب الساري في هذا الشهر
    const fullGross = sal.gross;                            // القديم: الإجمالي = الأساسي
    const gross = Math.round(fullGross*pr.factor*100)/100;   // أول شهر بعدد الأيام الفعلية
    const dailyRate = sal.base/30;                          // خصم الغياب على الأساسي (وفق القانون)
    const absenceDeduction = absentDays*dailyRate;
    const ot = data.overtime.filter(o=>o.employeeId===emp.id && monthKey(o.date)===ym)
      .reduce((s,o)=>s+(o.hours||0)*(o.rate||0),0);
    // السلف: المقطوعة (والقديمة بلا mode) تُخصم كاملة في شهرها؛ المقسّطة تُخصم كقسط
    const empAdvances = data.advances.filter(a=>a.employeeId===emp.id && a.type==='سلفة');
    const advances = empAdvances
      .filter(a=> a.mode!=='مقسّط' && monthKey(a.date)===ym)
      .reduce((s,a)=>s+(Number(a.amount)||0),0);
    const installments = empAdvances
      .reduce((s,a)=>s+installmentForMonth(a, ym, data),0);
    const deductions = data.advances.filter(a=>a.employeeId===emp.id && a.type==='خصم' && monthKey(a.date)===ym)
      .reduce((s,a)=>s+(Number(a.amount)||0),0);
    const net = gross - absenceDeduction + ot - advances - deductions - installments;   // الصافي يبدأ من الإجمالي
    return {emp, base:sal.base, gross, fullGross, prorateDays:pr.days, prorateDim:pr.dim, absentDays, absenceDeduction, ot, advances, installments, deductions, net};
  });
  return {rows, totalNet: rows.reduce((s,r)=>s+r.net,0)};
}

/* ================= تتبّع الوقت: تكلفة ساعة المهندس وتكلفة وقت المشروع ================= */
const WORK_HOURS_PER_DAY = 10;
// تكلفة الساعة = (الراتب الأساسي ÷ 30 يوم) ÷ 8 ساعات — الشهر 30 يوماً ثابتة
const hourlyRate = (emp, ym)=>{
  if(!emp) return 0;
  const base = ym ? salaryFor(emp, ym).base : (Number(emp.baseSalary)||0);
  return (base/30)/WORK_HOURS_PER_DAY;
};
const empById = (data, id)=> (data.employees||[]).find(e=>e.id===id);
// إجمالي تكلفة وقت المهندسين على مشروع معيّن (ساعات × تكلفة ساعة كل مهندس)
function projectTimeCost(data, pid){
  return (data.timesheets||[])
    .filter(t=> t.projectId===pid && !isArchived(t))
    .reduce((s,t)=> s + (Number(t.hours)||0) * hourlyRate(empById(data, t.employeeId), monthKey(t.date)), 0);
}
function projectTimeHours(data, pid){
  return (data.timesheets||[])
    .filter(t=> t.projectId===pid && !isArchived(t))
    .reduce((s,t)=> s + (Number(t.hours)||0), 0);
}

/* ================= رصيد الإجازات السنوي (30 يوماً وفق قانون العمل الإماراتي) ================= */
const ANNUAL_LEAVE = 30;
function computeLeaveBalance(data, empId, year){
  const y = year || String(new Date().getFullYear());
  const used = (data.leaves||[])
    .filter(l=>l.employeeId===empId && l.type==='سنوية' && (l.fromDate||'').startsWith(y))
    .reduce((s,l)=>s+(Number(l.days)||0),0);
  return {entitled:ANNUAL_LEAVE, used, remaining:ANNUAL_LEAVE-used};
}

/* ================= مكافأة نهاية الخدمة (تقديري وفق قانون العمل الإماراتي) ================= */
function computeGratuity(emp){
  if(!emp.hireDate) return {years:0, amount:0};
  const years = Math.max(0, (new Date() - new Date(emp.hireDate)) / (365.25*86400000));
  const daily = emp.baseSalary/30;
  let amount = 0;
  if(years < 1){ amount = 0; }
  else if(years <= 5){ amount = daily*21*years; }
  else { amount = daily*21*5 + daily*30*(years-5); }
  return {years, amount};
}

/* ================= حركات النقدية (خزينة + بنك) ================= */
function computeCashFlows(data){
  const flows = [];
  const projName = (id)=>{ const p=data.projects.find(x=>x.id===id); return p ? (p.projectNo?p.projectNo+' — ':'')+p.name : ''; };
  data.payments.forEach(p=>{
    const col = collectedOf(p);
    if(col<=0) return;
    const acc = p.account || (p.method==='نقداً' ? 'الخزينة' : 'البنك');
    const item = (p.phase==='إشراف' ? ('إشراف '+(p.month?fmtMonth(p.month):'')) : (p.label||'دفعة')) + (p.status==='مدفوعة جزئياً' ? ' (جزئية)' : '');
    flows.push({date:p.paidDate||p.date, desc:'قبض — '+projName(p.projectId)+' — '+item, inAmt:col*grossFactor(p), outAmt:0, account:acc, src:'دفعات استشارية'});
  });
  data.govFees.forEach(g=>{
    if(isArchived(g) || g.payerType==='المالك مباشرة') return;
    const acc = g.account||'البنك';
    if(g.paidStatus==='مدفوع') flows.push({date:g.date, desc:'رسوم حكومية — '+g.department+' — '+projName(g.projectId), inAmt:0, outAmt:g.amount, account:acc, src:'أمانات'});
    if(g.reimburseStatus==='مسترد') flows.push({date:g.date, desc:'استرداد رسوم من المالك — '+projName(g.projectId), inAmt:g.amount, outAmt:0, account:acc, src:'أمانات'});
  });
  // الشيك الصادر من حساب المكتب: يُخصم من البنك في تاريخ صرفه المتوقع؛ قبله يظهر «شيكات صادرة لم تُصرف»
  const today = todayISO();
  const chequeAcc = (e)=> (e.chequeDueDate && e.chequeDueDate > today) ? 'شيكات صادرة' : 'البنك';
  const chequeDate = (e)=> e.chequeDueDate || e.date;
  data.officeExpenses.forEach(e=>{
    if(e.payStatus==='معلق') return;                          // معلق لم يُدفع بعد
    if(isArchived(e)) return;
    if(isDebtExpense(e)){                                     // مدفوع من بنك غير WIO NITAQ → دين على المكتب، لا يُخصم من WIO
      flows.push({date:e.date, desc:'مصروف مكتب (تمويل خارجي) — '+e.category+(e.bankName?' — '+e.bankName:''), inAmt:0, outAmt:expGross(e), account:'دين على المكتب', src:'دين علينا'});
    } else {
      if(e.account==='شيك') flows.push({date:chequeDate(e), desc:'شيك صادر '+(e.chequeNo||'')+' — مصروف مكتب — '+e.category, inAmt:0, outAmt:expGross(e), account:chequeAcc(e), src:'مصروفات'});
      else flows.push({date:e.date, desc:'مصروف مكتب — '+e.category, inAmt:0, outAmt:expGross(e), account:e.account||'البنك', src:'مصروفات'});
    }
  });
  data.projectCosts.forEach(e=>{
    if(isArchived(e)) return;
    if(isDebtExpense(e)){
      flows.push({date:e.date, desc:'تكلفة مشروع (تمويل خارجي) — '+e.category+' — '+projName(e.projectId)+(e.bankName?' — '+e.bankName:''), inAmt:0, outAmt:expGross(e), account:'دين على المكتب', src:'دين علينا'});
    } else {
      if(e.account==='شيك') flows.push({date:chequeDate(e), desc:'شيك صادر '+(e.chequeNo||'')+' — تكلفة مشروع — '+e.category+' — '+projName(e.projectId), inAmt:0, outAmt:expGross(e), account:chequeAcc(e), src:'مصروفات'});
      else flows.push({date:e.date, desc:'تكلفة مشروع — '+e.category+' — '+projName(e.projectId), inAmt:0, outAmt:expGross(e), account:e.account||'البنك', src:'مصروفات'});
    }
  });
  data.treasury.forEach(t=>{
    if(isArchived(t)) return;
    if(t.type==='قبض') flows.push({date:t.date, desc:t.note||'قبض يدوي', inAmt:t.amount, outAmt:0, account:t.account, src:'يدوي'});
    else if(t.type==='صرف') flows.push({date:t.date, desc:t.note||'صرف يدوي', inAmt:0, outAmt:t.amount, account:t.account, src:'يدوي'});
    else if(t.type==='تحويل'){
      flows.push({date:t.date, desc:'تحويل إلى '+(t.toAccount||''), inAmt:0, outAmt:t.amount, account:t.account, src:'تحويل'});
      flows.push({date:t.date, desc:'تحويل من '+t.account, inAmt:t.amount, outAmt:0, account:t.toAccount||'البنك', src:'تحويل'});
    }
  });
  // السلف: صرف فعلي للموظف من الحساب المحدد (القديمة بلا حساب = الخزينة). الخصم من الراتب يقلّل قيد الرواتب لاحقاً.
  (data.advances||[]).forEach(a=>{
    if(isArchived(a) || a.type!=='سلفة' || !(Number(a.amount)>0)) return;
    const emp = (data.employees||[]).find(x=>x.id===a.employeeId);
    flows.push({date:a.date, desc:'سلفة موظف — '+(emp?emp.name:'')+(a.mode==='مقسّط'?' (مقسّطة)':''), inAmt:0, outAmt:Number(a.amount), account:a.account||'الخزينة', src:'سلف'});
  });
  (data.otherIncome||[]).forEach(r=>{
    if(isArchived(r)) return;
    flows.push({date:r.date, desc:'إيراد آخر — '+(r.category||'')+(r.payer?' — '+r.payer:''), inAmt:incGross(r), outAmt:0, account:r.account||'البنك', src:'إيرادات أخرى'});
  });
  flows.sort((a,b)=> (b.date||'').localeCompare(a.date||''));
  const bal = (acc)=> flows.filter(f=>f.account===acc).reduce((s,f)=>s+f.inAmt-f.outAmt,0);
  return {flows, bank:bal('البنك'), cash:bal('الخزينة'), debt:bal('دين على المكتب'), pendingCheques:-bal('شيكات صادرة')};
}

/* ================= Treasury View (الخزينة والبنك) ================= */
/* ================= الإيرادات الأخرى (غير التشغيلية) ================= */
function OtherIncomeView({data, configs, mutate}){
  const [catFilter, setCatFilter] = useState('');
  const [dFrom, setDFrom] = useState('');
  const [dTo, setDTo] = useState('');
  const m = mutate('otherIncome');

  let records = (data.otherIncome||[]);
  if(catFilter) records = records.filter(r=>r.category===catFilter);
  if(dFrom) records = records.filter(r=>(r.date||'')>=dFrom);
  if(dTo) records = records.filter(r=>(r.date||'')<=dTo);

  const active = records.filter(r=>!isArchived(r));
  const totNet   = active.reduce((s,r)=>s+(r.amount||0),0);
  const totVat   = active.reduce((s,r)=>s+incVat(r),0);
  const totGross = active.reduce((s,r)=>s+incGross(r),0);
  const taxableNet = active.filter(r=>incVatRate(r)>0).reduce((s,r)=>s+(r.amount||0),0);
  const catOpts = [...new Set((data.otherIncome||[]).map(r=>(r.category||'').trim()).filter(Boolean))].sort();
  const anyFilter = catFilter||dFrom||dTo;

  return (
    <div>
      <div className="grid" style={{gridTemplateColumns:'repeat(auto-fit, minmax(150px, 1fr))', marginBottom:14}}>
        <div className="card"><div className="kpi-label">إجمالي الإيرادات الأخرى{anyFilter?' (مفلتر)':''}</div><div className="kpi-value" style={{color:'var(--teal)'}}>{money(totNet)}</div><div className="kpi-note">{active.length} بند — قبل الضريبة</div></div>
        <div className="card"><div className="kpi-label">شامل الضريبة</div><div className="kpi-value" style={{color:'var(--ink)'}}>{money(totGross)}</div><div className="kpi-note">ما دخل الحساب فعلاً</div></div>
        <div className="card"><div className="kpi-label">ضريبة المخرجات</div><div className="kpi-value" style={{color:'var(--brass)'}}>{money(totVat)}</div><div className="kpi-note">على البنود الخاضعة ({money(taxableNet)})</div></div>
      </div>
      <p style={{fontSize:12, color:'var(--ink-faint)', marginBottom:14}}>* الإيرادات الأخرى هي الدخل غير التشغيلي (بيع أصول، إيجار فرعي، عمولات، استرداد…) — تدخل رصيد الحساب المحدد وتُحتسب في الإيراد الكلي، وتخضع لضريبة المخرجات إن اختُيرت "خاضعة". تظهر منفصلة عن إيراد المشاريع للحفاظ على وضوح ربحية النشاط الأساسي.</p>
      <EntityView config={configs.otherIncome} records={records} data={data}
        onAdd={m.add} onUpdate={m.update} onDelete={m.del}
        headExtra={
          <>
            {catOpts.length>0 && (
              <select value={catFilter} onChange={e=>setCatFilter(e.target.value)}
                style={{border:'1px solid var(--line-strong)', borderRadius:4, padding:'7px 10px', fontSize:12.5, background:'#fff'}}>
                <option value="">كل المصادر</option>
                {catOpts.map(c=><option key={c} value={c}>{c}</option>)}
              </select>
            )}
            <span style={{fontSize:12, color:'var(--ink-soft)'}}>من</span>
            <input type="date" value={dFrom} onChange={e=>setDFrom(e.target.value)}
              style={{border:'1px solid var(--line-strong)', borderRadius:4, padding:'6px 10px', fontSize:12.5, background:'#fff'}} />
            <span style={{fontSize:12, color:'var(--ink-soft)'}}>إلى</span>
            <input type="date" value={dTo} onChange={e=>setDTo(e.target.value)}
              style={{border:'1px solid var(--line-strong)', borderRadius:4, padding:'6px 10px', fontSize:12.5, background:'#fff'}} />
            {anyFilter && <button className="btn outline" style={{padding:'5px 12px', fontSize:12}} onClick={()=>{setCatFilter('');setDFrom('');setDTo('');}}>مسح الفلاتر</button>}
          </>
        }
      />
    </div>
  );
}

function TreasuryView({data, configs, mutate}){
  const m = mutate('treasury');
  const {flows, bank, cash, debt, pendingCheques} = computeCashFlows(data);

  /* --- فلاتر الحركات --- */
  const [fAcct, setFAcct] = useState('');     // البنك / الخزينة
  const [fType, setFType] = useState('');     // وارد / صادر
  const [fSrc, setFSrc]  = useState('');      // مصدر الحركة
  const [fFrom, setFFrom] = useState('');
  const [fTo, setFTo]   = useState('');
  const sources = useMemo(()=> [...new Set(flows.map(f=>f.src))], [flows]);

  const shown = useMemo(()=> flows.filter(f=>{
    if(fAcct && f.account!==fAcct) return false;
    if(fType==='in'  && !(f.inAmt>0)) return false;
    if(fType==='out' && !(f.outAmt>0)) return false;
    if(fSrc && f.src!==fSrc) return false;
    if(fFrom && (f.date||'') < fFrom) return false;
    if(fTo && (f.date||'') > fTo) return false;
    return true;
  }), [flows, fAcct, fType, fSrc, fFrom, fTo]);

  const shownIn  = shown.reduce((s,f)=>s+f.inAmt,0);
  const shownOut = shown.reduce((s,f)=>s+f.outAmt,0);
  const anyF = fAcct||fType||fSrc||fFrom||fTo;
  const resetF = ()=>{ setFAcct(''); setFType(''); setFSrc(''); setFFrom(''); setFTo(''); };

  /* --- مطابقة رصيد البنك --- */
  const [recAcct, setRecAcct] = useState('البنك');
  const [recDate, setRecDate] = useState(todayISO());
  const [recActual, setRecActual] = useState('');
  // رصيد النظام المحسوب للحساب المختار حتى تاريخ الكشف (شامله)
  const sysBalAt = useMemo(()=>{
    return flows.filter(f=> f.account===recAcct && (f.date||'') <= recDate)
                .reduce((s,f)=>s+f.inAmt-f.outAmt, 0);
  }, [flows, recAcct, recDate]);
  const actualNum = parseFloat(recActual);
  const hasActual = recActual!=='' && !isNaN(actualNum);
  const diff = hasActual ? (actualNum - sysBalAt) : 0;
  const matched = hasActual && Math.abs(diff) < 0.01;
  // حركات الحساب حوالين تاريخ الكشف للمراجعة (آخر 15 حتى التاريخ)
  const recFlows = useMemo(()=> flows
    .filter(f=> f.account===recAcct && (f.date||'') <= recDate)
    .slice(0, 15), [flows, recAcct, recDate]);

  const selEl = {border:'1px solid var(--line-strong)', borderRadius:4, padding:'7px 10px', fontSize:12.5, background:'#fff'};

  return (
    <div>
      <div className="grid grid-4" style={{marginBottom:18}}>
        <div className="card"><div className="kpi-label">رصيد البنك (WIO NITAQ)</div><div className="kpi-value" style={{color:bank>=0?'var(--ink)':'var(--rust)'}}>{money(bank)}</div><div className="kpi-note">محسوب من حركات الحساب فقط</div></div>
        <div className="card"><div className="kpi-label">رصيد الخزينة (نقدي)</div><div className="kpi-value" style={{color:cash>=0?'var(--ink)':'var(--rust)'}}>{money(cash)}</div><div className="kpi-note">الدفعات النقدية والمصروفات النثرية</div></div>
        <div className="card"><div className="kpi-label">إجمالي السيولة</div><div className="kpi-value" style={{color:'var(--brass)'}}>{money(bank+cash)}</div><div className="kpi-note">بنك + خزينة (لا يشمل الدين)</div></div>
        <div className="card"><div className="kpi-label">دين على المكتب</div><div className="kpi-value" style={{color:debt<0?'var(--rust)':'var(--ink)'}}>{money(Math.abs(debt))}</div><div className="kpi-note">مصروفات مموّلة من بنك غير WIO NITAQ</div></div>
      </div>
      {pendingCheques>0.009 && (
        <div className="card" style={{marginTop:-8, marginBottom:18, padding:'10px 14px', fontSize:13, borderInlineStart:'3px solid var(--brass)'}}>
          🧾 <b>شيكات صادرة لم تُصرف بعد: {money(pendingCheques)}</b> — ستُخصم من البنك في تواريخ صرفها المتوقعة. الرصيد المتاح فعلياً بعدها: <b>{money(bank - pendingCheques)}</b>
        </div>
      )}

      {/* --- مطابقة رصيد البنك --- */}
      <div className="section-title"><h3 style={{fontSize:13.5}}>مطابقة رصيد البنك — قارن رصيد النظام بكشف الحساب الفعلي</h3><div className="rule"></div></div>
      <div className="card" style={{marginBottom:24}}>
        <div style={{display:'flex', gap:12, flexWrap:'wrap', alignItems:'flex-end', marginBottom:14}}>
          <div className="field" style={{minWidth:130}}>
            <label>الحساب</label>
            <select value={recAcct} onChange={e=>setRecAcct(e.target.value)} style={selEl}>
              <option>البنك</option><option>الخزينة</option><option>دين على المكتب</option>
            </select>
          </div>
          <div className="field" style={{minWidth:150}}>
            <label>تاريخ كشف الحساب</label>
            <input type="date" value={recDate} onChange={e=>setRecDate(e.target.value)} style={selEl} />
          </div>
          <div className="field" style={{minWidth:170}}>
            <label>الرصيد الفعلي في الكشف (د.إ)</label>
            <input type="number" value={recActual} onChange={e=>setRecActual(e.target.value)} placeholder="اكتب الرصيد كما في البنك" style={selEl} />
          </div>
        </div>
        <div className="grid grid-3">
          <div className="card" style={{background:'var(--paper)'}}>
            <div className="kpi-label">رصيد النظام حتى {recDate}</div>
            <div className="kpi-value" style={{fontSize:18}}>{money(sysBalAt)}</div>
            <div className="kpi-note">محسوب من الحركات المسجّلة</div>
          </div>
          <div className="card" style={{background:'var(--paper)'}}>
            <div className="kpi-label">الرصيد الفعلي</div>
            <div className="kpi-value" style={{fontSize:18}}>{hasActual?money(actualNum):'—'}</div>
            <div className="kpi-note">من كشف الحساب البنكي</div>
          </div>
          <div className="card" style={{background: !hasActual?'var(--paper)':matched?'var(--teal-soft)':'var(--rust-soft)', borderColor: !hasActual?'var(--line)':matched?'var(--teal)':'var(--rust)'}}>
            <div className="kpi-label">الفرق</div>
            <div className="kpi-value" style={{fontSize:18, color: !hasActual?'var(--ink-faint)':matched?'var(--teal)':'var(--rust)'}}>
              {hasActual ? (matched ? 'مطابق ✓' : money(Math.abs(diff))) : '—'}
            </div>
            <div className="kpi-note">{hasActual && !matched ? (diff>0 ? 'البنك أعلى — حركة وارد ناقصة في النظام' : 'البنك أقل — حركة صادر ناقصة في النظام') : 'النظام = الكشف'}</div>
          </div>
        </div>
        {hasActual && !matched && (
          <div style={{marginTop:14}}>
            <p style={{fontSize:12.5, color:'var(--ink-soft)', marginBottom:8}}>
              راجع آخر حركات {recAcct} حتى {recDate} لاكتشاف المفقود — ثم سجّل الحركة الناقصة من "إضافة حركة" أدناه، وسيختفي الفرق تلقائياً:
            </p>
            <div style={{overflowX:'auto'}}>
            <table>
              <thead><tr><th>التاريخ</th><th>البيان</th><th>المصدر</th><th>وارد</th><th>صادر</th></tr></thead>
              <tbody>
                {recFlows.length===0 && <tr className="empty-row"><td colSpan={5}>لا حركات على هذا الحساب حتى التاريخ</td></tr>}
                {recFlows.map((f,i)=>(
                  <tr key={i}>
                    <td>{f.date}</td><td style={{fontSize:12}}>{f.desc}</td>
                    <td><span className="badge gray">{f.src}</span></td>
                    <td style={{color:'var(--teal)'}}>{f.inAmt?money(f.inAmt):''}</td>
                    <td style={{color:'var(--rust)'}}>{f.outAmt?money(f.outAmt):''}</td>
                  </tr>
                ))}
              </tbody>
            </table>
            </div>
          </div>
        )}
        <p style={{fontSize:11.5, color:'var(--ink-faint)', marginTop:12, marginBottom:0}}>* هذه أداة مقارنة واكتشاف فقط — لا تعدّل أي رصيد تلقائياً. أي تصحيح يتم بتسجيل حركة يدوية أدناه ليبقى له أثر واضح.</p>
      </div>

      {/* --- جدول الحركات مع الفلاتر --- */}
      <div className="section-title"><h3 style={{fontSize:13.5}}>الحركات (تلقائي من الدفعات والرسوم والمصروفات + الحركات اليدوية)</h3><div className="rule"></div></div>
      <div className="toolbar" style={{flexWrap:'wrap', gap:10}}>
        <select value={fAcct} onChange={e=>setFAcct(e.target.value)} style={selEl}>
          <option value="">كل الحسابات</option><option value="البنك">البنك</option><option value="الخزينة">الخزينة</option><option value="دين على المكتب">دين على المكتب</option>
        </select>
        <select value={fType} onChange={e=>setFType(e.target.value)} style={selEl}>
          <option value="">وارد وصادر</option><option value="in">وارد فقط</option><option value="out">صادر فقط</option>
        </select>
        <select value={fSrc} onChange={e=>setFSrc(e.target.value)} style={selEl}>
          <option value="">كل المصادر</option>
          {sources.map(s=><option key={s} value={s}>{s}</option>)}
        </select>
        <span style={{fontSize:12, color:'var(--ink-soft)'}}>من</span>
        <input type="date" value={fFrom} onChange={e=>setFFrom(e.target.value)} style={selEl} />
        <span style={{fontSize:12, color:'var(--ink-soft)'}}>إلى</span>
        <input type="date" value={fTo} onChange={e=>setFTo(e.target.value)} style={selEl} />
        {anyF && <button className="btn ghost small" onClick={resetF}>مسح الفلاتر</button>}
      </div>
      <div className="card" style={{padding:0, marginBottom:24}}>
        <div style={{overflowX:'auto'}}>
        <table>
          <thead><tr><th>التاريخ</th><th>البيان</th><th>المصدر</th><th>الحساب</th><th>وارد</th><th>صادر</th></tr></thead>
          <tbody>
            {shown.length===0 && <tr className="empty-row"><td colSpan={6}>لا توجد حركات مطابقة</td></tr>}
            {shown.slice(0,100).map((f,i)=>(
              <tr key={i}>
                <td>{f.date}</td>
                <td>{f.desc}</td>
                <td><span className="badge gray">{f.src}</span></td>
                <td>{f.account}</td>
                <td style={{color:'var(--teal)'}}>{f.inAmt?money(f.inAmt):''}</td>
                <td style={{color:'var(--rust)'}}>{f.outAmt?money(f.outAmt):''}</td>
              </tr>
            ))}
          </tbody>
          {shown.length>0 && (
            <tfoot>
              <tr style={{fontWeight:800, background:'rgba(19,42,70,.04)'}}>
                <td colSpan={4}>الإجمالي المعروض ({shown.length} حركة{shown.length>100?' — يُعرض أول 100':''})</td>
                <td style={{color:'var(--teal)'}}>{money(shownIn)}</td>
                <td style={{color:'var(--rust)'}}>{money(shownOut)}</td>
              </tr>
            </tfoot>
          )}
        </table>
        </div>
      </div>

      <EntityView config={configs.treasury} records={data.treasury} data={data}
        onAdd={m.add} onUpdate={m.update} onDelete={m.del} />
      <p style={{fontSize:12, color:'var(--ink-faint)', marginTop:14}}>* المقبوضات تشمل الضريبة (5%) لأنها ما يدخل الحساب فعلياً، والمصروفات تُخصم شاملة الضريبة كذلك. الرسوم الحكومية تُخصم من الحساب المحدد عند سدادها للدائرة وتُعاد إليه عند استردادها من المالك.</p>
    </div>
  );
}

/* ================= Dues View (الذمم — مدينون ودائنون) ================= */
function DuesView({data}){
  const receivables = data.projects.map(p=>{
    const duePays = data.payments.filter(i=>!isArchived(i) && i.projectId===p.id).reduce((s,i)=>s+remainderOf(i)*grossFactor(i),0);
    const feesOut = data.govFees.filter(g=>g.projectId===p.id && !isArchived(g) && g.payerType!=='المالك مباشرة' && g.paidStatus==='مدفوع' && g.reimburseStatus!=='مسترد').reduce((s,g)=>s+(isArchived(g)?0:g.amount),0);
    return {...p, duePays, feesOut, total:duePays+feesOut};
  }).filter(r=>r.total>0).sort((a,b)=>b.total-a.total);
  const totalRecv = receivables.reduce((s,r)=>s+r.total,0);

  const unpaidFees = data.govFees.filter(g=>!isArchived(g) && g.payerType!=='المالك مباشرة' && g.paidStatus!=='مدفوع');
  const feesByDept = {};
  unpaidFees.forEach(g=>{ feesByDept[g.department] = (feesByDept[g.department]||0) + g.amount; });

  const quarters = listQuarters();
  const doneQuarters = quarters.filter(q=> quarterEndDate(q) < todayISO());
  const lastQ = doneQuarters[doneQuarters.length-1];
  let vatDue = 0;
  if(lastQ){
    const ms = quarterMonths(lastQ);
    const outV = data.payments.filter(i=>!isArchived(i) && i.status!=='ملغاة' && ms.includes(monthKey(i.date))).reduce((s,i)=>s+billedVatOf(i),0)
      + (data.otherIncome||[]).filter(r=>!isArchived(r) && ms.includes(monthKey(r.date))).reduce((s,r)=>s+incVat(r),0);
    const inV = [...data.officeExpenses, ...data.projectCosts].filter(e=>!isArchived(e) && ms.includes(monthKey(e.date))).reduce((s,e)=>s+(e.amount||0)*expVatRate(e),0);   // نفس حساب الإقرار الضريبي
    vatDue = outV - inV;
  }
  const totalPay = Object.values(feesByDept).reduce((s,v)=>s+v,0) + Math.max(0,vatDue);

  return (
    <div>
      <div className="grid grid-3" style={{marginBottom:18}}>
        <div className="card"><div className="kpi-label">مدينون — مستحق لك</div><div className="kpi-value" style={{color:'var(--teal)'}}>{money(totalRecv)}</div><div className="kpi-note">دفعات غير محصلة + أمانات لم تُسترد</div></div>
        <div className="card"><div className="kpi-label">دائنون — مستحق عليك</div><div className="kpi-value" style={{color:'var(--rust)'}}>{money(totalPay)}</div><div className="kpi-note">رسوم للدوائر + ضريبة مستحقة</div></div>
        <div className="card"><div className="kpi-label">صافي المركز</div><div className="kpi-value" style={{color:(totalRecv-totalPay)>=0?'var(--teal)':'var(--rust)'}}>{money(totalRecv-totalPay)}</div><div className="kpi-note">مدينون − دائنون</div></div>
      </div>

      <div className="section-title"><h3 style={{fontSize:13.5}}>أعمار الذمم المدينة — حسب تاريخ الاستحقاق</h3><div className="rule"></div></div>
      <div className="card" style={{padding:0, marginBottom:24}}>
        <div style={{overflowX:'auto'}}>
        <table>
          <thead><tr><th>المالك</th><th>المشروع</th><th>البند</th><th>المبلغ المتبقي</th><th>الاستحقاق</th><th>العمر</th></tr></thead>
          <tbody>
            {(()=>{
              const rows = data.payments.filter(i=>remainderOf(i)>0 && i.dueDate).map(i=>{
                const p = data.projects.find(x=>x.id===i.projectId)||{};
                const age = -(daysUntil(i.dueDate)||0);
                const bucket = age<=0 ? 'لم يستحق بعد' : age<=30 ? '0-30 يوم' : age<=60 ? '31-60 يوم' : age<=90 ? '61-90 يوم' : 'أكثر من 90 يوم';
                const cls = age<=0 ? 'gray' : age<=30 ? 'ok' : age<=60 ? 'soon' : 'bad';
                return {i, p, age, bucket, cls};
              }).sort((a,b)=>b.age-a.age);
              if(rows.length===0) return <tr className="empty-row"><td colSpan={6}>لا توجد ذمم مستحقة</td></tr>;
              return rows.map(({i,p,age,bucket,cls})=>(
                <tr key={i.id}>
                  <td>{p.owner||'—'}</td>
                  <td>{(p.projectNo?p.projectNo+' — ':'')+(p.name||'')}</td>
                  <td>{i.phase==='إشراف' ? ('إشراف '+(i.month?fmtMonth(i.month):'')) : (i.label||'—')}</td>
                  <td style={{fontWeight:700}}>{money(remainderOf(i)*grossFactor(i))}</td>
                  <td>{i.dueDate}</td>
                  <td><span className={"badge "+cls}>{bucket}{age>0?' ('+age+' يوم)':''}</span></td>
                </tr>
              ));
            })()}
          </tbody>
        </table>
        </div>
      </div>

      <div className="section-title"><h3 style={{fontSize:13.5}}>مدينون — من يدين لك (حسب المالك / المشروع)</h3><div className="rule"></div></div>
      <div className="card" style={{padding:0, marginBottom:24}}>
        <table>
          <thead><tr><th>المشروع</th><th>المالك</th><th>دفعات مستحقة (شاملة الضريبة)</th><th>أمانات لم تُسترد</th><th>الإجمالي</th></tr></thead>
          <tbody>
            {receivables.length===0 && <tr className="empty-row"><td colSpan={5}>لا توجد ذمم مدينة — كل المستحقات محصلة</td></tr>}
            {receivables.map(r=>(
              <tr key={r.id}>
                <td>{(r.projectNo?r.projectNo+' — ':'')+r.name}</td>
                <td>{r.owner||'—'}</td>
                <td>{money(r.duePays)}</td>
                <td>{money(r.feesOut)}</td>
                <td style={{fontWeight:800}}>{money(r.total)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="section-title"><h3 style={{fontSize:13.5}}>دائنون — ما يستحق عليك</h3><div className="rule"></div></div>
      <div className="card" style={{padding:0}}>
        <table>
          <thead><tr><th>الجهة</th><th>البيان</th><th>المبلغ</th><th>الاستحقاق</th></tr></thead>
          <tbody>
            {Object.keys(feesByDept).length===0 && vatDue<=0 && <tr className="empty-row"><td colSpan={4}>لا توجد التزامات معلقة</td></tr>}
            {Object.entries(feesByDept).map(([dept,amt])=>(
              <tr key={dept}><td>{dept}</td><td>رسوم حكومية غير مسددة</td><td style={{fontWeight:700}}>{money(amt)}</td><td>—</td></tr>
            ))}
            {lastQ && vatDue>0 && (
              <tr><td>الهيئة الاتحادية للضرائب</td><td>إقرار ض.ق.م — فترة {quarterLabel(lastQ)}</td><td style={{fontWeight:700}}>{money(vatDue)}</td><td>{quarterDueDate(lastQ)}</td></tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

/* ================= Receipt Doc (إيصال استلام دفعة — النموذج الرسمي) ================= */
function Chk({on, ar, en}){
  return (
    <span className="rcpt-check">
      <span className="box">{on ? '✓' : ''}</span>
      <span>{ar}</span><span className="en">{en}</span>
    </span>
  );
}
function ReceiptDoc({payment, project, onBack}){
  if(payment.docSnapshot){
    const s = payment.docSnapshot;
    project = {...(project||{}), name:s.projectName, owner:s.owner, ownerTrn:s.ownerTrn, additionalOwners:s.additionalOwners||[], plotNumber:s.plotNumber, projectNo:s.projectNo};
  }
  const base = collectedOf(payment);
  const rate = vatRateOf(payment);
  const vat = base*rate;
  const total = base*(1+rate);
  const remaining = remainderOf(payment)*(1+rate);
  const instLabel = payment.phase==='إشراف' ? ('إشراف '+(payment.month?fmtMonth(payment.month):'')) : (payment.label||'');
  const projLine = project ? (project.name + (project.plotNumber ? ' — قطعة رقم '+project.plotNumber : '') + (project.projectNo ? ' · مشروع '+project.projectNo : '')) : '—';

  const Copy = ()=>(
    <div className="rcpt rcpt-a5" style={isArchived(payment)?{opacity:.75}:{}}>
      <div className="rcpt-band">
        <div className="rcpt-logo">
          <img src={NITAQ_LOGO} alt="نطاق NITAQ" style={{height:74, display:'block'}} />
        </div>
        <div className="rcpt-cotitle">
          <div className="ar">نطاق للاستشارات الهندسية</div>
          <div className="en">NITAQ <b>◆</b> ENGINEERING CONSULTANTS</div>
        </div>
      </div>
      <div className="rcpt-gold"></div>
      <div className="rcpt-body">
        <div className="rcpt-wm"><img src={NITAQ_LOGO} alt="" style={{width:340, opacity:.05, filter:'invert(1) brightness(0.2)'}} /></div>

        <div className="rcpt-titlerow">
          <div className="rcpt-meta">
            <div className="row"><span className="lbl">رقم الإيصال</span><span className="val">{payment.receiptNo||'—'}</span><span className="en">Receipt No.</span></div>
            <div className="row"><span className="lbl">التاريخ</span><span className="val">{payment.paidDate||payment.date}</span><span className="en">Date</span></div>
          </div>
          <div className="rcpt-title">
            <div className="ar">إيصال استلام دفعة</div>
            <div className="en">PAYMENT RECEIPT</div>
            <div className="orn">— ◇ —</div>
          </div>
        </div>

        <div className="rcpt-line">
          <span className="lbl">استلمنا من السيّد / السادة</span>
          <span className="val">{project ? (ownersLine(project)||'—') : '—'}</span>
          <span className="en">Received From</span>
        </div>

        <div className="rcpt-line">
          <span className="lbl">المشروع — رقم القطعة</span>
          <span className="val">{projLine}</span>
          <span className="en">Project — Plot No.</span>
        </div>

        <div className="rcpt-line">
          <span className="lbl">المرحلة / Stage</span>
          <Chk on={payment.phase==='تصميم'} ar="تصميم" en="Design" />
          <Chk on={payment.phase==='إشراف'} ar="إشراف" en="Supervision" />
          <Chk on={payment.phase==='أخرى'} ar="أخرى" en="Other" />
          <span className="lbl" style={{marginInlineStart:18}}>رقم الدفعة</span>
          <span className="val">{instLabel}</span>
          <span className="en">Inst. No.</span>
        </div>

        <div className="rcpt-line">
          <span className="lbl">طريقة الدفع / Method</span>
          <Chk on={payment.method==='نقداً'} ar="نقداً" en="Cash" />
          <Chk on={payment.method==='شيك'} ar="شيك" en="Cheque" />
          <Chk on={payment.method==='تحويل بنكي'} ar="تحويل" en="Transfer" />
          <Chk on={payment.method==='بطاقة'} ar="بطاقة" en="Card" />
          <span className="lbl" style={{marginInlineStart:18}}>رقم الشيك / التحويل</span>
          <span className="val">{payment.refNo||'—'}</span>
          <span className="en">Cheque / Ref. No.</span>
        </div>

        <div className="rcpt-line">
          <span className="lbl">ملاحظات</span>
          <span className="val" style={{fontWeight:600}}>{payment.note||''}</span>
          <span className="en">Notes</span>
        </div>

        <div className="rcpt-bottom">
          <div className="rcpt-stamp">
            <div>
              <div className="t">ختم وتوقيع المستلم</div>
              <div className="en">Received by · Stamp &amp; Signature</div>
            </div>
            <div className="co">NITAQ ENGINEERING CONSULTANCY</div>
          </div>
          <div className="rcpt-amount">
            <div className="hd"><span>المبلغ المستلم</span><span className="en">Amount Received</span></div>
            <div className="amt">
              <span className="cur">AED</span>
              <span className="num">{fmt(total)}</span>
            </div>
            <div className="words">فقط {tafqeet(total)}</div>
            {payment.status==='مدفوعة جزئياً' && <div className="vatline" style={{color:'var(--rust)', fontWeight:700}}>دفعة جزئية — المتبقي على هذه الدفعة: {money(remaining)}</div>}
          </div>
        </div>
      </div>
      <div className="rcpt-foot">
        <span>SHARJAH · UAE &nbsp;|&nbsp; {COMPANY.phone2} &nbsp;|&nbsp; {COMPANY.phone} &nbsp;|&nbsp; {COMPANY.email}</span>
        <span className="tag">{COMPANY.tagline}</span>
      </div>
    </div>
  );

  return (
    <div>
      <div className="toolbar no-print">
        <button className="btn outline" onClick={onBack}>← رجوع للدفعات</button>
        <button className="btn brass" onClick={()=>window.print()}><I.print/> طباعة الإيصال (نسختين A4)</button>
      </div>
      {isArchived(payment) && (
        <div className="no-print" style={{background:'var(--rust)', color:'#fff', padding:'10px 18px', borderRadius:4, marginBottom:12, fontWeight:800, fontSize:13}}>
          ⚠ هذا السند ملغى{payment.archiveReason ? ' — السبب: '+payment.archiveReason : ''} — لا يُعتد به مالياً
        </div>
      )}
      <div className="rcpt-pair">
        <Copy />
        <div className="rcpt-cutline"><span>✂ خط القص — Cut Here</span></div>
        <Copy />
      </div>
    </div>
  );
}

/* ================= Demand Doc (مطالبة بدفعة مستحقة — نفس تصميم سند القبض) ================= */
function DemandDoc({payment, project, onBack}){
  if(payment.docSnapshot){
    const s = payment.docSnapshot;
    project = {...(project||{}), name:s.projectName, owner:s.owner, ownerTrn:s.ownerTrn, additionalOwners:s.additionalOwners||[], plotNumber:s.plotNumber, projectNo:s.projectNo};
  }
  const base = remainderOf(payment);          // المتبقي غير المحصّل (صافي)
  const rate = vatRateOf(payment);
  const vat = base*rate;
  const total = base*(1+rate);                // المستحق شامل الضريبة
  const overdue = payment.dueDate ? daysSince(payment.dueDate) : null;
  const isLate = overdue!==null && overdue>0;
  const instLabel = payment.phase==='إشراف' ? ('إشراف '+(payment.month?fmtMonth(payment.month):'')) : (payment.label||'');
  const projLine = project ? (project.name + (project.plotNumber ? ' — قطعة رقم '+project.plotNumber : '') + (project.projectNo ? ' · مشروع '+project.projectNo : '')) : '—';

  const Copy = ()=>(
    <div className="rcpt rcpt-a5">
      <div className="rcpt-band">
        <div className="rcpt-logo">
          <img src={NITAQ_LOGO} alt="نطاق NITAQ" style={{height:74, display:'block'}} />
        </div>
        <div className="rcpt-cotitle">
          <div className="ar">نطاق للاستشارات الهندسية</div>
          <div className="en">NITAQ <b>◆</b> ENGINEERING CONSULTANTS</div>
        </div>
      </div>
      <div className="rcpt-gold"></div>
      <div className="rcpt-body">
        <div className="rcpt-wm"><img src={NITAQ_LOGO} alt="" style={{width:340, opacity:.05, filter:'invert(1) brightness(0.2)'}} /></div>

        <div className="rcpt-titlerow">
          <div className="rcpt-meta">
            <div className="row"><span className="lbl">رقم المطالبة</span><span className="val">{payment.demandNo||'—'}</span><span className="en">Demand No.</span></div>
            <div className="row"><span className="lbl">التاريخ</span><span className="val">{todayISO()}</span><span className="en">Date</span></div>
            <div className="row"><span className="lbl">تاريخ الاستحقاق</span><span className="val" style={isLate?{color:'var(--rust)', fontWeight:800}:{}}>{payment.dueDate||'—'}</span><span className="en">Due Date</span></div>
          </div>
          <div className="rcpt-title">
            <div className="ar">مطالبة بدفعة مستحقة</div>
            <div className="en">PAYMENT DEMAND</div>
            <div className="orn">— ◇ —</div>
          </div>
        </div>

        <div className="rcpt-line">
          <span className="lbl">إلى السيّد / السادة</span>
          <span className="val">{project ? (ownersLine(project)||'—') : '—'}</span>
          <span className="en">To</span>
        </div>

        <div className="rcpt-line">
          <span className="lbl">المشروع — رقم القطعة</span>
          <span className="val">{projLine}</span>
          <span className="en">Project — Plot No.</span>
        </div>

        <div className="rcpt-line">
          <span className="lbl">المرحلة / Stage</span>
          <Chk on={payment.phase==='تصميم'} ar="تصميم" en="Design" />
          <Chk on={payment.phase==='إشراف'} ar="إشراف" en="Supervision" />
          <Chk on={payment.phase==='أخرى'} ar="أخرى" en="Other" />
          <span className="lbl" style={{marginInlineStart:18}}>بيان الدفعة</span>
          <span className="val">{instLabel}</span>
          <span className="en">Description</span>
        </div>

        <div className="rcpt-line">
          <span className="lbl">تفصيل المبلغ</span>
          <span className="val" style={{fontWeight:600}}>
            Base {fmt(base)} AED{rate>0 ? ' + VAT (5%) '+fmt(vat)+' AED' : ' (Zero-rated)'}
          </span>
          <span className="en">Breakdown</span>
        </div>

        <div className="rcpt-line">
          <span className="lbl">ملاحظات</span>
          <span className="val" style={{fontWeight:600}}>{payment.note||''}</span>
          <span className="en">Notes</span>
        </div>

        <div className="rcpt-bottom">
          <div className="rcpt-stamp">
            <div>
              <div className="t">ختم وتوقيع المكتب</div>
              <div className="en">Issued by · Stamp &amp; Signature</div>
            </div>
            <div className="co">NITAQ ENGINEERING CONSULTANCY</div>
          </div>
          <div className="rcpt-amount">
            <div className="hd"><span>المبلغ المستحق</span><span className="en">Amount Due</span></div>
            <div className="amt">
              <span className="cur">AED</span>
              <span className="num">{fmt(total)}</span>
            </div>
            <div className="words">فقط {tafqeet(total)}</div>
            {isLate
              ? <div className="vatline" style={{color:'var(--rust)', fontWeight:800}}>⚠ متأخرة {overdue} يوم عن تاريخ الاستحقاق — يرجى السداد</div>
              : payment.dueDate && <div className="vatline">يرجى السداد قبل تاريخ الاستحقاق {payment.dueDate}</div>}
          </div>
        </div>
      </div>
      <div className="rcpt-foot">
        <span>SHARJAH · UAE &nbsp;|&nbsp; {COMPANY.phone2} &nbsp;|&nbsp; {COMPANY.phone} &nbsp;|&nbsp; {COMPANY.email}</span>
        <span className="tag">{COMPANY.tagline}</span>
      </div>
    </div>
  );

  return (
    <div>
      <div className="toolbar no-print">
        <button className="btn outline" onClick={onBack}>← رجوع للدفعات</button>
        <button className="btn brass" onClick={()=>window.print()}><I.print/> طباعة المطالبة (نسختين A4)</button>
      </div>
      <div className="no-print" style={{background:'var(--brass-soft)', color:'var(--ink)', padding:'10px 18px', borderRadius:4, marginBottom:12, fontSize:12.5, borderInlineStart:'4px solid var(--brass)'}}>
        مطالبة بدفعة مستحقة — مستند غير محاسبي للتذكير بالسداد، لا يُغني عن الفاتورة الضريبية ولا يُعتد به كسند قبض.
      </div>
      <div className="rcpt-pair">
        <Copy />
        <div className="rcpt-cutline"><span>✂ خط القص — Cut Here</span></div>
        <Copy />
      </div>
    </div>
  );
}

/* ================= Invoice Doc (فاتورة ضريبية — FTA compliant) ================= */
function InvoiceDoc({payment, project, settings, onBack, onRefresh}){
  if(payment.docSnapshot){
    const s = payment.docSnapshot;
    project = {...(project||{}), name:s.projectName, owner:s.owner, ownerTrn:s.ownerTrn, additionalOwners:s.additionalOwners||[], plotNumber:s.plotNumber, projectNo:s.projectNo};
  }
  const rate = vatRateOf(payment);
  const net = payment.amount||0;
  const vat = net*rate;
  const total = net*(1+rate);
  const item = payment.phase==='إشراف'
    ? ('أتعاب الإشراف الهندسي — '+(payment.month?fmtMonth(payment.month):''))
    : payment.phase==='أخرى'
    ? (payment.label||'خدمات استشارية أخرى')
    : ('أتعاب التصميم واعتماد المخططات — '+(payment.label||''));
  const paid = payment.status==='مدفوعة';
  const partial = payment.status==='مدفوعة جزئياً';

  return (
    <div>
      <div className="toolbar no-print">
        <button className="btn outline" onClick={onBack}>← رجوع للدفعات</button>
        {onRefresh && <button className="btn ghost" onClick={onRefresh} title="إعادة جلب اسم العميل والمشروع من بياناتهم الحالية">↻ تحديث البيانات</button>}
        <button className="btn brass" onClick={()=>window.print()}><I.print/> طباعة الفاتورة</button>
      </div>

      <div className="sinv" dir="ltr">
        {/* Header */}
        <div className="sinv-top">
          <div className="sinv-co" style={{textAlign:'left'}}>
            <div className="n">NITAQ ENGINEERING CONSULTANCY</div>
            <div className="ne">L.L.C. — SP</div>
            <div className="meta">
              TRN: {COMPANY.trn} &nbsp;·&nbsp; License {COMPANY.license}<br/>
              {COMPANY.address}<br/>
              {COMPANY.phone} &nbsp;·&nbsp; {COMPANY.email}
            </div>
          </div>
          <div className="sinv-logo"><img src={NITAQ_LOGO} alt="NITAQ" /></div>
        </div>

        {/* Title */}
        <div className="sinv-tag"><span className="en">TAX INVOICE</span></div>

        {/* Invoice & customer info */}
        <div className="sinv-info">
          <div>
            <div className="row"><span className="k">Invoice No.</span><span className="v">{payment.invoiceNo||'—'}</span></div>
            <div className="row"><span className="k">Issue Date</span><span className="v">{(payment.docSnapshot && payment.docSnapshot.issuedAt) || payment.date}</span></div>
            <div className="row"><span className="k">Supply Date</span><span className="v">{payment.date}</span></div>
            <div className="row"><span className="k">Due Date</span><span className="v">{payment.dueDate||'—'}</span></div>
          </div>
          <div>
            <div className="row"><span className="k">Customer</span><span className="v">{project ? (ownersLine(project)||'—') : '—'}</span></div>
            <div className="row"><span className="k">Customer TRN</span><span className="v">{(project && project.ownerTrn) || '—'}</span></div>
            <div className="row"><span className="k">Project</span><span className="v">{project ? (project.name||'—') : '—'}</span></div>
            <div className="row"><span className="k">Plot No.</span><span className="v">{(project && project.plotNumber) || '—'}</span></div>
          </div>
        </div>

        {/* Line items */}
        <table>
          <thead>
            <tr>
              <th style={{width:36}}>#</th>
              <th>Description</th>
              <th style={{width:120}}>Amount</th>
              <th style={{width:90}}>VAT 5%</th>
              <th style={{width:120}}>Total</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td>1</td>
              <td>{item}</td>
              <td>{fmt(net)}</td>
              <td>{rate>0?fmt(vat):'—'}</td>
              <td style={{fontWeight:700}}>{fmt(total)}</td>
            </tr>
          </tbody>
        </table>

        {/* Totals */}
        <div className="sinv-tot">
          <div className="box">
            <div className="r"><span>Subtotal</span><span>AED {fmt(net)}</span></div>
            <div className="r"><span>Discount</span><span>AED 0.00</span></div>
            <div className="r"><span>VAT (5%)</span><span>AED {fmt(vat)}</span></div>
            <div className="r grand"><span>Total incl. VAT</span><span>AED {fmt(total)}</span></div>
          </div>
        </div>

        <div className="sinv-words">Amount in words: {tafqeetEn(total)}</div>

        {/* Payment status */}
        <div className="sinv-pay" style={{
          background: paid?'var(--teal-soft)':partial?'var(--brass-soft)':'var(--rust-soft)',
          color: paid?'var(--teal)':partial?'var(--ink)':'var(--rust)',
          border:'1px solid '+(paid?'var(--teal)':partial?'var(--brass)':'var(--rust)')
        }}>
          {paid ? '✓ Payment Status: Paid in Full'
            : partial ? ('Payment Status: Partially Paid — Balance AED '+fmt(remainderOf(payment)*grossFactor(payment)))
            : '⚠ Payment Status: Due — please pay before '+(payment.dueDate||'')}
        </div>

        {settings && settings.iban ? (
          <div className="sinv-words" style={{fontWeight:600, color:'var(--ink-soft)'}}>
            Bank Transfer: {(settings.bankName||'')} — IBAN: {settings.iban}{settings.accountName?(' — '+settings.accountName):''}
          </div>
        ) : null}

        <div className="sinv-spacer"></div>

        {/* Signatures */}
        <div className="sinv-sign">
          <div className="s">Issued by<br/>NITAQ</div>
          <div className="s">Company Stamp</div>
          <div className="s">Customer Signature</div>
        </div>

        <div className="sinv-foot">SHARJAH · UAE &nbsp;|&nbsp; {COMPANY.phone2} &nbsp;|&nbsp; {COMPANY.phone} &nbsp;|&nbsp; {COMPANY.email}</div>
      </div>
    </div>
  );
}

/* ================= إشعار دائن (Credit Note) لفسخ العقد واسترداد الضريبة ================= */
function CreditNoteDoc({cn, onClose}){
  const { project, refundNet, refundVat, refundGross, reason, date, cnNo, origInvoice } = cn;
  const [lang, setLang] = useState('ar');
  const isEn = lang==='en';
  const bounced = !!origInvoice;   // شيك مرتجع لو فيه فاتورة أصلية، غير كده فسخ عقد

  const T = isEn ? {
    close:'Close', print:'Print', title:'TAX CREDIT NOTE',
    cnNo:'Credit Note No.', issue:'Issue Date', reason:'Reason', ref:'Against Invoice',
    reasonVal: bounced ? 'Returned Cheque — Invoice Cancellation' : 'Contract Termination',
    customer:'Customer', trn:'Customer TRN', project:'Project',
    thDesc:'Description', thAmt:'Amount', thVat:'VAT 5%', thTotal:'Total',
    desc: bounced
      ? ('Cancellation of Tax Invoice '+(origInvoice||'')+' — the cheque was returned unpaid; the full invoice is credited and output VAT reversed.')
      : 'Refund on contract termination — reversal of amounts collected in excess of work performed.',
    subtotal:'Subtotal (credited)', vatReclaim:'VAT (5%) reclaimed', grand:'Total Credit incl. VAT',
    words:'Amount in words', wordsSuffix:'(credited to customer)',
    notice:'↩ This Tax Credit Note reverses output VAT previously declared. Retain for FTA records.',
    issuedBy:'Issued by', stamp:'Company Stamp', sign:'Customer Signature',
  } : {
    close:'إغلاق', print:'طباعة الإشعار', title:'إشعار دائن ضريبي',
    cnNo:'رقم الإشعار', issue:'تاريخ الإصدار', reason:'السبب', ref:'عن الفاتورة',
    reasonVal: bounced ? 'شيك مرتجع — إلغاء فاتورة' : 'فسخ عقد',
    customer:'العميل', trn:'الرقم الضريبي للعميل', project:'المشروع',
    thDesc:'البيان', thAmt:'المبلغ', thVat:'ض.ق.م 5%', thTotal:'الإجمالي',
    desc: bounced
      ? ('إلغاء الفاتورة الضريبية '+(origInvoice||'')+' — ارتدّ الشيك بدون رصيد؛ تُقيَّد كامل قيمة الفاتورة دائناً وتُعكس ضريبة المخرجات.')
      : 'إرجاع عند فسخ العقد — عكس المبالغ المحصّلة الزائدة عن قيمة العمل المُنجز.',
    subtotal:'الصافي (دائن)', vatReclaim:'ض.ق.م المستردة (5%)', grand:'إجمالي الدائن شامل الضريبة',
    words:'المبلغ كتابةً', wordsSuffix:'(تُقيَّد دائناً للعميل)',
    notice:'↩ هذا الإشعار الدائن يعكس ضريبة المخرجات المُعلنة سابقاً. يُحتفظ به لسجلات الهيئة الاتحادية للضرائب.',
    issuedBy:'صادر عن', stamp:'ختم الشركة', sign:'توقيع العميل',
  };

  return (
    <div className="overlay" onMouseDown={(e)=>{ if(e.target===e.currentTarget) onClose(); }}>
      <div className="modal" style={{maxWidth:860, width:'96%', maxHeight:'92vh', overflowY:'auto', padding:12, background:'var(--paper)', boxShadow:'0 20px 50px rgba(0,0,0,.25)'}}>
        <div className="toolbar no-print" style={{justifyContent:'flex-end', marginBottom:8, gap:8}}>
          <div style={{display:'flex', border:'1px solid var(--line-strong)', borderRadius:4, overflow:'hidden'}}>
            <button onClick={()=>setLang('ar')} style={{padding:'7px 14px', fontSize:12.5, border:'none', cursor:'pointer', background: lang==='ar'?'var(--ink)':'#fff', color: lang==='ar'?'#fff':'var(--ink)'}}>عربي</button>
            <button onClick={()=>setLang('en')} style={{padding:'7px 14px', fontSize:12.5, border:'none', cursor:'pointer', background: lang==='en'?'var(--ink)':'#fff', color: lang==='en'?'#fff':'var(--ink)'}}>English</button>
          </div>
          <button className="btn outline" onClick={onClose}>{T.close}</button>
          <button className="btn brass" onClick={()=>window.print()}><I.print/> {T.print}</button>
        </div>
        <div className="sinv" dir={isEn?'ltr':'rtl'} style={{minHeight:'auto'}}>
          <div className="sinv-top">
            <div className="sinv-co" style={{textAlign: isEn?'left':'right'}}>
              <div className="n">{isEn ? 'NITAQ ENGINEERING CONSULTANCY' : COMPANY.nameAr}</div>
              <div className="ne">{isEn ? 'L.L.C. — SP' : COMPANY.nameEn}</div>
              <div className="meta">
                TRN: {COMPANY.trn} &nbsp;·&nbsp; {isEn?'License':'رخصة'} {COMPANY.license}<br/>
                {COMPANY.address}<br/>
                {COMPANY.phone} &nbsp;·&nbsp; {COMPANY.email}
              </div>
            </div>
            <div className="sinv-logo"><img src={NITAQ_LOGO} alt="NITAQ" /></div>
          </div>

          <div className="sinv-tag"><span className="en">{T.title}</span></div>

          <div className="sinv-info">
            <div>
              <div className="row"><span className="k">{T.cnNo}</span><span className="v">{cnNo||'—'}</span></div>
              <div className="row"><span className="k">{T.issue}</span><span className="v">{date}</span></div>
              {origInvoice && <div className="row"><span className="k">{T.ref}</span><span className="v">{origInvoice}</span></div>}
              <div className="row"><span className="k">{T.reason}</span><span className="v">{T.reasonVal}</span></div>
            </div>
            <div>
              <div className="row"><span className="k">{T.customer}</span><span className="v">{ownersLine(project)||'—'}</span></div>
              <div className="row"><span className="k">{T.trn}</span><span className="v">{project.ownerTrn||'—'}</span></div>
              <div className="row"><span className="k">{T.project}</span><span className="v">{project.name||'—'}</span></div>
            </div>
          </div>

          <table style={{tableLayout:'fixed', width:'100%'}}>
            <thead>
              <tr>
                <th style={{width:30}}>#</th>
                <th>{T.thDesc}</th>
                <th style={{width:95}}>{T.thAmt}</th>
                <th style={{width:80}}>{T.thVat}</th>
                <th style={{width:100}}>{T.thTotal}</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>1</td>
                <td style={{whiteSpace:'normal', wordBreak:'break-word', lineHeight:1.5}}>{T.desc}</td>
                <td>−{fmt(refundNet)}</td>
                <td>−{fmt(refundVat)}</td>
                <td style={{fontWeight:700}}>−{fmt(refundGross)}</td>
              </tr>
            </tbody>
          </table>

          <div className="sinv-tot">
            <div className="box">
              <div className="r"><span>{T.subtotal}</span><span>AED −{fmt(refundNet)}</span></div>
              <div className="r"><span>{T.vatReclaim}</span><span>AED −{fmt(refundVat)}</span></div>
              <div className="r grand"><span>{T.grand}</span><span>AED −{fmt(refundGross)}</span></div>
            </div>
          </div>

          <div className="sinv-words">{T.words}: {isEn?tafqeetEn(refundGross):tafqeet(refundGross)} {T.wordsSuffix}</div>

          <div className="sinv-pay" style={{background:'var(--rust-soft)', color:'var(--rust)', border:'1px solid var(--rust)'}}>
            {T.notice}
          </div>

          <div className="sinv-spacer"></div>
          <div className="sinv-sign">
            <div className="s">{T.issuedBy}<br/>NITAQ</div>
            <div className="s">{T.stamp}</div>
            <div className="s">{T.sign}</div>
          </div>
          <div className="sinv-foot">SHARJAH · UAE &nbsp;|&nbsp; {COMPANY.phone2} &nbsp;|&nbsp; {COMPANY.phone} &nbsp;|&nbsp; {COMPANY.email}</div>
        </div>
      </div>
    </div>
  );
}

/* ================= مصروفات المكتب بفلتر السداد والتاريخ ================= */
function OfficeExpensesView({data, configs, mutate, saveBudgets}){
  const [stFilter, setStFilter] = useState('');
  const [bankFilter, setBankFilter] = useState([]);   // اختيار متعدد للبنوك
  const [vendorFilter, setVendorFilter] = useState('');   // فلتر المورّد
  const [dFrom, setDFrom] = useState('');
  const [dTo, setDTo] = useState('');
  const m = mutate('officeExpenses');

  // قائمة البنوك المستخدمة فعلياً (تُبنى تلقائياً من البيانات)
  const bankOpts = [...new Set(data.officeExpenses.map(e=>(e.bankName||'').trim()).filter(Boolean))].sort();
  const vendorOpts = [...new Set(data.officeExpenses.map(e=>(e.vendor||'').trim()).filter(Boolean))].sort();
  const toggleBank = (b)=> setBankFilter(prev=> prev.includes(b) ? prev.filter(x=>x!==b) : [...prev, b]);
  const chipStyle = (on)=>({
    border:'1px solid '+(on?'var(--brass)':'var(--line-strong)'),
    background:on?'var(--brass)':'#fff', color:on?'#fff':'var(--ink-soft)',
    borderRadius:20, padding:'5px 13px', fontSize:12.5, fontWeight:700, cursor:'pointer', fontFamily:'inherit'
  });

  let records = stFilter
    ? data.officeExpenses.filter(e=> stFilter==='معلق' ? e.payStatus==='معلق' : e.payStatus!=='معلق')
    : data.officeExpenses;
  if(bankFilter.length) records = records.filter(e=> bankFilter.includes((e.bankName||'').trim()));
  if(vendorFilter) records = records.filter(e=> (e.vendor||'').trim()===vendorFilter);
  if(dFrom) records = records.filter(e=> (e.date||'') >= dFrom);
  if(dTo) records = records.filter(e=> (e.date||'') <= dTo);

  // الإجماليات تحترم الفلاتر المطبّقة (بدون المؤرشف) — شامل الضريبة (ما يخرج فعلاً من الحساب، مطابق للخزينة)
  const active = records.filter(e=>!isArchived(e));
  const totAll   = active.reduce((s,e)=>s+expGross(e),0);
  const totPaid  = active.filter(e=>e.payStatus!=='معلق').reduce((s,e)=>s+expGross(e),0);
  const totPend  = active.filter(e=>e.payStatus==='معلق').reduce((s,e)=>s+expGross(e),0);
  const totDebt  = active.reduce((s,e)=>s+expDebt(e),0);
  const totWio   = active.reduce((s,e)=>s+expOwnBank(e),0);
  const anyFilter = stFilter || bankFilter.length || vendorFilter || dFrom || dTo;

  // ===== تحليل بالتصنيف وأعلى الموردين (شامل الضريبة، يحترم الفلاتر) =====
  const [showBreakdown, setShowBreakdown] = useState(false);
  const byCat = {};
  active.forEach(e=>{ const k=e.category||'غير مصنّف'; byCat[k]=(byCat[k]||0)+expGross(e); });
  const catRows = Object.entries(byCat).map(([k,v])=>({k,v})).sort((a,b)=>b.v-a.v);
  const byVendor = {};
  active.forEach(e=>{ const v=(e.vendor||'').trim(); if(v) byVendor[v]=(byVendor[v]||0)+expGross(e); });
  const vendorRows = Object.entries(byVendor).map(([k,v])=>({k,v})).sort((a,b)=>b.v-a.v).slice(0,6);
  const barColors = ['var(--brass)','var(--teal)','var(--ink)','var(--rust)','var(--ink-soft)','#8A6D3B','#6E8B3D','#B7BCAF'];
  const pct = (v)=> totAll>0 ? Math.round(v/totAll*100) : 0;

  // ===== الموازنة الشهرية لكل تصنيف (مستقلة عن الفلاتر — عن الشهر الجاري) =====
  const budgets = (data.settings && data.settings.budgets) || {};
  const curYM = todayISO().slice(0,7);
  const [budgetOpen, setBudgetOpen] = useState(false);
  const [draftBudgets, setDraftBudgets] = useState(budgets);
  const spentThisMonthByCat = {};
  data.officeExpenses.filter(e=>!isArchived(e) && (e.date||'').slice(0,7)===curYM)
    .forEach(e=>{ const k=e.category||'غير مصنّف'; spentThisMonthByCat[k]=(spentThisMonthByCat[k]||0)+expGross(e); });
  const budgetCats = [...new Set([...OFFICE_CATEGORIES, ...Object.keys(budgets)])];
  const budgetRows = budgetCats.map(c=>({cat:c, budget:Number(budgets[c])||0, spent:spentThisMonthByCat[c]||0}))
    .filter(r=>r.budget>0 || r.spent>0);
  const overBudget = budgetRows.filter(r=>r.budget>0 && r.spent>r.budget);
  const money0 = (n)=> money(n);

  return (
    <div>
      <div className="grid" style={{gridTemplateColumns:'repeat(auto-fit, minmax(150px, 1fr))', marginBottom:14}}>
        <div className="card"><div className="kpi-label">إجمالي المصروفات{anyFilter?' (مفلتر)':''}</div><div className="kpi-value" style={{color:'var(--ink)'}}>{money(totAll)}</div><div className="kpi-note">{active.length} مصروف — شامل الضريبة</div></div>
        <div className="card"><div className="kpi-label">مدفوع</div><div className="kpi-value" style={{color:'var(--teal)'}}>{money(totPaid)}</div><div className="kpi-note">اتخصم فعلاً</div></div>
        <div className="card"><div className="kpi-label">معلق</div><div className="kpi-value" style={{color:'var(--brass)'}}>{money(totPend)}</div><div className="kpi-note">لم يُسدد بعد</div></div>
        <div className="card"><div className="kpi-label">WIO NITAQ</div><div className="kpi-value" style={{color:'var(--ink)'}}>{money(totWio)}</div><div className="kpi-note">مدفوع من حساب المكتب</div></div>
        <div className="card"><div className="kpi-label">دين علينا</div><div className="kpi-value" style={{color:totDebt>0?'var(--rust)':'var(--ink)'}}>{money(totDebt)}</div><div className="kpi-note">مدفوع من بنوك غير WIO NITAQ</div></div>
      </div>

      {active.length>0 && (
        <div className="card" style={{marginBottom:14}}>
          <div style={{display:'flex', justifyContent:'space-between', alignItems:'center', cursor:'pointer'}} onClick={()=>setShowBreakdown(x=>!x)}>
            <span style={{fontSize:13, fontWeight:800, color:'var(--ink)'}}>📊 تحليل المصروفات {anyFilter?'(حسب الفلتر الحالي)':''}</span>
            <span style={{fontSize:12, color:'var(--ink-soft)'}}>{showBreakdown?'▲ إخفاء':'▼ عرض'}</span>
          </div>
          {showBreakdown && (
            <div className="grid" style={{gridTemplateColumns:'repeat(auto-fit, minmax(280px, 1fr))', gap:20, marginTop:14}}>
              <div>
                <div style={{fontSize:12.5, fontWeight:800, color:'var(--ink-soft)', marginBottom:10}}>حسب التصنيف</div>
                {catRows.map((r,i)=>(
                  <div key={r.k} style={{marginBottom:9}}>
                    <div style={{display:'flex', justifyContent:'space-between', fontSize:12, marginBottom:3}}>
                      <span style={{color:'var(--ink)'}}>{r.k}</span>
                      <span style={{color:'var(--ink-soft)'}}><b>{money(r.v)}</b> · {pct(r.v)}%</span>
                    </div>
                    <div style={{height:8, background:'var(--line)', borderRadius:5, overflow:'hidden'}}>
                      <div style={{height:'100%', width:pct(r.v)+'%', background:barColors[i%barColors.length], borderRadius:5}}></div>
                    </div>
                  </div>
                ))}
              </div>
              <div>
                <div style={{fontSize:12.5, fontWeight:800, color:'var(--ink-soft)', marginBottom:10}}>أعلى الموردين</div>
                {vendorRows.length===0
                  ? <div style={{fontSize:12, color:'var(--ink-faint)', padding:'10px 0'}}>لا توجد مصروفات مُسندة لمورّد بعد — أضيفي المورّد في المصروف لرؤية التجميع هنا.</div>
                  : vendorRows.map((r,i)=>(
                    <div key={r.k} style={{marginBottom:9}}>
                      <div style={{display:'flex', justifyContent:'space-between', fontSize:12, marginBottom:3}}>
                        <span style={{color:'var(--ink)'}}>{r.k}</span>
                        <span style={{color:'var(--ink-soft)'}}><b>{money(r.v)}</b> · {pct(r.v)}%</span>
                      </div>
                      <div style={{height:8, background:'var(--line)', borderRadius:5, overflow:'hidden'}}>
                        <div style={{height:'100%', width:pct(r.v)+'%', background:barColors[i%barColors.length], borderRadius:5}}></div>
                      </div>
                    </div>
                  ))}
              </div>
            </div>
          )}
        </div>
      )}
      {overBudget.length>0 && (
        <div className="card" style={{marginBottom:14, borderInlineStart:'4px solid var(--rust)', background:'#FBF2EF'}}>
          <p style={{fontSize:13, fontWeight:800, color:'var(--rust)', marginBottom:6}}>⚠️ تجاوز الموازنة هذا الشهر ({fmtMonth ? fmtMonth(curYM) : curYM}):</p>
          {overBudget.map(r=>(
            <div key={r.cat} style={{fontSize:12.5, padding:'3px 0'}}>
              <b>{r.cat}</b>: صُرف {money(r.spent)} من موازنة {money(r.budget)} — <span style={{color:'var(--rust)'}}>تجاوز بـ {money(r.spent-r.budget)}</span>
            </div>
          ))}
        </div>
      )}

      {saveBudgets && (
        <div className="card" style={{marginBottom:14}}>
          <div style={{display:'flex', justifyContent:'space-between', alignItems:'center'}}>
            <span style={{fontSize:13, fontWeight:800, color:'var(--ink)'}}>🎯 الموازنة الشهرية {budgetRows.length>0?'— '+(fmtMonth?fmtMonth(curYM):curYM):''}</span>
            <button className="btn outline" style={{padding:'5px 12px', fontSize:12}} onClick={()=>{ setDraftBudgets(budgets); setBudgetOpen(x=>!x); }}>{budgetOpen?'إغلاق':'تعديل الموازنة'}</button>
          </div>
          {!budgetOpen && budgetRows.length>0 && (
            <div style={{marginTop:12}}>
              {budgetRows.map(r=>{
                const p = r.budget>0 ? Math.min(100, Math.round(r.spent/r.budget*100)) : 0;
                const over = r.budget>0 && r.spent>r.budget;
                const col = over?'var(--rust)':(p>=80?'var(--brass)':'var(--teal)');
                return (
                  <div key={r.cat} style={{marginBottom:10}}>
                    <div style={{display:'flex', justifyContent:'space-between', fontSize:12, marginBottom:3}}>
                      <span style={{color:'var(--ink)'}}>{r.cat}</span>
                      <span style={{color:'var(--ink-soft)'}}>{money(r.spent)} / {r.budget>0?money(r.budget):'—'}{r.budget>0?' · '+p+'%':''}</span>
                    </div>
                    <div style={{height:9, background:'var(--line)', borderRadius:5, overflow:'hidden'}}>
                      <div style={{height:'100%', width:(r.budget>0?p:0)+'%', background:col, borderRadius:5}}></div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
          {!budgetOpen && budgetRows.length===0 && (
            <p style={{fontSize:12, color:'var(--ink-faint)', marginTop:10}}>لم تُحدَّد موازنة بعد. اضغطي "تعديل الموازنة" لوضع حد شهري لكل تصنيف — وسينبهك النظام عند التجاوز.</p>
          )}
          {budgetOpen && (
            <div style={{marginTop:12}}>
              <p style={{fontSize:12, color:'var(--ink-soft)', marginBottom:10}}>حدّدي المبلغ الشهري لكل تصنيف (اتركيه فارغاً أو صفراً لإلغاء الموازنة). القيم شاملة الضريبة (ما يخرج فعلاً من البنك).</p>
              <div className="grid" style={{gridTemplateColumns:'repeat(auto-fit, minmax(220px, 1fr))', gap:10}}>
                {budgetCats.map(c=>(
                  <div key={c} style={{display:'flex', alignItems:'center', gap:8}}>
                    <span style={{fontSize:12.5, flex:1, color:'var(--ink)'}}>{c}</span>
                    <input type="number" value={draftBudgets[c]??''} placeholder="0"
                      onChange={e=>setDraftBudgets(prev=>({...prev, [c]: e.target.value}))}
                      style={{width:100, border:'1px solid var(--line-strong)', borderRadius:4, padding:'6px 8px', fontSize:12.5, background:'#fff'}} />
                  </div>
                ))}
              </div>
              <div style={{display:'flex', gap:8, marginTop:14}}>
                <button className="btn brass" style={{padding:'7px 16px', fontSize:12.5}} onClick={()=>{
                  const clean={};
                  Object.entries(draftBudgets).forEach(([k,v])=>{ const n=Number(v); if(n>0) clean[k]=n; });
                  saveBudgets(clean); setBudgetOpen(false);
                }}>حفظ الموازنة</button>
                <button className="btn outline" style={{padding:'7px 16px', fontSize:12.5}} onClick={()=>setBudgetOpen(false)}>إلغاء</button>
              </div>
            </div>
          )}
        </div>
      )}

      {anyFilter && (
        <div className="card" style={{marginBottom:14, borderInlineStart:'4px solid var(--teal)', display:'flex', gap:10, alignItems:'center', justifyContent:'space-between', flexWrap:'wrap'}}>
          <span style={{fontSize:13}}>🔎 نتيجة الفلتر: <b>{active.length}</b> مصروف — الإجمالي <b>{money(totAll)}</b>{bankFilter.length?<> — بنوك: <b>{bankFilter.join('، ')}</b> — دين: <b style={{color:'var(--rust)'}}>{money(totDebt)}</b></>:null}</span>
          <button className="btn outline" style={{padding:'5px 12px', fontSize:12}} onClick={()=>{setStFilter('');setBankFilter([]);setVendorFilter('');setDFrom('');setDTo('');}}>مسح كل الفلاتر</button>
        </div>
      )}
      {bankOpts.length>0 && (
        <div className="card" style={{marginBottom:14, display:'flex', gap:8, alignItems:'center', flexWrap:'wrap'}}>
          <span style={{fontSize:12.5, fontWeight:800, color:'var(--ink-soft)'}}>🏦 فلترة بالبنوك (اختاري كذا مع بعض):</span>
          <button onClick={()=>setBankFilter([])} style={chipStyle(bankFilter.length===0)}>كل البنوك</button>
          {bankOpts.map(b=>(
            <button key={b} onClick={()=>toggleBank(b)} style={chipStyle(bankFilter.includes(b))}>{b}</button>
          ))}
          {bankFilter.length>0 && <span style={{fontSize:12, color:'var(--ink-faint)'}}>({bankFilter.length} مختار)</span>}
        </div>
      )}
      <EntityView config={configs.officeExpenses} records={records} data={data}
        onAdd={m.add} onUpdate={m.update} onDelete={m.del}
        headExtra={
          <>
            <button className="btn outline" title="تصدير المصروفات الظاهرة (بعد الفلترة) لملف Excel للمطابقة مع المحاسب"
              onClick={async ()=>{
                if(active.length===0){ alert('لا توجد مصروفات للتصدير — امسحي الفلاتر أو غيّريها'); return; }
                try{ await exportOfficeExpensesXlsx(active, {banks:bankFilter, filtered:!!anyFilter}); }
                catch(e){ alert(e.message||'تعذر التصدير'); }
              }}
              style={{border:'1px solid var(--line-strong)', padding:'7px 12px', fontSize:12.5}}>
              ⬇️ تصدير Excel
            </button>
            <select value={stFilter} onChange={e=>setStFilter(e.target.value)}
              style={{border:'1px solid var(--line-strong)', borderRadius:4, padding:'7px 10px', fontSize:12.5, background:'#fff'}}>
              <option value="">كل الحالات</option>
              <option value="معلق">معلق فقط</option>
              <option value="مدفوع">مدفوع فقط</option>
            </select>
            {vendorOpts.length>0 && (
              <select value={vendorFilter} onChange={e=>setVendorFilter(e.target.value)} title="فلترة بالمورّد"
                style={{border:'1px solid var(--line-strong)', borderRadius:4, padding:'7px 10px', fontSize:12.5, background:'#fff'}}>
                <option value="">كل الموردين</option>
                {vendorOpts.map(v=><option key={v} value={v}>{v}</option>)}
              </select>
            )}
            <span style={{fontSize:12, color:'var(--ink-soft)'}}>من</span>
            <input type="date" value={dFrom} onChange={e=>setDFrom(e.target.value)}
              style={{border:'1px solid var(--line-strong)', borderRadius:4, padding:'6px 10px', fontSize:12.5, background:'#fff'}} />
            <span style={{fontSize:12, color:'var(--ink-soft)'}}>إلى</span>
            <input type="date" value={dTo} onChange={e=>setDTo(e.target.value)}
              style={{border:'1px solid var(--line-strong)', borderRadius:4, padding:'6px 10px', fontSize:12.5, background:'#fff'}} />
          </>
        }
      />
    </div>
  );
}

/* ================= الفواتير الدورية (اتصالات، إنترنت، سيوا...) ================= */
function RecurringBillsView({data, configs, mutate}){
  const m = mutate('recurringBills');
  const mExp = mutate('officeExpenses');
  const dueSoon = data.recurringBills.filter(b=>!isArchived(b) && b.active!=='متوقف').map(b=>({b, d:daysUntil(b.nextDueDate)})).filter(x=>x.d!==null && x.d<=(x.b.reminderDays||5)).sort((a,b)=>a.d-b.d);

  const markPaid = (bill)=>{
    if(!confirm('تسجيل سداد "'+bill.provider+'" بمبلغ '+money(bill.amount)+'؟\nهيتسجل مصروف مكتب جديد تلقائياً، وهيتحدث تاريخ الاستحقاق القادم لـ '+advanceDate(bill.nextDueDate, bill.frequency)+'.')) return;
    mExp.add({id:uid(), _ts:Date.now(), date:todayISO(), category:bill.category, amount:bill.amount, vatable:'غير خاضع', payStatus:'مدفوع', account:bill.account, note:'سداد دوري — '+bill.provider});
    m.update(bill.id, {nextDueDate: advanceDate(bill.nextDueDate, bill.frequency)});
  };

  return (
    <div>
      {dueSoon.length>0 && (
        <div className="card" style={{marginBottom:14, borderInlineStart:'4px solid var(--rust)'}}>
          <p style={{fontSize:13, fontWeight:800, marginBottom:8}}>⏰ فواتير قريبة الاستحقاق أو متأخرة:</p>
          {dueSoon.map(({b,d})=>(
            <div key={b.id} style={{display:'flex', justifyContent:'space-between', alignItems:'center', padding:'6px 0', borderTop:'1px solid var(--line)', fontSize:12.5}}>
              <span>{b.provider} ({b.category}) — {money(b.amount)} — {d<0?('متأخرة '+Math.abs(d)+' يوم'):(d===0?'مستحقة اليوم':('خلال '+d+' يوم'))} ({b.nextDueDate})</span>
              <button className="btn brass" style={{padding:'4px 12px', fontSize:11.5}} onClick={()=>markPaid(b)}>✓ تم السداد</button>
            </div>
          ))}
        </div>
      )}
      <EntityView config={configs.recurringBills} records={data.recurringBills} data={data}
        onAdd={m.add} onUpdate={m.update} onDelete={m.del}
        rowActions={(row)=> row.active!=='متوقف' && (
          <button className="btn ghost small" title="تسجيل سداد هذه الفاتورة" style={{color:'var(--teal)'}} onClick={()=>markPaid(row)}>✓</button>
        )}
      />
      <p style={{fontSize:12, color:'var(--ink-faint)', marginTop:14}}>* عند الضغط على "تم السداد"، يُسجَّل مصروف مكتب تلقائياً بنفس المبلغ والتصنيف، ويتقدّم تاريخ الاستحقاق القادم حسب دورية الفاتورة (شهري/ربع سنوي/نصف سنوي/سنوي). عدّل المبلغ من الفاتورة نفسها إذا اختلف عن المعتاد قبل الضغط على السداد.</p>
    </div>
  );
}

/* ================= قائمة عامة بفلتر مشروع ================= */
function ProjectFilteredList({entity, data, configs, mutate}){
  const [pid, setPid] = useState('');
  const m = mutate(entity);
  const records = pid ? (data[entity]||[]).filter(r=>r.projectId===pid) : (data[entity]||[]);
  return (
    <EntityView config={configs[entity]} records={records} data={data}
      onAdd={m.add} onUpdate={m.update} onDelete={m.del}
      headExtra={
        <select value={pid} onChange={e=>setPid(e.target.value)}
          style={{border:'1px solid var(--line-strong)', borderRadius:4, padding:'7px 10px', fontSize:12.5, background:'#fff'}}>
          <option value="">كل المشاريع</option>
          {data.projects.map(p=><option key={p.id} value={p.id}>{(p.projectNo?p.projectNo+' — ':'')+p.name}</option>)}
        </select>
      }
    />
  );
}

/* ================= Payments View (مع شريط ملخص وفلتر وسندات قبض) ================= */
function PaymentsView({data, configs, mutate, lockedProject, role}){
  const [filterProjState, setFilterProj] = useState('');
  const [settleFor, setSettleFor] = useState(null);
  const [bulkOpen, setBulkOpen] = useState(false);
  const filterProj = lockedProject || filterProjState;
  const [receiptFor, setReceiptFor] = useState(null);
  const [invoiceFor, setInvoiceFor] = useState(null);
  const [demandFor, setDemandFor] = useState(null);
  const [cnFor, setCnFor] = useState(null);   // إشعار دائن (شيك مرتجع)
  const m = mutate('payments');
  const records = filterProj ? data.payments.filter(p=>p.projectId===filterProj) : data.payments;

  if(receiptFor){
    const pay = data.payments.find(p=>p.id===receiptFor);
    if(pay){
      const proj = data.projects.find(p=>p.id===pay.projectId);
      return <ReceiptDoc payment={pay} project={proj} onBack={()=>setReceiptFor(null)} />;
    }
  }
  if(invoiceFor){
    const pay = data.payments.find(p=>p.id===invoiceFor);
    if(pay){
      const proj = data.projects.find(p=>p.id===pay.projectId);
      const refreshInvoice = ()=>{
        if(!proj) return;
        m.update(pay.id, {docSnapshot:{owner:proj.owner||'', ownerTrn:proj.ownerTrn||'', additionalOwners:proj.additionalOwners||[], projectName:proj.name||'', plotNumber:proj.plotNumber||'', projectNo:proj.projectNo||'', issuedAt:(pay.docSnapshot&&pay.docSnapshot.issuedAt)||todayISO()}});
      };
      return <InvoiceDoc payment={pay} project={proj} settings={data.settings} onBack={()=>setInvoiceFor(null)} onRefresh={refreshInvoice} />;
    }
  }
  if(demandFor){
    const pay = data.payments.find(p=>p.id===demandFor);
    if(pay){
      const proj = data.projects.find(p=>p.id===pay.projectId);
      return <DemandDoc payment={pay} project={proj} onBack={()=>setDemandFor(null)} />;
    }
  }

  if(cnFor) return <CreditNoteDoc cn={cnFor} onClose={()=>setCnFor(null)} />;

  const generateSupervision = () => {
    const ym = currentYM();
    const targets = (data.contracts||[]).filter(c=>{
      if(!contractHasSupervision(c) || c.status!=='سارٍ' || (c.category && c.category!=='خدمات استشارية')) return false;
      const proj = data.projects.find(p=>p.id===c.projectId);
      if(!proj || proj.status!=='جارٍ' || !projectReadyForSupervision(proj)) return false;
      const done = data.payments.filter(i=>!isArchived(i) && i.contractId===c.id && i.phase==='إشراف').length;
      if(done >= (c.supervisionMonths||0)) return false;
      return !data.payments.some(i=>!isArchived(i) && i.contractId===c.id && i.phase==='إشراف' && i.month===ym);
    });
    if(targets.length===0){ alert('لا توجد دفعات إشراف مطلوب توليدها لشهر '+fmtMonth(ym)); return; }
    const due = new Date(); due.setDate(due.getDate()+10);
    targets.forEach(c=>{
      m.add({id:uid(), projectId:c.projectId, contractId:c.id, phase:'إشراف', month:ym, amount:c.supervisionMonthly,
        date:todayISO(), dueDate:due.toISOString().slice(0,10), status:'معلقة', _ts:Date.now()});
    });
    alert('تم توليد '+targets.length+' دفعة إشراف لشهر '+fmtMonth(ym)+' بحالة معلقة');
  };

  const docSeq = (row, field, prefix) => {
    const proj = data.projects.find(p=>p.id===row.projectId);
    const pno = proj ? proj.projectNo : 0;
    const pre = prefix+'-'+pno+'-';
    const maxNo = data.payments.reduce((mx,p)=>{
      if(!(p[field]||'').startsWith(pre)) return mx;
      return Math.max(mx, parseInt((p[field]||'').slice(pre.length))||0);
    }, 0);
    return pre + String(maxNo+1).padStart(3,'0');
  };
  const takeSnapshot = (row)=>{
    if(row.docSnapshot) return {};
    const proj = data.projects.find(p=>p.id===row.projectId) || {};
    return {docSnapshot:{owner:proj.owner||'', ownerTrn:proj.ownerTrn||'', additionalOwners:proj.additionalOwners||[], projectName:proj.name||'', plotNumber:proj.plotNumber||'', projectNo:proj.projectNo||'', issuedAt:todayISO()}};
  };
  const openReceipt = (row) => {
    if(!row.receiptNo) m.update(row.id, {receiptNo: docSeq(row, 'receiptNo', 'RCP'), ...takeSnapshot(row)});
    setReceiptFor(row.id);
  };
  const openInvoice = (row) => {
    if(!row.invoiceNo) m.update(row.id, {invoiceNo: docSeq(row, 'invoiceNo', 'INV'), ...takeSnapshot(row)});
    setInvoiceFor(row.id);
  };
  const openDemand = (row) => {
    if(!row.demandNo) m.update(row.id, {demandNo: docSeq(row, 'demandNo', 'DMD'), ...takeSnapshot(row)});
    setDemandFor(row.id);
  };

  // ===== شيك مرتجع (حالة نادرة): عكس القبض + إشعار دائن لإبطال الضريبة + إلغاء الدفعة =====
  const bouncedCheque = (row) => {
    const net = row.amount||0;
    const rate = vatRateOf(row);
    const vat = net*rate;
    const gross = net*(1+rate);
    const proj = data.projects.find(p=>p.id===row.projectId) || {};
    const msg = 'تأكيد: شيك الدفعة ارتدّ (رجع بدون رصيد).\n\nهيتم تلقائياً:\n'
      + '• عكس القبض — '+money(gross)+' يخرج من رصيد '+(row.account||'البنك')+' تلقائياً (الفلوس ماجتش فعلاً)\n'
      + '• إشعار دائن لإبطال الفاتورة '+(row.invoiceNo||'')+' واسترداد الضريبة '+money(vat)+' من الهيئة\n'
      + '• تحويل الدفعة إلى "ملغاة — شيك مرتجع"\n\nمتابعة؟';
    if(!confirm(msg)) return;
    const refNote = row.refNo ? ' (شيك رقم '+row.refNo+')' : '';
    const cnNo = 'CN-'+(proj.projectNo||'')+'-'+(row.invoiceNo||todayISO().replace(/-/g,''));
    // ملاحظة: لا نضيف حركة خزينة صرف — لأن تحويل الدفعة إلى "ملغاة" يجعل collectedOf=0،
    // فيختفي قبضها تلقائياً من رصيد الحساب (عكس القبض ذاتي). إضافة صرف هنا كانت ستخصم المبلغ مرتين.
    // تحويل الدفعة إلى ملغاة (net يصير 0 فلا تُحتسب ذمة ولا إيراد) + حفظ رقم الإشعار لإعادة الطباعة
    m.update(row.id, {status:'ملغاة', cancelReason:'شيك مرتجع — ارتدّ شيك الفاتورة '+(row.invoiceNo||'')+refNote+'. عُكس القبض وأُبطلت الفاتورة بإشعار دائن.',
      bouncedCheque:true, bouncedDate:todayISO(), creditNoteNo:cnNo, lastCorrectionReason:'شيك مرتجع — عكس قبض وإبطال فاتورة', lastCorrectionAt:new Date().toISOString()});
    // 3) إشعار دائن بكامل قيمة الفاتورة (يبطّل أثر ضريبة المخرجات)
    setCnFor({ project:proj, refundNet:net, refundVat:vat, refundGross:gross, reason:'إبطال الفاتورة '+(row.invoiceNo||'')+' — شيك مرتجع'+refNote, date:todayISO(), cnNo, origInvoice:row.invoiceNo });
  };

  // إعادة فتح/طباعة إشعار الدائن لدفعة ملغاة بشيك مرتجع (في أي وقت)
  const reopenCreditNote = (row) => {
    const net = row.amount||0;
    const rate = vatRateOf(row);
    const vat = net*rate;
    const gross = net*(1+rate);
    const proj = data.projects.find(p=>p.id===row.projectId) || {};
    const refNote = row.refNo ? ' (شيك رقم '+row.refNo+')' : '';
    const cnNo = row.creditNoteNo || ('CN-'+(proj.projectNo||'')+'-'+(row.invoiceNo||''));
    setCnFor({ project:proj, refundNet:net, refundVat:vat, refundGross:gross, reason:'إبطال الفاتورة '+(row.invoiceNo||'')+' — شيك مرتجع'+refNote, date:row.bouncedDate||todayISO(), cnNo, origInvoice:row.invoiceNo });
  };

  const designTotal = records.filter(p=>p.phase==='تصميم').reduce((s,p)=>s+billedOf(p),0);
  const supervTotal = records.filter(p=>p.phase==='إشراف').reduce((s,p)=>s+billedOf(p),0);
  const otherTotal = records.filter(p=>p.phase==='أخرى').reduce((s,p)=>s+billedOf(p),0);
  const unpaid = records.reduce((s,p)=>s+remainderOf(p)*grossFactor(p),0);

  return (
    <div>
      <div className="grid grid-4" style={{marginBottom:18}}>
        <div className="card">
          <div className="kpi-label">دفعات التصميم والاعتماد</div>
          <div className="kpi-value" style={{fontSize:19}}>{money(designTotal)}</div>
          <div className="kpi-note">المرحلة الأولى — قبل الضريبة</div>
        </div>
        <div className="card">
          <div className="kpi-label">دفعات الإشراف الشهري</div>
          <div className="kpi-value" style={{fontSize:19}}>{money(supervTotal)}</div>
          <div className="kpi-note">المرحلة الثانية — قبل الضريبة</div>
        </div>
        <div className="card">
          <div className="kpi-label">رسوم أخرى خاضعة للضريبة</div>
          <div className="kpi-value" style={{fontSize:19}}>{money(otherTotal)}</div>
          <div className="kpi-note">فحوصات وخدمات خارجية</div>
        </div>
        <div className="card">
          <div className="kpi-label">مستحقات غير محصلة</div>
          <div className="kpi-value" style={{fontSize:19, color:unpaid>0?'var(--rust)':'var(--teal)'}}>{money(unpaid)}</div>
          <div className="kpi-note">شاملة الضريبة — معلقة أو متأخرة</div>
        </div>
      </div>
      {settleFor && <SettlePaymentModal payment={settleFor} mutate={mutate} onClose={()=>setSettleFor(null)} />}
      {bulkOpen && <BulkSettleModal data={data} mutate={mutate} presetProject={lockedProject||filterProj||''} onClose={()=>setBulkOpen(false)} />}
      <EntityView config={lockedProject ? {...configs.payments, defaults:{...configs.payments.defaults, projectId:lockedProject}} : configs.payments} records={records} data={data}
        onAdd={m.add} onUpdate={m.update} onDelete={m.del} role={role}
        rowActions={(row)=>(
          <React.Fragment>
            <button className="btn ghost small" title="فاتورة ضريبية" onClick={()=>openInvoice(row)}><I.docfile/></button>
            {row.status!=='مدفوعة' && !isArchived(row) && remainderOf(row)>0 && (
              <button className="btn ghost small" title="مطالبة بدفعة (للإرسال للمالك)" style={{color:'var(--brass)'}} onClick={()=>openDemand(row)}>📄</button>
            )}
            {row.status!=='مدفوعة' && row.status!=='ملغاة' && !isArchived(row) && (
              <button className="btn ghost small" title="تسجيل تحصيل" style={{color:'var(--teal)'}} onClick={()=>setSettleFor(row)}>💰</button>
            )}
            {(row.status==='مدفوعة'||row.status==='مدفوعة جزئياً') && (
              <button className="btn ghost small" title="سند قبض" onClick={()=>openReceipt(row)}><I.print/></button>
            )}
            {row.status==='مدفوعة' && row.method==='شيك' && !isArchived(row) && (
              <button className="btn ghost small" title="شيك مرتجع — عكس القبض وإبطال الفاتورة بإشعار دائن" style={{color:'var(--rust)'}} onClick={()=>bouncedCheque(row)}>⟲</button>
            )}
            {row.bouncedCheque && (
              <button className="btn ghost small" title="إعادة طباعة إشعار الدائن (شيك مرتجع)" style={{color:'var(--rust)'}} onClick={()=>reopenCreditNote(row)}>🧾</button>
            )}

          </React.Fragment>
        )}
        headExtra={
          <React.Fragment>
            <button className="btn outline" onClick={generateSupervision}>توليد دفعات إشراف {fmtMonth(currentYM())}</button>
            <button className="btn outline" onClick={()=>setBulkOpen(true)}>💰 تحصيل مجمّع</button>
            {lockedProject ? null : <select value={filterProj} onChange={e=>setFilterProj(e.target.value)}
              style={{border:'1px solid var(--line-strong)', borderRadius:4, padding:'7px 10px', fontSize:12.5, background:'#fff'}}>
              <option value="">كل المشاريع</option>
              {data.projects.map(p=><option key={p.id} value={p.id}>{(p.projectNo?p.projectNo+' — ':'')+p.name}</option>)}
            </select>}
          </React.Fragment>
        }
      />
      <p style={{fontSize:12, color:'var(--ink-faint)', marginTop:14}}>* بجوار كل دفعة: زر الفاتورة الضريبية (لأي دفعة)، وزر 📄 المطالبة بدفعة (للدفعات المستحقة غير المحصّلة — تُطبع بنفس تصميم سند القبض لإرسالها للمالك)، وزر سند القبض (للدفعات المدفوعة فقط). الترقيم تسلسلي تلقائي ومنفصل لكل نوع (RCP / INV / DMD).</p>
    </div>
  );
}

/* ================= Gov Fees View (أمانات خارج الإيرادات والضريبة) ================= */
function GovFeesView({data, configs, mutate, lockedProject}){
  const [filterProjState, setFilterProj] = useState('');
  const filterProj = lockedProject || filterProjState;
  const m = mutate('govFees');
  const records = filterProj ? data.govFees.filter(g=>g.projectId===filterProj) : data.govFees;

  const total = records.reduce((s,g)=>s+(isArchived(g)?0:g.amount),0);
  const paidToDept = records.filter(g=>g.payerType!=='المالك مباشرة' && g.paidStatus==='مدفوع').reduce((s,g)=>s+(isArchived(g)?0:g.amount),0);
  const reimbursed = records.filter(g=>g.reimburseStatus==='مسترد').reduce((s,g)=>s+(isArchived(g)?0:g.amount),0);
  const outstanding = records.filter(g=>!isArchived(g) && g.payerType!=='المالك مباشرة' && g.paidStatus==='مدفوع' && g.reimburseStatus!=='مسترد').reduce((s,g)=>s+(isArchived(g)?0:g.amount),0);

  return (
    <div>
      <div className="grid grid-4" style={{marginBottom:18}}>
        <div className="card"><div className="kpi-label">إجمالي الرسوم</div><div className="kpi-value" style={{fontSize:20}}>{money(total)}</div><div className="kpi-note">{records.length} بند</div></div>
        <div className="card"><div className="kpi-label">مدفوع للدوائر</div><div className="kpi-value" style={{fontSize:20, color:'var(--blue)'}}>{money(paidToDept)}</div><div className="kpi-note">من خزينة المكتب</div></div>
        <div className="card"><div className="kpi-label">مسترد من العملاء</div><div className="kpi-value" style={{fontSize:20, color:'var(--teal)'}}>{money(reimbursed)}</div><div className="kpi-note">تمت تسويته</div></div>
        <div className="card"><div className="kpi-label">معلق الاسترداد</div><div className="kpi-value" style={{fontSize:20, color:outstanding>0?'var(--rust)':'var(--teal)'}}>{money(outstanding)}</div><div className="kpi-note">مدفوع للدائرة ولم يُسترد من العميل</div></div>
      </div>
      <EntityView config={lockedProject ? {...configs.govFees, defaults:{...configs.govFees.defaults, projectId:lockedProject}} : configs.govFees} records={records} data={data}
        onAdd={m.add} onUpdate={m.update} onDelete={m.del}
        headExtra={ lockedProject ? null : (
          <select value={filterProj} onChange={e=>setFilterProj(e.target.value)}
            style={{border:'1px solid var(--line-strong)', borderRadius:4, padding:'7px 10px', fontSize:12.5, background:'#fff'}}>
            <option value="">كل المشاريع</option>
            {data.projects.map(p=><option key={p.id} value={p.id}>{(p.projectNo?p.projectNo+' — ':'')+p.name}</option>)}
          </select>
        )}
      />
      <p style={{fontSize:12, color:'var(--ink-faint)', marginTop:14}}>* الرسوم الحكومية أمانات تُدفع نيابة عن العميل — لا تدخل ضمن إيرادات المكتب ولا تخضع لضريبة القيمة المضافة، وتظهر في تقرير مستقل.</p>
    </div>
  );
}

/* ================= Attendance View ================= */
const ATT_STATES = [null,'present','absent','leave','late'];
const ATT_MARK = {present:'ح', absent:'غ', leave:'إ', late:'ت'};
function AttendanceView({data, setAttendance}){
  const [ym, setYm] = useState(currentYM());
  const [year, month] = ym.split('-').map(Number);
  const daysInMonth = new Date(year, month, 0).getDate();
  const days = Array.from({length:daysInMonth}, (_,i)=>i+1);

  const cycle = (empId, day) => {
    const dateStr = ym+'-'+String(day).padStart(2,'0');
    const cur = (data.attendance[empId]||{})[dateStr] || null;
    const idx = ATT_STATES.indexOf(cur);
    const next = ATT_STATES[(idx+1)%ATT_STATES.length];
    setAttendance(empId, dateStr, next);
  };

  return (
    <div>
      <div className="toolbar">
        <div className="section-title" style={{marginBottom:0, flex:1}}>
          <h3>الحضور والانصراف</h3>
          <div className="rule"></div>
        </div>
        <input type="month" value={ym} onChange={e=>setYm(e.target.value)} />
      </div>
      <div className="card" style={{padding:16}}>
        <p style={{fontSize:12.5, color:'var(--ink-soft)', marginBottom:14}}>انقر على أي خلية للتبديل بين: حاضر ← غائب ← إجازة ← متأخر ← فارغ</p>
        <div className="att-grid">
          <table className="att-table">
            <thead>
              <tr>
                <th className="att-name-col">الموظف</th>
                {days.map(d=>(<th key={d} style={{minWidth:26}}>{d}</th>))}
              </tr>
            </thead>
            <tbody>
              {data.employees.map(emp=>(
                <tr key={emp.id}>
                  <td className="att-name-col">{emp.name}</td>
                  {days.map(d=>{
                    const dateStr = ym+'-'+String(d).padStart(2,'0');
                    const st = (data.attendance[emp.id]||{})[dateStr] || null;
                    return (
                      <td key={d} className={"att-cell "+(st||'empty')} onClick={()=>cycle(emp.id,d)}>
                        {st ? ATT_MARK[st] : ''}
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="legend">
          <span><i style={{background:'var(--teal-soft)'}}></i> حاضر</span>
          <span><i style={{background:'var(--rust-soft)'}}></i> غائب</span>
          <span><i style={{background:'var(--blue-soft)'}}></i> إجازة</span>
          <span><i style={{background:'var(--amber-soft)'}}></i> متأخر</span>
        </div>
      </div>
    </div>
  );
}

/* ================= VAT View (ربع سنوي وفق شهادة الهيئة) ================= */
function VatView({data}){
  const projName = (id)=>{ const p=(data.projects||[]).find(x=>x.id===id); return p ? (p.projectNo?p.projectNo+' — ':'')+p.name : '—'; };
  const quarters = listQuarters();
  const [qk, setQk] = useState(quarters[quarters.length-1]);
  const [fProj, setFProj] = useState('');
  const [fMonth, setFMonth] = useState('');
  const [fFrom, setFFrom] = useState('');
  const [fTo, setFTo] = useState('');
  const [q, setQ] = useState('');
  const qLower = q.trim().toLowerCase();
  const months = quarterMonths(qk);

  // فلتر مشترك يطبّق على الدفعات والمصروفات معاً
  const inWindow = (dateStr)=>{
    const d = dateStr||'';
    if(!months.includes(monthKey(d))) return false;      // ضمن الربع المختار
    if(fMonth && monthKey(d)!==fMonth) return false;      // شهر محدّد داخل الربع
    if(fFrom && d < fFrom) return false;                  // مدى مخصّص
    if(fTo && d > fTo) return false;
    return true;
  };

  const payIn = data.payments.filter(i=>{
    if(!inWindow(i.date)) return false;
    if(fProj && i.projectId!==fProj) return false;
    if(qLower){
      const hay = ((i.label||'')+' '+projName(i.projectId)+' '+(i.phase||'')).toLowerCase();
      if(!hay.includes(qLower)) return false;
    }
    return true;
  });
  const expIn = [...data.officeExpenses.map(e=>({...e,_src:'مكتب'})), ...data.projectCosts.map(e=>({...e,_src:'مشروع'}))].filter(e=>{
    if(!inWindow(e.date)) return false;
    if(fProj && e.projectId!==fProj) return false;         // المصروفات المرتبطة بالمشروع؛ مصروفات المكتب تُستبعد عند اختيار مشروع
    if(qLower){
      const hay = ((e.category||'')+' '+(e.note||'')+' '+(e._src||'')).toLowerCase();
      if(!hay.includes(qLower)) return false;
    }
    return true;
  });
  // الإيرادات الأخرى الخاضعة للضريبة (تدخل نافذة التاريخ؛ وتُستبعد عند اختيار مشروع لأنها غير مرتبطة بمشروع)
  const incIn = (data.otherIncome||[]).filter(r=>{
    if(!inWindow(r.date)) return false;
    if(fProj) return false;
    if(qLower){ const hay = ((r.category||'')+' '+(r.note||'')+' '+(r.payer||'')).toLowerCase(); if(!hay.includes(qLower)) return false; }
    return true;
  });
  // الدفعة الملغاة (شيك مرتجع / فسخ عقد) تُستثنى من ضريبة المخرجات — عُكس أثرها بإشعار دائن
  const outputVat = payIn.reduce((s,i)=>s+((isArchived(i)||i.status==='ملغاة')?0:i.amount*vatRateOf(i)),0)
    + incIn.reduce((s,r)=>s+(isArchived(r)?0:incVat(r)),0);
  const inputVat = expIn.reduce((s,e)=>s+(isArchived(e)?0:(e.amount||0)*expVatRate(e)),0);
  const net = outputVat - inputVat;
  const due = quarterDueDate(qk);
  const dd = daysUntil(due);
  const ended = quarterEndDate(qk) < todayISO();
  const anyF = fProj||fMonth||fFrom||fTo||q;
  const resetF = ()=>{ setFProj(''); setFMonth(''); setFFrom(''); setFTo(''); setQ(''); };
  // أشهر الربع للقائمة المنسدلة
  const monthOpts = months.slice().sort();
  const selEl = {border:'1px solid var(--line-strong)', borderRadius:4, padding:'7px 10px', fontSize:12.5, background:'#fff'};

  // تفاصيل ضريبة المخرجات (الدفعات الخاضعة فقط — تُستثنى الملغاة لأن أثرها عُكس بإشعار دائن)
  const outRows = [
    ...payIn.filter(i=>!isArchived(i) && i.status!=='ملغاة' && vatRateOf(i)>0)
      .map(i=>({ date:i.date, proj:projName(i.projectId),
        label: i.phase==='إشراف' ? ('إشراف '+(i.month?fmtMonth(i.month):'')) : (i.label||'دفعة'),
        net:i.amount||0, vat:(i.amount||0)*0.05 })),
    ...incIn.filter(r=>!isArchived(r) && incVatRate(r)>0)
      .map(r=>({ date:r.date, proj:'إيراد آخر', label:(r.category||'إيراد آخر')+(r.payer?' — '+r.payer:''), net:r.amount||0, vat:incVat(r) })),
  ].sort((a,b)=>(a.date||'').localeCompare(b.date||''));
  // تفاصيل ضريبة المدخلات (المصروفات الخاضعة فقط)
  const inRows = expIn.filter(e=>!isArchived(e) && expVatRate(e)>0)
    .sort((a,b)=>(a.date||'').localeCompare(b.date||''))
    .map(e=>({ date:e.date, src:e._src, cat:e.category||'—', note:e.note||'',
      net:e.amount||0, vat:(e.amount||0)*0.05 }));

  return (
    <div>
      <div className="toolbar no-print" style={{flexWrap:'wrap', gap:10}}>
        <div className="section-title" style={{marginBottom:0, flex:'1 1 100%'}}><h3>ضريبة القيمة المضافة — فترات ربع سنوية</h3><div className="rule"></div></div>
        <select value={qk} onChange={e=>{setQk(e.target.value); setFMonth('');}} style={selEl}>
          {quarters.map(q=><option key={q} value={q}>{quarterLabel(q)}</option>)}
        </select>
        <select value={fProj} onChange={e=>setFProj(e.target.value)} style={selEl}>
          <option value="">كل المشاريع</option>
          {data.projects.map(p=><option key={p.id} value={p.id}>{(p.projectNo?p.projectNo+' — ':'')+p.name}</option>)}
        </select>
        <select value={fMonth} onChange={e=>setFMonth(e.target.value)} style={selEl}>
          <option value="">كل أشهر الربع</option>
          {monthOpts.map(mm=><option key={mm} value={mm}>{fmtMonth(mm)}</option>)}
        </select>
        <span style={{fontSize:12, color:'var(--ink-soft)'}}>من</span>
        <input type="date" value={fFrom} onChange={e=>setFFrom(e.target.value)} style={selEl} />
        <span style={{fontSize:12, color:'var(--ink-soft)'}}>إلى</span>
        <input type="date" value={fTo} onChange={e=>setFTo(e.target.value)} style={selEl} />
        <input value={q} onChange={e=>setQ(e.target.value)} placeholder="بحث في البيان / المورد" style={{...selEl, minWidth:170}} />
        {anyF && <button className="btn ghost small" onClick={resetF}>مسح الفلاتر</button>}
        <button className="btn outline" onClick={()=>window.print()}><I.print/> طباعة</button>
      </div>

      <div className="print-only" style={{display:'none'}}>
        <div className="doc-head" style={{marginBottom:16}}>
          <div className="doc-brand">
            <img src={NITAQ_LOGO} alt="نطاق" style={{height:56}} />
            <div><h1>نطاق للاستشارات الهندسية</h1><p>NITAQ ENGINEERING CONSULTANTS · TRN: {COMPANY.trn}</p></div>
          </div>
          <div className="doc-type"><div className="t">تقرير ضريبة القيمة المضافة</div><div className="n">{quarterLabel(qk)} · صادر {todayISO()}</div></div>
        </div>
        {anyF && <p style={{fontSize:12, margin:'0 0 12px'}}>نطاق التقرير: {[fProj?'مشروع: '+projName(fProj):'', fMonth?'شهر: '+fmtMonth(fMonth):'', (fFrom||fTo)?('الفترة: '+(fFrom||'البداية')+' ← '+(fTo||'النهاية')):'', q?('بحث: '+q):''].filter(Boolean).join(' · ')}</p>}
      </div>

      <div className="grid grid-4" style={{marginBottom:18}}>
        <div className="card">
          <div className="kpi-label">ضريبة المخرجات</div>
          <div className="kpi-value" style={{fontSize:19, color:'var(--teal)'}}>{money(outputVat)}</div>
          <div className="kpi-note">{outRows.length} دفعة خاضعة خلال الفترة</div>
        </div>
        <div className="card">
          <div className="kpi-label">ضريبة المدخلات</div>
          <div className="kpi-value" style={{fontSize:19, color:'var(--blue)'}}>{money(inputVat)}</div>
          <div className="kpi-note">{inRows.length} مصروف خاضع — بشرط فاتورة ضريبية سارية</div>
        </div>
        <div className="card">
          <div className="kpi-label">صافي الضريبة</div>
          <div className="kpi-value" style={{fontSize:19, color:net>=0?'var(--rust)':'var(--teal)'}}>{money(Math.abs(net))}</div>
          <div className="kpi-note">{net>=0 ? 'مستحقة للهيئة' : 'مستردة لصالح الشركة'}</div>
        </div>
        <div className="card">
          <div className="kpi-label">استحقاق الإقرار</div>
          <div className="kpi-value" style={{fontSize:19}}>{due}</div>
          <div className="kpi-note">
            {ended
              ? (dd!==null && dd<0 ? <span className="badge bad">تجاوز الاستحقاق بـ {Math.abs(dd)} يوم</span> : <span className={"badge "+(dd<=15?'soon':'ok')}>متبقي {dd} يوم للتقديم</span>)
              : <span className="badge gray">الفترة لم تنتهِ بعد</span>}
          </div>
        </div>
      </div>

      {/* تفاصيل ضريبة المخرجات */}
      <div className="section-title"><h3 style={{fontSize:13.5}}>تفاصيل ضريبة المخرجات — من أين جاءت؟ (الدفعات الاستشارية الخاضعة)</h3><div className="rule"></div></div>
      <div className="card" style={{padding:0, marginBottom:22}}>
        <div style={{overflowX:'auto'}}>
        <table>
          <thead><tr><th>التاريخ</th><th>المشروع</th><th>البيان</th><th>المبلغ الصافي</th><th>الضريبة (5%)</th></tr></thead>
          <tbody>
            {outRows.length===0 && <tr className="empty-row"><td colSpan={5}>لا دفعات خاضعة في هذه الفترة</td></tr>}
            {outRows.map((r,i)=>(
              <tr key={i}><td>{r.date}</td><td>{r.proj}</td><td>{r.label}</td><td>{money(r.net)}</td><td style={{color:'var(--teal)', fontWeight:700}}>{money(r.vat)}</td></tr>
            ))}
          </tbody>
          {outRows.length>0 && <tfoot><tr style={{fontWeight:800, background:'rgba(19,42,70,.04)'}}><td colSpan={3}>إجمالي ضريبة المخرجات</td><td>{money(outRows.reduce((s,r)=>s+r.net,0))}</td><td style={{color:'var(--teal)'}}>{money(outputVat)}</td></tr></tfoot>}
        </table>
        </div>
      </div>

      {/* تفاصيل ضريبة المدخلات */}
      <div className="section-title"><h3 style={{fontSize:13.5}}>تفاصيل ضريبة المدخلات — القابلة للاسترداد (المصروفات الخاضعة بفاتورة ضريبية)</h3><div className="rule"></div></div>
      <div className="card" style={{padding:0, marginBottom:22}}>
        <div style={{overflowX:'auto'}}>
        <table>
          <thead><tr><th>التاريخ</th><th>النوع</th><th>التصنيف</th><th>المورد / البيان</th><th>المبلغ الصافي</th><th>الضريبة (5%)</th></tr></thead>
          <tbody>
            {inRows.length===0 && <tr className="empty-row"><td colSpan={6}>لا مصروفات خاضعة في هذه الفترة</td></tr>}
            {inRows.map((r,i)=>(
              <tr key={i}><td>{r.date}</td><td><span className="badge gray">{r.src}</span></td><td>{r.cat}</td><td style={{fontSize:12}}>{r.note||'—'}</td><td>{money(r.net)}</td><td style={{color:'var(--blue)', fontWeight:700}}>{money(r.vat)}</td></tr>
            ))}
          </tbody>
          {inRows.length>0 && <tfoot><tr style={{fontWeight:800, background:'rgba(19,42,70,.04)'}}><td colSpan={4}>إجمالي ضريبة المدخلات</td><td>{money(inRows.reduce((s,r)=>s+r.net,0))}</td><td style={{color:'var(--blue)'}}>{money(inputVat)}</td></tr></tfoot>}
        </table>
        </div>
      </div>

      {/* الصافي */}
      <div className="card" style={{background:net>=0?'var(--rust-soft)':'var(--teal-soft)', borderColor:net>=0?'var(--rust)':'var(--teal)', marginBottom:18}}>
        <div style={{display:'flex', justifyContent:'space-between', alignItems:'center', flexWrap:'wrap', gap:8}}>
          <div>
            <div className="kpi-label">صافي الضريبة المستحقة = المخرجات − المدخلات</div>
            <div style={{fontSize:12, color:'var(--ink-soft)'}}>{money(outputVat)} − {money(inputVat)}</div>
          </div>
          <div style={{fontSize:22, fontWeight:800, color:net>=0?'var(--rust)':'var(--teal)'}}>
            {money(Math.abs(net))} <span style={{fontSize:13, fontWeight:600}}>{net>=0?'مستحقة للهيئة':'مستردة لكم'}</span>
          </div>
        </div>
      </div>

      <p style={{fontSize:12, color:'var(--ink-faint)'}}>* الفترات الضريبية ربع سنوية وفق شهادة التسجيل الرسمية (TRN: {COMPANY.trn}) — تاريخ التسجيل الفعلي {COMPANY.vatRegDate}، وأول فترة إقرار {quarterLabel(quarterOfYM(COMPANY.vatRegDate.slice(0,7)))} مستحقة في {quarterDueDate(quarterOfYM(COMPANY.vatRegDate.slice(0,7)))}. الضريبة تُحسب على تاريخ إصدار الدفعة/المصروف (أساس الاستحقاق). ضريبة المدخلات لا تُسترد إلا بفاتورة ضريبية سارية باسم المكتب. الرسوم الحكومية (الأمانات) مستثناة بالكامل. يُنصح بمراجعة محاسب مختص قبل التقديم عبر بوابة الهيئة الاتحادية للضرائب.</p>
    </div>
  );
}

/* ================= Statement View (كشف حساب مشروع) ================= */
function StatementView({data, fixedPid}){
  const [pidState, setPid] = useState((data.projects[0]||{}).id || '');
  const [lang, setLang] = useState('ar');
  const [stType, setStType] = useState('full');      // full | gov | pays — نوع الكشف
  const [hideOwnerCol, setHideOwnerCol] = useState(false);  // إخفاء عمود "من المالك" للنسخة اللي تروح للمالك
  const [showSummary, setShowSummary] = useState(true);     // إظهار/إخفاء جزء الخلاصة
  const pid = fixedPid || pidState;
  const p = data.projects.find(x=>x.id===pid);

  if(!p) return (
    <div className="card"><p style={{fontSize:13, color:'var(--ink-faint)', margin:0}}>أضف مشروعاً أولاً من قسم المشاريع والعقود لعرض كشف الحساب.</p></div>
  );

  const pays = data.payments.filter(i=>!isArchived(i) && i.projectId===pid).sort((a,b)=>(a.date||'').localeCompare(b.date||''));
  const fees = data.govFees.filter(g=>!isArchived(g) && g.projectId===pid).sort((a,b)=>(a.date||'').localeCompare(b.date||''));

  const stCons = (data.contracts||[]).filter(c=>c.projectId===pid && c.status!=='ملغى' && !isArchived(c) && (isConsultancy(c)));
  const contract = stCons.length>0
    ? stCons.reduce((s,c)=> s + contractTotalOf(c), 0)
    : (p.designFee||0) + (p.supervisionMonthly||0)*(p.supervisionMonths||0);
  const billed = pays.reduce((s,i)=>s+billedOf(i),0);
  const collected = pays.reduce((s,i)=>s+collectedOf(i)*grossFactor(i),0);
  const duePays = pays.reduce((s,i)=>s+remainderOf(i)*grossFactor(i),0);
  const billedVat = pays.reduce((s,i)=>s+billedVatOf(i),0);
  const feesTotal = fees.reduce((s,g)=>s+(isArchived(g)?0:g.amount),0);
  const feesOutstanding = fees.filter(g=>!isArchived(g) && g.payerType!=='المالك مباشرة' && g.paidStatus==='مدفوع' && g.reimburseStatus!=='مسترد').reduce((s,g)=>s+(isArchived(g)?0:g.amount),0);
  const totalDue = duePays + feesOutstanding;
  // المتبقّي من قيمة العقد = قيمة العقد شاملة الضريبة − المحصّل فعلاً (العقود الاستشارية خاضعة للضريبة)
  const contractGross = contract * 1.05;
  const contractRemaining = Math.max(0, contractGross - collected);
  const ownerBalance = contractRemaining + feesOutstanding;   // الصندوق الأخير

  const isEn = lang==='en';
  const payLabel = (i)=> i.phase==='إشراف'
    ? ((isEn?'Supervision Fee — ':'أتعاب إشراف — ')+(i.month?(isEn?fmtMonthEn(i.month):fmtMonth(i.month)):''))
    : (i.label||'');
  const ST = { // ترجمة نصوص الحالة الثابتة فقط — النصوص الحرة (وصف الدفعة، ملاحظات الرسوم) تبقى كما أُدخلت
    'مدفوعة':'Paid', 'مدفوعة جزئياً':'Partially Paid', 'معلقة':'Pending', 'متأخرة':'Overdue',
    'مدفوع':'Paid', 'غير مدفوع':'Unpaid',
    'مسترد':'Reimbursed', 'غير مسترد':'Not Reimbursed',
    'المكتب':'Office', 'المالك مباشرة':'Owner (Direct)', 'لا ينطبق':'N/A',
    'ملك':'Freehold', 'منحة':'Grant', 'معفاة':'Exempt',
    // ترجمة الدوائر الحكومية الشائعة
    'دائرة التخطيط والمساحة':'Planning & Survey Dept.',
    'بلدية الشارقة':'Sharjah Municipality',
    'الدفاع المدني':'Civil Defence',
    'هيئة كهرباء ومياه الشارقة':'SEWA',
    'سيوا':'SEWA',
    'دائرة الأشغال العامة':'Public Works Dept.',
    'هيئة الكهرباء والمياه':'Electricity & Water Authority',
    'المرور':'Traffic Dept.',
    'الأراضي والأملاك':'Land & Properties Dept.',
    'أخرى':'Other',
  };
  const tr = (s)=> isEn ? (ST[s]||s) : s;
  const T = isEn ? {
    title:'Project Statement of Account', print:'Print Statement', docType:'Statement of Account', issuedOn:'Issued on',
    projectNo:'Project No.', projectName:'Project Name', owner:'Owner', landType:'Land Type', govNo:'Government Plot No.',
    ownNo:'Ownership No. (Freehold)', startDate:'Project Start Date', contractValue:'Contract Value',
    sec1:'1 — Consultancy Payments', thDate:'Issue Date', thDesc:'Description', thNet:'Before VAT', thVat:'VAT 5%',
    thTotal:'Total', thPaidDate:'Receipt Date', thStatus:'Status', noPays:'No payments recorded', total:'Total',
    sec2:'2 — Government Fees',
    thDate2:'Date', thDept:'Department', thDetail:'Details', thAmount:'Amount', thReceipt:'Receipt No.', thPaidBy:'Paid By',
    thDeptStatus:'Dept. Settlement', thOwnerStatus:'Owner Reimbursement', noFees:'No government fees recorded',
    summary:'Summary', totalCollected:'Total Collected (VAT incl.)', duePaysL:'Outstanding Consultancy Payments (VAT incl.)',
    feesOutL:'Government Fees Paid on Owner\'s Behalf, Not Yet Reimbursed', totalDueL:'Remaining Contract Balance (VAT incl.)',
    contractGrossL:'Total Contract Value (VAT incl.)', contractRemL:'Remaining from Contract Value',
    signOffice:'For '+COMPANY.nameEn, signOwner:'Reviewed — Owner',
    footNote:'This statement reflects records as of its issue date and does not constitute a discharge of liability',
  } : {
    title:'كشف حساب مشروع', print:'طباعة الكشف', docType:'كشف حساب', issuedOn:'صادر بتاريخ',
    projectNo:'رقم المشروع', projectName:'اسم المشروع', owner:'المالك', landType:'نوع الأرض', govNo:'الرقم الحكومي',
    ownNo:'رقم الأرض (ملك)', startDate:'تاريخ فتح المشروع', contractValue:'قيمة العقد',
    sec1:'أولاً — الدفعات الاستشارية', thDate:'تاريخ الإصدار', thDesc:'البيان', thNet:'قبل الضريبة', thVat:'ض.ق.م 5%',
    thTotal:'الإجمالي', thPaidDate:'تاريخ الاستلام', thStatus:'الحالة', noPays:'لا توجد دفعات مسجلة', total:'الإجمالي',
    sec2:'ثانياً — الرسوم الحكومية',
    thDate2:'التاريخ', thDept:'الدائرة', thDetail:'التفصيل', thAmount:'المبلغ', thReceipt:'الإيصال', thPaidBy:'السداد',
    thDeptStatus:'للدائرة', thOwnerStatus:'من المالك', noFees:'لا توجد رسوم حكومية مسجلة',
    summary:'الخلاصة', totalCollected:'إجمالي المحصّل (شامل الضريبة)', duePaysL:'دفعات استشارية مستحقة غير مسددة (شاملة الضريبة)',
    feesOutL:'رسوم حكومية مدفوعة نيابة عن المالك ولم تُسترد', totalDueL:'المتبقّي من قيمة العقد (شامل الضريبة)',
    contractGrossL:'إجمالي قيمة العقد (شامل الضريبة)', contractRemL:'المتبقّي من قيمة العقد',
    signOffice:'عن نطاق للاستشارات الهندسية', signOwner:'اطّلع عليه — المالك',
    footNote:'هذا الكشف يعكس السجلات حتى تاريخ إصداره ولا يُعد إبراء ذمة',
  };

  return (
    <div>
      <div className="toolbar no-print">
        <div className="section-title" style={{marginBottom:0, flex:1}}><h3>{T.title}</h3><div className="rule"></div></div>
        {!fixedPid && (
          <select value={pid} onChange={e=>setPid(e.target.value)}
            style={{border:'1px solid var(--line-strong)', borderRadius:4, padding:'7px 10px', fontSize:12.5, background:'#fff'}}>
            {data.projects.map(pr=><option key={pr.id} value={pr.id}>{(pr.projectNo?pr.projectNo+' — ':'')+pr.name}</option>)}
          </select>
        )}
        <div style={{display:'flex', border:'1px solid var(--line-strong)', borderRadius:4, overflow:'hidden'}}>
          {[['full', isEn?'Full':'عام'],['gov', isEn?'Gov. Fees':'دوائر حكومية'],['pays', isEn?'Payments':'دفعات المشروع']].map(([v,l])=>(
            <button key={v} onClick={()=>setStType(v)} style={{padding:'7px 12px', fontSize:12, border:'none', borderInlineStart: v!=='full'?'1px solid var(--line-strong)':'none', cursor:'pointer', background: stType===v?'var(--brass)':'#fff', color: stType===v?'#fff':'var(--ink)'}}>{l}</button>
          ))}
        </div>
        {stType!=='pays' && (
          <label style={{display:'flex', alignItems:'center', gap:6, fontSize:12, color:'var(--ink-soft)', cursor:'pointer', border:'1px solid var(--line-strong)', borderRadius:4, padding:'6px 10px', background:'#fff'}}>
            <input type="checkbox" checked={hideOwnerCol} onChange={e=>setHideOwnerCol(e.target.checked)} />
            {isEn?'Hide "Owner Reimbursement"':'إخفاء عمود «من المالك»'}
          </label>
        )}
        <label style={{display:'flex', alignItems:'center', gap:6, fontSize:12, color:'var(--ink-soft)', cursor:'pointer', border:'1px solid var(--line-strong)', borderRadius:4, padding:'6px 10px', background:'#fff'}}>
          <input type="checkbox" checked={showSummary} onChange={e=>setShowSummary(e.target.checked)} />
          {isEn?'Show Summary':'إظهار الخلاصة'}
        </label>
        <div style={{display:'flex', border:'1px solid var(--line-strong)', borderRadius:4, overflow:'hidden'}}>
          <button onClick={()=>setLang('ar')} style={{padding:'7px 14px', fontSize:12.5, border:'none', cursor:'pointer', background: lang==='ar'?'var(--ink)':'#fff', color: lang==='ar'?'#fff':'var(--ink)'}}>عربي</button>
          <button onClick={()=>setLang('en')} style={{padding:'7px 14px', fontSize:12.5, border:'none', cursor:'pointer', background: lang==='en'?'var(--ink)':'#fff', color: lang==='en'?'#fff':'var(--ink)'}}>English</button>
        </div>
        <button className="btn brass" onClick={()=>window.print()}><I.print/> {T.print}</button>
      </div>

      <div className="doc" dir={isEn?'ltr':'rtl'} style={isEn?{textAlign:'left'}:undefined}>
        <div className="doc-head">
          <div className="doc-brand">
            <img src={NITAQ_LOGO} alt="نطاق" style={{height:64}} />
            <div>
              <h1>{isEn ? COMPANY.nameEn : COMPANY.nameAr}</h1>
              <p>{isEn ? COMPANY.nameAr : (COMPANY.nameEn+' · رخصة رقم '+COMPANY.license)}</p>
              <p>{isEn?'TRN: ':'الرقم الضريبي TRN: '}{COMPANY.trn}</p>
            </div>
          </div>
          <div className="doc-type">
            <div className="t">{T.docType}</div>
            {stType==='gov' && <div className="n" style={{fontWeight:700}}>{isEn?'Government Fees Only':'الرسوم الحكومية فقط'}</div>}
            {stType==='pays' && <div className="n" style={{fontWeight:700}}>{isEn?'Consultancy Payments Only':'الدفعات الاستشارية فقط'}</div>}
            <div className="n">{T.issuedOn}: {todayISO()}</div>
          </div>
        </div>
        <div className="doc-body">
          <div className="doc-info-grid">
            <div className="doc-line"><span className="lbl">{T.projectNo}</span><span className="val">{p.projectNo||'—'}</span></div>
            <div className="doc-line"><span className="lbl">{T.projectName}</span><span className="val">{p.name}</span></div>
            <div className="doc-line"><span className="lbl">{T.owner}</span><span className="val">{ownersLine(p)||'—'}</span></div>
            <div className="doc-line"><span className="lbl">{T.landType}</span><span className="val">{tr(p.landType)||'—'}</span></div>
            <div className="doc-line"><span className="lbl">{T.govNo}</span><span className="val">{p.plotNumber||'—'}</span></div>
            {p.landType==='ملك' && <div className="doc-line"><span className="lbl">{T.ownNo}</span><span className="val">{p.ownershipNumber||'—'}</span></div>}
            <div className="doc-line"><span className="lbl">{T.startDate}</span><span className="val">{p.startDate||'—'}</span></div>
            <div className="doc-line"><span className="lbl">{T.contractValue}</span><span className="val">{money(contract)}</span></div>
          </div>

          {stType!=='gov' && <>
          <h4 className="sec">{stType==='pays' ? (isEn?'Consultancy Payments':'الدفعات الاستشارية') : T.sec1}</h4>
          <table>
            <thead><tr><th>{T.thDate}</th><th>{T.thDesc}</th><th>{T.thNet}</th><th>{T.thVat}</th><th>{T.thTotal}</th><th>{T.thPaidDate}</th><th>{T.thStatus}</th></tr></thead>
            <tbody>
              {pays.length===0 && <tr className="empty-row"><td colSpan={7}>{T.noPays}</td></tr>}
              {pays.map(i=>(
                <tr key={i.id}>
                  <td style={{whiteSpace:'nowrap'}}>{i.date}</td>
                  <td>{payLabel(i)}</td>
                  <td>{money(i.amount)}</td>
                  <td>{vatRateOf(i)===0 ? tr('معفاة') : money(i.amount*0.05)}</td>
                  <td><b>{money(i.amount*grossFactor(i))}</b></td>
                  <td>{(i.status==='مدفوعة'||i.status==='مدفوعة جزئياً') ? (i.paidDate||i.date) : '—'}</td>
                  <td><span className={"badge "+(i.status==='مدفوعة'?'ok':i.status==='مدفوعة جزئياً'?'neutral':i.status==='متأخرة'?'bad':'soon')}>{tr(i.status)}</span></td>
                </tr>
              ))}
              {pays.length>0 && (
                <tr style={{fontWeight:800, background:'rgba(19,42,70,.03)'}}>
                  <td colSpan={2}>{T.total}</td>
                  <td>{money(billed)}</td>
                  <td>{money(billedVat)}</td>
                  <td>{money(billed+billedVat)}</td>
                  <td colSpan={2}></td>
                </tr>
              )}
            </tbody>
          </table>
          </>}

          {stType!=='pays' && <>
          <h4 className="sec">{stType==='gov' ? (isEn?'Government Fees':'الرسوم الحكومية') : T.sec2}{/* العام: ثانياً — الرسوم الحكومية ، الحكومي فقط: الرسوم الحكومية */}</h4>
          <table>
            <colgroup>{hideOwnerCol
              ? <><col style={{width:'10%'}}/><col style={{width:'16%'}}/><col style={{width:'31%'}}/><col style={{width:'11%'}}/><col style={{width:'9%'}}/><col style={{width:'11%'}}/><col style={{width:'12%'}}/></>
              : <><col style={{width:'9%'}}/><col style={{width:'14%'}}/><col style={{width:'26%'}}/><col style={{width:'10%'}}/><col style={{width:'8%'}}/><col style={{width:'10%'}}/><col style={{width:'11%'}}/><col style={{width:'12%'}}/></>}
            </colgroup>
            <thead><tr><th>{T.thDate2}</th><th>{T.thDept}</th><th>{T.thDetail}</th><th>{T.thAmount}</th><th>{T.thReceipt}</th><th>{T.thPaidBy}</th><th>{T.thDeptStatus}</th>{!hideOwnerCol && <th>{T.thOwnerStatus}</th>}</tr></thead>
            <tbody>
              {fees.length===0 && <tr className="empty-row"><td colSpan={hideOwnerCol?7:8}>{T.noFees}</td></tr>}
              {fees.map(g=>(
                <tr key={g.id}>
                  <td style={{whiteSpace:'nowrap'}}>{g.date}</td>
                  <td>{tr(g.department)}</td>
                  <td>{isEn ? (g.descriptionEn || g.description) : g.description}</td>
                  <td>{money(g.amount)}</td>
                  <td>{g.receiptNo||'—'}</td>
                  <td>{tr(g.payerType==='المالك مباشرة' ? 'المالك مباشرة' : 'المكتب')}</td>
                  <td><span className={"badge "+(g.paidStatus==='مدفوع'?'ok':'soon')}>{tr(g.paidStatus)}</span></td>
                  {!hideOwnerCol && <td>{g.payerType==='المالك مباشرة' ? <span className="badge gray">{tr('لا ينطبق')}</span> : <span className={"badge "+(g.reimburseStatus==='مسترد'?'ok':'bad')}>{tr(g.reimburseStatus)}</span>}</td>}
                </tr>
              ))}
              {fees.length>0 && (
                <tr style={{fontWeight:800, background:'rgba(19,42,70,.03)'}}>
                  <td colSpan={3}>{T.total}</td><td>{money(feesTotal)}</td><td colSpan={hideOwnerCol?3:4}></td>
                </tr>
              )}
            </tbody>
          </table>
          </>}

          {showSummary && <>
          <h4 className="sec">{T.summary}</h4>
          <table>
            <tbody>
              {stType!=='gov' && <>
                <tr><td>{T.contractGrossL}</td><td style={{textAlign: isEn?'right':'left'}}>{money(contractGross)}</td></tr>
                <tr><td>{T.totalCollected}</td><td style={{textAlign: isEn?'right':'left'}}>−{money(collected)}</td></tr>
                <tr style={{fontWeight:700}}><td>{T.contractRemL}</td><td style={{textAlign: isEn?'right':'left'}}>{money(contractRemaining)}</td></tr>
                <tr><td>{T.duePaysL}</td><td style={{textAlign: isEn?'right':'left'}}>{money(duePays)}</td></tr>
              </>}
              {stType!=='pays' && <tr><td>{T.feesOutL}</td><td style={{textAlign: isEn?'right':'left'}}>{money(feesOutstanding)}</td></tr>}
            </tbody>
          </table>
          {(()=>{
            // الصندوق الأخير يتكيّف مع نوع الكشف
            const boxVal = stType==='gov' ? feesOutstanding : (stType==='pays' ? contractRemaining : ownerBalance);
            const boxLbl = stType==='gov' ? T.feesOutL : (stType==='pays' ? T.contractRemL : T.totalDueL);
            return (
              <div className={"due-box"+(boxVal<=0?' ok':'')}>
                <span>{boxLbl}</span>
                <span>{money(boxVal)}{(!isEn && boxVal>0) ? ' — فقط '+tafqeet(boxVal) : ''}</span>
              </div>
            );
          })()}
          </>}
          <div className="doc-sign">
            <div>{T.signOffice}</div>
            <div>{T.signOwner}</div>
          </div>
        </div>
        <div className="doc-foot">
          <span>SHARJAH · UAE | {COMPANY.phone2} | {COMPANY.phone} | {COMPANY.email}</span>
          <span>{COMPANY.tagline} · {T.footNote}</span>
        </div>
      </div>
    </div>
  );
}

/* ================= WhatsApp Intelligence: تحليل محادثات المشروع ================= */
function parseWhatsAppTxt(txt){
  const lines = txt.split(/\r?\n/);
  const msgs = [];
  const re1 = /^\[?(\d{1,2})[\/.](\d{1,2})[\/.](\d{2,4})[,\s]+(\d{1,2}:\d{2})(?::\d{2})?\s*(?:[صمAPMapm.\u200f\u200e ]*)\]?\s*[-–]?\s*([^:]+?):\s*(.*)$/;
  lines.forEach(line=>{
    const m = re1.exec(line);
    if(m){
      let [_, d, mo, y, time, sender, text] = m;
      if(y.length===2) y = '20'+y;
      const date = y+'-'+String(mo).padStart(2,'0')+'-'+String(d).padStart(2,'0');
      msgs.push({date, sender:sender.trim(), text:(text||'').trim()});
    } else if(msgs.length && line.trim()){
      msgs[msgs.length-1].text += ' '+line.trim();
    }
  });
  return msgs;
}

const WA_NOISE = /^(صباح|مساء|شكرا|شكرًا|مشكور|تمام|اوك|أوك|ok|okay|تسلم|الله يعطيك|السلام عليكم|وعليكم السلام|هلا|أهلا|اهلا|👍|✅|هههه|جزاك)/i;
const WA_MEDIA = /(<Media omitted>|تم حذف هذه الرسالة|الوسائط|image omitted|video omitted|sticker omitted|null)/i;
const WA_RULES = [
  {re:/(اعتمد|تمت الموافقة|موافق|وافق المالك|approved|اعتماد نهائي)/i, cat:'اعتماد المالك'},
  {re:/(أمر تغيير|اعمال اضافية|أعمال إضافية|زيادة في|variation|بدل .* إلى|استبدال)/i, cat:'أمر تغيير (Variation)'},
  {re:/(تعديل|عدلوا|غيروا|نغير|revision|ريفيجن|تحديث المخطط)/i, cat:'تعديل تصميمي'},
  {re:/(اجتماع|موعد|زيارة الموقع|نلتقي|meeting|inspection|فحص يوم|معاينة)/i, cat:'اجتماع / موعد'},
  {re:/(البلدية|بلدية|دفاع مدني|سيوا|تخطيط ومساحة|الدائرة|رد الجهة|ملاحظات الجهة|إجازة البناء|رخصة)/i, cat:'ملاحظة دائرة حكومية'},
  {re:/(دفعة|فاتورة|تحويل|شيك|سداد|حوّل|المبلغ|payment|invoice|مستحق)/i, cat:'مالية'},
  {re:/(مشكلة|توقف|تأخير|تأخر|خطر|عيب|ملاحظة موقع|delay|issue|متوقف)/i, cat:'ملاحظة موقع / مخاطرة'},
  {re:/(مطلوب|برجاء|يرجى|لازم|قبل يوم|deadline|آخر موعد|أنجزوا|جهزوا)/i, cat:'مهمة'},
];
function heuristicExtract(msgs){
  const out = [];
  const seen = new Set();
  msgs.forEach(m=>{
    const t = m.text;
    if(!t || t.length<15) return;
    if(WA_NOISE.test(t) || WA_MEDIA.test(t)) return;
    for(const rule of WA_RULES){
      if(rule.re.test(t)){
        const key = (t.slice(0,60)).replace(/\s+/g,' ');
        if(seen.has(key)) return;
        seen.add(key);
        out.push({date:m.date, category:rule.cat, description:t.slice(0,300), responsible:m.sender});
        return;
      }
    }
  });
  return out;
}

async function aiExtractDecisions(msgs){
  const text = msgs.map(m=>m.date+' | '+m.sender+': '+m.text).join('\n').slice(-14000);
  const prompt = 'أنت محلل مشاريع هندسية. أمامك تصدير محادثة واتساب لمشروع. استخرج فقط القرارات والوقائع المهمة إدارياً (اعتمادات المالك، تعديلات تصميمية، أوامر تغيير، مهام، مواعيد اجتماعات ومعاينات، ملاحظات الدوائر الحكومية، نقاشات مالية، مخاطر). تجاهل التحيات والمجاملات والتكرار. أعد JSON فقط بدون أي نص آخر، مصفوفة عناصرها: {"date":"YYYY-MM-DD","category":"واحدة من: اعتماد المالك | تعديل تصميمي | أمر تغيير (Variation) | مهمة | اجتماع / موعد | ملاحظة دائرة حكومية | ملاحظة موقع / مخاطرة | مالية | أخرى","description":"ملخص موجز بالعربية","responsible":"اسم المرسل"}. الحد الأقصى 25 عنصراً.\n\nالمحادثة:\n'+text;
  const res = await fetch('https://api.anthropic.com/v1/messages', {
    method:'POST', headers:{'Content-Type':'application/json'},
    body: JSON.stringify({model:'claude-sonnet-4-6', max_tokens:1000, messages:[{role:'user', content:prompt}]})
  });
  if(!res.ok) throw new Error('AI unavailable');
  const d = await res.json();
  const raw = (d.content||[]).filter(c=>c.type==='text').map(c=>c.text).join('').replace(/```json|```/g,'').trim();
  const arr = JSON.parse(raw);
  if(!Array.isArray(arr)) throw new Error('bad format');
  return arr.filter(x=>x && x.description).map(x=>({
    date: x.date || todayISO(),
    category: DECISION_CATEGORIES.includes(x.category) ? x.category : 'أخرى',
    description: String(x.description).slice(0,300),
    responsible: x.responsible || '',
  }));
}

function WaImport({project, data, onApprove, onClose}){
  const [stage, setStage] = useState('pick'); // pick | working | review
  const [engine, setEngine] = useState('');
  const [items, setItems] = useState([]);
  const [decided, setDecided] = useState({}); // idx -> 'ok'|'no'
  const fileRef = useRef(null);

  const handleFile = async (e)=>{
    const f = e.target.files && e.target.files[0];
    if(!f) return;
    setStage('working');
    const txt = await f.text();
    const msgs = parseWhatsAppTxt(txt);
    if(msgs.length===0){ alert('لم يتم التعرف على صيغة الملف — تأكد أنه تصدير محادثة واتساب نصي (بدون وسائط)'); setStage('pick'); return; }
    let extracted = null;
    try{
      extracted = await aiExtractDecisions(msgs);
      setEngine('الذكاء الاصطناعي (Claude)');
    }catch(err){
      extracted = heuristicExtract(msgs);
      setEngine('المحرك الذكي المحلي (كلمات مفتاحية)');
    }
    if(!extracted || extracted.length===0){ alert('لم يُعثر على قرارات مهمة في المحادثة'); setStage('pick'); return; }
    setItems(extracted);
    setStage('review');
  };

  const decide = (idx, val)=>{
    setDecided(d=>({...d,[idx]:val}));
    if(val==='ok'){
      const it = items[idx];
      onApprove({id:uid(), projectId:project.id, date:it.date, category:it.category, description:it.description,
        responsible:it.responsible, status: it.category==='مهمة' ? 'مفتوح' : 'منفذ', source:'واتساب', _ts:Date.now()});
    }
  };
  const remaining = items.filter((_,i)=>!decided[i]).length;
  const approvedCount = Object.values(decided).filter(v=>v==='ok').length;

  return (
    <div className="overlay" onMouseDown={(e)=>{ if(e.target===e.currentTarget) onClose(); }}>
      <div className="modal" style={{maxWidth:680}}>
        <div className="modal-head">
          <h3>استيراد محادثة واتساب — مشروع {project.projectNo}</h3>
          <button className="close-x" onClick={onClose}>✕</button>
        </div>
        <div className="modal-body" style={{maxHeight:'62vh', overflowY:'auto'}}>
          {stage==='pick' && (
            <div style={{textAlign:'center', padding:'18px 0'}}>
              <p style={{fontSize:13, color:'var(--ink-soft)', marginBottom:6}}>من جروب المشروع في واتساب: <b>⋮ ← المزيد ← تصدير الدردشة ← بدون وسائط</b></p>
              <p style={{fontSize:12, color:'var(--ink-faint)', marginBottom:16}}>ثم ارفع ملف الـ TXT هنا. النظام سيستخرج القرارات المهمة فقط ويعرضها عليك — <b>لن يُضاف شيء للسجل إلا بموافقتك</b>.</p>
              <button className="btn brass" onClick={()=>fileRef.current && fileRef.current.click()}>اختيار ملف المحادثة (.txt)</button>
              <input ref={fileRef} type="file" accept=".txt,text/plain" style={{display:'none'}} onChange={handleFile} />
            </div>
          )}
          {stage==='working' && <p style={{textAlign:'center', padding:'30px 0', fontSize:13.5}}>جارٍ تحليل المحادثة واستخراج القرارات...</p>}
          {stage==='review' && (
            <div>
              <p style={{fontSize:12, color:'var(--ink-faint)', marginBottom:12}}>المحرك: {engine} · {items.length} قرار مقترح · اعتمدت {approvedCount} · متبقٍ {remaining}</p>
              {items.map((it, idx)=>(
                <div key={idx} style={{border:'1px solid var(--line)', borderRadius:5, padding:'10px 14px', marginBottom:10,
                  opacity: decided[idx]==='no' ? .35 : 1,
                  background: decided[idx]==='ok' ? 'var(--teal-soft)' : '#fff',
                  borderColor: decided[idx]==='ok' ? 'var(--teal)' : 'var(--line)'}}>
                  <div style={{display:'flex', gap:8, alignItems:'center', marginBottom:6, flexWrap:'wrap'}}>
                    <span className="badge gray">{it.date}</span>
                    <span className="badge neutral">{it.category}</span>
                    {it.responsible && <span style={{fontSize:11, color:'var(--ink-faint)'}}>{it.responsible}</span>}
                    <span style={{marginInlineStart:'auto', display:'flex', gap:6}}>
                      {!decided[idx] && (
                        <React.Fragment>
                          <button className="btn small brass" onClick={()=>decide(idx,'ok')}>✓ اعتماد وإضافة</button>
                          <button className="btn small outline" onClick={()=>decide(idx,'no')}>✕ تجاهل</button>
                        </React.Fragment>
                      )}
                      {decided[idx]==='ok' && <span className="badge ok">أُضيف للسجل</span>}
                      {decided[idx]==='no' && <span className="badge gray">مُتجاهَل</span>}
                    </span>
                  </div>
                  <div style={{fontSize:13}}>{it.description}</div>
                </div>
              ))}
            </div>
          )}
        </div>
        <div className="modal-foot">
          <span style={{fontSize:11.5, color:'var(--ink-faint)', marginInlineEnd:'auto'}}>الصور تبقى في واتساب أو مجلد المشروع — النظام يسجل القرار فقط</span>
          <button className="btn brass" onClick={onClose}>{stage==='review' ? 'إنهاء ('+approvedCount+' أُضيف)' : 'إغلاق'}</button>
        </div>
      </div>
    </div>
  );
}

/* ================= تسوية فسخ العقد (محاسبياً + ضريبياً) ================= */
function TerminationModal({project, data, mutate, onClose}){
  const [cnData, setCnData] = useState(null);   // بيانات إشعار الدائن للعرض بعد التسوية
  const pays = data.payments.filter(i=>i.projectId===project.id && !isArchived(i));
  // المحصّل فعلاً (صافي قبل الضريبة + شامل)
  const collectedNet = pays.reduce((s,i)=>s+collectedOf(i),0);
  const collectedGross = pays.reduce((s,i)=>s+collectedOf(i)*grossFactor(i),0);
  // قيمة العقد الأصلية (صافي)
  const stCons = (data.contracts||[]).filter(c=>c.projectId===project.id && c.status!=='ملغى' && !isArchived(c) && isConsultancy(c));
  const contractNet = stCons.length>0 ? stCons.reduce((s,c)=>s+contractTotalOf(c),0) : ((project.designFee||0)+(project.supervisionMonthly||0)*(project.supervisionMonths||0));
  // الدفعات غير المحصّلة (هتتلغى بالفسخ)
  const openPays = pays.filter(i=>remainderOf(i)>0);
  const openTotal = openPays.reduce((s,i)=>s+remainderOf(i)*grossFactor(i),0);

  const [earnedNet, setEarnedNet] = useState('');     // قيمة الشغل المُنجز فعلاً (صافي قبل الضريبة)
  const [reason, setReason] = useState('');
  const [refundAccount, setRefundAccount] = useState('البنك');

  const earned = parseFloat(earnedNet);
  const hasEarned = earnedNet!=='' && Number.isFinite(earned) && earned>=0;
  const diffNet = hasEarned ? (collectedNet - earned) : 0;   // موجب = حصّلنا زيادة (يُرد) ، سالب = حصّلنا أقل (مستحق باقٍ)
  const refundNet = Math.max(0, diffNet);
  const refundVat = refundNet*0.05;
  const refundGross = refundNet + refundVat;
  const stillDueNet = Math.max(0, -diffNet);
  const stillDueGross = stillDueNet*1.05;

  const canApply = hasEarned && reason.trim().length>=3 && earned<=contractNet+0.5;

  const apply = ()=>{
    if(!canApply){ alert('أكملي قيمة الشغل المُنجز (لا تتجاوز قيمة العقد) وسبب الفسخ.'); return; }
    const mp = mutate('payments');
    // 1) الدفعات غير المحصّلة بالكامل (معلقة/متأخرة) تُلغى بالكامل — سقطت بالفسخ.
    //    الدفعات الجزئية تبقى كما هي (المحصّل منها محسوب، والباقي يُعدّ ساقطاً ضمنياً لأنه لن يُطالَب به).
    openPays.filter(i=>i.status!=='مدفوعة جزئياً').forEach(i=>{
      mp.update(i.id, {status:'ملغاة', cancelReason:'سقطت بفسخ العقد — '+reason.trim()});
    });
    // 2) لو فيه مبلغ يُرد للمالك: حركة خزينة صادرة + إشعار دائن
    if(refundGross>0.5){
      mutate('treasury').add({id:uid(), _ts:Date.now(), type:'صرف', account:refundAccount, amount:refundGross, date:todayISO(),
        note:'إرجاع للمالك عند فسخ عقد المشروع '+(project.projectNo||'')+' — '+project.name+' (شامل ض.ق.م المستردة)'});
    }
    // 3) إقفال المشروع كـ"مفسوخ" مع بيانات التسوية الكاملة
    mutate('projects').update(project.id, {
      status:'مفسوخ', closedAt:todayISO(), terminationReason:reason.trim(),
      termination:{ date:todayISO(), contractNet, collectedNet, earnedNet:earned, refundNet, refundVat, refundGross, stillDueNet, reason:reason.trim() }
    });
    // 4) إشعار دائن لاسترداد الضريبة (لو فيه إرجاع) — يُعرض للطباعة
    if(refundGross>0.5){
      const cnNo = 'CN-'+(project.projectNo||'')+'-'+todayISO().replace(/-/g,'');
      // حفظ مرجع الإشعار على المشروع للتوثيق
      mutate('projects').update(project.id, {creditNote:{cnNo, refundNet, refundVat, refundGross, date:todayISO()}});
      setCnData({ project, refundNet, refundVat, refundGross, reason:reason.trim(), date:todayISO(), cnNo });
    } else {
      alert('تم فسخ العقد وتسويته وإقفال المشروع.');
      onClose();
    }
  };

  if(cnData) return <CreditNoteDoc cn={cnData} onClose={()=>{ setCnData(null); onClose(); }} />;

  const Row = ({label, val, color, bold})=>(
    <div style={{display:'flex', justifyContent:'space-between', padding:'7px 0', borderTop:'1px solid var(--line)', fontSize:12.5, fontWeight:bold?800:400, color:color||'var(--ink)'}}>
      <span>{label}</span><span>{money(val)}</span>
    </div>
  );

  return (
    <div className="overlay" onMouseDown={(e)=>{ if(e.target===e.currentTarget) onClose(); }}>
      <div className="modal" style={{maxWidth:640}}>
        <div className="modal-head">
          <h3>تسوية فسخ العقد — {project.projectNo} {project.name}</h3>
          <button className="close-x" onClick={onClose}>✕</button>
        </div>
        <div className="modal-body">
          <p style={{fontSize:12.5, color:'var(--ink-soft)', marginBottom:14}}>عند إنهاء المالك للعقد قبل اكتماله، نسوّي الحساب على أساس <b>قيمة الشغل المُنجز فعلاً</b>: الباقي غير المحصّل يسقط، وأي مبلغ محصّل زائد عن المنجز يُرد للمالك مع إشعار دائن لاسترداد الضريبة.</p>

          <div className="card" style={{marginBottom:14, background:'var(--paper)'}}>
            <Row label="قيمة العقد الأصلية (صافي)" val={contractNet} />
            <Row label="المحصّل فعلاً (صافي)" val={collectedNet} color="var(--teal)" />
            <Row label="دفعات غير محصّلة ستسقط بالفسخ (شامل الضريبة)" val={openTotal} color="var(--ink-soft)" />
          </div>

          <div className="field" style={{marginBottom:12}}>
            <label>قيمة الشغل المُنجز فعلاً حتى الفسخ (صافي قبل الضريبة) *</label>
            <input type="number" step="0.01" value={earnedNet} onChange={e=>setEarnedNet(e.target.value)}
              placeholder="مثال: قيمة مرحلة التصميم المكتملة" />
            <div style={{fontSize:11, color:'var(--ink-faint)', marginTop:4}}>قدّري نسبة الإنجاز × قيمة العقد، أو أدخلي قيمة المراحل المكتملة فعلاً. لا تتجاوز قيمة العقد.</div>
          </div>

          {hasEarned && (
            <div className="card" style={{marginBottom:14, borderInlineStart:'4px solid '+(refundGross>0.5?'var(--rust)':(stillDueGross>0.5?'var(--brass)':'var(--teal)'))}}>
              {refundGross>0.5 && <>
                <div style={{fontSize:13, fontWeight:800, color:'var(--rust)', marginBottom:6}}>↩ يُرد للمالك (حصّلتِ أكثر من المنجز)</div>
                <Row label="الفرق (صافي)" val={refundNet} />
                <Row label="ض.ق.م المستردة (5%)" val={refundVat} />
                <Row label="إجمالي المبلغ المُرد" val={refundGross} color="var(--rust)" bold />
                <div className="field" style={{marginTop:10}}>
                  <label>يُرد من حساب</label>
                  <select value={refundAccount} onChange={e=>setRefundAccount(e.target.value)}>
                    <option value="البنك">البنك</option>
                    <option value="الخزينة">الخزينة (نقدي)</option>
                  </select>
                </div>
                <div style={{fontSize:11, color:'var(--ink-faint)', marginTop:6}}>سيُسجَّل صرف من الخزينة + إشعار دائن (Credit Note) لاسترداد الضريبة من الهيئة.</div>
              </>}
              {stillDueGross>0.5 && <>
                <div style={{fontSize:13, fontWeight:800, color:'var(--brass)', marginBottom:6}}>⚠ مستحق باقٍ على المالك (المنجز أكثر من المحصّل)</div>
                <Row label="مستحق عن شغل منجز (صافي)" val={stillDueNet} />
                <Row label="شامل الضريبة" val={stillDueGross} color="var(--brass)" bold />
                <div style={{fontSize:11, color:'var(--ink-faint)', marginTop:6}}>هذا مبلغ حقيقي مستحق عن عمل تم تنفيذه — يبقى كدفعة مستحقة ولا يسقط. سجّلي تحصيله لاحقاً قبل إقفال نهائي، أو أقفلي مع إبقائه ديناً موثّقاً.</div>
              </>}
              {refundGross<=0.5 && stillDueGross<=0.5 && (
                <div style={{fontSize:13, fontWeight:700, color:'var(--teal)'}}>✓ الحساب متوازن — المحصّل يساوي قيمة المنجز. الباقي يسقط بالفسخ ولا توجد تسويات.</div>
              )}
            </div>
          )}

          <div className="field">
            <label>سبب فسخ العقد (يُحفظ للتوثيق والتدقيق) *</label>
            <textarea rows="2" value={reason} onChange={e=>setReason(e.target.value)}
              placeholder="مثال: أنهى المالك العقد في مرحلة التصميم قبل تنفيذ العمل الكامل" />
          </div>
        </div>
        <div className="modal-foot" style={{flexWrap:'wrap', gap:8}}>
          <button className="btn outline" onClick={onClose}>إلغاء</button>
          <button className="btn brass" disabled={!canApply} onClick={apply}
            style={!canApply?{opacity:.4, cursor:'not-allowed'}:{background:'var(--rust)', borderColor:'var(--rust)'}}>
            تسوية وفسخ العقد
          </button>
        </div>
      </div>
    </div>
  );
}

/* ================= قائمة تحقق إقفال المشروع ================= */
function ClosingChecklistModal({project, data, mutate, onClose}){
  const pays = data.payments.filter(i=>i.projectId===project.id);
  const outstanding = pays.reduce((s,i)=>s+remainderOf(i)*grossFactor(i),0);
  const contractors = (data.contracts||[]).filter(c=>c.projectId===project.id && (c.category==='مقاول رئيسي' || c.category==='مقاول باطن'));
  const commUninvoiced = contractors.reduce((s,c)=>{
    const cm = contractCommission(c);
    const inv = data.payments.filter(i=>i.contractId===c.id).reduce((x,i)=>x+billedOf(i),0);
    return s + Math.max(0, cm - inv);
  }, 0);
  const feesUnrecovered = data.govFees.filter(g=>g.projectId===project.id && !isArchived(g) && g.payerType!=='المالك مباشرة' && g.paidStatus==='مدفوع' && g.reimburseStatus!=='مسترد').reduce((s,g)=>s+(isArchived(g)?0:g.amount),0);
  const feesUnpaid = data.govFees.filter(g=>g.projectId===project.id && !isArchived(g) && g.payerType!=='المالك مباشرة' && g.paidStatus!=='مدفوع').reduce((s,g)=>s+(isArchived(g)?0:g.amount),0);
  const stages = project.timeline||{};
  const handoverDone = stages.handover && stages.handover.status==='مكتملة';
  const supervisionContract = (data.contracts||[]).find(c=>c.projectId===project.id && isConsultancy(c) && (c.type==='إشراف'||isComboContract(c)));
  const supDone = supervisionContract ? data.payments.filter(i=>i.contractId===supervisionContract.id && i.phase==='إشراف').length : 0;
  const supTotal = supervisionContract ? (supervisionContract.supervisionMonths||0) : 0;
  const supIncomplete = supervisionContract && supDone < supTotal;
  const openApprovals = APPROVAL_ITEMS.filter(name=>{
    const a = (project.approvals||{})[name];
    return a && a.submitDate && !a.done;
  });

  const items = [
    {ok: outstanding<1, label:'كل الدفعات محصّلة بالكامل', detail: outstanding<1 ? '✓ لا مستحقات' : 'يتبقى '+money(outstanding)+' غير محصّل', critical:true},
    {ok: commUninvoiced<1, label:'عمولات المقاولين مفوترة', detail: commUninvoiced<1 ? '✓ كل العمولات مفوترة أو لا توجد' : 'يتبقى '+money(commUninvoiced)+' عمولة غير مفوترة', critical:true},
    {ok: feesUnrecovered<1, label:'الأمانات الحكومية مستردة من المالك', detail: feesUnrecovered<1 ? '✓ لا أمانات معلقة' : 'يتبقى '+money(feesUnrecovered)+' لم تُسترد', critical:true},
    {ok: feesUnpaid<1, label:'كل رسوم الدوائر مسددة', detail: feesUnpaid<1 ? '✓ كل الرسوم مسددة' : 'يتبقى '+money(feesUnpaid)+' غير مسدد', critical:false},
    {ok: openApprovals.length===0, label:'لا اعتمادات معلقة عند الدوائر', detail: openApprovals.length===0 ? '✓ لا اعتمادات معلقة' : openApprovals.length+' اعتماد ما زال قيد المتابعة: '+openApprovals.join('، '), critical:false},
    {ok: !supIncomplete, label:'دفعات الإشراف مكتملة', detail: !supIncomplete ? '✓ لا يوجد إشراف ناقص' : 'أُصدر '+supDone+' من '+supTotal+' دفعة إشراف', critical:false},
    {ok: handoverDone, label:'مرحلة التسليم مكتملة في Timeline', detail: handoverDone ? '✓ مكتملة' : 'حدّث مرحلة التسليم في تبويب "نظرة عامة"', critical:false},
  ];
  const criticalOpen = items.filter(x=>x.critical && !x.ok).length;
  const totalOpen = items.filter(x=>!x.ok).length;
  const canClose = criticalOpen === 0;

  const close = ()=>{
    if(!canClose){ alert('لا يمكن الإقفال — يوجد '+criticalOpen+' بند مالي حرج مفتوح'); return; }
    if(totalOpen>0 && !confirm('يوجد '+totalOpen+' بند غير حرج مفتوح. إقفال المشروع رغم ذلك؟')) return;
    mutate('projects').update(project.id, {status:'منتهٍ', closedAt:todayISO()});
    alert('تم إقفال المشروع بنجاح');
    onClose();
  };

  // فسخ العقد: إنهاء المشروع لأن المالك أنهى العقد قبل اكتماله — الدفعات غير المحصّلة يجب أن تكون ملغاة أولاً
  // فسخ العقد: يفتح شاشة التسوية المحاسبية الكاملة
  const [showTerm, setShowTerm] = useState(false);

  return (
    <div className="overlay" onMouseDown={(e)=>{ if(e.target===e.currentTarget) onClose(); }}>
      <div className="modal" style={{maxWidth:640}}>
        <div className="modal-head">
          <h3>قائمة تحقق إقفال المشروع — {project.projectNo} {project.name}</h3>
          <button className="close-x" onClick={onClose}>✕</button>
        </div>
        <div className="modal-body">
          <p style={{fontSize:12.5, color:'var(--ink-soft)', marginBottom:16}}>راجع البنود التالية قبل تحويل المشروع إلى "منتهٍ" — البنود المالية الحرجة يجب إغلاقها.</p>
          {items.map((it,i)=>(
            <div key={i} style={{display:'flex', gap:12, padding:'10px 12px', borderInlineStart:'3px solid '+(it.ok?'var(--teal)':it.critical?'var(--rust)':'var(--brass)'), background:it.ok?'#F4FAF8':it.critical?'#FDF4F1':'#FEF9F0', marginBottom:8, borderRadius:4}}>
              <span style={{fontSize:16, flexShrink:0}}>{it.ok?'✓':it.critical?'✕':'!'}</span>
              <div style={{flex:1}}>
                <div style={{fontSize:13, fontWeight:700}}>{it.label} {it.critical && !it.ok && <span className="badge bad" style={{marginInlineStart:6, fontSize:9}}>حرج</span>}</div>
                <div style={{fontSize:11.5, color:'var(--ink-soft)', marginTop:2}}>{it.detail}</div>
              </div>
            </div>
          ))}
          <div style={{padding:12, background:'var(--paper)', borderRadius:4, marginTop:14, fontSize:12.5}}>
            <b>الحالة:</b> {canClose ? <span style={{color:'var(--teal)'}}>✓ جاهز للإقفال</span> : <span style={{color:'var(--rust)'}}>يوجد {criticalOpen} بند حرج مفتوح</span>}
          </div>
        </div>
        <div className="modal-foot" style={{flexWrap:'wrap', gap:8}}>
          <button className="btn outline" onClick={onClose}>إغلاق النافذة</button>
          <button className="btn outline" onClick={()=>setShowTerm(true)}
            style={{borderColor:'var(--rust)', color:'var(--rust)'}}
            title="أنهى المالك العقد قبل اكتماله — تسوية محاسبية وإقفال كـ مفسوخ">
            فسخ العقد وتسوية
          </button>
          <button className="btn brass" disabled={!canClose} onClick={close}
            style={!canClose?{opacity:.4, cursor:'not-allowed'}:{}}>
            إقفال المشروع نهائياً
          </button>
        </div>
      </div>
      {showTerm && <TerminationModal project={project} data={data} mutate={mutate} onClose={()=>{ setShowTerm(false); onClose(); }} />}
    </div>
  );
}

/* ================= جدول الدفعات + تسجيل التحصيل ================= */
function InstallmentScheduleModal({contract, data, mutate, onClose}){
  const total = contract.type==='إشراف' ? 0
    : isComboContract(contract) ? (contract.designValue||0) : (contract.value||0);
  const invoiced = (data.payments||[]).filter(i=>!isArchived(i) && i.status!=='ملغاة' && i.contractId===contract.id && i.phase==='تصميم').reduce((s,i)=>s+(i.amount||0),0);
  const remaining = Math.max(0, total - invoiced);
  const [rows, setRows] = useState([
    {pct:50, amount:Math.round(remaining*0.5), dueDate:todayISO(), label:'الدفعة الأولى — توقيع العقد 50%'},
    {pct:30, amount:Math.round(remaining*0.3), dueDate:todayISO(), label:'الدفعة الثانية — مخططات ابتدائية 30%'},
    {pct:20, amount:Math.round(remaining*0.2), dueDate:todayISO(), label:'الدفعة الثالثة — اعتماد نهائي 20%'},
  ]);
  const [mode, setMode] = useState('pct');
  const updateRow = (i, patch)=>{
    setRows(rs=> rs.map((r,idx)=>{
      if(idx!==i) return r;
      const nr = {...r, ...patch};
      if(patch.pct!==undefined && remaining>0) nr.amount = Math.round(remaining*(patch.pct||0)/100);
      if(patch.amount!==undefined && remaining>0) nr.pct = Math.round((patch.amount||0)/remaining*100);
      return nr;
    }));
  };
  const addRow = ()=> setRows(rs=>[...rs, {pct:0, amount:0, dueDate:todayISO(), label:'دفعة إضافية'}]);
  const delRow = (i)=> setRows(rs=> rs.filter((_,idx)=>idx!==i));
  const sumPct = rows.reduce((s,r)=>s+(r.pct||0),0);
  const sumAmt = rows.reduce((s,r)=>s+(r.amount||0),0);
  const generate = ()=>{
    if(rows.length===0){ alert('أضف دفعة واحدة على الأقل'); return; }
    if(!confirm('سيتم إنشاء '+rows.length+' دفعة معلقة بإجمالي '+money(sumAmt)+'. متابعة؟')) return;
    rows.forEach(r=>{
      mutate('payments').add({id:uid(), projectId:contract.projectId, contractId:contract.id,
        phase:'تصميم', label:r.label, amount:r.amount||0,
        date:todayISO(), dueDate:r.dueDate, status:'معلقة', _ts:Date.now()});
    });
    alert('تم إنشاء الجدول');
    onClose();
  };
  return (
    <div className="overlay" onMouseDown={(e)=>{ if(e.target===e.currentTarget) onClose(); }}>
      <div className="modal" style={{maxWidth:720}}>
        <div className="modal-head">
          <h3>جدول دفعات العقد — المتبقي {money(remaining)} من إجمالي {money(total)}</h3>
          <button className="close-x" onClick={onClose}>✕</button>
        </div>
        <div className="modal-body">
          {invoiced>0 && (
            <p style={{fontSize:11.5, color:'var(--ink-faint)', marginBottom:12}}>* مفوتر بالفعل من هذا العقد: {money(invoiced)} — الجدول أدناه للمتبقي فقط.</p>
          )}
          <div style={{display:'flex', gap:6, marginBottom:12}}>
            <button className={"btn small "+(mode==='pct'?'brass':'outline')} onClick={()=>setMode('pct')}>بالنسبة %</button>
            <button className={"btn small "+(mode==='amt'?'brass':'outline')} onClick={()=>setMode('amt')}>بالمبلغ</button>
            <span style={{marginInlineStart:'auto', fontSize:12, color:'var(--ink-faint)'}}>مجموع: {sumPct}% · {money(sumAmt)}</span>
          </div>
          <table>
            <thead><tr><th>#</th><th>{mode==='pct'?'النسبة %':'المبلغ'}</th><th>الوصف</th><th>تاريخ الاستحقاق</th><th></th></tr></thead>
            <tbody>
              {rows.map((r,i)=>(
                <tr key={i}>
                  <td>{i+1}</td>
                  <td>{mode==='pct'
                    ? <input type="number" value={r.pct||''} onChange={e=>updateRow(i,{pct:+e.target.value})} style={{width:70}} />
                    : <input type="number" value={r.amount||''} onChange={e=>updateRow(i,{amount:+e.target.value})} style={{width:110}} />}</td>
                  <td><input value={r.label} onChange={e=>updateRow(i,{label:e.target.value})} style={{width:'100%'}} /></td>
                  <td><input type="date" value={r.dueDate} onChange={e=>updateRow(i,{dueDate:e.target.value})} /></td>
                  <td><button className="btn ghost small" style={{color:'var(--rust)'}} onClick={()=>delRow(i)}>✕</button></td>
                </tr>
              ))}
            </tbody>
          </table>
          <button className="btn outline small" style={{marginTop:10}} onClick={addRow}>+ إضافة سطر</button>
          {Math.abs(sumPct-100)>1 && mode==='pct' && <p style={{fontSize:11.5, color:'var(--rust)', marginTop:8}}>⚠ مجموع النسب {sumPct}% — تأكد أنه 100%</p>}
        </div>
        <div className="modal-foot">
          <button className="btn outline" onClick={onClose}>إلغاء</button>
          <button className="btn brass" onClick={generate}>إنشاء الجدول ({rows.length} دفعة)</button>
        </div>
      </div>
    </div>
  );
}

function SettlePaymentModal({payment, mutate, onClose}){
  const rnd = (x)=> Math.round((parseFloat(x)||0)*100)/100;
  const remainingNet = remainderOf(payment);
  const remainingGross = rnd(remainingNet * grossFactor(payment));
  const [grossAmount, setGrossAmount] = useState(remainingGross);
  const [date, setDate] = useState(todayISO());
  const [method, setMethod] = useState('تحويل بنكي');
  const [account, setAccount] = useState('البنك');
  const [refNo, setRefNo] = useState('');
  const pickMethod = (mNew)=>{ setMethod(mNew); setAccount(mNew==='نقداً' ? 'الخزينة' : 'البنك'); };
  const netAmount = rnd((grossAmount||0) / grossFactor(payment));
  const save = ()=>{
    if(!grossAmount || grossAmount<=0){ alert('أدخل مبلغاً صحيحاً'); return; }
    if(netAmount > remainingNet+1){ alert('المبلغ أكبر من المتبقي ('+money(remainingGross)+' شامل الضريبة)'); return; }
    const full = Math.abs(netAmount - remainingNet) < 1;
    const patch = full
      ? {status:'مدفوعة', paidDate:date, method, account, refNo, collectedAmount:0}
      : {status:'مدفوعة جزئياً', paidDate:date, method, account, refNo, collectedAmount:(payment.collectedAmount||0)+netAmount};
    if(mutate('payments').update(payment.id, patch)===false)return;
    onClose();
  };
  return (
    <div className="overlay" onMouseDown={(e)=>{ if(e.target===e.currentTarget) onClose(); }}>
      <div className="modal" style={{maxWidth:460}}>
        <div className="modal-head">
          <h3>تسجيل تحصيل دفعة</h3>
          <button className="close-x" onClick={onClose}>✕</button>
        </div>
        <div className="modal-body">
          <p style={{fontSize:12.5, color:'var(--ink-soft)', marginBottom:14}}>
            إجمالي الدفعة (شامل الضريبة): <b>{money((payment.amount||0)*grossFactor(payment))}</b><br/>
            المتبقي: <b style={{color:'var(--rust)'}}>{money(remainingGross)}</b>
          </p>
          <div className="field" style={{marginBottom:12}}>
            <label>المبلغ المستلم فعلياً (شامل الضريبة) *</label>
            <input type="number" value={grossAmount} onChange={e=>setGrossAmount(+e.target.value)} />
            <div style={{fontSize:11, color:'var(--ink-faint)', marginTop:3}}>= {money(netAmount)} قبل الضريبة</div>
          </div>
          <div className="field" style={{marginBottom:12}}>
            <label>تاريخ الاستلام *</label>
            <input type="date" value={date} onChange={e=>setDate(e.target.value)} />
          </div>
          <div className="field" style={{marginBottom:12}}>
            <label>طريقة الدفع *</label>
            <select value={method} onChange={e=>pickMethod(e.target.value)}>
              <option>نقداً</option><option>شيك</option><option>تحويل بنكي</option><option>بطاقة</option>
            </select>
          </div>
          <div className="field" style={{marginBottom:12}}>
            <label>الحساب المستلِم *</label>
            <select value={account} onChange={e=>setAccount(e.target.value)}>
              <option>البنك</option><option>الخزينة</option>
            </select>
            <div style={{fontSize:11, color:'var(--ink-faint)', marginTop:3}}>يُحدَّد تلقائياً من طريقة الدفع — عدّله يدوياً لو لزم</div>
          </div>
          {method!=='نقداً' && (
            <div className="field" style={{marginBottom:12}}>
              <label>رقم الشيك / مرجع التحويل أو العملية</label>
              <input value={refNo} onChange={e=>setRefNo(e.target.value)} />
            </div>
          )}
          <div style={{padding:10, background:'var(--paper)', borderRadius:4, fontSize:12}}>
            <span style={{color:'var(--ink-soft)'}}>الحالة بعد التسجيل: </span>
            <b style={{color: Math.abs(netAmount-remainingNet)<1 ? 'var(--teal)' : 'var(--brass)'}}>
              {Math.abs(netAmount-remainingNet)<1 ? 'مدفوعة بالكامل ✓' : 'مدفوعة جزئياً — يتبقى '+money(remainingGross-grossAmount)}
            </b>
          </div>
        </div>
        <div className="modal-foot">
          <button className="btn outline" onClick={onClose}>إلغاء</button>
          <button className="btn brass" onClick={save}>تسجيل التحصيل</button>
        </div>
      </div>
    </div>
  );
}

function BulkSettleModal({data, mutate, presetProject, onClose}){
  const [pid, setPid] = useState(presetProject||'');
  const [total, setTotal] = useState('');
  const [date, setDate] = useState(todayISO());
  const [method, setMethod] = useState('تحويل بنكي');
  const [account, setAccount] = useState('البنك');
  const [refNo, setRefNo] = useState('');
  const [alloc, setAlloc] = useState({});
  const pickMethod = (mNew)=>{ setMethod(mNew); setAccount(mNew==='نقداً' ? 'الخزينة' : 'البنك'); };
  const rows = useMemo(()=> data.payments
    .filter(i=>!isArchived(i) && i.projectId===pid && remainderOf(i)>0)
    .sort((a,b)=>(a.dueDate||'').localeCompare(b.dueDate||'')), [data.payments, pid]);
  const remGross = (i)=> remainderOf(i)*grossFactor(i);
  const autoFill = ()=>{
    let left = parseFloat(total)||0; const a={};
    rows.forEach(i=>{ const r=remGross(i); const x=Math.min(left, r); if(x>0.01){ a[i.id]=Math.round(x*100)/100; left-=x; } });
    setAlloc(a);
  };
  const sumAlloc = rows.reduce((s,i)=>s+(parseFloat(alloc[i.id])||0),0);
  const totalNum = parseFloat(total)||0;
  const apply = ()=>{
    const lines = rows.filter(i=>(parseFloat(alloc[i.id])||0)>0);
    if(lines.length===0){ alert('أدخل مبالغ التوزيع أو استخدم "توزيع تلقائياً"'); return; }
    for(const i of lines){
      if((parseFloat(alloc[i.id])||0) > remGross(i)+0.5){ alert('المبلغ الموزع على "'+(i.label||i.phase)+'" أكبر من المتبقي عليها'); return; }
    }
    const prepared=lines.map(i=>{
      const net=Math.round(((parseFloat(alloc[i.id])||0)/grossFactor(i))*100)/100;
      const full=net>=remainderOf(i)-0.5;
      const patch=full?{status:'مدفوعة',paidDate:date,method,account,refNo,collectedAmount:0}:{status:'مدفوعة جزئياً',paidDate:date,method,account,refNo,collectedAmount:(i.collectedAmount||0)+net};
      return {i,patch,check:paymentControl(i,{...i,...patch})};
    });
    for(const line of prepared){if(line.check.error||line.check.correction){alert(line.check.error||'إحدى الدفعات تحتاج تصحيحًا فرديًا بسبب مسجل قبل التحصيل المجمّع. لم نغيّر أي دفعة.');return;}}
    if(!confirm('تسجيل تحصيل إجمالي '+money(sumAlloc)+' موزعًا على '+lines.length+' دفعة؟'))return;
    let saved=0;
    for(const line of prepared){if(mutate('payments').update(line.i.id,line.patch)===false){alert('توقف التحصيل المجمّع بعد حفظ '+saved+' طلب. راجع العمليات قبل إعادة المحاولة.');return;}saved++;}
    alert('تم حفظ طلبات التحصيل المجمّع للمزامنة على '+saved+' دفعة');
    onClose();
  };
  return (
    <div className="overlay" onMouseDown={(e)=>{ if(e.target===e.currentTarget) onClose(); }}>
      <div className="modal" style={{maxWidth:680}}>
        <div className="modal-head">
          <h3>تحصيل مجمّع — تحويل واحد يغطي عدة دفعات</h3>
          <button className="close-x" onClick={onClose}>✕</button>
        </div>
        <div className="modal-body">
          {!presetProject && (
            <div className="field" style={{marginBottom:12}}>
              <label>المشروع *</label>
              <select value={pid} onChange={e=>{ setPid(e.target.value); setAlloc({}); }}>
                <option value="">اختر...</option>
                {data.projects.filter(p=>!isArchived(p)).map(p=><option key={p.id} value={p.id}>{(p.projectNo?p.projectNo+' — ':'')+p.name}</option>)}
              </select>
            </div>
          )}
          {pid && rows.length===0 && <p style={{fontSize:12.5, color:'var(--teal)'}}>✓ لا توجد دفعات معلقة على هذا المشروع.</p>}
          {pid && rows.length>0 && (
            <React.Fragment>
              <div style={{display:'flex', gap:8, alignItems:'flex-end', marginBottom:12, flexWrap:'wrap'}}>
                <div className="field" style={{flex:1, minWidth:160}}>
                  <label>المبلغ المستلم (شامل الضريبة) *</label>
                  <input type="number" value={total} onChange={e=>setTotal(e.target.value)} placeholder="مثال: 50000" />
                </div>
                <button className="btn outline small" onClick={autoFill} style={{marginBottom:2}}>توزيع تلقائياً (الأقدم أولاً)</button>
              </div>
              <table>
                <thead><tr><th>الدفعة</th><th>الاستحقاق</th><th>المتبقي (شامل)</th><th>التوزيع</th></tr></thead>
                <tbody>
                  {rows.map(i=>(
                    <tr key={i.id}>
                      <td style={{fontSize:12}}>{i.phase==='إشراف' ? 'إشراف '+(i.month?fmtMonth(i.month):'') : (i.label||i.phase)}</td>
                      <td style={{fontSize:11.5}}>{i.dueDate||'—'}</td>
                      <td>{money(remGross(i))}</td>
                      <td><input type="number" value={alloc[i.id]===undefined?'':alloc[i.id]} style={{width:110}}
                        onChange={e=>setAlloc(a=>({...a, [i.id]:e.target.value}))} /></td>
                    </tr>
                  ))}
                  <tr style={{fontWeight:800, background:'rgba(19,42,70,.03)'}}>
                    <td colSpan={3}>مجموع الموزع</td>
                    <td style={{color: Math.abs(sumAlloc-totalNum)<1||!totalNum ? 'var(--teal)' : 'var(--rust)'}}>{money(sumAlloc)}{totalNum>0 && Math.abs(sumAlloc-totalNum)>=1 ? ' ≠ '+money(totalNum) : ''}</td>
                  </tr>
                </tbody>
              </table>
              <div style={{display:'flex', gap:10, marginTop:14, flexWrap:'wrap'}}>
                <div className="field" style={{flex:1, minWidth:130}}>
                  <label>تاريخ الاستلام *</label>
                  <input type="date" value={date} onChange={e=>setDate(e.target.value)} />
                </div>
                <div className="field" style={{flex:1, minWidth:130}}>
                  <label>طريقة الدفع *</label>
                  <select value={method} onChange={e=>pickMethod(e.target.value)}>
                    <option>نقداً</option><option>شيك</option><option>تحويل بنكي</option><option>بطاقة</option>
                  </select>
                </div>
                <div className="field" style={{flex:1, minWidth:120}}>
                  <label>الحساب المستلِم *</label>
                  <select value={account} onChange={e=>setAccount(e.target.value)}>
                    <option>البنك</option><option>الخزينة</option>
                  </select>
                </div>
                <div className="field" style={{flex:1.4, minWidth:150}}>
                  <label>مرجع التحويل / الشيك</label>
                  <input value={refNo} onChange={e=>setRefNo(e.target.value)} />
                </div>
              </div>
            </React.Fragment>
          )}
        </div>
        <div className="modal-foot">
          <button className="btn outline" onClick={onClose}>إلغاء</button>
          <button className="btn brass" onClick={apply} disabled={!pid||rows.length===0}>تسجيل التحصيل المجمّع</button>
        </div>
      </div>
    </div>
  );
}

/* ================= ملف المشروع (Project-Centric Hub) ================= */
function ProjectProfile({project, data, configs, mutate, onBack, role}){
  const [tab, setTab] = useState('overview');
  const p = data.projects.find(x=>x.id===project.id) || project;
  const upd = (patch)=> mutate('projects').update(p.id, patch);
  const mC = mutate('contracts');

  const [stageModal, setStageModal] = useState(null);
  const [apvModal, setApvModal] = useState(null);

  const toggleApproval = (name)=>{
    const cur = (p.approvals||{})[name] || {done:false};
    upd({approvals:{...(p.approvals||{}), [name]:{...cur, done:!cur.done, date: !cur.done ? todayISO() : ''}}});
  };

  const STAGE_FIELDS = [
    {name:'status', label:'حالة المرحلة', type:'select', options:STAGE_STATUSES.map(s=>({value:s,label:s})), required:true},
    {name:'progress', label:'نسبة الإنجاز %', type:'number'},
    {name:'startDate', label:'تاريخ البدء', type:'date'},
    {name:'targetDays', label:'المدة المستهدفة (أيام)', type:'number'},
    {name:'responsibleId', label:'الموظف المسؤول', type:'select', allowAddNew:true, addNewPrompt:'اسم المهندس/الموظف المسؤول:', hint:'مش لاقي الاسم؟ اختر "➕ إضافة تصنيف جديد..." من آخر القائمة واكتب الاسم مباشرة — من غير ما تحتاج تضيفه كموظف رسمي في قسم الموظفين الأول',
      options:(d)=>(d.employees&&d.employees.length ? d.employees.map(e=>({value:e.id,label:e.name})) : (d.staffDir||[]).map(s=>({value:s.empId,label:s.name})))},
    {name:'notes', label:'ملاحظات', type:'textarea'},
    {name:'attachRef', label:'مرجع المرفقات', hint:'أسماء الملفات داخل مجلد المشروع — الملفات نفسها تُحفظ في المجلد لا داخل النظام'},
  ];
  const APV_FIELDS = [
    {name:'done', label:'حالة الاعتماد', type:'select', options:[{value:'معتمد',label:'معتمد'},{value:'غير معتمد',label:'قيد الاعتماد / لم يُقدَّم'}], required:true},
    {name:'submitDate', label:'تاريخ آخر تقديم للدائرة', type:'date'},
    {name:'targetDays', label:'المدة المتوقعة للاعتماد (أيام)', type:'number'},
    {name:'submissionNo', label:'رقم مرة التقديم', type:'number', hint:'كم مرة تم تقديم هذا الاعتماد؟ 1 = تقديم أول، 2 = بعد ملاحظات، ...'},
    {name:'lastRemarks', label:'ملاحظات الدائرة على آخر تقديم', type:'textarea', hint:'يظهر هنا سبب الرد لسهولة المتابعة'},
    {name:'responsibleId', label:'الموظف المسؤول', type:'select', allowAddNew:true, addNewPrompt:'اسم المهندس/الموظف المسؤول:', hint:'مش لاقي الاسم؟ اختر "➕ إضافة تصنيف جديد..." من آخر القائمة واكتب الاسم مباشرة',
      options:(d)=>(d.employees&&d.employees.length ? d.employees.map(e=>({value:e.id,label:e.name})) : (d.staffDir||[]).map(s=>({value:s.empId,label:s.name})))},
    {name:'notes', label:'ملاحظات عامة', type:'textarea'},
  ];
  const empNameOf = (id)=> id ? ((data.employees.find(e=>e.id===id)||{}).name || ((data.staffDir||[]).find(s=>s.empId===id)||{}).name || id) : '';
  const stageOverdue = (s)=> s && s.status==='جارية' && s.startDate && s.targetDays && daysSince(s.startDate) > s.targetDays;
  const apvOverdue = (a)=> a && !a.done && a.submitDate && a.targetDays && daysSince(a.submitDate) > a.targetDays;

  const cons = (data.contracts||[]).filter(c=>!isArchived(c) && c.projectId===p.id);
  const consultancy = cons.filter(c=>c.status!=='ملغى' && !isArchived(c) && (isConsultancy(c)));
  const contractors = cons.filter(c=>c.category==='مقاول رئيسي' || c.category==='مقاول باطن');
  const consValue = consultancy.reduce((s,c)=> s + contractTotalOf(c), 0);
  const pays = data.payments.filter(i=>!isArchived(i) && i.projectId===p.id);
  const billed = pays.reduce((s,i)=>s+billedOf(i),0);
  const collected = pays.reduce((s,i)=>s+collectedOf(i)*grossFactor(i),0);
  const remainingContract = Math.max(0, consValue - billed);
  const duePays = pays.reduce((s,i)=>s+remainderOf(i)*grossFactor(i),0);
  const fees = data.govFees.filter(g=>!isArchived(g) && g.projectId===p.id);
  const feesTotal = fees.reduce((s,g)=>s+(isArchived(g)?0:g.amount),0);
  const feesOut = fees.filter(g=>!isArchived(g) && g.payerType!=='المالك مباشرة' && g.paidStatus==='مدفوع' && g.reimburseStatus!=='مسترد').reduce((s,g)=>s+(isArchived(g)?0:g.amount),0);
  const costs = data.projectCosts.filter(e=>!isArchived(e) && e.projectId===p.id).reduce((s,e)=>s+(e.amount||0),0);
  const timeCost = projectTimeCost(data, p.id);           // تكلفة وقت المهندسين
  const timeHours = projectTimeHours(data, p.id);
  const totalCost = costs + timeCost;                     // التكلفة الحقيقية = مباشرة + وقت
  const folderName = p.folderName || ((p.projectNo||'')+' - '+(p.name||''));
  const folderPath = ((data.settings&&data.settings.projectsRoot)||'D:\\Projects')+'\\'+folderName;
  const openFolder = ()=>{
    let u = folderPath.replace(/\\/g,'/');
    if(u.startsWith('//')) u = 'file:'+'///'+u;
    else u = 'file:///'+u;
    const w = window.open(u, '_blank');
    if(!w) alert('المتصفح منع الفتح المباشر — استخدم زر نسخ المسار والصقه في الـ Explorer');
  };

  const copyPath = ()=>{
    if(navigator.clipboard && navigator.clipboard.writeText){
      navigator.clipboard.writeText(folderPath).then(()=>alert('تم نسخ المسار — الصقه في شريط عنوان الـ Explorer:\n'+folderPath));
    } else { prompt('انسخ المسار:', folderPath); }
  };

  const projDecisions = (data.decisions||[]).filter(x=>x.projectId===p.id);
  const TABS = [
    {key:'overview', label:'نظرة عامة و Timeline'},
    {key:'activity', label:'نشاط المشروع ('+projDecisions.length+')'},
    {key:'contracts', label:'العقود ('+cons.length+')'},
    {key:'payments', label:'الدفعات ('+pays.length+')'},
    {key:'govFees', label:'الرسوم الحكومية ('+fees.length+')'},
    {key:'finance', label:'الملف المالي'},
    {key:'statement', label:'كشف الحساب'},
    {key:'folder', label:'مجلد المشروع'},
  ];

  /* --- بناء الـ Activity Feed الموحّد --- */
  const [waOpen, setWaOpen] = useState(false);
  const [scheduleFor, setScheduleFor] = useState(null);
  const [closingOpen, setClosingOpen] = useState(false);
  const [cnView, setCnView] = useState(null); // عرض إشعار دائن (فسخ عقد)
  const [decModal, setDecModal] = useState(null); // 'decision' | 'meeting'
  const mD = mutate('decisions');
  const feed = [];
  projDecisions.forEach(x=> feed.push({date:x.date, tag:x.category, cls:x.category==='اعتماد المالك'?'ok':x.category==='مهمة'?'soon':'neutral', text:x.description + (x.responsible?' — '+x.responsible:''), src:x.source||'يدوي'}));
  pays.forEach(i=>{
    if(i.invoiceNo){ const cancelled = isArchived(i)||i.status==='ملغاة'; feed.push({date:i.date, tag:cancelled?'فاتورة ملغاة':'فاتورة', cls:cancelled?'bad':'gray', text:'إصدار الفاتورة '+i.invoiceNo+' بقيمة '+money(i.amount*grossFactor(i))+(cancelled?' — ملغاة'+((i.archiveReason||i.cancelReason)?' ('+(i.archiveReason||i.cancelReason)+')':''):''), src:'مالية'}); }
    if(i.receiptNo && (i.status==='مدفوعة'||i.status==='مدفوعة جزئياً')) feed.push({date:i.paidDate||i.date, tag:'سند قبض', cls:'ok', text:'استلام دفعة — سند '+i.receiptNo+' ('+money(collectedOf(i)*grossFactor(i))+')', src:'مالية'});
  });
  fees.forEach(g=> feed.push({date:g.date, tag:'رسوم حكومية', cls:'gray', text:g.department+' — '+g.description+' ('+money(g.amount)+')', src:'أمانات'}));
  cons.forEach(c=> feed.push({date:c.date, tag:'عقد', cls:'neutral', text:'عقد '+(c.category||'خدمات استشارية')+(c.contractor?' — '+c.contractor:'')+': '+(c.description||''), src:'عقود'}));
  TIMELINE_STAGES.forEach(st=>{
    const s = (p.timeline||{})[st.key];
    if(s && s.status==='مكتملة' && s.date) feed.push({date:s.date, tag:'مرحلة', cls:'ok', text:'اكتمال مرحلة "'+st.label+'"', src:'Timeline'});
  });
  APPROVAL_ITEMS.forEach(name=>{
    const a = (p.approvals||{})[name];
    if(a && a.done && a.date) feed.push({date:a.date, tag:'اعتماد', cls:'ok', text:'اعتماد '+name, src:'اعتمادات'});
  });
  feed.sort((a,b)=> (b.date||'').localeCompare(a.date||''));

  return (
    <div>
      <div className="toolbar no-print">
        <button className="btn outline" onClick={onBack}>← كل المشاريع</button>
        <div style={{flex:1}}>
          <div style={{fontFamily:'Cairo', fontWeight:900, fontSize:17, color:'var(--ink)'}}>
            <span style={{color:'var(--brass)'}}>{p.projectNo}</span> — {p.name}
          </div>
          <div style={{fontSize:11.5, color:'var(--ink-faint)'}}>{p.owner} · {(p.emirate||'')+(p.area?' — '+p.area:'')} · {p.projectType||''}</div>
        </div>
        {p.status==='جارٍ' && <button className="btn outline" onClick={()=>setClosingOpen(true)}>قائمة إقفال المشروع</button>}
        {p.status==='مفسوخ' && p.creditNote && (
          <button className="btn outline" style={{borderColor:'var(--rust)', color:'var(--rust)'}}
            title="إعادة طباعة إشعار الدائن (فسخ عقد)"
            onClick={()=>{
              const cn=p.creditNote;
              setCnView({ project:p, refundNet:cn.refundNet, refundVat:cn.refundVat, refundGross:cn.refundGross,
                reason:(p.terminationReason||'فسخ عقد'), date:cn.date||p.closedAt||todayISO(), cnNo:cn.cnNo });
            }}>🧾 إشعار الدائن</button>
        )}
        <span className={"badge "+(p.status==='جارٍ'?'neutral':p.status==='منتهٍ'?'ok':'bad')}>{p.status}</span>
      </div>
      {cnView && <CreditNoteDoc cn={cnView} onClose={()=>setCnView(null)} />}

      <div className="tabs no-print">
        {TABS.map(t=>(
          <div key={t.key} className={"tab "+(tab===t.key?'active':'')} onClick={()=>setTab(t.key)}>{t.label}</div>
        ))}
      </div>

      {tab==='overview' && (
        <div>
          {p.quickNotes && (
            <div className="card" style={{marginBottom:18, borderInlineStart:'4px solid var(--brass)', background:'#FEF9F0'}}>
              <div style={{fontSize:11, fontWeight:800, color:'var(--brass)', marginBottom:6, letterSpacing:1}}>📌 ملاحظات سريعة</div>
              <div style={{fontSize:13.5, lineHeight:1.7, whiteSpace:'pre-wrap'}}>{p.quickNotes}</div>
            </div>
          )}
          <div className="card" style={{marginBottom:18}}>
            <div className="section-title"><h3>Timeline المشروع — انقر أي مرحلة لفتح ملفها الكامل (الحالة، المسؤول، المدة، الملاحظات)</h3><div className="rule"></div></div>
            <div className="tl">
              {TIMELINE_STAGES.map(st=>{
                const s = (p.timeline||{})[st.key] || {status:'لم تبدأ'};
                const cls = s.status==='مكتملة'?'done':s.status==='جارية'?'active':'';
                const late = stageOverdue(s);
                return (
                  <div key={st.key} className={"tl-step "+cls} onClick={()=>setStageModal(st.key)} title={'ملف المرحلة — '+s.status}>
                    <div className="tl-dot" style={late?{borderColor:'var(--rust)', background:'var(--rust)'}:{}}>{s.status==='مكتملة'?'✓':s.status==='جارية'?'●':''}</div>
                    <div className="tl-label">{st.label}</div>
                    <div className="tl-date">
                      {late ? <span style={{color:'var(--rust)', fontWeight:800}}>متأخرة {daysSince(s.startDate)-s.targetDays} يوم</span>
                        : s.status==='مكتملة'&&s.date ? s.date
                        : s.status==='جارية' ? ((s.progress?s.progress+'%':'جارية')+(s.responsibleId?' · '+empNameOf(s.responsibleId).split(' ')[1]||'':'')) : ''}
                    </div>
                    {s.status==='جارية' && s.progress>0 && <div className="progress" style={{width:56, margin:'4px auto 0'}}><div style={{width:Math.min(100,s.progress)+'%'}}></div></div>}
                  </div>
                );
              })}
            </div>
          </div>

          <div className="card" style={{marginBottom:18}}>
            <div className="section-title"><h3>الاعتمادات الحكومية — انقر للتحديد</h3><div className="rule"></div></div>
            <div className="apv">
              {APPROVAL_ITEMS.map(name=>{
                const a = (p.approvals||{})[name] || {done:false};
                return (
                  <div key={name} className={"apv-item "+(a.done?'on':'')} onClick={()=>toggleApproval(name)}
                    style={apvOverdue(a)?{borderColor:'var(--rust)'}:{}}>
                    <span className="bx">{a.done?'✓':''}</span>
                    <span>{name}</span>
                    <span className="dt">
                      {a.done && a.date ? a.date
                        : apvOverdue(a) ? <b style={{color:'var(--rust)'}}>متأخر {daysSince(a.submitDate)-a.targetDays} يوم</b>
                        : a.submitDate ? ('تقديم '+(a.submissionNo||1)+' — منذ '+daysSince(a.submitDate)+' يوم') : ''}
                      {(a.submissionNo||0)>1 && !a.done && <span className="badge soon" style={{marginInlineStart:6, fontSize:9}}>مرة {a.submissionNo}</span>}
                    </span>
                    <span onClick={(e)=>{e.stopPropagation(); setApvModal(name);}}
                      style={{marginInlineStart:6, color:'var(--brass)', fontWeight:900, padding:'0 4px'}} title="ملف الاعتماد">⋯</span>
                  </div>
                );
              })}
            </div>
            <p style={{fontSize:11.5, color:'var(--ink-faint)', marginTop:12, marginBottom:0}}>* بدون قيود على ترتيب التنفيذ — رسوم كل دائرة تُسجل في قسم الرسوم الحكومية وتظهر تلقائياً في الملف المالي وكشف الحساب.</p>
          </div>

          <div className="card">
            <div className="section-title"><h3>بيانات المشروع</h3><div className="rule"></div></div>
            <div className="info-grid">
              <div className="doc-line"><span className="lbl">رقم المشروع</span><span className="val">{p.projectNo}</span></div>
              <div className="doc-line"><span className="lbl">المالك</span><span className="val">{p.owner||'—'}</span></div>
              <div className="doc-line"><span className="lbl">الجهة المالكة</span><span className="val">{p.owningEntity||'—'}</span></div>
              {(p.additionalOwners||[]).filter(o=>o.name).length>0 && (
                <div className="doc-line"><span className="lbl">ملاك إضافيون</span><span className="val">{(p.additionalOwners||[]).filter(o=>o.name).map(o=>o.name+(o.entity?' ('+o.entity+')':'')).join(' — ')}</span></div>
              )}
              <div className="doc-line"><span className="lbl">نوع الأرض</span><span className="val">{p.landType||'—'}</span></div>
              <div className="doc-line"><span className="lbl">الرقم الحكومي</span><span className="val">{p.plotNumber||'—'}</span></div>
              {p.landType==='ملك' && <div className="doc-line"><span className="lbl">رقم الأرض (ملك)</span><span className="val">{p.ownershipNumber||'—'}</span></div>}
              <div className="doc-line"><span className="lbl">الإمارة — المنطقة</span><span className="val">{(p.emirate||'—')+(p.area?' — '+p.area:'')}</span></div>
              <div className="doc-line"><span className="lbl">نوع المشروع</span><span className="val">{p.projectType||'—'}</span></div>
              <div className="doc-line"><span className="lbl">المهندس المسؤول</span><span className="val">{p.engineer||'—'}</span></div>
              <div className="doc-line"><span className="lbl">تاريخ الفتح</span><span className="val">{p.startDate||'—'}</span></div>
            </div>
          </div>
        </div>
      )}

      {stageModal && (
        <FormModal
          title={'ملف مرحلة: '+(TIMELINE_STAGES.find(s=>s.key===stageModal)||{}).label}
          fields={STAGE_FIELDS}
          initial={(p.timeline||{})[stageModal] || {status:'لم تبدأ', progress:0}}
          data={data}
          onCancel={()=>setStageModal(null)}
          onSave={(vals)=>{
            const prev = (p.timeline||{})[stageModal] || {};
            const rec = {...prev, ...vals};
            if(rec.status==='مكتملة'){ rec.date = rec.date || todayISO(); rec.progress = 100; }
            if(rec.status==='جارية' && !rec.startDate) rec.startDate = todayISO();
            upd({timeline:{...(p.timeline||{}), [stageModal]:rec}});
            setStageModal(null);
          }}
        />
      )}
      {apvModal && (
        <FormModal
          title={'ملف اعتماد: '+apvModal}
          fields={APV_FIELDS}
          initial={(()=>{ const a=(p.approvals||{})[apvModal]||{}; return {...a, done: a.done?'معتمد':'غير معتمد'}; })()}
          data={data}
          onCancel={()=>setApvModal(null)}
          onSave={(vals)=>{
            const prev = (p.approvals||{})[apvModal] || {};
            const done = vals.done==='معتمد';
            upd({approvals:{...(p.approvals||{}), [apvModal]:{...prev, ...vals, done, date: done ? (prev.date||todayISO()) : ''}}});
            setApvModal(null);
          }}
        />
      )}

      {tab==='activity' && (
        <div>
          <div className="toolbar no-print">
            <div className="section-title" style={{marginBottom:0, flex:1}}><h3>سجل نشاط المشروع — كل الأحداث في تسلسل واحد</h3><div className="rule"></div></div>
            <button className="btn outline" onClick={()=>setDecModal('meeting')}>ملخص اجتماع</button>
            <button className="btn outline" onClick={()=>setDecModal('decision')}>+ قرار جديد</button>
            <button className="btn brass" onClick={()=>setWaOpen(true)}>استيراد محادثة واتساب</button>
          </div>
          <div className="card">
            {feed.length===0 && <p style={{fontSize:13, color:'var(--ink-faint)'}}>لا يوجد نشاط مسجل بعد — ابدأ باستيراد محادثة واتساب أو تسجيل قرار.</p>}
            {feed.map((f,i)=>{
              const showDate = i===0 || feed[i-1].date!==f.date;
              return (
                <div key={i}>
                  {showDate && <div style={{fontFamily:'Cairo', fontWeight:800, fontSize:12.5, color:'var(--brass)', margin:(i===0?'0':'18px')+' 0 8px', display:'flex', alignItems:'center', gap:10}}>{f.date}<span style={{flex:1, borderTop:'1px dashed var(--line-strong)'}}></span></div>}
                  <div style={{display:'flex', gap:10, alignItems:'flex-start', padding:'7px 0 7px 0', borderRight:'2px solid var(--line)', paddingRight:14, marginRight:4}}>
                    <span className={"badge "+f.cls} style={{flexShrink:0}}>{f.tag}</span>
                    <span style={{fontSize:13, flex:1}}>{f.text}</span>
                    <span style={{fontSize:10, color:'var(--ink-faint)', flexShrink:0}}>{f.src}</span>
                  </div>
                </div>
              );
            })}
          </div>
          <p style={{fontSize:11.5, color:'var(--ink-faint)', marginTop:12}}>* القرارات المستوردة من واتساب لا تدخل السجل إلا بعد اعتمادك لكل قرار على حدة. تعديل أو حذف القرارات من قسم "القرارات والوقائع".</p>
        </div>
      )}

      {waOpen && <WaImport project={p} data={data} onApprove={(d)=>mD.add(d)} onClose={()=>setWaOpen(false)} />}
      {scheduleFor && <InstallmentScheduleModal contract={scheduleFor} data={data} mutate={mutate} onClose={()=>setScheduleFor(null)} />}
      {closingOpen && <ClosingChecklistModal project={p} data={data} mutate={mutate} onClose={()=>setClosingOpen(false)} />}
      {decModal && (
        <FormModal
          title={decModal==='meeting' ? 'ملخص اجتماع — مشروع '+p.projectNo : 'قرار جديد — مشروع '+p.projectNo}
          fields={configs.decisions.fields.filter(f=>f.name!=='projectId')}
          initial={decModal==='meeting'
            ? {date:todayISO(), category:'ملخص اجتماع', status:'منفذ', source:'اجتماع'}
            : {date:todayISO(), category:'اعتماد المالك', status:'مفتوح', source:'يدوي'}}
          data={data}
          onCancel={()=>setDecModal(null)}
          onSave={(vals)=>{ mD.add({...vals, projectId:p.id, id:uid(), _ts:Date.now()}); setDecModal(null); }}
        />
      )}

      {tab==='contracts' && (
        <EntityView config={{...configs.contracts, defaults:{...configs.contracts.defaults, projectId:p.id}}}
          records={cons} data={data}
          onAdd={mC.add} onUpdate={mC.update} onDelete={mC.del}
          rowActions={(row)=>{
            const designTotal = row.type==='إشراف' ? 0 : (isComboContract(row) ? (row.designValue||0) : (row.value||0));
            const designInvoiced = data.payments.filter(i=>!isArchived(i) && i.status!=='ملغاة' && i.contractId===row.id && i.phase==='تصميم').reduce((s,i)=>s+(i.amount||0),0);
            const canSchedule = isConsultancy(row) && row.type!=='إشراف' && row.status==='سارٍ' && designTotal>0 && designInvoiced < designTotal*0.999;
            const cm = contractCommission(row);
            const invoiced = data.payments.filter(i=>i.contractId===row.id).reduce((s,i)=>s+billedOf(i),0);
            const canCommission = cm>0 && invoiced<cm*0.999 && row.status==='سارٍ';
            return (
              <React.Fragment>
                {canSchedule && (
                  <button className="btn ghost small" title="إنشاء جدول دفعات" style={{color:'var(--teal)'}}
                    onClick={()=>setScheduleFor(row)}>📋 جدول</button>
                )}
                {canCommission && (
                  <button className="btn ghost small" title="توليد دفعة العمولة" style={{color:'var(--brass)'}}
                    onClick={()=>{
                  if(!confirm('إصدار دفعة عمولة بقيمة '+money(cm-invoiced)+' عن عقد '+(row.contractor||row.subType||row.category)+'؟')) return;
                  const due = new Date(); due.setDate(due.getDate()+10);
                  mutate('payments').add({id:uid(), projectId:p.id, contractId:row.id, phase:'أخرى',
                    label:'عمولة الاستشاري — عقد '+(row.subType?row.subType+' ':'')+(row.contractor||''),
                    amount:cm-invoiced, taxable:'خاضعة', date:todayISO(), dueDate:due.toISOString().slice(0,10), status:'معلقة', _ts:Date.now()});
                  alert('تم إنشاء دفعة العمولة — تجدها في تبويب الدفعات');
                }}>+ عمولة</button>
                )}
              </React.Fragment>
            );
          }} />
      )}

      {tab==='payments' && <PaymentsView data={data} configs={configs} mutate={mutate} lockedProject={p.id} role={role} />}
      {tab==='govFees' && <GovFeesView data={data} configs={configs} mutate={mutate} lockedProject={p.id} />}

      {tab==='finance' && (
        <div>
          <div className="grid grid-4" style={{marginBottom:18}}>
            <div className="card"><div className="kpi-label">قيمة العقود الاستشارية</div><div className="kpi-value" style={{fontSize:19}}>{money(consValue)}</div><div className="kpi-note">{consultancy.length} عقد استشاري · {contractors.length} عقد مقاولين</div></div>
            <div className="card"><div className="kpi-label">المحصّل (شامل الضريبة)</div><div className="kpi-value" style={{fontSize:19, color:'var(--teal)'}}>{money(collected)}</div><div className="kpi-note">مفوتر: {money(billed)} قبل الضريبة</div></div>
            <div className="card"><div className="kpi-label">مستحق غير محصّل</div><div className="kpi-value" style={{fontSize:19, color:duePays>0?'var(--rust)':'var(--teal)'}}>{money(duePays)}</div><div className="kpi-note">من الفواتير الصادرة</div></div>
            <div className="card"><div className="kpi-label">متبقٍ لم يُفوتر من العقود</div><div className="kpi-value" style={{fontSize:19}}>{money(remainingContract)}</div><div className="kpi-note">قبل الضريبة</div></div>
          </div>
          {(()=>{
            const billed = pays.reduce((s,i)=>s+billedOf(i),0);
            const collectRatio = billed>0 ? (pays.reduce((s,i)=>s+collectedOf(i),0)/billed*100) : 100;
            const margin = billed>0 ? ((billed-totalCost)/billed*100) : null;
            const budUse = (p.budgetAmount||0)>0 ? (costs/p.budgetAmount*100) : null;
            let score = 0;
            if(collectRatio>=80) score++; if(margin===null||margin>=30) score++;
            if(duePays+feesOut < billed*0.25 || billed===0) score++;
            if(budUse===null||budUse<=100) score++;
            const health = score>=4 ? ['ممتاز','ok'] : score===3 ? ['جيد','neutral'] : score===2 ? ['تحذير','soon'] : ['حرج','bad'];
            return (
              <div className="card" style={{marginBottom:18, display:'flex', gap:24, alignItems:'center', flexWrap:'wrap'}}>
                <div>
                  <div className="kpi-label">الصحة المالية للمشروع</div>
                  <div style={{marginTop:6}}><span className={"badge "+health[1]} style={{fontSize:14, padding:'6px 16px'}}>{health[0]}</span></div>
                </div>
                <div style={{fontSize:12, color:'var(--ink-soft)'}}>نسبة التحصيل: <b>{collectRatio.toFixed(0)}%</b></div>
                {margin!==null && <div style={{fontSize:12, color:'var(--ink-soft)'}}>هامش الربح: <b style={{color:margin<20?'var(--rust)':'var(--teal)'}}>{margin.toFixed(0)}%</b></div>}
                {budUse!==null && (
                  <div style={{flex:1, minWidth:200}}>
                    <div style={{fontSize:11.5, color:'var(--ink-soft)', marginBottom:4}}>استهلاك الميزانية: <b style={{color:budUse>100?'var(--rust)':'var(--ink)'}}>{budUse.toFixed(0)}%</b> ({money(costs)} من {money(p.budgetAmount)})</div>
                    <div className="progress" style={{width:'100%'}}><div style={{width:Math.min(100,budUse)+'%', background:budUse>100?'var(--rust)':budUse>80?'var(--amber, #B8860B)':'var(--teal)'}}></div></div>
                    {budUse>100 && <div style={{fontSize:11, color:'var(--rust)', fontWeight:700, marginTop:3}}>⚠ تجاوزت التكاليف الميزانية المحددة</div>}
                  </div>
                )}
              </div>
            );
          })()}
          <div className="grid" style={{gridTemplateColumns:'repeat(auto-fit, minmax(170px, 1fr))', marginBottom:18}}>
            <div className="card"><div className="kpi-label">عمولات متوقعة من عقود المقاولين</div>
              <div className="kpi-value" style={{fontSize:18, color:'var(--brass)'}}>{money(contractors.reduce((s,c)=>s+contractCommission(c),0))}</div>
              <div className="kpi-note">تتحول لدخل عند توليد دفعتها من تبويب العقود — قيم عقود المقاولين نفسها خارج الإيرادات والضريبة</div></div>
            <div className="card"><div className="kpi-label">الرسوم الحكومية (أمانات)</div><div className="kpi-value" style={{fontSize:18}}>{money(feesTotal)}</div><div className="kpi-note" style={{color:feesOut>0?'var(--rust)':'var(--ink-faint)'}}>{feesOut>0 ? 'منها '+money(feesOut)+' لم تُسترد من المالك' : 'مسوّاة بالكامل'}</div></div>
            <div className="card"><div className="kpi-label">تكاليف المشروع المباشرة</div><div className="kpi-value" style={{fontSize:18}}>{money(costs)}</div><div className="kpi-note">طباعة، مواصلات، فحوصات...</div></div>
            <div className="card"><div className="kpi-label">تكلفة وقت المهندسين</div><div className="kpi-value" style={{fontSize:18, color:'var(--rust)'}}>{money(timeCost)}</div><div className="kpi-note">{timeHours} ساعة مسجّلة × تكلفة ساعة كل مهندس</div></div>
            {(p.estHours||0)>0 && (()=>{
              const est = Number(p.estHours)||0;
              const pct = est>0 ? (timeHours/est*100) : 0;
              const over = timeHours > est;
              return (
                <div className="card"><div className="kpi-label">الساعات: فعلي مقابل مقدّر</div>
                  <div className="kpi-value" style={{fontSize:18, color:over?'var(--rust)':'var(--teal)'}}>{Math.round(timeHours*10)/10} / {est} ساعة</div>
                  <div className="progress" style={{width:'100%', marginTop:4}}><div style={{width:Math.min(100,pct)+'%', background:over?'var(--rust)':pct>80?'var(--amber,#B8860B)':'var(--teal)'}}></div></div>
                  <div className="kpi-note" style={{color:over?'var(--rust)':'var(--ink-faint)'}}>{over?('⚠ تجاوز التقدير بـ '+Math.round(timeHours-est)+' ساعة — راجع التسعير'):(pct.toFixed(0)+'% من التقدير')}</div>
                </div>
              );
            })()}
            <div className="card"><div className="kpi-label">الربح الحقيقي (تراكمي)</div><div className="kpi-value" style={{fontSize:18, color:(billed-totalCost)>=0?'var(--teal)':'var(--rust)'}}>{money(billed-totalCost)}</div><div className="kpi-note">المفوتر − (التكاليف المباشرة + تكلفة الوقت)</div></div>
          </div>
          <div className="card" style={{padding:0}}>
            <div style={{overflowX:'auto'}}>
            <table>
              <thead><tr><th>التاريخ</th><th>النوع</th><th>البند</th><th>الإجمالي شامل الضريبة</th><th>الحالة</th><th>فاتورة / سند</th></tr></thead>
              <tbody>
                {pays.length===0 && <tr className="empty-row"><td colSpan={6}>لا توجد دفعات — تُضاف من قسم الدفعات الاستشارية</td></tr>}
                {[...pays].sort((a,b)=>(b.date||'').localeCompare(a.date||'')).map(i=>(
                  <tr key={i.id}>
                    <td>{i.date}</td>
                    <td><span className={"badge "+(i.phase==='إشراف'?'neutral':i.phase==='أخرى'?'soon':'gray')}>{i.phase}</span></td>
                    <td>{i.phase==='إشراف' ? ('إشراف '+(i.month?fmtMonth(i.month):'')) : (i.label||'—')}</td>
                    <td><b>{money(i.amount*grossFactor(i))}</b></td>
                    <td><span className={"badge "+(i.status==='مدفوعة'?'ok':i.status==='مدفوعة جزئياً'?'neutral':i.status==='متأخرة'?'bad':'soon')}>{i.status}</span></td>
                    <td style={{fontSize:11}}>{i.invoiceNo||'—'}{i.receiptNo?' / '+i.receiptNo:''}</td>
                  </tr>
                ))}
              </tbody>
            </table>
            </div>
          </div>
        </div>
      )}

      {tab==='statement' && <StatementView data={data} fixedPid={p.id} />}

      {tab==='folder' && (
        <div className="card">
          <div className="section-title"><h3>مجلد مستندات المشروع</h3><div className="rule"></div></div>
          <p style={{fontSize:13, color:'var(--ink-soft)'}}>المستندات لا تُخزن داخل النظام — تُحفظ في مجلد المشروع على الجهاز:</p>
          <div style={{display:'flex', gap:10, alignItems:'center', flexWrap:'wrap', marginTop:8}}>
            <code style={{background:'var(--paper)', border:'1px solid var(--line-strong)', borderRadius:4, padding:'10px 16px', fontSize:15, fontWeight:700, direction:'ltr'}}>{folderPath}</code>
            <button className="btn brass" onClick={copyPath}>نسخ المسار</button>
            <button className="btn outline" onClick={openFolder}>محاولة فتح المجلد</button>
          </div>
          <p style={{fontSize:11.5, color:'var(--ink-faint)', marginTop:14}}>* اسم المجلد الافتراضي: "رقم المشروع - اسمه" وقابل للتخصيص من بيانات المشروع. زر الفتح المباشر يعمل غالباً إذا كان النظام مفتوحاً كملف محلي — وإن منعه المتصفح فانسخ المسار والصقه في الـ Explorer.</p>
        </div>
      )}
    </div>
  );
}

/* ================= Projects View (قائمة + ملف المشروع) ================= */
const recentGet = ()=>{ try{ return JSON.parse(localStorage.getItem('nitaq-recent')||'[]'); }catch(e){ return []; } };
const recentPush = (id)=>{ try{ const r = [id, ...recentGet().filter(x=>x!==id)].slice(0,6); localStorage.setItem('nitaq-recent', JSON.stringify(r)); }catch(e){} };

function ProjectsView({data, configs, mutate, jumpId, onJumpDone, role}){
  const [selected, setSelected] = useState(null);
  const [stFilter, setStFilter] = useState('');
  const m = mutate('projects');
  useEffect(()=>{ if(jumpId){ setSelected(jumpId); recentPush(jumpId); onJumpDone && onJumpDone(); } }, [jumpId]);
  const open = (id)=>{ recentPush(id); setSelected(id); };
  const sel = selected ? data.projects.find(p=>p.id===selected) : null;
  if(sel) return <ProjectProfile project={sel} data={data} configs={configs} mutate={mutate} onBack={()=>setSelected(null)} role={role} />;
  const recents = recentGet().map(id=>data.projects.find(p=>p.id===id)).filter(Boolean).filter(p=>!isArchived(p));
  const byStatus = stFilter ? data.projects.filter(p=>p.status===stFilter) : data.projects;
  const sortedRecords = [...byStatus].sort((a,b)=> (b.pinned?1:0)-(a.pinned?1:0));
  const updateProject = (id, vals)=>{
    const prev = data.projects.find(p=>p.id===id) || {};
    let patch = {...vals};
    if(vals.status==='منتهٍ' && !prev.archived){
      patch.archived = true; patch.autoArchivedOnFinish = true;
    } else if(vals.status!=='منتهٍ' && prev.archived && prev.autoArchivedOnFinish){
      patch.archived = false; patch.autoArchivedOnFinish = false;
    }
    m.update(id, patch);
  };
  const addProject = (rec)=> m.add(rec.status==='منتهٍ' ? {...rec, archived:true, autoArchivedOnFinish:true} : rec);
  return (
    <div>
      {recents.length>0 && (
        <div style={{display:'flex', gap:8, flexWrap:'wrap', alignItems:'center', marginBottom:14}}>
          <span style={{fontSize:11, fontWeight:800, color:'var(--ink-faint)', letterSpacing:.5}}>آخر المشاريع:</span>
          {recents.map(p=>(
            <button key={p.id} className="btn outline small" onClick={()=>open(p.id)}>
              {p.pinned?'⭐ ':''}{(p.projectNo?p.projectNo+' — ':'')+p.name}
            </button>
          ))}
        </div>
      )}
      <EntityView config={configs.projects} records={sortedRecords} data={data}
        onAdd={addProject} onUpdate={updateProject} onDelete={m.del}
        onRowClick={(row)=>open(row.id)}
        headExtra={
          <select value={stFilter} onChange={e=>setStFilter(e.target.value)}
            style={{border:'1px solid var(--line-strong)', borderRadius:4, padding:'7px 10px', fontSize:12.5, background:'#fff'}}>
            <option value="">كل الحالات</option>
            <option value="جارٍ">جارٍ فقط</option>
            <option value="منتهٍ">منتهٍ فقط</option>
            <option value="متوقف">متوقف فقط</option>
          </select>
        }
        rowActions={(row)=>(
          <React.Fragment>
            <button className="btn ghost small" title={row.pinned?'إزالة التثبيت':'تثبيت كمفضل (يظهر أول القائمة)'}
              style={{color:row.pinned?'var(--brass)':'var(--ink-faint)'}}
              onClick={()=>m.update(row.id, {pinned:!row.pinned})}>{row.pinned?'⭐':'☆'}</button>
            <button className="btn ghost small" title="فتح ملف المشروع" style={{color:'var(--brass)'}} onClick={()=>open(row.id)}><I.compass/></button>
          </React.Fragment>
        )}
      />
      <p style={{fontSize:12, color:'var(--ink-faint)', marginTop:14}}>* اضغط على أي مشروع لفتح ملفه الكامل: Timeline، الاعتمادات، العقود، الملف المالي، كشف الحساب، ومجلد المستندات. استخدم خانة البحث بالرقم أو الاسم أو المالك أو رقم القطعة. * أي مشروع تُغيّر حالته إلى "منتهٍ" ينتقل تلقائياً إلى الأرشيف ولا يظهر في القائمة الرئيسية — يمكن استعراضه عبر زر "مؤرشف" أعلى الجدول، أو تُعاد حالته لغير "منتهٍ" لإرجاعه تلقائياً.</p>
    </div>
  );
}

/* ================= Settings View ================= */
function SbConfigForm(){
  const cfg = getSbConfig() || {url:'', key:''};
  const [url, setUrl] = useState(cfg.url||'');
  const [key, setKey] = useState(cfg.key||'');
  const isDefault = cfg.url===DEFAULT_SB_CONFIG.url && cfg.key===DEFAULT_SB_CONFIG.key;
  const save = ()=>{
    if(url && key){ setSbConfig({url:url.trim(), key:key.trim()}); alert('تم الحفظ — سيُعاد تحميل النظام للاتصال بالسحابة'); window.location.reload(); }
    else if(!url && !key){ setSbConfig({disabled:true}); alert('تم إلغاء الربط السحابي على هذا الجهاز — سيعمل النظام محلياً بدون مزامنة'); window.location.reload(); }
    else alert('أدخل الرابط والمفتاح معاً، أو اتركهما فارغين لإلغاء الربط على هذا الجهاز فقط');
  };
  return (
    <div>
      {isDefault && (
        <p style={{fontSize:12, color:'var(--teal)', marginBottom:12}}>✓ متصل تلقائياً بإعداد الشركة الافتراضي — لا داعي لتغيير أي شيء هنا إلا لو تستخدم مشروع Supabase مختلف.</p>
      )}
      <div className="field" style={{marginBottom:12}}>
        <label>Project URL</label>
        <input value={url} onChange={e=>setUrl(e.target.value)} style={{direction:'ltr'}} placeholder="https://xxxx.supabase.co" />
      </div>
      <div className="field" style={{marginBottom:12}}>
        <label>Anon Public Key</label>
        <input value={key} onChange={e=>setKey(e.target.value)} style={{direction:'ltr'}} placeholder="eyJ..." />
      </div>
      <button className="btn brass" onClick={save}>حفظ والاتصال</button>
      <p style={{fontSize:11.5, color:'var(--ink-faint)', marginTop:12}}>الخطوات: supabase.com ← مشروع جديد (مجاني) ← SQL Editor ← تشغيل ملف nitaq-supabase-schema.sql ← ثم انسخ من Settings ← API: الـ URL والـ anon key وضعهما هنا. أول حساب يسجل يصبح المالك.</p>
    </div>
  );
}


function SettingsView({data, setSettings}){
  const [s, setS] = useState(Object.assign({projectsRoot:'D:\\Projects', bankName:'', iban:'', accountName:''}, data.settings||{}));
  const set = (k,v)=> setS(x=>({...x,[k]:v}));
  return (
    <div>
      <div className="card" style={{maxWidth:640, marginBottom:18}}>
        <div className="section-title"><h3>إعدادات النظام</h3><div className="rule"></div></div>
        <div className="field" style={{marginBottom:14}}>
          <label>المسار الرئيسي لمجلدات المشاريع</label>
          <input value={s.projectsRoot} onChange={e=>set('projectsRoot', e.target.value)} style={{direction:'ltr'}} />
          <div style={{fontSize:11, color:'var(--ink-faint)', marginTop:4}}>يدعم مسارات الشبكة مثل \\SERVER\Projects — مجلد كل مشروع = هذا المسار + "رقم المشروع - اسمه"</div>
        </div>
        <div className="section-title" style={{marginTop:22}}><h3>بيانات الحساب البنكي (تظهر على الفاتورة الضريبية)</h3><div className="rule"></div></div>
        <div className="field" style={{marginBottom:14}}>
          <label>اسم البنك</label>
          <input value={s.bankName} onChange={e=>set('bankName', e.target.value)} />
        </div>
        <div className="field" style={{marginBottom:14}}>
          <label>IBAN</label>
          <input value={s.iban} onChange={e=>set('iban', e.target.value)} style={{direction:'ltr'}} placeholder="AE.." />
        </div>
        <div className="field" style={{marginBottom:14}}>
          <label>اسم صاحب الحساب</label>
          <input value={s.accountName} onChange={e=>set('accountName', e.target.value)} />
        </div>
        <button className="btn brass" onClick={()=>{ setSettings(s); alert('تم حفظ الإعدادات'); }}>حفظ الإعدادات</button>
      </div>
      <div className="card" style={{maxWidth:640, marginBottom:18}}>
        <div className="section-title"><h3>الربط السحابي (Supabase) — للعمل الجماعي على أجهزة متعددة</h3><div className="rule"></div></div>
        <SbConfigForm />
      </div>
      <div className="card" style={{maxWidth:640}}>
        <div className="section-title"><h3>بيانات الشركة الثابتة (من شهادة التسجيل الضريبي)</h3><div className="rule"></div></div>
        <div className="info-grid">
          <div className="doc-line"><span className="lbl">الاسم القانوني</span><span className="val">{COMPANY.nameAr}</span></div>
          <div className="doc-line"><span className="lbl">TRN</span><span className="val">{COMPANY.trn}</span></div>
          <div className="doc-line"><span className="lbl">رقم الرخصة</span><span className="val">{COMPANY.license}</span></div>
          <div className="doc-line"><span className="lbl">الهاتف</span><span className="val">{COMPANY.phone2} / {COMPANY.phone}</span></div>
        </div>
      </div>
    </div>
  );
}

/* ================= تصدير Excel شامل ================= */
const loadXlsxLib = ()=> new Promise((resolve, reject)=>{
  if(window.XLSX) return resolve(window.XLSX);
  const s = document.createElement('script');
  s.src = 'https://cdnjs.cloudflare.com/ajax/libs/xlsx/0.18.5/xlsx.full.min.js';
  s.onload = ()=> resolve(window.XLSX);
  s.onerror = ()=> reject(new Error('تعذر تحميل مكتبة Excel — تحقق من اتصال الإنترنت'));
  document.head.appendChild(s);
});

const EXTRA_FIELD_AR = {id:'المعرف (تقني)', archived:'مؤرشف', archiveReason:'سبب الأرشفة/الإلغاء', archivedAt:'تاريخ الأرشفة',
  invoiceNo:'رقم الفاتورة', receiptNo:'رقم السند', collectedAmount:'المحصّل جزئياً (صافي)', paidDate:'تاريخ السداد',
  method:'طريقة الدفع', refNo:'المرجع', pinned:'مثبت كمفضل', closedAt:'تاريخ الإقفال', projectNo:'رقم المشروع',
  timeline:'مراحل Timeline', approvals:'الاعتمادات'};

async function exportExcelBackup(data, configs){
  const XLSX = await loadXlsxLib();
  const wb = XLSX.utils.book_new();
  wb.Workbook = {Views:[{RTL:true}]};
  const projName = (id)=>{ const p=data.projects.find(x=>x.id===id); return p ? (p.projectNo?p.projectNo+' — ':'')+p.name : ''; };
  const contractName = (id)=>{ const c=(data.contracts||[]).find(x=>x.id===id); return c ? (c.type||c.category||'عقد')+(c.contractor?' — '+c.contractor:'') : ''; };
  const empName = (id)=> id ? ((data.employees.find(e=>e.id===id)||{}).name || ((data.staffDir||[]).find(s=>s.empId===id)||{}).name || id) : '';
  const fmt = (k, v)=>{
    if(v===undefined || v===null || v==='') return '';
    if(k==='projectId') return projName(v);
    if(k==='contractId') return contractName(v);
    if(k==='employeeId' || k==='responsibleId' || k==='assignedTo') return empName(v) || v;
    if(v===true) return 'نعم';
    if(v===false) return 'لا';
    if(typeof v==='object') return JSON.stringify(v).slice(0, 500);
    return v;
  };
  const SHEETS = [['projects','المشاريع'],['contracts','العقود'],['payments','الدفعات'],['govFees','الرسوم الحكومية'],
    ['officeExpenses','مصروفات المكتب'],['projectCosts','تكاليف المشاريع'],['treasury','الخزينة'],
    ['employees','الموظفون'],['overtime','الأوفرتايم'],['advances','السلف'],['cars','السيارات'],['decisions','القرارات والوقائع'],
    ['otherIncome','الإيرادات الأخرى'],['recurringBills','الفواتير المتكررة'],['leaves','الإجازات'],['timesheets','ساعات العمل']];
  SHEETS.forEach(([key, name])=>{
    const recs = data[key]||[];
    const cfg = configs[key];
    const fieldOrder = cfg ? cfg.fields.map(f=>f.name) : [];
    const labels = {};
    if(cfg) cfg.fields.forEach(f=>{ labels[f.name] = f.label; });
    const extras = [];
    recs.forEach(r=> Object.keys(r).forEach(k=>{
      if(k!=='_ts' && k!=='docSnapshot' && k!=='id' && !fieldOrder.includes(k) && !extras.includes(k)) extras.push(k);
    }));
    const cols = [...fieldOrder, ...extras, 'id'];
    const rows = recs.map(r=>{
      const o = {};
      cols.forEach(k=>{ o[labels[k] || EXTRA_FIELD_AR[k] || k] = fmt(k, r[k]); });
      return o;
    });
    const ws = XLSX.utils.json_to_sheet(rows.length ? rows : [{'لا بيانات':''}]);
    ws['!cols'] = cols.map(()=>({wch:18}));
    XLSX.utils.book_append_sheet(wb, ws, name);
  });
  const attRows = [];
  Object.entries(data.attendance||{}).forEach(([empId, map])=>{
    Object.entries(map||{}).forEach(([dt, st])=> attRows.push({'الموظف':empName(empId)||empId, 'التاريخ':dt, 'الحالة':st}));
  });
  attRows.sort((a,b)=> (a['التاريخ']||'').localeCompare(b['التاريخ']||''));
  XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(attRows.length?attRows:[{'لا بيانات':''}]), 'الحضور');
  const audRows = [...(data.auditLog||[])].sort((a,b)=>(b._ts||0)-(a._ts||0)).map(r=>({'الوقت':r.at, 'المستخدم':r.user, 'العملية':r.action, 'القسم':ENTITY_AR[r.entity]||r.entity, 'التفاصيل':r.summary}));
  XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(audRows.length?audRows:[{'لا بيانات':''}]), 'سجل التدقيق');
  const setRows = Object.entries(data.settings||{}).map(([k,v])=>({'الإعداد':k, 'القيمة':String(v||'')}));
  XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(setRows.length?setRows:[{'لا بيانات':''}]), 'الإعدادات');
  XLSX.writeFile(wb, 'NITAQ-ERP-Backup-'+todayISO()+'.xlsx');
}

/* ===== تصدير قائمة مصروفات المكتب (شيت مطابقة للمحاسب) ===== */
async function exportOfficeExpensesXlsx(rows, meta){
  const XLSX = await loadXlsxLib();
  const wb = XLSX.utils.book_new();
  wb.Workbook = {Views:[{RTL:true}]};
  const payDetails = (r)=>{
    if(r.account==='شيك') return 'شيك '+(r.chequeNo||'—')+' — استحقاق '+(r.chequeDueDate||'—');
    if(r.account==='البنك') return [r.bankName, r.bankRef].filter(Boolean).join(' — ');
    return '';
  };
  const header = ['التاريخ','التصنيف','المورّد','رقم فاتورة المورّد','البيان','الحساب','اسم البنك','حالة السداد',
    'المبلغ قبل الضريبة','ض.ق.م 5%','المبلغ شامل الضريبة','دين علينا (شامل الضريبة)','تفاصيل الدفع'];
  const body = rows.map(r=>{
    const net = r.amount||0;
    const gross = expGross(r);
    const vat = Math.round((gross-net)*100)/100;
    return [ r.date||'', r.category||'', r.vendor||'', r.vendorInvoiceNo||'', r.note||'', r.account||'', r.bankName||'', r.payStatus||'',
      net, vat, gross, expDebt(r), payDetails(r) ];
  });
  const sum = (i)=> Math.round(body.reduce((s,row)=> s+(typeof row[i]==='number'?row[i]:0),0)*100)/100;
  const totals = ['الإجمالي','','','','','','','', sum(8), sum(9), sum(10), sum(11), ''];
  const ws = XLSX.utils.aoa_to_sheet([header, ...body, [], totals]);
  ws['!cols'] = [{wch:12},{wch:16},{wch:16},{wch:16},{wch:32},{wch:9},{wch:14},{wch:12},{wch:15},{wch:11},{wch:17},{wch:18},{wch:30}];
  XLSX.utils.book_append_sheet(wb, ws, 'مصروفات المكتب');
  const tag = (meta && meta.banks && meta.banks.length) ? '-'+meta.banks.join('_').replace(/\s+/g,'') : (meta && meta.filtered ? '-filtered' : '');
  XLSX.writeFile(wb, 'NITAQ-Office-Expenses-'+todayISO()+tag+'.xlsx');
}

/* ===== تصدير الإيرادات (نظرة عامة) — يحترم فلتر الفترة ===== */
async function exportRevenueXlsx({data, pays, inc, fromD, toD, payDate, summary}){
  const XLSX = await loadXlsxLib();
  const wb = XLSX.utils.book_new();
  wb.Workbook = {Views:[{RTL:true}]};
  const r2 = (n)=> Math.round((n||0)*100)/100;
  const projName = (id)=>{ const p=(data.projects||[]).find(x=>x.id===id); return p ? (p.projectNo?p.projectNo+' — ':'')+p.name : '—'; };
  const period = (fromD||toD) ? ((fromD||'البداية')+' ← '+(toD||'اليوم')) : 'كل الفترات';

  // 1) الملخص
  const sm = [
    ['ملخص الإيرادات — نطاق للاستشارات الهندسية'],
    ['الفترة', period],
    ['تاريخ التصدير', todayISO()],
    [],
    ['البند','القيمة (د.إ)'],
    ['إجمالي الإيرادات (صافي قبل الضريبة)', r2(summary.totalNet)],
    ['إجمالي الإيرادات (شامل الضريبة)', r2(summary.totalGross)],
    ['منها ضريبة القيمة المضافة', r2(summary.totalVat)],
    ['إيرادات المشاريع — مفوتر (صافي)', r2(summary.projBilled)],
    ['الإيرادات الأخرى (صافي)', r2(summary.otherNet)],
    ['محصّل من المشاريع (شامل الضريبة)', r2(summary.projCollected)],
    ['مستحق غير محصّل (شامل الضريبة)', r2(summary.projDue)],
  ];
  const ws1 = XLSX.utils.aoa_to_sheet(sm);
  ws1['!cols'] = [{wch:38},{wch:20}];
  XLSX.utils.book_append_sheet(wb, ws1, 'ملخص');

  // 2) دفعات المشاريع
  const h2 = ['التاريخ المعتمد في الفلتر','تاريخ الإصدار','تاريخ الاستلام','المشروع','المرحلة','وصف الدفعة','رقم الفاتورة','الحالة',
    'المبلغ قبل الضريبة','ض.ق.م','المبلغ شامل الضريبة','المحصّل (شامل الضريبة)','المتبقّي (شامل الضريبة)'];
  const b2 = [...pays].sort((a,b)=>payDate(a).localeCompare(payDate(b))).map(i=>{
    const net = billedOf(i), gf = grossFactor(i);
    return [payDate(i), i.date||'', i.paidDate||'', projName(i.projectId), i.phase||'', i.label||'', i.invoiceNo||'', i.status||'',
      r2(net), r2(net*(gf-1)), r2(net*gf), r2(collectedOf(i)*gf), r2(remainderOf(i)*gf)];
  });
  const sum2 = (k)=> r2(b2.reduce((s,row)=>s+(row[k]||0),0));
  const t2 = ['الإجمالي','','','','','','','', sum2(8), sum2(9), sum2(10), sum2(11), sum2(12)];
  const ws2 = XLSX.utils.aoa_to_sheet(b2.length ? [h2, ...b2, [], t2] : [h2, ['لا توجد دفعات في الفترة']]);
  ws2['!cols'] = [{wch:14},{wch:12},{wch:12},{wch:30},{wch:12},{wch:28},{wch:14},{wch:14},{wch:15},{wch:11},{wch:17},{wch:18},{wch:18}];
  XLSX.utils.book_append_sheet(wb, ws2, 'دفعات المشاريع');

  // 3) الإيرادات الأخرى
  const h3 = ['التاريخ','التصنيف','البيان','الجهة الدافعة','الحساب','المبلغ قبل الضريبة','ض.ق.م','المبلغ شامل الضريبة'];
  const b3 = [...inc].sort((a,b)=>(a.date||'').localeCompare(b.date||'')).map(r=>
    [r.date||'', r.category||'', r.note||'', r.payer||'', r.account||'', r2(r.amount), r2(incVat(r)), r2(incGross(r))]);
  const sum3 = (k)=> r2(b3.reduce((s,row)=>s+(row[k]||0),0));
  const t3 = ['الإجمالي','','','','', sum3(5), sum3(6), sum3(7)];
  const ws3 = XLSX.utils.aoa_to_sheet(b3.length ? [h3, ...b3, [], t3] : [h3, ['لا توجد إيرادات أخرى في الفترة']]);
  ws3['!cols'] = [{wch:12},{wch:20},{wch:32},{wch:20},{wch:10},{wch:16},{wch:11},{wch:18}];
  XLSX.utils.book_append_sheet(wb, ws3, 'الإيرادات الأخرى');

  const tag = (fromD||toD) ? '-'+(fromD||'start')+'_to_'+(toD||'today') : '-all';
  XLSX.writeFile(wb, 'NITAQ-Revenue'+tag+'.xlsx');
}

/* ================= البحث الشامل ================= */
function GlobalSearch({data, go, jumpToProject, navAllowed}){
  const [q, setQ] = useState('');
  const [open, setOpen] = useState(false);
  const query = q.trim().toLowerCase();
  const results = useMemo(()=>{
    if(query.length<2) return [];
    const out = [];
    const pn = (id)=>{ const p=data.projects.find(x=>x.id===id); return p ? (p.projectNo?p.projectNo+' — ':'')+p.name : ''; };
    data.projects.forEach(p=>{
      if(out.length>=14) return;
      const t = ((p.projectNo||'')+' '+(p.name||'')+' '+(p.owner||'')+' '+(p.plotNumber||'')+' '+(p.ownershipNumber||'')+' '+((p.additionalOwners||[]).map(o=>o.name||'').join(' '))).toLowerCase();
      if(t.includes(query)) out.push({kind:'مشروع', cls:'ok', text:(p.projectNo?p.projectNo+' — ':'')+p.name+(p.owner?' · '+p.owner:''), act:()=>jumpToProject(p.id)});
    });
    if(navAllowed('payments')) data.payments.forEach(i=>{
      if(out.length>=14) return;
      const t = ((i.label||'')+' '+(i.invoiceNo||'')+' '+(i.receiptNo||'')+' '+(i.refNo||'')).toLowerCase();
      if(t.includes(query)) out.push({kind:'دفعة', cls:'neutral', text:(i.invoiceNo||i.receiptNo||i.label||i.phase)+' · '+money(i.amount||0)+' · '+pn(i.projectId), act:()=>go('payments')});
    });
    (data.contracts||[]).forEach(c=>{
      if(out.length>=14) return;
      const t = ((c.type||'')+' '+(c.category||'')+' '+(c.description||'')+' '+(c.contractor||'')).toLowerCase();
      if(t.includes(query)) out.push({kind:'عقد', cls:'gray', text:(c.type||c.category||'عقد')+' · '+(c.contractor||c.description||'')+' · '+pn(c.projectId), act:()=>go('contracts')});
    });
    (data.decisions||[]).forEach(dc=>{
      if(out.length>=14) return;
      const t = ((dc.title||'')+' '+(dc.description||'')).toLowerCase();
      if(t.includes(query)) out.push({kind:'قرار', cls:'soon', text:(dc.title||'قرار')+' · '+pn(dc.projectId), act:()=>go('decisions')});
    });
    return out.slice(0,14);
  }, [query, data]);
  return (
    <div style={{position:'relative', minWidth:200, flex:'0 1 300px'}}>
      <input className="searchbox" style={{width:'100%'}} placeholder="🔍 بحث شامل: مشروع، فاتورة، عقد..."
        value={q}
        onChange={e=>{ setQ(e.target.value); setOpen(true); }}
        onFocus={()=>setOpen(true)}
        onBlur={()=>setTimeout(()=>setOpen(false), 200)} />
      {open && query.length>=2 && (
        <div style={{position:'absolute', top:'110%', insetInlineStart:0, insetInlineEnd:0, background:'#fff', border:'1px solid var(--line-strong)', borderRadius:6, boxShadow:'0 8px 28px rgba(13,27,62,.14)', zIndex:80, maxHeight:340, overflowY:'auto'}}>
          {results.length===0 && <div style={{padding:'12px 14px', fontSize:12.5, color:'var(--ink-faint)'}}>لا نتائج</div>}
          {results.map((r,i)=>(
            <div key={i} onMouseDown={()=>{ r.act(); setQ(''); setOpen(false); }}
              style={{padding:'9px 13px', fontSize:12.5, cursor:'pointer', borderBottom:'1px solid var(--line)', display:'flex', gap:8, alignItems:'center'}}
              onMouseEnter={e=>e.currentTarget.style.background='var(--paper)'}
              onMouseLeave={e=>e.currentTarget.style.background='#fff'}>
              <span className={"badge "+r.cls} style={{flexShrink:0}}>{r.kind}</span>
              <span style={{overflow:'hidden', textOverflow:'ellipsis', whiteSpace:'nowrap'}}>{r.text}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

/* ================= سجل التدقيق ================= */
function AuditView({data}){
  const [q, setQ] = useState('');
  const [actFilter, setActFilter] = useState('');
  const [open, setOpen] = useState({});
  const rows = useMemo(()=> [...(data.auditLog||[])].sort((a,b)=>(b._ts||0)-(a._ts||0)), [data.auditLog]);
  const query = q.trim().toLowerCase();
  const filtered = rows.filter(r=>{
    if(actFilter && r.action!==actFilter) return false;
    if(!query) return true;
    return ((r.user||'')+' '+(r.action||'')+' '+(ENTITY_AR[r.entity]||r.entity||'')+' '+(r.summary||'')).toLowerCase().includes(query);
  }).slice(0, 300);
  const ACT_CLS = {'إنشاء':'ok','تعديل':'neutral','أرشفة / إلغاء':'bad','استرجاع من الأرشيف':'soon','إصدار مستند':'gray','حذف نهائي':'bad'};
  const actions = [...new Set(rows.map(r=>r.action))];
  return (
    <div>
      <div className="toolbar">
        <div className="section-title" style={{marginBottom:0, flex:1}}><h3>سجل العمليات — {rows.length} عملية مسجلة</h3><div className="rule"></div></div>
        <input className="searchbox" placeholder="بحث بالمستخدم أو الوصف..." value={q} onChange={e=>setQ(e.target.value)} />
        <select value={actFilter} onChange={e=>setActFilter(e.target.value)}
          style={{border:'1px solid var(--line-strong)', borderRadius:4, padding:'7px 10px', fontSize:12.5, background:'#fff'}}>
          <option value="">كل العمليات</option>
          {actions.map(a=><option key={a} value={a}>{a}</option>)}
        </select>
      </div>
      <div className="card" style={{padding:0}}>
        <div style={{overflowX:'auto'}}>
        <table>
          <thead><tr><th style={{width:28}}></th><th>الوقت</th><th>المستخدم</th><th>العملية</th><th>القسم</th><th>التفاصيل</th></tr></thead>
          <tbody>
            {filtered.length===0 && <tr className="empty-row"><td colSpan={6}>{query||actFilter ? 'لا نتائج مطابقة' : 'لا عمليات مسجلة بعد — يبدأ التسجيل تلقائياً من الآن'}</td></tr>}
            {filtered.map(r=>{
              const hasDetail = Array.isArray(r.changes) && r.changes.length>0;
              return (
              <React.Fragment key={r.id}>
                <tr style={hasDetail?{cursor:'pointer'}:{}} onClick={hasDetail?()=>setOpen(o=>({...o,[r.id]:!o[r.id]})):undefined}>
                  <td style={{textAlign:'center', color:'var(--brass)', fontWeight:800}}>{hasDetail?(open[r.id]?'▾':'▸'):''}</td>
                  <td style={{whiteSpace:'nowrap', fontSize:11.5}}>{r.at}</td>
                  <td style={{fontWeight:700}}>{r.user}</td>
                  <td><span className={"badge "+(ACT_CLS[r.action]||'gray')}>{r.action}</span></td>
                  <td>{ENTITY_AR[r.entity]||r.entity}</td>
                  <td style={{fontSize:12, maxWidth:420}}>{r.summary||'—'}</td>
                </tr>
                {hasDetail && open[r.id] && (
                  <tr style={{background:'rgba(19,42,70,.02)'}}>
                    <td></td>
                    <td colSpan={5} style={{padding:'4px 10px 12px'}}>
                      <table style={{width:'100%', fontSize:11.5}}>
                        <thead><tr><th style={{width:'34%'}}>الحقل</th><th style={{width:'33%'}}>قبل</th><th style={{width:'33%'}}>بعد</th></tr></thead>
                        <tbody>
                          {r.changes.map((c,i)=>(
                            <tr key={i}>
                              <td style={{fontWeight:700}}>{c.field}</td>
                              <td style={{color:'var(--ink-faint)'}}>{c.before}</td>
                              <td style={{color:'var(--ink)', fontWeight:600}}>{c.after}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </td>
                  </tr>
                )}
              </React.Fragment>
            );})}
          </tbody>
        </table>
        </div>
      </div>
      <p style={{fontSize:11.5, color:'var(--ink-faint)', marginTop:12}}>* السجل غير قابل للتعديل أو الحذف — يعرض آخر 300 عملية، والبحث يشمل الكل. اضغط أي صف عليه سهم (▸) لعرض <b>كل القيم قبل وبعد التعديل</b> بالتفصيل. سجلات ما قبل تفعيل هذه الميزة تعرض الملخص فقط دون تفاصيل قبل/بعد.</p>
    </div>
  );
}

/* ================= مركز القيادة المالية ================= */
function buildFccItems(data){
  const items = [];
  const nowYM = currentYM();
  const projOf = (id)=> data.projects.find(p=>p.id===id) || {};
  const pLabel = (p)=> (p.projectNo?p.projectNo+' — ':'')+(p.name||'');

  data.payments.forEach(i=>{
    if(!isArchived(i) && i.projectId && !i.contractId && (i.phase==='تصميم'||i.phase==='إشراف')){
      const p0 = projOf(i.projectId);
      items.push({key:'noc-'+i.id, pr:'med', cat:'فواتير', dot:'🟣', date:i.date,
        text:'دفعة بلا عقد مرتبط — '+pLabel(p0)+' — '+(i.label||i.phase)+' ('+money(i.amount||0)+') — افتحها بزر التعديل واربطها بعقدها',
        actions:[{label:'فتح الدفعات', go:'payments'}]});
    }
    if(remainderOf(i)<=0) return;
    const dd = daysUntil(i.dueDate);
    const p = projOf(i.projectId);
    if(dd!==null && dd<0){
      items.push({key:'ovd-'+i.id, pr:'high', cat:'تحصيلات', dot:'🔴', date:i.dueDate,
        text:'دفعة متأخرة '+Math.abs(dd)+' يوم — '+pLabel(p)+' — متبقٍ '+money(remainderOf(i)*grossFactor(i)),
        actions:[{label:'فتح الدفعات', go:'payments'}]});
    } else if(dd!==null && dd<=7){
      items.push({key:'due-'+i.id, pr:'low', cat:'تحصيلات', dot:'🟢', date:i.dueDate,
        text:'دفعة تستحق خلال '+dd+' يوم — '+pLabel(p)+' ('+money(remainderOf(i)*grossFactor(i))+')',
        actions:[{label:'فتح الدفعات', go:'payments'}]});
    }
  });

  (data.contracts||[]).forEach(c=>{
    if(isArchived(c)) return;
    const p = projOf(c.projectId);
    if(contractHasSupervision(c) && c.status==='سارٍ' && isConsultancy(c) && p.status==='جارٍ' && projectReadyForSupervision(p)){
      const done = data.payments.filter(i=>!isArchived(i) && i.contractId===c.id && i.phase==='إشراف').length;
      if(done < (c.supervisionMonths||0) && !data.payments.some(i=>!isArchived(i) && i.contractId===c.id && i.phase==='إشراف' && i.month===nowYM)){
        items.push({key:'sup-'+c.id+'-'+nowYM, pr:'high', cat:'فواتير', dot:'🔴', date:todayISO(),
          text:'مطلوب إصدار دفعة إشراف '+fmtMonth(nowYM)+' — '+pLabel(p)+' ('+money(c.supervisionMonthly)+')',
          actions:[{label:'⚡ توليد الآن', gen:'supervision', contractId:c.id}]});
      }
    }
    const cm = contractCommission(c);
    if(cm>0){
      const invoiced = data.payments.filter(i=>i.contractId===c.id).reduce((s,i)=>s+billedOf(i),0);
      if(invoiced < cm*0.999){
        items.push({key:'comm-'+c.id, pr:'med', cat:'عقود', dot:'🟡', date:c.date,
          text:'عمولة غير مفوترة '+money(cm-invoiced)+' — عقد '+(c.subType?c.subType+' ':'')+(c.contractor||'')+' — '+pLabel(p),
          actions:[{label:'⚡ توليد دفعة العمولة', gen:'commission', contractId:c.id}]});
      }
    }
    if(isConsultancy(c) && c.type!=='إشراف' && c.status!=='ملغى' && !isArchived(c)){
      const target = isComboContract(c) ? (c.designValue||0) : (c.value||0);
      const billed = data.payments.filter(i=>i.contractId===c.id && i.phase!=='إشراف').reduce((s,i)=>s+billedOf(i),0);
      const stg = (p.timeline||{});
      const designDone = (stg.design&&stg.design.status==='مكتملة');
      if(designDone && billed < target*0.999 && target>0){
        items.push({key:'des-'+c.id, pr:'med', cat:'عقود', dot:'🟣', date:todayISO(),
          text:'التصميم مكتمل ومتبقٍ '+money(target-billed)+' غير مفوتر من عقد — '+pLabel(p),
          actions:[{label:'فتح المشروع', go:'projects'}]});
      }
    }
  });

  data.projects.forEach(p=>{
    const feesOut = data.govFees.filter(g=>g.projectId===p.id && !isArchived(g) && g.payerType!=='المالك مباشرة' && g.paidStatus==='مدفوع' && g.reimburseStatus!=='مسترد').reduce((s,g)=>s+(isArchived(g)?0:g.amount),0);
    if(feesOut>0) items.push({key:'gov-'+p.id, pr:'high', cat:'رسوم حكومية', dot:'⚫', date:todayISO(),
      text:'أمانات '+money(feesOut)+' مدفوعة من خزينتك ولم تُسترد — '+pLabel(p),
      actions:[{label:'فتح الرسوم', go:'govFees'}]});

    const costs = data.projectCosts.filter(e=>!isArchived(e) && e.projectId===p.id).reduce((s,e)=>s+(e.amount||0),0);
    if((p.budgetAmount||0)>0 && costs > p.budgetAmount){
      items.push({key:'bud-'+p.id, pr:'med', cat:'الميزانية', dot:'🔵', date:todayISO(),
        text:'تجاوز الميزانية بـ '+Math.round((costs/p.budgetAmount-1)*100)+'% — '+pLabel(p)+' (التكاليف '+money(costs)+' من '+money(p.budgetAmount)+')',
        actions:[{label:'فتح المشروع', go:'projects'}]});
    }
    const billedP = data.payments.filter(i=>!isArchived(i) && i.projectId===p.id).reduce((s,i)=>s+billedOf(i),0);
    if(p.status==='جارٍ' && billedP>10000){
      const margin = (billedP-costs-projectTimeCost(data, p.id))/billedP*100;
      if(margin<20) items.push({key:'mrg-'+p.id, pr:'med', cat:'الربحية', dot:'🟠', date:todayISO(),
        text:'هامش الربح الحقيقي انخفض إلى '+margin.toFixed(0)+'% — '+pLabel(p),
        actions:[{label:'فتح التحليلات', go:'analytics'}]});
    }
  });

  data.govFees.filter(g=>!isArchived(g) && g.payerType!=='المالك مباشرة' && g.paidStatus!=='مدفوع').forEach(g=>{
    const p = projOf(g.projectId);
    items.push({key:'govp-'+g.id, pr:'med', cat:'رسوم حكومية', dot:'🟠', date:g.date,
      text:'رسم '+g.department+' غير مسدد للدائرة ('+money(g.amount)+') — '+pLabel(p),
      actions:[{label:'فتح الرسوم', go:'govFees'}]});
  });

  listQuarters().forEach(q=>{
    if(quarterEndDate(q) < todayISO()){
      const dd = daysUntil(quarterDueDate(q));
      if(dd!==null && dd<=30) items.push({key:'vat-'+q, pr:'high', cat:'الضريبة', dot:'🔴', date:quarterDueDate(q),
        text:'إقرار ض.ق.م عن '+quarterLabel(q)+' — '+(dd<0?('متأخر '+Math.abs(dd)+' يوم'):('متبقٍ '+dd+' يوم')),
        actions:[{label:'فتح الضريبة', go:'vat'}]});
    }
  });

  const prOrder = {high:0, med:1, low:2};
  items.sort((a,b)=> prOrder[a.pr]-prOrder[b.pr] || (a.date||'').localeCompare(b.date||''));
  return items;
}

function FccView({data, mutate, go, setFcc}){
  const [prFilter, setPrFilter] = useState('');
  const [catFilter, setCatFilter] = useState('');
  const st = data.fccState || {};
  const all = buildFccItems(data);
  const visible = all.filter(it=>{
    const s = st[it.key];
    if(s && s.done) return false;
    if(s && s.snoozeUntil && s.snoozeUntil >= todayISO()) return false;
    if(prFilter && it.pr!==prFilter) return false;
    if(catFilter && it.cat!==catFilter) return false;
    return true;
  });
  const hiddenCount = all.length - all.filter(it=>{ const s=st[it.key]; return !(s&&(s.done||(s.snoozeUntil&&s.snoozeUntil>=todayISO()))); }).length;
  const cats = [...new Set(all.map(i=>i.cat))];
  const PR_AR = {high:'عاجل', med:'متوسط', low:'قريباً'};
  const PR_CLS = {high:'bad', med:'soon', low:'ok'};

  const mark = (key, patch)=> setFcc({...st, [key]:{...(st[key]||{}), ...patch}});
  const runGen = (it, act)=>{
    const c = (data.contracts||[]).find(x=>x.id===act.contractId);
    if(!c) return;
    const due = new Date(); due.setDate(due.getDate()+10);
    if(act.gen==='supervision'){
      if(data.payments.some(i=>!isArchived(i) && i.contractId===c.id && i.phase==='إشراف' && i.month===currentYM())){
        alert('دفعة إشراف هذا الشهر مولّدة بالفعل لهذا العقد'); return;
      }
      mutate('payments').add({id:uid(), projectId:c.projectId, contractId:c.id, phase:'إشراف', month:currentYM(),
        amount:c.supervisionMonthly, date:todayISO(), dueDate:due.toISOString().slice(0,10), status:'معلقة', _ts:Date.now()});
      alert('تم توليد دفعة الإشراف — تجدها في الدفعات');
    } else if(act.gen==='commission'){
      const cm = contractCommission(c);
      const invoiced = data.payments.filter(i=>i.contractId===c.id).reduce((s,i)=>s+billedOf(i),0);
      mutate('payments').add({id:uid(), projectId:c.projectId, contractId:c.id, phase:'أخرى',
        label:'عمولة الاستشاري — عقد '+(c.subType?c.subType+' ':'')+(c.contractor||''),
        amount:cm-invoiced, taxable:'خاضعة', date:todayISO(), dueDate:due.toISOString().slice(0,10), status:'معلقة', _ts:Date.now()});
      alert('تم توليد دفعة العمولة');
    }
  };

  return (
    <div>
      <div className="grid grid-4" style={{marginBottom:18}}>
        <div className="card"><div className="kpi-label">إجراءات عاجلة</div><div className="kpi-value" style={{color:'var(--rust)'}}>{visible.filter(i=>i.pr==='high').length}</div><div className="kpi-note">تحتاج تصرفاً اليوم</div></div>
        <div className="card"><div className="kpi-label">متوسطة الأولوية</div><div className="kpi-value" style={{color:'var(--amber, #B8860B)'}}>{visible.filter(i=>i.pr==='med').length}</div><div className="kpi-note">هذا الأسبوع</div></div>
        <div className="card"><div className="kpi-label">قادمة</div><div className="kpi-value" style={{color:'var(--teal)'}}>{visible.filter(i=>i.pr==='low').length}</div><div className="kpi-note">للمتابعة</div></div>
        <div className="card"><div className="kpi-label">منجزة / مؤجلة</div><div className="kpi-value">{hiddenCount}</div><div className="kpi-note">مخفاة من القائمة</div></div>
      </div>

      <div className="toolbar" style={{flexWrap:'wrap'}}>
        <div className="section-title" style={{marginBottom:0, flex:1}}><h3>ما الذي يحتاج تصرفاً؟</h3><div className="rule"></div></div>
        <select value={prFilter} onChange={e=>setPrFilter(e.target.value)}
          style={{border:'1px solid var(--line-strong)', borderRadius:4, padding:'7px 10px', fontSize:12.5, background:'#fff'}}>
          <option value="">كل الأولويات</option>
          <option value="high">عاجل</option><option value="med">متوسط</option><option value="low">قريباً</option>
        </select>
        <select value={catFilter} onChange={e=>setCatFilter(e.target.value)}
          style={{border:'1px solid var(--line-strong)', borderRadius:4, padding:'7px 10px', fontSize:12.5, background:'#fff'}}>
          <option value="">كل التصنيفات</option>
          {cats.map(c=><option key={c} value={c}>{c}</option>)}
        </select>
      </div>

      <div className="card">
        {visible.length===0 && <p style={{fontSize:13.5, color:'var(--teal)', margin:0, fontWeight:700}}>✓ لا توجد إجراءات مالية معلقة — كل شيء تحت السيطرة.</p>}
        {visible.map(it=>(
          <div key={it.key} style={{display:'flex', gap:10, alignItems:'flex-start', padding:'12px 0', borderBottom:'1px solid var(--line)', flexWrap:'wrap'}}>
            <span style={{fontSize:15, flexShrink:0}}>{it.dot}</span>
            <div style={{flex:1, minWidth:220}}>
              <div style={{fontSize:13.5}}>{it.text}</div>
              <div style={{fontSize:10.5, color:'var(--ink-faint)', marginTop:3}}>
                <span className={"badge "+PR_CLS[it.pr]} style={{marginInlineEnd:6}}>{PR_AR[it.pr]}</span>
                <span className="badge gray">{it.cat}</span>
              </div>
            </div>
            <div style={{display:'flex', gap:6, flexWrap:'wrap', alignItems:'center'}}>
              {it.actions.map((a,i)=> a.gen
                ? <button key={i} className="btn small brass" onClick={()=>runGen(it, a)}>{a.label}</button>
                : <button key={i} className="btn small outline" onClick={()=>go(a.go)}>{a.label}</button>
              )}
              <button className="btn ghost small" title="تأجيل 3 أيام" onClick={()=>{ const d=new Date(); d.setDate(d.getDate()+3); mark(it.key,{snoozeUntil:d.toISOString().slice(0,10)}); }}>⏰ تأجيل</button>
              <button className="btn ghost small" title="تم" style={{color:'var(--teal)'}} onClick={()=>mark(it.key,{done:true, at:todayISO()})}>✓ تم</button>
            </div>
          </div>
        ))}
      </div>
      <p style={{fontSize:11.5, color:'var(--ink-faint)', marginTop:12}}>* القائمة تتولد تلقائياً من بيانات النظام وتتحدث لحظياً — البنود المنجزة فعلياً (كسداد دفعة) تختفي وحدها، وزر "تم" لإخفاء ما عالجته خارج النظام. "تأجيل" يخفي البند 3 أيام.</p>
    </div>
  );
}

/* ================= التحليلات الذكية ================= */
function AnalyticsView({data}){
  const [lang, setLang] = useState('ar');

  /* --- ربحية المشاريع بالهوامش (شاملة تكلفة وقت المهندسين) --- */
  const margins = data.projects.map(p=>{
    const billed = data.payments.filter(i=>!isArchived(i) && i.projectId===p.id).reduce((s,i)=>s+billedOf(i),0);
    const directCosts = data.projectCosts.filter(e=>!isArchived(e) && e.projectId===p.id).reduce((s,e)=>s+(e.amount||0),0);
    const timeCost = projectTimeCost(data, p.id);
    const costs = directCosts + timeCost;
    const margin = billed>0 ? (billed-costs)/billed*100 : null;
    return {...p, billed, costs, directCosts, timeCost, profit:billed-costs, margin};
  }).filter(r=>r.billed>0).sort((a,b)=>(a.margin??100)-(b.margin??100));

  /* --- توقع التدفق النقدي 3 أشهر --- */
  const {bank, cash} = computeCashFlows(data);
  const startBal = bank+cash;
  const now = new Date();
  const next3 = [1,2,3].map(k=>{ const d=new Date(now.getFullYear(), now.getMonth()+k, 1); return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0'); });
  const avgOver = (arr, months)=>{
    const sums = months.map(m=> arr.filter(e=>monthKey(e.date)===m).reduce((s,e)=>s+e.amount,0));
    return sums.reduce((s,v)=>s+v,0)/months.length;
  };
  const prev3 = [1,2,3].map(k=>{ const d=new Date(now.getFullYear(), now.getMonth()-k, 1); return d.getFullYear()+'-'+String(d.getMonth()+1).padStart(2,'0'); });
  const avgOffice = avgOver(officeExpNoPayroll(data), prev3)*1.05;   // الرواتب تُضاف منفصلة (payrollNow)
  const avgProjCosts = avgOver(data.projectCosts.filter(e=>!isArchived(e)), prev3)*1.05;
  const payrollNow = computePayroll(data, currentYM()).totalNet;
  let running = startBal;
  const forecast = next3.map(m=>{
    const scheduled = data.payments.filter(i=> remainderOf(i)>0 && monthKey(i.dueDate)===m).reduce((s,i)=>s+remainderOf(i)*grossFactor(i),0);
    const supervision = (data.contracts||[]).filter(c=> contractHasSupervision(c) && c.status==='سارٍ' && isConsultancy(c))
      .filter(c=>{
        const proj = data.projects.find(p=>p.id===c.projectId);
        if(!proj || proj.status!=='جارٍ' || !projectReadyForSupervision(proj)) return false;
        const done = data.payments.filter(i=>!isArchived(i) && i.contractId===c.id && i.phase==='إشراف').length;
        return done < (c.supervisionMonths||0) && !data.payments.some(i=>i.contractId===c.id && i.month===m);
      }).reduce((s,c)=>s+(c.supervisionMonthly||0)*1.05,0);
    const inflow = scheduled + supervision;
    const outflow = avgOffice + avgProjCosts + payrollNow;
    running += inflow - outflow;
    return {m, inflow, outflow, net:inflow-outflow, balance:running};
  });

  /* --- مصروفات غير طبيعية --- */
  const nowYM = currentYM();
  const catTotals = (arr, m)=>{
    const t={}; arr.filter(e=>monthKey(e.date)===m).forEach(e=>{ t[e.category]=(t[e.category]||0)+e.amount; }); return t;
  };
  const anomalies = [];
  [['مصروفات المكتب', data.officeExpenses],['تكاليف المشاريع', data.projectCosts]].forEach(([label, arr])=>{
    const cur = catTotals(arr, nowYM);
    Object.entries(cur).forEach(([cat, amt])=>{
      const avg = prev3.reduce((s,m)=> s + (catTotals(arr,m)[cat]||0), 0)/3;
      if(amt>500 && avg>0 && amt > avg*1.5){
        anomalies.push({label, cat, amt, avg, pct: Math.round((amt/avg-1)*100)});
      } else if(amt>2000 && avg===0){
        anomalies.push({label, cat, amt, avg:0, pct:null});
      }
    });
  });

  /* --- اقتراحات الفوترة --- */
  const suggestions = [];
  (data.contracts||[]).filter(c=> contractHasSupervision(c) && c.status==='سارٍ' && isConsultancy(c)).forEach(c=>{
    const proj = data.projects.find(p=>p.id===c.projectId);
    if(!proj || proj.status!=='جارٍ' || !projectReadyForSupervision(proj)) return;
    const done = data.payments.filter(i=>!isArchived(i) && i.contractId===c.id && i.phase==='إشراف').length;
    if(done < (c.supervisionMonths||0) && !data.payments.some(i=>i.contractId===c.id && i.month===nowYM)){
      suggestions.push('إصدار فاتورة إشراف '+fmtMonth(nowYM)+' لمشروع '+(proj.projectNo||'')+' '+proj.name+' ('+money(c.supervisionMonthly)+') — زر التوليد في قسم الدفعات');
    }
  });
  (data.contracts||[]).filter(c=> c.status!=='ملغى' && !isArchived(c) && isConsultancy(c) && c.type!=='إشراف').map(c=> isComboContract(c) ? {...c, value:(c.designValue||0)} : c).forEach(c=>{
    const proj = data.projects.find(p=>p.id===c.projectId);
    if(!proj) return;
    const billed = data.payments.filter(i=>i.contractId===c.id).reduce((s,i)=>s+billedOf(i),0);
    const stg = (proj.timeline||{});
    const designDone = (stg.design&&stg.design.status==='مكتملة') || (stg.detailed&&stg.detailed.status==='مكتملة');
    if(designDone && billed < (c.value||0)*0.999){
      suggestions.push('مشروع '+(proj.projectNo||'')+' '+proj.name+': مرحلة التصميم مكتملة والمفوتر '+money(billed)+' من '+money(c.value)+' — متبقٍ '+money((c.value||0)-billed)+' يُنصح بفوترته');
    }
  });

  /* --- التقرير الشهري ثنائي اللغة --- */
  const ymNow = currentYM();
  const rev = data.payments.filter(i=>monthKey(i.date)===ymNow).reduce((s,i)=>s+billedOf(i),0);
  const offM = officeExpNoPayroll(data).filter(e=>monthKey(e.date)===ymNow).reduce((s,e)=>s+(e.amount||0),0);   // الرواتب منفصلة (payrollNow)
  const pcM = data.projectCosts.filter(e=>!isArchived(e) && monthKey(e.date)===ymNow).reduce((s,e)=>s+(e.amount||0),0);
  const netM = rev - offM - pcM - payrollNow;
  const recv = data.projects.reduce((s,p)=> s + data.payments.filter(i=>!isArchived(i) && i.projectId===p.id).reduce((x,i)=>x+remainderOf(i)*grossFactor(i),0), 0);
  const amanat = data.govFees.filter(g=>!isArchived(g) && g.payerType!=='المالك مباشرة' && g.paidStatus==='مدفوع' && g.reimburseStatus!=='مسترد').reduce((s,g)=>s+(isArchived(g)?0:g.amount),0);
  const T = lang==='ar' ? {
    rpt:'التقرير الشهري — الإدارة المالية', period:'الفترة', rev:'الإيرادات الاستشارية المفوترة', off:'مصروفات المكتب', pc:'تكاليف المشاريع المباشرة',
    pay:'صافي الرواتب', net:'صافي الشهر (تقديري)', liq:'السيولة الحالية (بنك + خزينة)', recv:'مستحقات لدى العملاء', amn:'أمانات لم تُسترد',
    proj:'المشاريع الجارية', print:'طباعة التقرير', sw:'English'
  } : {
    rpt:'Monthly Report — Financial Management', period:'Period', rev:'Billed Consultancy Revenue', off:'Office Expenses', pc:'Direct Project Costs',
    pay:'Net Payroll', net:'Month Net (Estimate)', liq:'Current Liquidity (Bank + Cash)', recv:'Client Receivables', amn:'Unrecovered Deposits',
    proj:'Active Projects', print:'Print Report', sw:'العربية'
  };

  return (
    <div>
      <div className="grid grid-4" style={{marginBottom:18}}>
        <div className="card"><div className="kpi-label">أدنى هامش ربح</div><div className="kpi-value" style={{fontSize:19, color:(margins[0]&&margins[0].margin<20)?'var(--rust)':'var(--teal)'}}>{margins[0]&&margins[0].margin!==null?margins[0].margin.toFixed(0)+'%':'—'}</div><div className="kpi-note">{margins[0]?margins[0].name:''}</div></div>
        <div className="card"><div className="kpi-label">الرصيد المتوقع بعد 3 أشهر</div><div className="kpi-value" style={{fontSize:19, color:forecast[2]&&forecast[2].balance>=0?'var(--teal)':'var(--rust)'}}>{forecast[2]?money(forecast[2].balance):'—'}</div><div className="kpi-note">من {money(startBal)} حالياً</div></div>
        <div className="card"><div className="kpi-label">مصروفات غير طبيعية</div><div className="kpi-value" style={{fontSize:19, color:anomalies.length?'var(--rust)':'var(--teal)'}}>{anomalies.length}</div><div className="kpi-note">هذا الشهر مقابل متوسط 3 أشهر</div></div>
        <div className="card"><div className="kpi-label">اقتراحات فوترة</div><div className="kpi-value" style={{fontSize:19, color:'var(--brass)'}}>{suggestions.length}</div><div className="kpi-note">فرص تحصيل جاهزة</div></div>
      </div>

      {(()=>{
        const consCons = (data.contracts||[]).filter(c=> c.status!=='ملغى' && !isArchived(c) && isConsultancy(c));
        const contracted = consCons.reduce((s,c)=>s+contractTotalOf(c),0)
          + (data.contracts||[]).filter(c=>c.category&&c.category!=='خدمات استشارية').reduce((s,c)=>s+contractCommission(c),0);
        const invoiced = data.payments.reduce((s,i)=>s+billedOf(i),0);
        const uninvoiced = Math.max(0, contracted - invoiced);
        const collected = data.payments.reduce((s,i)=>s+collectedOf(i)*grossFactor(i),0);
        const outstanding = data.payments.reduce((s,i)=>s+remainderOf(i)*grossFactor(i),0);
        const horizon = (days)=>{
          const lim = new Date(); lim.setDate(lim.getDate()+days);
          const limS = lim.toISOString().slice(0,10);
          return data.payments.filter(i=>remainderOf(i)>0 && i.dueDate && i.dueDate<=limS).reduce((s,i)=>s+remainderOf(i)*grossFactor(i),0);
        };
        return (
          <div>
            <div className="section-title"><h3 style={{fontSize:13.5}}>خط الإيرادات — من التعاقد إلى التحصيل</h3><div className="rule"></div></div>
            <div className="grid grid-4" style={{marginBottom:10}}>
              <div className="card"><div className="kpi-label">إجمالي المتعاقد عليه</div><div className="kpi-value" style={{fontSize:18}}>{money(contracted)}</div><div className="kpi-note">عقود استشارية + عمولات المقاولين</div></div>
              <div className="card"><div className="kpi-label">المفوتر / غير المفوتر</div><div className="kpi-value" style={{fontSize:18}}>{money(invoiced)}</div><div className="kpi-note" style={{color:uninvoiced>0?'var(--rust)':'var(--ink-faint)'}}>متبقٍ بلا فوترة: {money(uninvoiced)}</div></div>
              <div className="card"><div className="kpi-label">المحصّل (شامل الضريبة)</div><div className="kpi-value" style={{fontSize:18, color:'var(--teal)'}}>{money(collected)}</div><div className="kpi-note">مستحق غير محصّل: {money(outstanding)}</div></div>
              <div className="card"><div className="kpi-label">تحصيلات متوقعة</div><div className="kpi-value" style={{fontSize:15}}>{money(horizon(30))}</div><div className="kpi-note">خلال 30 يوم · 60: {money(horizon(60))} · 90: {money(horizon(90))}</div></div>
            </div>
            {(()=>{
              const done = data.payments.filter(i=>!isArchived(i) && i.paidDate && i.date && collectedOf(i)>0);
              const dso = done.length ? Math.round(done.reduce((s,i)=>{
                const d = (new Date(i.paidDate) - new Date(i.date))/86400000;
                return s + Math.max(0, d);
              },0)/done.length) : null;
              const outs = data.payments.filter(i=>remainderOf(i)>0 && i.dueDate);
              let wSum=0, wTot=0;
              outs.forEach(i=>{
                const age = Math.max(0, -(daysUntil(i.dueDate)||0));
                const w = remainderOf(i)*grossFactor(i);
                wSum += age*w; wTot += w;
              });
              const arAge = wTot>0 ? Math.round(wSum/wTot) : null;
              return (
                <p style={{fontSize:11.5, color:'var(--ink-faint)', marginBottom:22}}>
                  * قيم عقود المقاولين نفسها خارج هذا الخط بالكامل — تدخل عمولاتها فقط.
                  {dso!==null && <span> · <b style={{color:'var(--ink-soft)'}}>متوسط أيام التحصيل (DSO): {dso} يوم</b> من تاريخ الفاتورة للاستلام</span>}
                  {arAge!==null && <span> · <b style={{color: arAge>30 ? 'var(--rust)' : 'var(--ink-soft)'}}>متوسط تأخر الذمم القائمة: {arAge} يوم</b> (مرجّح بالمبالغ)</span>}
                </p>
              );
            })()}
          </div>
        );
      })()}

      <div className="section-title"><h3 style={{fontSize:13.5}}>هوامش ربح المشاريع (الأقل أولاً)</h3><div className="rule"></div></div>
      <div className="card" style={{padding:0, marginBottom:22}}>
        <table>
          <thead><tr><th>المشروع</th><th>المفوتر</th><th>تكاليف مباشرة</th><th>تكلفة الوقت</th><th>الربح الحقيقي</th><th>الهامش</th></tr></thead>
          <tbody>
            {margins.length===0 && <tr className="empty-row"><td colSpan={6}>لا بيانات كافية</td></tr>}
            {margins.map(r=>(
              <tr key={r.id}>
                <td>{(r.projectNo?r.projectNo+' — ':'')+r.name}</td>
                <td>{money(r.billed)}</td>
                <td>{money(r.directCosts)}</td>
                <td style={{color:r.timeCost>0?'var(--rust)':'var(--ink-faint)'}}>{money(r.timeCost)}</td>
                <td style={{color:r.profit>=0?'var(--teal)':'var(--rust)', fontWeight:700}}>{money(r.profit)}</td>
                <td>{r.margin!==null ? <span className={"badge "+(r.margin<20?'bad':r.margin<40?'soon':'ok')}>{r.margin.toFixed(0)}%</span> : '—'}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="section-title"><h3 style={{fontSize:13.5}}>توقع التدفق النقدي — الأشهر الثلاثة القادمة</h3><div className="rule"></div></div>
      <div className="card" style={{padding:0, marginBottom:8}}>
        <table>
          <thead><tr><th>الشهر</th><th>وارد متوقع</th><th>صادر متوقع</th><th>الصافي</th><th>الرصيد التراكمي</th></tr></thead>
          <tbody>
            {forecast.map(f=>(
              <tr key={f.m}>
                <td>{fmtMonth(f.m)}</td>
                <td style={{color:'var(--teal)'}}>{money(f.inflow)}</td>
                <td style={{color:'var(--rust)'}}>{money(f.outflow)}</td>
                <td style={{fontWeight:700, color:f.net>=0?'var(--teal)':'var(--rust)'}}>{money(f.net)}</td>
                <td style={{fontWeight:800, color:f.balance>=0?'var(--ink)':'var(--rust)'}}>{money(f.balance)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <p style={{fontSize:11.5, color:'var(--ink-faint)', marginBottom:22}}>* الوارد = الدفعات المستحقة حسب تواريخها + دفعات الإشراف الشهرية للعقود السارية. الصادر = متوسط مصروفات آخر 3 أشهر + رواتب الشهر الحالي. توقع استرشادي وليس التزاماً.</p>

      <div className="grid grid-2" style={{marginBottom:22}}>
        <div className="card">
          <div className="section-title"><h3>مصروفات غير طبيعية هذا الشهر</h3><div className="rule"></div></div>
          {anomalies.length===0 && <p style={{fontSize:12.5, color:'var(--ink-faint)'}}>لا توجد مصروفات شاذة — الإنفاق ضمن النمط المعتاد.</p>}
          {anomalies.map((a,i)=>(
            <div className="alert-item" key={i}>
              <span>{a.label} — {a.cat}: {money(a.amt)} {a.pct!==null ? '(أعلى من المتوسط بـ '+a.pct+'%)' : '(بند جديد غير معتاد)'}</span>
              <span className="badge bad">راجِع</span>
            </div>
          ))}
        </div>
        <div className="card">
          <div className="section-title"><h3>اقتراحات إصدار الفواتير</h3><div className="rule"></div></div>
          {suggestions.length===0 && <p style={{fontSize:12.5, color:'var(--ink-faint)'}}>لا توجد اقتراحات حالياً — الفوترة مواكبة للإنجاز.</p>}
          {suggestions.map((s,i)=>(
            <div className="alert-item" key={i}>
              <span>{s}</span>
              <span className="badge soon">فوترة</span>
            </div>
          ))}
        </div>
      </div>

      <div className="toolbar">
        <div className="section-title" style={{marginBottom:0, flex:1}}><h3 style={{fontSize:13.5}}>{T.rpt}</h3><div className="rule"></div></div>
        <button className="btn outline no-print" onClick={()=>setLang(lang==='ar'?'en':'ar')}>{T.sw}</button>
        <button className="btn brass no-print" onClick={()=>window.print()}><I.print/> {T.print}</button>
      </div>
      <div className="doc" dir={lang==='ar'?'rtl':'ltr'}>
        <div className="doc-head">
          <div className="doc-brand">
            <img src={NITAQ_LOGO} alt="نطاق" style={{height:56}} />
            <div>
              <h1>{lang==='ar'?COMPANY.nameAr:COMPANY.nameEn}</h1>
              <p>TRN: {COMPANY.trn}</p>
            </div>
          </div>
          <div className="doc-type">
            <div className="t">{T.rpt}</div>
            <div className="n">{T.period}: {fmtMonth(ymNow)} · {todayISO()}</div>
          </div>
        </div>
        <div className="doc-body">
          <table>
            <tbody>
              <tr><td>{T.rev}</td><td style={{textAlign:'left'}}>{money(rev)}</td></tr>
              <tr><td>{T.off}</td><td style={{textAlign:'left'}}>−{money(offM)}</td></tr>
              <tr><td>{T.pc}</td><td style={{textAlign:'left'}}>−{money(pcM)}</td></tr>
              <tr><td>{T.pay}</td><td style={{textAlign:'left'}}>−{money(payrollNow)}</td></tr>
              <tr style={{fontWeight:800}}><td>{T.net}</td><td style={{textAlign:'left', color:netM>=0?'var(--teal)':'var(--rust)'}}>{money(netM)}</td></tr>
              <tr><td>{T.liq}</td><td style={{textAlign:'left'}}>{money(startBal)}</td></tr>
              <tr><td>{T.recv}</td><td style={{textAlign:'left'}}>{money(recv)}</td></tr>
              <tr><td>{T.amn}</td><td style={{textAlign:'left'}}>{money(amanat)}</td></tr>
              <tr><td>{T.proj}</td><td style={{textAlign:'left'}}>{data.projects.filter(p=>p.status==='جارٍ').length}</td></tr>
            </tbody>
          </table>
        </div>
        <div className="doc-foot">
          <span>SHARJAH · UAE | {COMPANY.phone2} | {COMPANY.phone} | {COMPANY.email}</span>
          <span className="tag">{COMPANY.tagline}</span>
        </div>
      </div>
    </div>
  );
}

/* ================= Project Revenue View (إيرادات المشاريع) ================= */
/* ================= صفحة الإيرادات الموحّدة (ملخّص + تبويبات) ================= */
function RevenueHub({data, configs, mutate}){
  const [tab, setTab] = useState('overview');   // overview | projects | other

  // ===== فلتر الفترة (نظرة عامة فقط) — نفس منطق تبويب إيرادات المشاريع =====
  const [fromD, setFromD] = useState('');
  const [toD, setToD] = useState('');
  const inRange = (d)=> (!fromD || (d||'') >= fromD) && (!toD || (d||'') <= toD);
  const anyPeriod = !!(fromD || toD);
  const setPreset = (k)=>{
    const t = todayISO(); const y = t.slice(0,4); const m = parseInt(t.slice(5,7),10);
    const pad = (n)=> String(n).padStart(2,'0');
    const lastDay = (yy,mm)=> pad(new Date(parseInt(yy,10), mm, 0).getDate());
    if(k==='all'){ setFromD(''); setToD(''); }
    else if(k==='month'){ setFromD(y+'-'+pad(m)+'-01'); setToD(y+'-'+pad(m)+'-'+lastDay(y,m)); }
    else if(k==='quarter'){ const q0=Math.floor((m-1)/3)*3+1, q1=q0+2; setFromD(y+'-'+pad(q0)+'-01'); setToD(y+'-'+pad(q1)+'-'+lastDay(y,q1)); }
    else if(k==='year'){ setFromD(y+'-01-01'); setToD(y+'-12-31'); }
  };
  const isCollectedPay = (i)=> i.status==='مدفوعة' || i.status==='مدفوعة جزئياً';
  // المحصّلة تُفلتر بتاريخ التحصيل الفعلي؛ المعلّقة بتاريخ الإصدار
  const payDate = (i)=> (isCollectedPay(i) ? (i.paidDate || i.date) : i.date) || '';

  // إيرادات المشاريع الاستشارية
  const pays = (data.payments||[]).filter(i=>!isArchived(i) && i.status!=='ملغاة' && inRange(payDate(i)));
  const projBilled = pays.reduce((s,i)=>s+billedOf(i),0);                       // مفوتر (صافي)
  const projCollected = pays.reduce((s,i)=>s+collectedOf(i)*grossFactor(i),0);  // محصّل (شامل الضريبة)
  const projDue = pays.reduce((s,i)=>s+remainderOf(i)*grossFactor(i),0);        // مستحق غير محصّل (شامل)
  // الإيرادات الأخرى
  const inc = (data.otherIncome||[]).filter(r=>!isArchived(r) && inRange(r.date));
  const otherNet = inc.reduce((s,r)=>s+(r.amount||0),0);          // صافي
  const otherGross = inc.reduce((s,r)=>s+incGross(r),0);          // شامل الضريبة (محصّل فعلاً عادةً)
  // الإجمالي الكلي (صافي قبل الضريبة لمقارنة متجانسة)
  const totalNet = projBilled + otherNet;
  // الإجمالي شامل الضريبة (المفوتر من المشاريع + الإيرادات الأخرى، كلٌّ حسب خضوعه)
  const projBilledGross = pays.reduce((s,i)=>s+billedOf(i)*grossFactor(i),0);
  const totalGross = projBilledGross + otherGross;
  const totalVat = totalGross - totalNet;
  const pctProj = totalNet>0 ? Math.round(projBilled/totalNet*100) : 0;
  const pctOther = totalNet>0 ? Math.round(otherNet/totalNet*100) : 0;

  const tabBtn = (v,label)=>(
    <button onClick={()=>setTab(v)} style={{padding:'8px 16px', fontSize:13, fontWeight:700, border:'none', borderBottom:'2.5px solid '+(tab===v?'var(--brass)':'transparent'), background:'transparent', color:tab===v?'var(--ink)':'var(--ink-soft)', cursor:'pointer', fontFamily:'inherit'}}>{label}</button>
  );

  return (
    <div>
      <div className="section-title no-print"><h3>الإيرادات</h3><div className="rule"></div></div>

      {/* شريط التبويبات */}
      <div className="no-print" style={{display:'flex', gap:4, borderBottom:'1px solid var(--line)', marginBottom:16}}>
        {tabBtn('overview','نظرة عامة')}
        {tabBtn('projects','إيرادات المشاريع')}
        {tabBtn('other','الإيرادات الأخرى')}
      </div>

      {tab==='overview' && (
        <div>
          {/* شريط فلتر الفترة */}
          <div className="card no-print" style={{marginBottom:14, display:'flex', flexWrap:'wrap', alignItems:'center', gap:10, padding:'12px 14px'}}>
            <span style={{fontSize:13, fontWeight:800, color:'var(--ink)'}}>📅 الفترة:</span>
            {[['month','الشهر ده'],['quarter','الربع ده'],['year','السنة دي'],['all','الكل']].map(([k,l])=>(
              <button key={k} className="btn outline" style={{padding:'5px 12px', fontSize:12}} onClick={()=>setPreset(k)}>{l}</button>
            ))}
            <span style={{fontSize:12, color:'var(--ink-soft)', marginInlineStart:6}}>من</span>
            <input type="date" value={fromD} onChange={e=>setFromD(e.target.value)} style={{padding:'5px 8px', fontSize:12, fontFamily:'inherit', border:'1px solid var(--line-strong)', borderRadius:6}} />
            <span style={{fontSize:12, color:'var(--ink-soft)'}}>إلى</span>
            <input type="date" value={toD} onChange={e=>setToD(e.target.value)} style={{padding:'5px 8px', fontSize:12, fontFamily:'inherit', border:'1px solid var(--line-strong)', borderRadius:6}} />
            {anyPeriod && <span style={{fontSize:12, color:'var(--brass)', fontWeight:700}}>معروض: {fromD||'البداية'} ← {toD||'اليوم'}</span>}
            <button className="btn" style={{padding:'6px 14px', fontSize:12.5, marginInlineStart:'auto'}}
              onClick={async ()=>{ try{ await exportRevenueXlsx({data, pays, inc, fromD, toD, payDate,
                summary:{totalNet, totalGross, totalVat, projBilled, otherNet, projCollected, projDue}}); }catch(e){ alert('تعذّر التصدير: '+e.message); } }}>
              ⬇ تصدير Excel{anyPeriod?' (الفترة المختارة)':' (الكل)'}
            </button>
          </div>
          <div className="grid" style={{gridTemplateColumns:'repeat(auto-fit, minmax(160px, 1fr))', marginBottom:16}}>
            <div className="card"><div className="kpi-label">إجمالي الإيرادات (صافي){anyPeriod?' (مفلتر)':''}</div><div className="kpi-value" style={{color:'var(--teal)'}}>{money(totalNet)}</div><div className="kpi-note">المشاريع + الأخرى — قبل الضريبة</div></div>
            <div className="card"><div className="kpi-label">إجمالي الإيرادات (شامل الضريبة){anyPeriod?' (مفلتر)':''}</div><div className="kpi-value" style={{color:'var(--teal)'}}>{money(totalGross)}</div><div className="kpi-note">منها ضريبة: {money(totalVat)}</div></div>
            <div className="card"><div className="kpi-label">إيرادات المشاريع (مفوتر)</div><div className="kpi-value" style={{color:'var(--ink)'}}>{money(projBilled)}</div><div className="kpi-note">{pctProj}% من الإجمالي</div></div>
            <div className="card"><div className="kpi-label">الإيرادات الأخرى</div><div className="kpi-value" style={{color:'var(--ink)'}}>{money(otherNet)}</div><div className="kpi-note">{pctOther}% من الإجمالي</div></div>
            <div className="card"><div className="kpi-label">محصّل من المشاريع</div><div className="kpi-value" style={{color:'var(--teal)'}}>{money(projCollected)}</div><div className="kpi-note" style={{color:projDue>0?'var(--rust)':'var(--ink-faint)'}}>مستحق غير محصّل: {money(projDue)}</div></div>
          </div>

          {/* رسم نسبة أنواع الإيراد */}
          {totalNet===0 && anyPeriod && (
            <div className="card" style={{marginBottom:16, fontSize:13, color:'var(--ink-soft)'}}>لا توجد إيرادات في الفترة المختارة.</div>
          )}
          {totalNet>0 && (
            <div className="card" style={{marginBottom:16}}>
              <div style={{fontSize:13, fontWeight:800, color:'var(--ink)', marginBottom:12}}>📊 توزيع الإيرادات حسب النوع</div>
              {[
                {label:'إيرادات المشاريع الاستشارية', val:projBilled, pct:pctProj, col:'var(--brass)'},
                {label:'الإيرادات الأخرى (غير تشغيلية)', val:otherNet, pct:pctOther, col:'var(--teal)'},
              ].map(r=>(
                <div key={r.label} style={{marginBottom:12}}>
                  <div style={{display:'flex', justifyContent:'space-between', fontSize:12.5, marginBottom:4}}>
                    <span style={{color:'var(--ink)'}}>{r.label}</span>
                    <span style={{color:'var(--ink-soft)'}}><b>{money(r.val)}</b> · {r.pct}%</span>
                  </div>
                  <div style={{height:10, background:'var(--line)', borderRadius:6, overflow:'hidden'}}>
                    <div style={{height:'100%', width:r.pct+'%', background:r.col, borderRadius:6}}></div>
                  </div>
                </div>
              ))}
              <div style={{display:'flex', justifyContent:'space-between', fontSize:13, fontWeight:800, paddingTop:10, marginTop:4, borderTop:'1.5px solid var(--line-strong)'}}>
                <span>الإجمالي الكلي (صافي)</span><span style={{color:'var(--teal)'}}>{money(totalNet)}</span>
              </div>
            </div>
          )}

          <p style={{fontSize:12, color:'var(--ink-faint)'}}>* الإيرادات مفصولة في العرض (تشغيلي من المشاريع / غير تشغيلي أخرى) للحفاظ على وضوح ربحية النشاط الأساسي، ومجمّعة في الإجمالي الكلي وفي الإقرار الضريبي — وهو المعيار المحاسبي المتّبع. فلتر الفترة: الدفعات المحصّلة بتاريخ استلامها، والدفعات غير المحصّلة بتاريخ إصدارها، والإيرادات الأخرى بتاريخ البند — نفس منطق تبويب «إيرادات المشاريع». اضغطي التبويبات بالأعلى للتفصيل الكامل.</p>
        </div>
      )}

      {tab==='projects' && <ProjectRevenueView data={data} />}
      {tab==='other' && <OtherIncomeView data={data} configs={configs} mutate={mutate} />}
    </div>
  );
}

function ProjectRevenueView({data}){
  const [pid, setPid] = useState('');
  const [phase, setPhase] = useState('');        // تصميم / إشراف / أخرى
  const [status, setStatus] = useState('');      // محصّل / معلّق
  const [acct, setAcct] = useState('');          // البنك / الخزينة
  const [fromD, setFromD] = useState('');
  const [toD, setToD] = useState('');
  const [expanded, setExpanded] = useState({});

  const acctOf = (i)=> i.account || 'البنك';     // الدفعات القديمة تُعتبر بنك
  const isCollected = (i)=> i.status==='مدفوعة' || i.status==='مدفوعة جزئياً';

  const phaseLabel = (p)=> p==='إشراف' ? 'إشراف' : p==='أخرى' ? 'رسوم أخرى' : 'تصميم واعتماد';

  // الإيراد = الدفعات الاستشارية فقط (المقاولون والأمانات مستبعدون تماماً)، والملغى مستبعد
  const rows = useMemo(()=>{
    return (data.payments||[]).filter(i=>{
      if(isArchived(i)) return false;
      if(i.status==='ملغاة') return false;   // الدفعة الملغاة (شيك مرتجع / فسخ عقد) مستبعدة من الإيرادات والضريبة
      if(pid && i.projectId!==pid) return false;
      if(phase && i.phase!==phase) return false;
      if(status==='collected' && !isCollected(i)) return false;
      if(status==='pending' && isCollected(i)) return false;
      if(acct && acctOf(i)!==acct) return false;
      // المحصّلة تُفلتر بتاريخ التحصيل الفعلي؛ المعلّقة بتاريخ الإصدار حتى لا تختفي من المتبقّي
      const d = (isCollected(i) ? (i.paidDate || i.date) : i.date) || '';
      if(fromD && d < fromD) return false;
      if(toD && d > toD) return false;
      return true;
    });
  }, [data.payments, pid, phase, status, acct, fromD, toD]);

  // تجميع حسب المشروع
  const groups = useMemo(()=>{
    const map = {};
    rows.forEach(i=>{
      const k = i.projectId||'—';
      if(!map[k]) map[k] = {pid:k, items:[], invoiced:0, collected:0, remaining:0, vat:0};
      const g = map[k];
      const net = i.amount||0;
      g.items.push(i);
      g.invoiced  += net;
      g.collected += collectedOf(i);
      g.remaining += remainderOf(i);
      g.vat       += net * vatRateOf(i);
    });
    const proj = (id)=> (data.projects||[]).find(p=>p.id===id);
    return Object.values(map).map(g=>{
      const p = proj(g.pid) || {};
      return {...g, projectNo:p.projectNo||'', name:p.name||'—', owner:p.owner||'—', emirate:p.emirate||''};
    }).sort((a,b)=> (a.projectNo||0)-(b.projectNo||0));
  }, [rows, data.projects]);

  const tot = useMemo(()=> groups.reduce((s,g)=>({
    invoiced:s.invoiced+g.invoiced, collected:s.collected+g.collected, remaining:s.remaining+g.remaining, vat:s.vat+g.vat, count:s.count+g.items.length
  }), {invoiced:0, collected:0, remaining:0, vat:0, count:0}), [groups]);

  const bankCollected = useMemo(()=> rows.filter(i=>acctOf(i)==='البنك').reduce((s,i)=>s+collectedOf(i),0), [rows]);
  const cashCollected = useMemo(()=> rows.filter(i=>acctOf(i)==='الخزينة').reduce((s,i)=>s+collectedOf(i),0), [rows]);

  const toggle = (k)=> setExpanded(e=>({...e, [k]:!e[k]}));
  const reset = ()=>{ setPid(''); setPhase(''); setStatus(''); setAcct(''); setFromD(''); setToD(''); };

  const anyFilter = pid||phase||status||acct||fromD||toD;
  const filterDesc = [
    pid ? 'مشروع: '+((data.projects.find(p=>p.id===pid)||{}).name||'') : '',
    phase ? 'النوع: '+phaseLabel(phase) : '',
    status==='collected' ? 'المحصّل فقط' : status==='pending' ? 'المعلّق فقط' : '',
    acct ? 'الحساب: '+acct : '',
    (fromD||toD) ? ('الفترة: '+(fromD||'البداية')+' ← '+(toD||'الآن')) : '',
  ].filter(Boolean).join(' · ') || 'كل الإيرادات';

  const selEl = {border:'1px solid var(--line-strong)', borderRadius:4, padding:'7px 10px', fontSize:12.5, background:'#fff'};

  return (
    <div>
      {/* شريط الأدوات والفلاتر */}
      <div className="toolbar no-print" style={{flexWrap:'wrap', gap:10}}>
        <div className="section-title" style={{marginBottom:0, flex:'1 1 100%'}}><h3>إيرادات المشاريع</h3><div className="rule"></div></div>
        <select value={pid} onChange={e=>setPid(e.target.value)} style={selEl}>
          <option value="">كل المشاريع</option>
          {data.projects.map(p=><option key={p.id} value={p.id}>{(p.projectNo?p.projectNo+' — ':'')+p.name}</option>)}
        </select>
        <select value={phase} onChange={e=>setPhase(e.target.value)} style={selEl}>
          <option value="">كل الأنواع</option>
          <option value="تصميم">تصميم واعتماد</option>
          <option value="إشراف">إشراف</option>
          <option value="أخرى">رسوم أخرى</option>
        </select>
        <select value={status} onChange={e=>setStatus(e.target.value)} style={selEl}>
          <option value="">كل الحالات</option>
          <option value="collected">المحصّل</option>
          <option value="pending">المعلّق / المتأخر</option>
        </select>
        <select value={acct} onChange={e=>setAcct(e.target.value)} style={selEl}>
          <option value="">كل الحسابات</option>
          <option value="البنك">البنك</option>
          <option value="الخزينة">الخزينة</option>
        </select>
        <span style={{fontSize:12, color:'var(--ink-soft)'}}>من</span>
        <input type="date" value={fromD} onChange={e=>setFromD(e.target.value)} style={selEl} />
        <span style={{fontSize:12, color:'var(--ink-soft)'}}>إلى</span>
        <input type="date" value={toD} onChange={e=>setToD(e.target.value)} style={selEl} />
        {anyFilter && <button className="btn ghost small" onClick={reset}>مسح الفلاتر</button>}
        <button className="btn outline" onClick={()=>window.print()}><I.print/> طباعة</button>
      </div>

      {/* ترويسة الطباعة فقط */}
      <div className="print-only" style={{display:'none'}}>
        <div className="doc-head" style={{marginBottom:16}}>
          <div className="doc-brand">
            <img src={NITAQ_LOGO} alt="نطاق" style={{height:56}} />
            <div><h1>نطاق للاستشارات الهندسية</h1><p>NITAQ ENGINEERING CONSULTANTS · {COMPANY.trn}</p></div>
          </div>
          <div className="doc-type"><div className="t">تقرير إيرادات المشاريع</div><div className="n">صادر بتاريخ {todayISO()}</div></div>
        </div>
        <p style={{fontSize:12, margin:'0 0 12px'}}>نطاق التقرير: {filterDesc}</p>
      </div>

      {/* بطاقات الإجماليات */}
      <div className="grid grid-4" style={{marginBottom:18}}>
        <div className="card">
          <div className="kpi-label">إجمالي المفوتر (صافي)</div>
          <div className="kpi-value" style={{fontSize:19}}>{money(tot.invoiced)}</div>
          <div className="kpi-note">{tot.count} دفعة · {groups.length} مشروع</div>
        </div>
        <div className="card">
          <div className="kpi-label">إجمالي المحصّل (صافي)</div>
          <div className="kpi-value" style={{fontSize:19, color:'var(--teal)'}}>{money(tot.collected)}</div>
          <div className="kpi-note">بنك {money(bankCollected)} · خزينة {money(cashCollected)}</div>
        </div>
        <div className="card">
          <div className="kpi-label">المتبقّي (صافي)</div>
          <div className="kpi-value" style={{fontSize:19, color:tot.remaining>0?'var(--rust)':'var(--teal)'}}>{money(tot.remaining)}</div>
          <div className="kpi-note">قيد التحصيل</div>
        </div>
        <div className="card">
          <div className="kpi-label">ضريبة المخرجات على المفوتر</div>
          <div className="kpi-value" style={{fontSize:19, color:'var(--blue)'}}>{money(tot.vat)}</div>
          <div className="kpi-note">5% على الدفعات الخاضعة</div>
        </div>
      </div>

      {/* الجدول المُجمّع القابل للتفصيل */}
      <div className="card" style={{padding:0}}>
        <div className="rev-scroll" style={{overflowX:'auto'}}>
        <table className="rev-table">
          <thead><tr>
            <th style={{width:32}}></th><th>المشروع</th><th>المالك</th><th>عدد الدفعات</th>
            <th>المفوتر (صافي)</th><th>المحصّل (صافي)</th><th>المتبقّي (صافي)</th><th>ض.ق.م</th>
          </tr></thead>
          <tbody>
            {groups.length===0 && <tr className="empty-row"><td colSpan={8}>لا توجد إيرادات مطابقة للفلاتر المختارة</td></tr>}
            {groups.map(g=>(
              <React.Fragment key={g.pid}>
                <tr style={{cursor:'pointer'}} onClick={()=>toggle(g.pid)}>
                  <td style={{textAlign:'center', color:'var(--brass)', fontWeight:800}}>{expanded[g.pid]?'▾':'▸'}</td>
                  <td><b>{(g.projectNo?g.projectNo+' — ':'')+g.name}</b></td>
                  <td>{g.owner}</td>
                  <td>{g.items.length}</td>
                  <td>{money(g.invoiced)}</td>
                  <td style={{color:'var(--teal)', fontWeight:700}}>{money(g.collected)}</td>
                  <td style={{color:g.remaining>0?'var(--rust)':'var(--teal)', fontWeight:700}}>{money(g.remaining)}</td>
                  <td>{money(g.vat)}</td>
                </tr>
                {expanded[g.pid] && g.items.slice().sort((a,b)=>(a.date||'').localeCompare(b.date||'')).map(i=>(
                  <tr key={i.id} style={{background:'rgba(19,42,70,.02)', fontSize:12}}>
                    <td></td>
                    <td>
                      <span className={"badge "+(i.phase==='إشراف'?'neutral':i.phase==='أخرى'?'soon':'gray')}>{phaseLabel(i.phase)}</span>
                      <span style={{marginInlineStart:6}}>{i.phase==='إشراف' ? (i.month?fmtMonth(i.month):'') : (i.label||'')}</span>
                    </td>
                    <td>{i.date}</td>
                    <td>
                      {isCollected(i)
                        ? <span className="badge ok">{i.status==='مدفوعة جزئياً'?'محصّل جزئياً':'محصّل'}</span>
                        : <span className={"badge "+(i.status==='متأخرة'?'bad':'soon')}>{i.status}</span>}
                    </td>
                    <td>{money(i.amount||0)}</td>
                    <td style={{color:'var(--teal)'}}>{money(collectedOf(i))}</td>
                    <td style={{color:remainderOf(i)>0?'var(--rust)':'var(--teal)'}}>{money(remainderOf(i))}</td>
                    <td>{isCollected(i) ? <span className="badge gray">{acctOf(i)}</span> : '—'}</td>
                  </tr>
                ))}
              </React.Fragment>
            ))}
          </tbody>
          {groups.length>0 && (
            <tfoot>
              <tr style={{fontWeight:800, background:'rgba(19,42,70,.04)'}}>
                <td></td><td>الإجمالي</td><td></td><td>{tot.count}</td>
                <td>{money(tot.invoiced)}</td>
                <td style={{color:'var(--teal)'}}>{money(tot.collected)}</td>
                <td style={{color:tot.remaining>0?'var(--rust)':'var(--teal)'}}>{money(tot.remaining)}</td>
                <td>{money(tot.vat)}</td>
              </tr>
            </tfoot>
          )}
        </table>
        </div>
      </div>

      <p style={{fontSize:12, color:'var(--ink-faint)', marginTop:14}}>* الإيراد هنا = الدفعات الاستشارية فقط (تصميم/إشراف/رسوم أخرى). عقود المقاولين والرسوم الحكومية (الأمانات) لا تُحتسب ضمن الإيرادات. الدفعات الملغاة مستبعدة. "المحصّل" هو ما دخل فعلاً موزّعاً على البنك/الخزينة — والدفعات القديمة قبل إضافة حقل الحساب تُعتبر بنكاً افتراضياً. فلتر الفترة يعتمد على <b>تاريخ التحصيل</b> للدفعات المحصّلة، وعلى <b>تاريخ الإصدار</b> للدفعات المعلّقة حتى تبقى ظاهرة في المتبقّي. المبالغ صافية قبل الضريبة ما لم يُذكر غير ذلك. اضغط أي مشروع لعرض دفعاته.</p>
    </div>
  );
}

/* ================= Reports View ================= */
function ReportsView({data}){
  const [fromYm, setFromYm] = useState(currentYM());
  const [toYm, setToYm] = useState(currentYM());
  const inRange = (d)=>{ const k=monthKey(d); return k>=fromYm && k<=toYm; };
  const monthsInRange = (()=>{
    const arr=[]; let [y,m]=fromYm.split('-').map(Number);
    const [ty,tm]=toYm.split('-').map(Number);
    let guard=0;
    while((y<ty || (y===ty && m<=tm)) && guard<120){ arr.push(y+'-'+String(m).padStart(2,'0')); m++; if(m>12){m=1;y++;} guard++; }
    return arr;
  })();
  const payIn = data.payments.filter(i=>inRange(i.date));
  const designRev = payIn.filter(p=>p.phase==='تصميم').reduce((s,i)=>s+billedOf(i),0);
  const supervRev = payIn.filter(p=>p.phase==='إشراف').reduce((s,i)=>s+billedOf(i),0);
  const otherRev = payIn.filter(p=>p.phase==='أخرى').reduce((s,i)=>s+billedOf(i),0);
  const otherIncomeM = (data.otherIncome||[]).filter(r=>!isArchived(r) && inRange(r.date)).reduce((s,r)=>s+(r.amount||0),0);
  const projCostsM = data.projectCosts.filter(e=>!isArchived(e) && inRange(e.date)).reduce((s,e)=>s+(e.amount||0),0);
  const officeM = officeExpNoPayroll(data).filter(e=>inRange(e.date)).reduce((s,e)=>s+(e.amount||0),0);   // بدون قيود الرواتب (تُحتسب في payrollCost) وبدون المؤرشف
  const payrollCost = monthsInRange.reduce((s,m)=>s+computePayroll(data,m).totalNet,0);
  const gross = designRev + supervRev + otherRev + otherIncomeM - projCostsM;
  const net = gross - officeM - payrollCost;
  const rangeLabel = fromYm===toYm ? fmtMonth(fromYm) : ('من '+fmtMonth(fromYm)+' إلى '+fmtMonth(toYm));

  const projRows = useMemo(()=> data.projects.map(p=>{
    const dPaid = data.payments.filter(i=>!isArchived(i) && i.projectId===p.id && i.phase==='تصميم').reduce((s,i)=>s+billedOf(i),0);
    const sPaid = data.payments.filter(i=>!isArchived(i) && i.projectId===p.id && i.phase==='إشراف').reduce((s,i)=>s+billedOf(i),0);
    const oPaid = data.payments.filter(i=>!isArchived(i) && i.projectId===p.id && i.phase==='أخرى').reduce((s,i)=>s+billedOf(i),0);
    const sCount = data.payments.filter(i=>!isArchived(i) && i.projectId===p.id && i.phase==='إشراف').length;
    const spent = data.projectCosts.filter(e=>!isArchived(e) && e.projectId===p.id).reduce((s,e)=>s+(e.amount||0),0);
    const cons = (data.contracts||[]).filter(c=>c.projectId===p.id && c.status!=='ملغى' && !isArchived(c) && (isConsultancy(c)));
    const contract = cons.length>0
      ? cons.reduce((s,c)=> s + contractTotalOf(c), 0)
      : (p.designFee||0) + (p.supervisionMonthly||0)*(p.supervisionMonths||0);
    const supMonths = cons.filter(c=>contractHasSupervision(c)).reduce((s,c)=>s+(c.supervisionMonths||0),0) || (p.supervisionMonths||0);
    return {...p, dPaid, sPaid, oPaid, sCount, spent, contract, supMonths, profit:dPaid+sPaid+oPaid-spent};
  }), [data.projects, data.payments, data.projectCosts, data.contracts]);

  const govRows = data.projects.map(p=>{
    const fees = data.govFees.filter(g=>g.projectId===p.id);
    const total = fees.reduce((s,g)=>s+(isArchived(g)?0:g.amount),0);
    const paid = fees.filter(g=>g.paidStatus==='مدفوع').reduce((s,g)=>s+(isArchived(g)?0:g.amount),0);
    const reimb = fees.filter(g=>g.reimburseStatus==='مسترد').reduce((s,g)=>s+(isArchived(g)?0:g.amount),0);
    const outst = fees.filter(g=>!isArchived(g) && g.payerType!=='المالك مباشرة' && g.paidStatus==='مدفوع' && g.reimburseStatus!=='مسترد').reduce((s,g)=>s+(isArchived(g)?0:g.amount),0);
    return {...p, total, paid, reimb, outst, count:fees.length};
  }).filter(r=>r.count>0);

  return (
    <div>
      <div className="toolbar">
        <div className="section-title" style={{marginBottom:0, flex:1}}><h3>التقارير المالية</h3><div className="rule"></div></div>
        <div style={{display:'flex', gap:10, alignItems:'center', flexWrap:'wrap'}}>
          <span style={{fontSize:12, color:'var(--ink-soft)'}}>من</span>
          <input type="month" value={fromYm} onChange={e=>setFromYm(e.target.value)} />
          <span style={{fontSize:12, color:'var(--ink-soft)'}}>إلى</span>
          <input type="month" value={toYm} onChange={e=>setToYm(e.target.value)} />
          <button className="btn outline no-print" onClick={()=>window.print()}><I.print/> طباعة</button>
        </div>
      </div>

      <div className="section-title"><h3 style={{fontSize:13.5}}>قائمة الدخل — {rangeLabel}</h3><div className="rule"></div></div>
      <div className="card" style={{marginBottom:24}}>
        <table>
          <tbody>
            <tr><td>إيرادات التصميم واعتماد المخططات</td><td style={{textAlign:'left'}}>{money(designRev)}</td></tr>
            <tr><td>إيرادات الإشراف الشهري</td><td style={{textAlign:'left'}}>{money(supervRev)}</td></tr>
            <tr><td>إيرادات رسوم أخرى (فحوصات وخدمات خارجية)</td><td style={{textAlign:'left'}}>{money(otherRev)}</td></tr>
            <tr><td>إيرادات أخرى غير تشغيلية (بيع أصول، إيجار فرعي، عمولات…)</td><td style={{textAlign:'left'}}>{money(otherIncomeM)}</td></tr>
            <tr><td>تكاليف المشاريع المباشرة</td><td style={{textAlign:'left'}}>−{money(projCostsM)}</td></tr>
            <tr style={{fontWeight:700}}><td>مجمل الربح</td><td style={{textAlign:'left'}}>{money(gross)}</td></tr>
            <tr><td>مصروفات المكتب العمومية</td><td style={{textAlign:'left'}}>−{money(officeM)}</td></tr>
            <tr><td>صافي الرواتب للفترة (وفق كشف الرواتب الفعلي)</td><td style={{textAlign:'left'}}>−{money(payrollCost)}</td></tr>
            <tr style={{fontWeight:800, fontSize:15}}><td>صافي الربح / الخسارة</td><td style={{textAlign:'left', color:net>=0?'var(--teal)':'var(--rust)'}}>{money(net)}</td></tr>
          </tbody>
        </table>
        <p style={{fontSize:11.5, color:'var(--ink-faint)', marginTop:10, marginBottom:0}}>* الرسوم الحكومية أمانات لا تظهر ضمن الإيرادات أو المصروفات.</p>
      </div>

      <div className="section-title"><h3 style={{fontSize:13.5}}>ربحية المشاريع (تراكمي)</h3><div className="rule"></div></div>
      <div className="card" style={{padding:0, marginBottom:24}}>
        <div style={{overflowX:'auto'}}>
        <table>
          <thead><tr><th>المشروع</th><th>قيمة العقد</th><th>محصّل التصميم</th><th>محصّل الإشراف</th><th>رسوم أخرى</th><th>تقدم الإشراف</th><th>تكاليف مباشرة</th><th>الربح</th></tr></thead>
          <tbody>
            {projRows.map(p=>(
              <tr key={p.id}>
                <td>{(p.projectNo?p.projectNo+' — ':'')+p.name}</td>
                <td>{money(p.contract)}</td>
                <td>{money(p.dPaid)}</td>
                <td>{money(p.sPaid)}</td>
                <td>{money(p.oPaid)}</td>
                <td>{p.supMonths>0 ? (
                  <span>
                    {p.sCount} من {p.supMonths} شهر
                    <div className="progress" style={{width:70}}><div style={{width:Math.min(100,(p.sCount/p.supMonths)*100)+'%'}}></div></div>
                  </span>
                ) : '—'}</td>
                <td>{money(p.spent)}</td>
                <td style={{color:p.profit>=0?'var(--teal)':'var(--rust)', fontWeight:700}}>{money(p.profit)}</td>
              </tr>
            ))}
          </tbody>
        </table>
        </div>
      </div>

      <div className="section-title"><h3 style={{fontSize:13.5}}>الرسوم الحكومية حسب المشروع (أمانات)</h3><div className="rule"></div></div>
      <div className="card" style={{padding:0}}>
        <table>
          <thead><tr><th>المشروع</th><th>إجمالي الرسوم</th><th>مدفوع للدوائر</th><th>مسترد من العميل</th><th>معلق الاسترداد</th></tr></thead>
          <tbody>
            {govRows.length===0 && <tr className="empty-row"><td colSpan={5}>لا توجد رسوم حكومية مسجلة</td></tr>}
            {govRows.map(r=>(
              <tr key={r.id}>
                <td>{r.name}</td>
                <td>{money(r.total)}</td>
                <td>{money(r.paid)}</td>
                <td>{money(r.reimb)}</td>
                <td style={{color:r.outst>0?'var(--rust)':'var(--teal)', fontWeight:700}}>{money(r.outst)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

/* ================= Payroll View ================= */
function PayslipDoc({row, ym, data, onBack}){
  const e = row.emp;
  const lb = computeLeaveBalance(data, e.id);
  const earnings = [
    {k:'إجمالي الراتب'+(row.prorateDays!=null?(' ('+row.prorateDays+' من '+row.prorateDim+' يوم — من '+fmt(row.fullGross)+')'):''), v:row.gross},
    {k:'الأوفرتايم', v:row.ot},
  ];
  const deductions = [
    {k:'خصم الغياب ('+row.absentDays+' يوم)', v:row.absenceDeduction},
    {k:'السلف (مقطوعة)', v:row.advances},
    {k:'قسط السلف المقسّطة', v:row.installments||0},
    {k:'الخصومات', v:row.deductions},
  ];
  const totalEarn = earnings.reduce((s,x)=>s+x.v,0);
  const totalDed = deductions.reduce((s,x)=>s+x.v,0);
  // حماية الأجور: الصافي يجب ألا يقل عن 85% من الراتب التعاقدي (الإجمالي)
  const contract = row.gross||0;
  const wpsThreshold = contract*0.85;
  const wpsPct = contract>0 ? (row.net/contract)*100 : 0;
  const wpsOk = contract>0 && row.net>=wpsThreshold;
  return (
    <div>
      <div className="toolbar no-print">
        <button className="btn outline" onClick={onBack}>← رجوع للرواتب</button>
        <button className="btn brass" onClick={()=>window.print()}><I.print/> طباعة كشف الراتب</button>
      </div>
      <div className="sinv">
        <div className="sinv-top">
          <div className="sinv-co">
            <div className="n">{COMPANY.nameAr}</div>
            <div className="ne">NITAQ ENGINEERING CONSULTANCY</div>
            <div className="meta">TRN: {COMPANY.trn} &nbsp;·&nbsp; رخصة {COMPANY.license}<br/>{COMPANY.address}</div>
          </div>
          <div className="sinv-logo"><img src={NITAQ_LOGO} alt="NITAQ" /></div>
        </div>
        <div className="sinv-tag">كشف راتب — <span className="en">PAYSLIP</span> · {fmtMonth(ym)}</div>
        <div className="sinv-info">
          <div>
            <div className="row"><span className="k">الموظف</span><span className="v">{e.name}</span></div>
            <div className="row"><span className="k">الوظيفة</span><span className="v">{e.position||'—'}</span></div>
            <div className="row"><span className="k">الراتب الأساسي</span><span className="v">{fmt(row.base!=null?row.base:e.baseSalary)}</span></div>
            <div className="row"><span className="k">تاريخ التعيين</span><span className="v">{e.hireDate||'—'}</span></div>
          </div>
          <div>
            <div className="row"><span className="k">رقم الإقامة</span><span className="v">{e.iqamaNumber||'—'}</span></div>
            <div className="row"><span className="k">الآيبان</span><span className="v">{e.iban||'—'}</span></div>
            <div className="row"><span className="k">رصيد الإجازة السنوي</span><span className="v">{lb.remaining} / {lb.entitled} يوم</span></div>
          </div>
        </div>
        <div style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap:0}}>
          <table>
            <thead><tr><th>الاستحقاقات</th><th style={{textAlign:'left'}}>د.إ</th></tr></thead>
            <tbody>
              {earnings.map((x,i)=><tr key={i}><td>{x.k}</td><td style={{textAlign:'left'}}>{fmt(x.v)}</td></tr>)}
              <tr style={{fontWeight:800, background:'rgba(19,42,70,.03)'}}><td>إجمالي الاستحقاقات</td><td style={{textAlign:'left'}}>{fmt(totalEarn)}</td></tr>
            </tbody>
          </table>
          <table>
            <thead><tr><th>الاستقطاعات</th><th style={{textAlign:'left'}}>د.إ</th></tr></thead>
            <tbody>
              {deductions.map((x,i)=><tr key={i}><td>{x.k}</td><td style={{textAlign:'left'}}>{fmt(x.v)}</td></tr>)}
              <tr style={{fontWeight:800, background:'rgba(19,42,70,.03)'}}><td>إجمالي الاستقطاعات</td><td style={{textAlign:'left'}}>{fmt(totalDed)}</td></tr>
            </tbody>
          </table>
        </div>
        <div className="sinv-tot">
          <div className="box">
            <div className="r"><span>إجمالي الاستحقاقات</span><span>AED {fmt(totalEarn)}</span></div>
            <div className="r"><span>إجمالي الاستقطاعات</span><span>AED {fmt(totalDed)}</span></div>
            <div className="r grand"><span>صافي الراتب</span><span>AED {fmt(row.net)}</span></div>
          </div>
        </div>
        <div className="sinv-words">المبلغ كتابةً: فقط {tafqeet(row.net)}</div>
        {(()=>{ const pl = salaryPaymentsForEmp(data, e.id, ym, row.net); const paid = salaryPaidForEmp(data, e.id, ym, row.net); const rem = Math.max(0, row.net-paid);
          if(!pl.length) return null;
          return (
            <div style={{margin:'4px 26px 14px'}}>
              <table>
                <thead><tr><th>دفعات صرف الراتب</th><th>الحساب</th><th style={{textAlign:'left'}}>د.إ</th></tr></thead>
                <tbody>
                  {pl.map((x,i)=><tr key={i}><td>{x.date||'—'} — {x.via}</td><td>{x.account==='الخزينة'?'نقدي':(x.bankName||x.account||'—')}</td><td style={{textAlign:'left'}}>{fmt(x.amount)}</td></tr>)}
                  <tr style={{fontWeight:800}}><td colSpan={2}>المتبقّي من الصافي</td><td style={{textAlign:'left'}}>{fmt(rem)}</td></tr>
                </tbody>
              </table>
            </div>);
        })()}

        {contract>0 && (
          <div style={{margin:'4px 26px 14px', border:'1px solid '+(wpsOk?'var(--teal)':'var(--rust)'), borderRadius:6, overflow:'hidden'}}>
            <div style={{background:wpsOk?'var(--teal)':'var(--rust)', color:'#fff', fontWeight:800, fontSize:12, padding:'6px 10px', textAlign:'center'}}>
              حماية الأجور (WPS) — الحد الأدنى 85% من الراتب التعاقدي
            </div>
            <div style={{display:'flex', flexWrap:'wrap', fontSize:12}}>
              <div style={{flex:1, minWidth:110, padding:'7px 10px', borderInlineEnd:'1px solid var(--line)', textAlign:'center'}}>
                <div style={{fontSize:10, color:'var(--ink-soft)'}}>الراتب التعاقدي</div>
                <div style={{fontWeight:700}}>{fmt(contract)}</div>
              </div>
              <div style={{flex:1, minWidth:110, padding:'7px 10px', borderInlineEnd:'1px solid var(--line)', textAlign:'center'}}>
                <div style={{fontSize:10, color:'var(--ink-soft)'}}>الصافي المدفوع</div>
                <div style={{fontWeight:700}}>{fmt(row.net)}</div>
              </div>
              <div style={{flex:1, minWidth:80, padding:'7px 10px', borderInlineEnd:'1px solid var(--line)', textAlign:'center'}}>
                <div style={{fontSize:10, color:'var(--ink-soft)'}}>النسبة</div>
                <div style={{fontWeight:700, color:wpsOk?'var(--teal)':'var(--rust)'}}>{wpsPct.toFixed(1)}%</div>
              </div>
              <div style={{flex:1, minWidth:100, padding:'7px 10px', textAlign:'center', background:wpsOk?'var(--teal-soft)':'var(--rust-soft)'}}>
                <div style={{fontSize:10, color:'var(--ink-soft)'}}>الحالة</div>
                <div style={{fontWeight:800, color:wpsOk?'var(--teal)':'var(--rust)'}}>{wpsOk?'✔ مستوفٍ':'✖ غير مستوفٍ'}</div>
              </div>
            </div>
          </div>
        )}

        <div className="sinv-spacer"></div>
        <div className="sinv-sign">
          <div className="s">توقيع الموظف</div>
          <div className="s">المحاسب</div>
          <div className="s">الإدارة · NITAQ</div>
        </div>
        <div className="sinv-foot">SHARJAH · UAE &nbsp;|&nbsp; {COMPANY.phone} &nbsp;|&nbsp; {COMPANY.email}</div>
      </div>
    </div>
  );
}

/* ================= تتبّع الوقت: تايمر حي + سجل الساعات ================= */
const TIMER_KEY = 'nitaq-active-timer';
const MAX_SESSION_HOURS = 10;           // حد أقصى للجلسة الواحدة
const timerGet = ()=>{ try{ return JSON.parse(localStorage.getItem(TIMER_KEY)||'null'); }catch(e){ return null; } };
const timerSet = (t)=>{ try{ if(t) localStorage.setItem(TIMER_KEY, JSON.stringify(t)); else localStorage.removeItem(TIMER_KEY); }catch(e){} };

function TimesheetsView({data, configs, mutate}){
  const m = mutate('timesheets');
  const mPay = mutate('payments');
  const [timer, setTimer] = useState(()=>timerGet());   // {employeeId, projectId, phase, startMs}
  const [now, setNow] = useState(Date.now());
  // فوترة بالساعة
  const [billProj, setBillProj] = useState('');
  const [clientRate, setClientRate] = useState('');
  // اختيارات بدء التايمر
  const [empId, setEmpId] = useState('');
  const [projId, setProjId] = useState('');
  const [phase, setPhase] = useState('تصميم');

  // عدّاد حي يتحدّث كل ثانية أثناء التشغيل
  useEffect(()=>{
    if(!timer) return;
    const iv = setInterval(()=>setNow(Date.now()), 1000);
    return ()=>clearInterval(iv);
  }, [timer]);

  const emps = data.employees||[];
  const projs = (data.projects||[]).filter(p=>p.status==='جارٍ');
  // --- تقرير ساعات الفريق ---
  const [rFrom, setRFrom] = useState('');
  const [rTo, setRTo] = useState('');
  const [rProj, setRProj] = useState('');
  const rptRows = (data.timesheets||[]).filter(t=>{
    if(isArchived(t)) return false;
    const d = t.date||'';
    if(rFrom && d < rFrom) return false;
    if(rTo && d > rTo) return false;
    if(rProj && t.projectId!==rProj) return false;
    return true;
  });
  const hoursCostOf = (t)=>{ const e=(data.employees||[]).find(x=>x.id===t.employeeId); return (Number(t.hours)||0)*hourlyRate(e, monthKey(t.date)); };
  // تجميع حسب المهندس
  const byEmp = {};
  rptRows.forEach(t=>{
    const k=t.employeeId||'—'; if(!byEmp[k]) byEmp[k]={hours:0,cost:0,projs:new Set()};
    byEmp[k].hours+=Number(t.hours)||0; byEmp[k].cost+=hoursCostOf(t); if(t.projectId) byEmp[k].projs.add(t.projectId);
  });
  // تجميع حسب المشروع
  const byProj = {};
  rptRows.forEach(t=>{
    const k=t.projectId||'—'; if(!byProj[k]) byProj[k]={hours:0,cost:0,emps:new Set()};
    byProj[k].hours+=Number(t.hours)||0; byProj[k].cost+=hoursCostOf(t); if(t.employeeId) byProj[k].emps.add(t.employeeId);
  });
  const empRows = Object.entries(byEmp).map(([id,v])=>({id,name:(data.employees||[]).find(e=>e.id===id)?.name||'—',...v})).sort((a,b)=>b.hours-a.hours);
  const projRows = Object.entries(byProj).map(([id,v])=>{ const p=(data.projects||[]).find(x=>x.id===id); return {id,name:p?((p.projectNo?p.projectNo+' — ':'')+p.name):'—',...v}; }).sort((a,b)=>b.hours-a.hours);
  const totHours = rptRows.reduce((s,t)=>s+(Number(t.hours)||0),0);
  const totCost = rptRows.reduce((s,t)=>s+hoursCostOf(t),0);
  const anyRF = rFrom||rTo||rProj;

  const BASE_PHASES = ['تصميم','مخططات تفصيلية','إشراف','اعتمادات','أخرى'];
  const usedPhases = [...new Set((data.timesheets||[]).map(t=>t.phase).filter(Boolean))];
  const PHASES = [...BASE_PHASES, ...usedPhases.filter(p=>!BASE_PHASES.includes(p))];
  const pickPhase = (val)=>{
    if(val==='__add__'){
      const np = prompt('اسم المرحلة الجديدة:');
      if(np && np.trim()){ setPhase(np.trim()); }   // تُحفظ تلقائياً عند أول تسجيل وتظهر في القائمة بعدها
    } else setPhase(val);
  };
  const empName = (id)=>{ const e=emps.find(x=>x.id===id); return e?e.name:'—'; };
  const projName = (id)=>{ const p=(data.projects||[]).find(x=>x.id===id); return p?((p.projectNo?p.projectNo+' — ':'')+p.name):'—'; };

  const start = ()=>{
    if(!empId || !projId){ alert('اختر المهندس والمشروع أولاً'); return; }
    const t = {employeeId:empId, projectId:projId, phase, startMs:Date.now()};
    timerSet(t); setTimer(t); setNow(Date.now());
  };
  const cancel = ()=>{
    if(!confirm('إلغاء التايمر دون تسجيل أي ساعات؟')) return;
    timerSet(null); setTimer(null);
  };
  const stop = ()=>{
    if(!timer) return;
    const rawHours = (Date.now() - timer.startMs) / 3600000;
    let hours = Math.round(rawHours*100)/100;
    let flag = '';
    if(hours > MAX_SESSION_HOURS){
      hours = MAX_SESSION_HOURS;
      flag = ' — ⚠ تجاوزت الجلسة الحد (سُجّلت '+MAX_SESSION_HOURS+' ساعة، راجعها)';
      alert('الجلسة تجاوزت '+MAX_SESSION_HOURS+' ساعة — غالباً نُسي إيقاف التايمر.\nسيُسجَّل '+MAX_SESSION_HOURS+' ساعة فقط، عدّلها يدوياً إن لزم.');
    }
    if(hours < 0.02){ // أقل من دقيقة
      if(!confirm('المدة أقل من دقيقة. تسجيلها كـ '+hours.toFixed(2)+' ساعة؟')){ return; }
    }
    const task = prompt('وصف المهمة المنجزة (اختياري):', '') || '';
    m.add({id:uid(), employeeId:timer.employeeId, projectId:timer.projectId, phase:timer.phase,
      date:todayISO(), hours, task:(task+flag).trim(), _ts:Date.now(),
      source:'timer', startedAt:new Date(timer.startMs).toISOString(), endedAt:new Date().toISOString()});
    timerSet(null); setTimer(null);
  };

  // --- فوترة بالساعة: الساعات غير المفوترة × سعر ساعة العميل ---
  const unbilledRows = (data.timesheets||[]).filter(t=> t.projectId===billProj && !isArchived(t) && !t.billed);
  const unbilledHours = unbilledRows.reduce((s,t)=>s+(Number(t.hours)||0),0);
  const billAmount = unbilledHours * (parseFloat(clientRate)||0);
  const generateBill = ()=>{
    if(!billProj){ alert('اختر المشروع أولاً'); return; }
    if(!(parseFloat(clientRate)>0)){ alert('أدخل سعر الساعة للعميل'); return; }
    if(unbilledHours<=0){ alert('لا ساعات غير مفوترة على هذا المشروع'); return; }
    if(!confirm('توليد دفعة أتعاب بالساعة؟\n'+unbilledHours.toFixed(1)+' ساعة × '+money(parseFloat(clientRate))+' = '+money(billAmount)+' (قبل الضريبة)')) return;
    const due = new Date(); due.setDate(due.getDate()+15);
    mPay.add({id:uid(), projectId:billProj, phase:'أخرى',
      label:'أتعاب بالساعة — '+unbilledHours.toFixed(1)+' ساعة × '+money(parseFloat(clientRate)),
      amount:Math.round(billAmount*100)/100, taxable:'خاضعة', date:todayISO(),
      dueDate:due.toISOString().slice(0,10), status:'معلقة', _ts:Date.now()});
    // وسم الساعات بأنها مفوترة حتى لا تُحتسب مرتين
    unbilledRows.forEach(t=> m.update(t.id, {billed:true, billedAt:todayISO()}));
    alert('تم توليد الدفعة — تجدها في تبويب الدفعات. الساعات المفوترة لن تُحتسب مرة أخرى.');
    setClientRate('');
  };

  // عرض الوقت المنقضي ساعة:دقيقة:ثانية
  const elapsed = timer ? Math.max(0, now - timer.startMs) : 0;
  const hh = String(Math.floor(elapsed/3600000)).padStart(2,'0');
  const mm = String(Math.floor((elapsed%3600000)/60000)).padStart(2,'0');
  const ss = String(Math.floor((elapsed%60000)/1000)).padStart(2,'0');
  const over = elapsed/3600000 > MAX_SESSION_HOURS;

  const selEl = {border:'1px solid var(--line-strong)', borderRadius:4, padding:'8px 10px', fontSize:13, background:'#fff'};

  return (
    <div>
      {/* قسم التايمر الحي */}
      <div className="card" style={{marginBottom:18, border:'1px solid '+(timer?'var(--teal)':'var(--line)'), background:timer?'var(--teal-soft)':'#fff'}}>
        <div className="section-title"><h3 style={{fontSize:14}}>⏱ تايمر العمل الحي</h3><div className="rule"></div></div>
        {!timer ? (
          <div style={{display:'flex', gap:10, flexWrap:'wrap', alignItems:'flex-end'}}>
            <div className="field" style={{minWidth:160}}>
              <label>المهندس</label>
              <select value={empId} onChange={e=>setEmpId(e.target.value)} style={selEl}>
                <option value="">اختر...</option>
                {emps.map(e=><option key={e.id} value={e.id}>{e.name}</option>)}
              </select>
            </div>
            <div className="field" style={{minWidth:180}}>
              <label>المشروع</label>
              <select value={projId} onChange={e=>setProjId(e.target.value)} style={selEl}>
                <option value="">اختر...</option>
                {projs.map(p=><option key={p.id} value={p.id}>{(p.projectNo?p.projectNo+' — ':'')+p.name}</option>)}
              </select>
            </div>
            <div className="field" style={{minWidth:140}}>
              <label>المرحلة</label>
              <select value={phase} onChange={e=>pickPhase(e.target.value)} style={selEl}>
                {(PHASES.includes(phase)?PHASES:[phase,...PHASES]).map(p=><option key={p} value={p}>{p}</option>)}
                <option value="__add__">➕ إضافة مرحلة جديدة...</option>
              </select>
            </div>
            <button className="btn brass" style={{fontSize:14, padding:'9px 22px'}} onClick={start}>▶ بدء العمل</button>
          </div>
        ) : (
          <div style={{display:'flex', gap:18, flexWrap:'wrap', alignItems:'center'}}>
            <div>
              <div style={{fontSize:12, color:'var(--ink-soft)', marginBottom:4}}>
                {empName(timer.employeeId)} · {projName(timer.projectId)} · {timer.phase}
              </div>
              <div style={{fontSize:34, fontWeight:900, fontFamily:'monospace', color:over?'var(--rust)':'var(--teal)', letterSpacing:2}}>
                {hh}:{mm}:{ss}
              </div>
              {over && <div style={{fontSize:12, color:'var(--rust)', fontWeight:700}}>⚠ تجاوزت {MAX_SESSION_HOURS} ساعة — سيُسجَّل {MAX_SESSION_HOURS} فقط</div>}
            </div>
            <div style={{flex:1}}></div>
            <button className="btn" style={{background:'var(--rust)', color:'#fff', fontSize:15, padding:'11px 26px'}} onClick={stop}>⏹ إيقاف وتسجيل</button>
            <button className="btn ghost small" onClick={cancel}>إلغاء</button>
          </div>
        )}
        <p style={{fontSize:11.5, color:'var(--ink-faint)', marginTop:12, marginBottom:0}}>
          * التايمر يحفظ وقت البدء — لو أغلقت الصفحة وأعدت فتحها يكمل من حيث توقف. الساعات تُحسب من (وقت الإيقاف − وقت البدء)، بحد أقصى {MAX_SESSION_HOURS} ساعات للجلسة.
        </p>
      </div>

      {/* فوترة العميل بالساعة */}
      <div className="card" style={{marginBottom:18}}>
        <div className="section-title"><h3 style={{fontSize:13.5}}>فوترة العميل بالساعة (للعقود بالساعة)</h3><div className="rule"></div></div>
        <div style={{display:'flex', gap:10, flexWrap:'wrap', alignItems:'flex-end'}}>
          <div className="field" style={{minWidth:180}}>
            <label>المشروع</label>
            <select value={billProj} onChange={e=>setBillProj(e.target.value)} style={selEl}>
              <option value="">اختر...</option>
              {(data.projects||[]).map(p=><option key={p.id} value={p.id}>{(p.projectNo?p.projectNo+' — ':'')+p.name}</option>)}
            </select>
          </div>
          <div className="field" style={{minWidth:150}}>
            <label>سعر الساعة للعميل (د.إ)</label>
            <input type="number" value={clientRate} onChange={e=>setClientRate(e.target.value)} placeholder="مثال: 150" style={selEl} />
          </div>
          {billProj && (
            <div style={{fontSize:12.5, color:'var(--ink-soft)', paddingBottom:8}}>
              ساعات غير مفوترة: <b>{Math.round(unbilledHours*10)/10}</b>
              {clientRate && <> · القيمة: <b style={{color:'var(--teal)'}}>{money(billAmount)}</b></>}
            </div>
          )}
          <button className="btn brass" onClick={generateBill}>توليد دفعة بالساعة</button>
        </div>
        <p style={{fontSize:11.5, color:'var(--ink-faint)', marginTop:10, marginBottom:0}}>
          * يحسب الساعات غير المفوترة على المشروع × سعر الساعة، ويولّد دفعة أتعاب معلّقة في الدفعات. الساعات المفوترة تُوسَم فلا تُحتسب مرتين. للعقود بقيمة ثابتة لا تحتاج هذا القسم.
        </p>
      </div>

      {/* تقرير ساعات الفريق */}
      <div className="toolbar no-print" style={{flexWrap:'wrap', gap:10}}>
        <div className="section-title" style={{marginBottom:0, flex:'1 1 100%'}}><h3 style={{fontSize:13.5}}>تقرير ساعات الفريق على المشاريع</h3><div className="rule"></div></div>
        <select value={rProj} onChange={e=>setRProj(e.target.value)} style={selEl}>
          <option value="">كل المشاريع</option>
          {(data.projects||[]).map(p=><option key={p.id} value={p.id}>{(p.projectNo?p.projectNo+' — ':'')+p.name}</option>)}
        </select>
        <span style={{fontSize:12, color:'var(--ink-soft)'}}>من</span>
        <input type="date" value={rFrom} onChange={e=>setRFrom(e.target.value)} style={selEl} />
        <span style={{fontSize:12, color:'var(--ink-soft)'}}>إلى</span>
        <input type="date" value={rTo} onChange={e=>setRTo(e.target.value)} style={selEl} />
        {anyRF && <button className="btn ghost small" onClick={()=>{setRFrom('');setRTo('');setRProj('');}}>مسح</button>}
        <button className="btn outline no-print" onClick={()=>window.print()}><I.print/> طباعة</button>
      </div>
      <div className="grid grid-3" style={{marginBottom:16}}>
        <div className="card"><div className="kpi-label">إجمالي الساعات</div><div className="kpi-value">{Math.round(totHours*10)/10} ساعة</div><div className="kpi-note">{rptRows.length} سجل</div></div>
        <div className="card"><div className="kpi-label">إجمالي تكلفة الوقت</div><div className="kpi-value" style={{color:'var(--rust)'}}>{money(totCost)}</div><div className="kpi-note">ساعات × تكلفة ساعة كل مهندس</div></div>
        <div className="card"><div className="kpi-label">مهندسون نشطون</div><div className="kpi-value">{empRows.length}</div><div className="kpi-note">على {projRows.length} مشروع</div></div>
      </div>

      <div className="grid" style={{gridTemplateColumns:'1fr 1fr', gap:16, marginBottom:24}}>
        <div>
          <div className="section-title"><h3 style={{fontSize:13}}>حسب المهندس</h3><div className="rule"></div></div>
          <div className="card" style={{padding:0}}>
            <table>
              <thead><tr><th>المهندس</th><th>الساعات</th><th>التكلفة</th><th>مشاريع</th></tr></thead>
              <tbody>
                {empRows.length===0 && <tr className="empty-row"><td colSpan={4}>لا ساعات في النطاق المحدد</td></tr>}
                {empRows.map(r=>(
                  <tr key={r.id}><td>{r.name}</td><td><b>{Math.round(r.hours*10)/10}</b></td><td style={{color:'var(--rust)'}}>{money(r.cost)}</td><td>{r.projs.size}</td></tr>
                ))}
              </tbody>
              {empRows.length>0 && <tfoot><tr style={{fontWeight:800, background:'rgba(19,42,70,.04)'}}><td>الإجمالي</td><td>{Math.round(totHours*10)/10}</td><td style={{color:'var(--rust)'}}>{money(totCost)}</td><td></td></tr></tfoot>}
            </table>
          </div>
        </div>
        <div>
          <div className="section-title"><h3 style={{fontSize:13}}>حسب المشروع</h3><div className="rule"></div></div>
          <div className="card" style={{padding:0}}>
            <table>
              <thead><tr><th>المشروع</th><th>الساعات</th><th>التكلفة</th><th>مهندسون</th></tr></thead>
              <tbody>
                {projRows.length===0 && <tr className="empty-row"><td colSpan={4}>لا ساعات في النطاق المحدد</td></tr>}
                {projRows.map(r=>(
                  <tr key={r.id}><td>{r.name}</td><td><b>{Math.round(r.hours*10)/10}</b></td><td style={{color:'var(--rust)'}}>{money(r.cost)}</td><td>{r.emps.size}</td></tr>
                ))}
              </tbody>
              {projRows.length>0 && <tfoot><tr style={{fontWeight:800, background:'rgba(19,42,70,.04)'}}><td>الإجمالي</td><td>{Math.round(totHours*10)/10}</td><td style={{color:'var(--rust)'}}>{money(totCost)}</td><td></td></tr></tfoot>}
            </table>
          </div>
        </div>
      </div>

      {/* الجدول اليدوي المعتاد */}
      <div className="section-title"><h3 style={{fontSize:13.5}}>سجل الساعات (يمكن أيضاً الإدخال اليدوي)</h3><div className="rule"></div></div>
      <EntityView config={configs.timesheets} records={data.timesheets} data={data}
        onAdd={m.add} onUpdate={m.update} onDelete={m.del} />
    </div>
  );
}

function DocAlertsView({data}){
  const [showAll, setShowAll] = useState(false);
  const items = [];
  (data.employees||[]).forEach(e=>{
    if(isArchived(e)) return;
    if(e.iqamaExpiry)    items.push({who:e.name, type:'الإقامة', date:e.iqamaExpiry, warn:WARN_IQAMA, d:daysUntil(e.iqamaExpiry)});
    if(e.passportExpiry) items.push({who:e.name, type:'جواز السفر', date:e.passportExpiry, warn:WARN_PASSPORT, d:daysUntil(e.passportExpiry)});
    if(e.workCardExpiry) items.push({who:e.name, type:'بطاقة العمل', date:e.workCardExpiry, warn:WARN_DEFAULT, d:daysUntil(e.workCardExpiry)});
  });
  (data.cars||[]).forEach(c=>{
    if(isArchived(c)) return;
    if(c.licenseExpiry) items.push({who:(c.model||'')+' · '+(c.plate||''), type:'رخصة السيارة', date:c.licenseExpiry, warn:WARN_DEFAULT, d:daysUntil(c.licenseExpiry)});
  });
  const active = items.filter(i=> i.d!==null && (showAll || i.d<=i.warn));
  active.sort((a,b)=> (a.d==null?9e9:a.d)-(b.d==null?9e9:b.d));
  const expired = active.filter(i=>i.d<0).length;
  const soon = active.filter(i=>i.d>=0 && i.d<=i.warn).length;

  return (
    <div>
      <div className="grid grid-3" style={{marginBottom:18}}>
        <div className="card"><div className="kpi-label">منتهية بالفعل</div><div className="kpi-value" style={{color:'var(--rust)'}}>{expired}</div><div className="kpi-note">تحتاج تجديداً فورياً</div></div>
        <div className="card"><div className="kpi-label">قاربت على الانتهاء</div><div className="kpi-value" style={{color:'var(--brass)'}}>{soon}</div><div className="kpi-note">ضمن فترة التنبيه</div></div>
        <div className="card"><div className="kpi-label">إجمالي الوثائق المتابَعة</div><div className="kpi-value">{items.length}</div><div className="kpi-note">موظفين + سيارات</div></div>
      </div>
      <div className="toolbar no-print">
        <div className="section-title" style={{marginBottom:0, flex:1}}><h3>الوثائق القريبة من الانتهاء</h3><div className="rule"></div></div>
        <button className="btn ghost small" onClick={()=>setShowAll(s=>!s)}>{showAll?'عرض التنبيهات فقط':'عرض كل الوثائق'}</button>
        <button className="btn outline no-print" onClick={()=>window.print()}><I.print/> طباعة</button>
      </div>
      <div className="card" style={{padding:0}}>
        <div style={{overflowX:'auto'}}>
        <table>
          <thead><tr><th>الجهة</th><th>الوثيقة</th><th>تاريخ الانتهاء</th><th>الحالة</th><th>المتبقّي</th></tr></thead>
          <tbody>
            {active.length===0 && <tr className="empty-row"><td colSpan={5}>لا توجد وثائق ضمن فترة التنبيه — كل شيء سارٍ ✓</td></tr>}
            {active.map((it,i)=>(
              <tr key={i}>
                <td><b>{it.who}</b></td>
                <td>{it.type}</td>
                <td>{it.date}</td>
                <td><span className={"badge "+expiryStatus(it.date, it.warn)}>{it.d<0?'منتهية':it.d<=it.warn?'قاربت':'سارية'}</span></td>
                <td style={{color:it.d<0?'var(--rust)':it.d<=it.warn?'var(--brass)':'var(--ink)', fontWeight:700}}>
                  {it.d<0?('منتهية منذ '+Math.abs(it.d)+' يوم'):(it.d+' يوم')}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        </div>
      </div>
      <p style={{fontSize:12, color:'var(--ink-faint)', marginTop:12}}>* فترات التنبيه: جواز السفر قبل 7 شهور، الإقامة قبل شهر، بطاقة العمل ورخصة السيارة قبل 60 يوماً. مرتّبة حسب الأقرب انتهاءً.</p>
    </div>
  );
}

/* نافذة صرف رواتب WPS: تاريخ الصرف الفعلي + مراجعة الأسماء والمبالغ */
function WpsRunModal({ym, rows, total, outside, onClose, onSave}){
  const [date, setDate] = useState(todayISO());
  const [bankName, setBankName] = useState('WIO NITAQ');
  const [note, setNote] = useState('');
  const inp = {width:'100%', padding:'7px 9px', fontFamily:'inherit', fontSize:13, border:'1px solid var(--line-strong)', borderRadius:6};
  return (
    <div className="overlay" onMouseDown={(e)=>{ if(e.target===e.currentTarget) onClose(); }}>
      <div className="modal" style={{maxWidth:520}}>
        <h3 style={{marginBottom:4}}>صرف رواتب {fmtMonth(ym)} — WPS</h3>
        <div style={{fontSize:12.5, color:'var(--ink-soft)', marginBottom:12}}>{rows.length} موظف · الإجمالي <b style={{color:'var(--brass)'}}>{money(total)}</b>{outside?(' · '+outside+' موظف خارج WPS غير مشمولين (يُصرف لهم من زر «صرف»)'):''}</div>
        <div style={{maxHeight:220, overflowY:'auto', border:'1px solid var(--line)', borderRadius:6, marginBottom:12}}>
          <table style={{fontSize:12.5}}>
            <thead><tr><th>الموظف</th><th style={{textAlign:'left'}}>الصافي</th></tr></thead>
            <tbody>
              {rows.map(r=><tr key={r.emp.id}><td>{r.emp.name}</td><td style={{textAlign:'left', whiteSpace:'nowrap'}}>{money(r.net)}</td></tr>)}
              <tr style={{fontWeight:800}}><td>الإجمالي</td><td style={{textAlign:'left', whiteSpace:'nowrap'}}>{money(total)}</td></tr>
            </tbody>
          </table>
        </div>
        <div style={{display:'grid', gap:10}}>
          <label style={{fontSize:12.5}}>تاريخ الصرف الفعلي *<input type="date" style={inp} value={date} onChange={e=>setDate(e.target.value)} /></label>
          <label style={{fontSize:12.5}}>اسم البنك *<input style={inp} value={bankName} onChange={e=>setBankName(e.target.value)} /></label>
          <label style={{fontSize:12.5}}>ملاحظة إضافية<input style={inp} value={note} onChange={e=>setNote(e.target.value)} placeholder="اختياري" /></label>
          <div style={{fontSize:11.5, color:'var(--ink-faint)'}}>أسماء الموظفين ومبالغهم هتتكتب في ملاحظات قيد المصروف تلقائياً، والمبلغ هيتخصم من البنك بتاريخ الصرف ده.</div>
        </div>
        <div style={{display:'flex', gap:8, justifyContent:'flex-end', marginTop:16}}>
          <button className="btn outline" onClick={onClose}>إلغاء</button>
          <button className="btn brass" disabled={!date || !bankName.trim()} onClick={()=>onSave({date, bankName:bankName.trim(), note:note.trim()})}>تأكيد الصرف</button>
        </div>
      </div>
    </div>
  );
}

/* نافذة دفعة راتب لموظف خارج WPS */
function SalaryPartModal({row, ym, data, onClose, onSave}){
  const [amount, setAmount] = useState(String(row.remaining));
  const [date, setDate] = useState(todayISO());
  const [account, setAccount] = useState('البنك');
  const [bankName, setBankName] = useState('WIO NITAQ');
  const [note, setNote] = useState('');
  const prev = salaryPaymentsForEmp(data, row.emp.id, ym, row.net);
  const amt = parseFloat(amount);
  const valid = amt>0 && amt<=row.remaining+0.01 && !!date && (account!=='البنك' || bankName.trim());
  const inp = {width:'100%', padding:'7px 9px', fontFamily:'inherit', fontSize:13, border:'1px solid var(--line-strong)', borderRadius:6};
  return (
    <div className="overlay" onMouseDown={(e)=>{ if(e.target===e.currentTarget) onClose(); }}>
      <div className="modal" style={{maxWidth:460}}>
        <h3 style={{marginBottom:4}}>دفعة راتب — {row.emp.name}</h3>
        <div style={{fontSize:12.5, color:'var(--ink-soft)', marginBottom:12}}>{fmtMonth(ym)} · الصافي {money(row.net)} · المصروف {money(row.paid)} · <b style={{color:'var(--rust)'}}>المتبقّي {money(row.remaining)}</b></div>
        {prev.length>0 && (
          <div style={{fontSize:12, background:'var(--paper)', border:'1px solid var(--line)', borderRadius:6, padding:'6px 10px', marginBottom:12}}>
            {prev.map((x,i)=><div key={i}>• {x.date} — {money(x.amount)} ({x.account==='الخزينة'?'نقدي':(x.bankName||x.account||'')})</div>)}
          </div>
        )}
        <div style={{display:'grid', gap:10}}>
          <label style={{fontSize:12.5}}>المبلغ (د.إ) *<input type="number" style={inp} value={amount} onChange={e=>setAmount(e.target.value)} /></label>
          <label style={{fontSize:12.5}}>تاريخ الصرف *<input type="date" style={inp} value={date} onChange={e=>setDate(e.target.value)} /></label>
          <label style={{fontSize:12.5}}>من حساب *
            <select style={inp} value={account} onChange={e=>setAccount(e.target.value)}>
              <option value="البنك">البنك (تحويل)</option><option value="الخزينة">الخزينة (نقدي)</option>
            </select></label>
          {account==='البنك' && <label style={{fontSize:12.5}}>اسم البنك *<input style={inp} value={bankName} onChange={e=>setBankName(e.target.value)} /></label>}
          <label style={{fontSize:12.5}}>ملاحظة<input style={inp} value={note} onChange={e=>setNote(e.target.value)} /></label>
          {amt>row.remaining+0.01 && <div style={{color:'var(--rust)', fontSize:12}}>المبلغ أكبر من المتبقّي.</div>}
        </div>
        <div style={{display:'flex', gap:8, justifyContent:'flex-end', marginTop:16}}>
          <button className="btn outline" onClick={onClose}>إلغاء</button>
          <button className="btn brass" disabled={!valid} onClick={()=>onSave({amount:Math.round(amt*100)/100, date, account, bankName:bankName.trim(), note:note.trim()})}>تسجيل الدفعة</button>
        </div>
      </div>
    </div>
  );
}

function PayrollView({data, mutate}){
  const [ym, setYm] = useState(currentYM());
  const [slipFor, setSlipFor] = useState(null);
  const [payFor, setPayFor] = useState(null);     // موظف خارج WPS: نافذة دفعة راتب
  const [wpsOpen, setWpsOpen] = useState(false);  // نافذة صرف رواتب WPS (تاريخ الصرف الفعلي)
  const {rows: baseRows, totalNet} = computePayroll(data, ym);
  // المصروف والمتبقّي لكل موظف عن هذا الشهر
  const rows = baseRows.map(r=>{
    const paid = salaryPaidForEmp(data, r.emp.id, ym, r.net);
    const remaining = Math.max(0, Math.round((r.net - paid)*100)/100);
    return {...r, wps:isWpsEmp(r.emp), paid, remaining};
  });
  const wpsRows = rows.filter(r=>r.wps);
  const totalPaid = rows.reduce((s,r)=>s+r.paid,0);
  const totalRemaining = rows.reduce((s,r)=>s+r.remaining,0);
  const mT = mutate('treasury');

  // كشف راتب فردي
  if(slipFor){
    const row = rows.find(r=>r.emp.id===slipFor);
    if(row) return <PayslipDoc row={row} ym={ym} data={data} onBack={()=>setSlipFor(null)} />;
  }

  // تصدير ملف WPS (نظام حماية الأجور) بصيغة CSV
  const exportWPS = ()=>{
    const header = ['Employee ID','Employee Name','IBAN','Salary Month','Basic','Gross','Overtime','Deductions','Net Salary'];
    const lines = wpsRows.map(r=>[
      r.emp.id, r.emp.name, (r.emp.iban||''), ym,
      fmt(r.base), fmt(r.gross), fmt(r.ot), fmt(r.absenceDeduction+r.advances+r.deductions+(r.installments||0)), fmt(r.net)
    ].join(','));
    const csv = '\uFEFF'+header.join(',')+'\n'+lines.join('\n');
    const blob = new Blob([csv], {type:'text/csv;charset=utf-8;'});
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a'); a.href=url; a.download='WPS_'+ym+'.csv'; a.click();
    URL.revokeObjectURL(url);
  };

  const mExp = mutate('officeExpenses');
  // يُبحث عن صرف الرواتب في المصروفات (الجديد) وفي الخزينة (سجلات قديمة) لضمان التوافق
  const paidExp = data.officeExpenses.find(e=>e.kind==='رواتب' && e.month===ym);
  const paidTreasury = data.treasury.find(t=>t.kind==='رواتب' && t.month===ym);
  const paidRec = paidExp || paidTreasury;
  // الصرف الجماعي: موظفو WPS فقط (قيد واحد للشهر) — موظفو «خارج WPS» يُصرف لهم بزر «صرف» على دفعات
  const wpsTotal = Math.round(wpsRows.reduce((s,r)=>s+r.net,0)*100)/100;
  const paySalaries = () => {
    if(paidRec){ alert('تم تسجيل صرف رواتب '+fmtMonth(ym)+' (WPS) مسبقاً'); return; }
    if(!wpsRows.length){ alert('لا يوجد موظفون عبر WPS — اصرفي لموظفي «خارج WPS» من زر «صرف» بجانب كل موظف.'); return; }
    setWpsOpen(true);
  };
  const confirmWpsRun = (f) => {
    const list = wpsRows.map(r=>r.emp.name+' '+fmt(Math.round(r.net*100)/100)).join(' · ');
    mExp.add({id:uid(), category:'رواتب', amount:wpsTotal, date:f.date, account:'البنك',
      bankName:f.bankName||'WIO NITAQ', vatable:'غير خاضع', payStatus:'مدفوع',
      note:'صرف رواتب '+fmtMonth(ym)+' — WPS ('+wpsRows.length+' موظف): '+list+' — الإجمالي '+fmt(wpsTotal)+(f.note?(' — '+f.note):''),
      kind:'رواتب', month:ym,
      lines:wpsRows.map(r=>({employeeId:r.emp.id, amount:Math.round(r.net*100)/100})), _ts:Date.now()});
    setWpsOpen(false);
  };
  const addSalaryPart = (row, f) => {
    mExp.add({id:uid(), category:'رواتب', amount:f.amount, date:f.date, account:f.account,
      bankName: f.account==='البنك' ? (f.bankName||'WIO NITAQ') : '', vatable:'غير خاضع', payStatus:'مدفوع',
      note:'دفعة راتب '+row.emp.name+' — '+fmtMonth(ym)+(f.note?(' — '+f.note):''),
      kind:SALARY_PART_KIND, month:ym, employeeId:row.emp.id, _ts:Date.now()});
    setPayFor(null);
  };

  const grats = data.employees.filter(e=>!isArchived(e)).map(e=>({e, ...computeGratuity(e)}));
  const gratTotal = grats.reduce((s,g)=>s+g.amount,0);

  return (
    <div>
      <div className="toolbar">
        <div className="section-title" style={{marginBottom:0, flex:1}}><h3>كشف الرواتب</h3><div className="rule"></div></div>
        <div style={{display:'flex', gap:10}}>
          <input type="month" value={ym} onChange={e=>setYm(e.target.value)} />
          <button className={"btn "+(paidRec?'outline':'brass')+" no-print"} onClick={paySalaries}>
            {paidRec ? '✓ رواتب WPS مصروفة' : 'تسجيل صرف الرواتب (WPS)'}
          </button>
          <button className="btn outline no-print" onClick={exportWPS} title="تصدير ملف حماية الأجور (CSV) للبنك">↓ ملف WPS</button>
          <button className="btn outline no-print" onClick={()=>window.print()}><I.print/> طباعة</button>
        </div>
      </div>
      <div className="card payroll-wrap" style={{padding:0, marginBottom:16, overflowX:'auto'}}>
        <style>{`.payroll-wrap table{font-size:12px; min-width:100%} .payroll-wrap th,.payroll-wrap td{padding:8px 7px; white-space:nowrap} .payroll-wrap td:first-child{white-space:normal; min-width:150px; max-width:220px} .payroll-wrap .badge{white-space:nowrap} @media print{.payroll-wrap{overflow:visible}}`}</style>
        <table>
          <thead>
            <tr>
              <th>الموظف</th><th>الأساسي</th><th>الإجمالي</th><th>أيام غياب</th><th>خصم الغياب</th>
              <th>الأوفرتايم</th><th>سلف</th><th>قسط السلف</th><th>خصومات</th><th>رصيد الإجازة</th><th>الصافي</th><th>المصروف</th><th>المتبقّي</th><th className="no-print">صرف</th><th className="no-print">كشف</th>
            </tr>
          </thead>
          <tbody>
            {rows.map(r=>{
              const lb = computeLeaveBalance(data, r.emp.id);
              return (
              <tr key={r.emp.id}>
                <td>{r.emp.name}{!r.wps && <div><span className="badge soon" style={{fontSize:10}}>خارج WPS</span></div>}{r.prorateDays!=null && <div style={{fontSize:10.5, color:'var(--brass)'}}>أول شهر: {r.prorateDays}/{r.prorateDim} يوم</div>}</td>
                <td>{money(r.base)}</td>
                <td>{money(r.gross)}</td>
                <td>{r.absentDays}</td>
                <td>−{money(r.absenceDeduction)}</td>
                <td>+{money(r.ot)}</td>
                <td>−{money(r.advances)}</td>
                <td>−{money(r.installments||0)}</td>
                <td>−{money(r.deductions)}</td>
                <td><span className={"badge "+(lb.remaining<=5?'soon':'ok')}>{lb.remaining}/{lb.entitled} يوم</span></td>
                <td style={{fontWeight:800}}>{money(r.net)}</td>
                <td style={{color:'var(--teal)'}}>{money(r.paid)}</td>
                <td>{r.net<=0 ? '—' : r.remaining<=0.009
                  ? <span className="badge ok">✓ مصروف</span>
                  : <span className={"badge "+(r.paid>0?'soon':'gray')}>{r.paid>0?'◐ ':''}{money(r.remaining)}</span>}</td>
                <td className="no-print">{!r.wps && r.remaining>0.009
                  ? <button className="btn brass small" onClick={()=>setPayFor(r.emp.id)}>صرف</button>
                  : <span style={{color:'var(--ink-faint)', fontSize:11}}>{r.wps?'مع WPS':''}</span>}</td>
                <td className="no-print"><button className="btn ghost small" onClick={()=>setSlipFor(r.emp.id)}>📄</button></td>
              </tr>
            );})}
          </tbody>
        </table>
      </div>
      <div className="card grid grid-4" style={{padding:16, marginBottom:24}}>
        <div><div className="kpi-label">عدد الموظفين</div><div className="kpi-value" style={{fontSize:20}}>{rows.length}</div></div>
        <div><div className="kpi-label">إجمالي الرواتب الأساسية</div><div className="kpi-value" style={{fontSize:20}}>{money(rows.reduce((s,r)=>s+(r.base||0),0))}</div></div>
        <div><div className="kpi-label">إجمالي الأوفرتايم</div><div className="kpi-value" style={{fontSize:20}}>{money(rows.reduce((s,r)=>s+r.ot,0))}</div></div>
        <div><div className="kpi-label">إجمالي صافي الرواتب</div><div className="kpi-value" style={{fontSize:20, color:'var(--brass)'}}>{money(totalNet)}</div></div>
        <div><div className="kpi-label">المصروف فعلاً عن الشهر</div><div className="kpi-value" style={{fontSize:20, color:'var(--teal)'}}>{money(totalPaid)}</div></div>
        <div><div className="kpi-label">رواتب مستحقة لم تُصرف</div><div className="kpi-value" style={{fontSize:20, color:totalRemaining>0.009?'var(--rust)':'var(--ink)'}}>{money(totalRemaining)}</div></div>
      </div>
      {wpsOpen && <WpsRunModal ym={ym} rows={wpsRows} total={wpsTotal} outside={rows.length-wpsRows.length} onClose={()=>setWpsOpen(false)} onSave={confirmWpsRun} />}
      {payFor && (()=>{ const row = rows.find(r=>r.emp.id===payFor); return row ? <SalaryPartModal row={row} ym={ym} data={data} onClose={()=>setPayFor(null)} onSave={(f)=>addSalaryPart(row,f)} /> : null; })()}

      <div className="section-title"><h3 style={{fontSize:13.5}}>مخصص مكافأة نهاية الخدمة (تقديري — التزام متراكم)</h3><div className="rule"></div></div>
      <div className="card" style={{padding:0}}>
        <table>
          <thead><tr><th>الموظف</th><th>تاريخ التعيين</th><th>مدة الخدمة</th><th>المكافأة المستحقة حتى اليوم</th></tr></thead>
          <tbody>
            {grats.map(g=>(
              <tr key={g.e.id}>
                <td>{g.e.name}</td>
                <td>{g.e.hireDate||'—'}</td>
                <td>{g.years.toFixed(1)} سنة</td>
                <td style={{fontWeight:700}}>{g.years<1 ? <span className="badge gray">أقل من سنة — لا تستحق</span> : money(g.amount)}</td>
              </tr>
            ))}
            <tr style={{fontWeight:800, background:'rgba(19,42,70,.03)'}}>
              <td colSpan={3}>إجمالي الالتزام المتراكم</td>
              <td>{money(gratTotal)}</td>
            </tr>
          </tbody>
        </table>
      </div>
      <p style={{fontSize:12, color:'var(--ink-faint)', marginTop:12}}>* حساب تقديري وفق قانون العمل الإماراتي: 21 يوماً من الراتب الأساسي عن كل سنة من أول 5 سنوات، و30 يوماً عمّا زاد. زر تسجيل صرف الرواتب يُنشئ حركة صرف واحدة لكل شهر لموظفي WPS. موظفو «خارج WPS» يُصرف لهم على دفعات بزر «صرف» — كل دفعة مصروف مستقل بتاريخها، ومجموعها لا يتجاوز الصافي. ملف WPS يشمل موظفي WPS فقط.</p>
    </div>
  );
}

/* ================= Dashboard ================= */
function Dashboard({data, go}){
  const totalRevenue = data.payments.reduce((s,i)=>s+billedOf(i),0);
  const totalExpenses = data.officeExpenses.filter(e=>!isArchived(e)).reduce((s,e)=>s+(e.amount||0),0) + data.projectCosts.filter(e=>!isArchived(e)).reduce((s,e)=>s+(e.amount||0),0);
  const govOutstanding = data.govFees.filter(g=>!isArchived(g) && g.payerType!=='المالك مباشرة' && g.paidStatus==='مدفوع' && g.reimburseStatus!=='مسترد').reduce((s,g)=>s+(isArchived(g)?0:g.amount),0);
  const activeProjects = data.projects.filter(p=>p.status==='جارٍ').length;

  const months = last6Months();
  const chartData = months.map(m=>({
    m,
    rev: data.payments.filter(i=>monthKey(i.date)===m).reduce((s,i)=>s+billedOf(i),0),
    exp: data.officeExpenses.filter(e=>!isArchived(e) && monthKey(e.date)===m).reduce((s,e)=>s+(e.amount||0),0)
       + data.projectCosts.filter(e=>!isArchived(e) && monthKey(e.date)===m).reduce((s,e)=>s+(e.amount||0),0),
  }));
  const maxVal = Math.max(1,...chartData.flatMap(d=>[d.rev,d.exp]));

  const nowYM = currentYM();
  const alerts = useMemo(()=>{
    const alerts = [];
    data.projects.filter(p=>p.status==='جارٍ' && (p.supervisionMonthly||0)>0).forEach(p=>{
    const has = data.payments.some(i=>i.projectId===p.id && i.phase==='إشراف' && i.month===nowYM);
    const done = data.payments.filter(i=>!isArchived(i) && i.projectId===p.id && i.phase==='إشراف').length;
    if(!has && done < (p.supervisionMonths||0)){
      alerts.push({text:'دفعة إشراف '+fmtMonth(nowYM)+' لمشروع "'+p.name+'" لم تُسجل بعد', status:'soon', go:'payments'});
    }
  });
  data.payments.forEach(i=>{
    if(remainderOf(i)>0){
      const d = daysUntil(i.dueDate);
      if(d!==null && d<0) alerts.push({text:'دفعة متأخرة — '+((data.projects.find(p=>p.id===i.projectId)||{}).name||'')+' — متبقٍ '+money(remainderOf(i)*grossFactor(i))+' وتجاوزت الاستحقاق بـ '+Math.abs(d)+' يوم', status:'bad', go:'payments'});
    }
  });
  data.projects.filter(p=>p.status==='جارٍ').forEach(p=>{
    TIMELINE_STAGES.forEach(st=>{
      const s = (p.timeline||{})[st.key];
      if(s && s.status==='جارية' && s.startDate && s.targetDays && daysSince(s.startDate) > s.targetDays){
        const emp = (data.employees.find(e=>e.id===s.responsibleId)||{}).name || ((data.staffDir||[]).find(x=>x.empId===s.responsibleId)||{}).name || s.responsibleId;
        alerts.push({text:'مرحلة "'+st.label+'" — مشروع '+(p.projectNo||'')+' '+p.name+': تجاوزت المدة المستهدفة بـ '+(daysSince(s.startDate)-s.targetDays)+' يوم'+(emp?' (المسؤول: '+emp+')':''), status:'bad', go:'projects'});
      }
    });
    APPROVAL_ITEMS.forEach(name=>{
      const a = (p.approvals||{})[name];
      if(a && !a.done && a.submitDate && a.targetDays && daysSince(a.submitDate) > a.targetDays){
        const emp = (data.employees.find(e=>e.id===a.responsibleId)||{}).name || ((data.staffDir||[]).find(x=>x.empId===a.responsibleId)||{}).name || a.responsibleId;
        alerts.push({text:'اعتماد "'+name+'" — مشروع '+(p.projectNo||'')+': مقدَّم منذ '+daysSince(a.submitDate)+' يوم وتجاوز المتوقع بـ '+(daysSince(a.submitDate)-a.targetDays)+' يوم'+(emp?' (المسؤول: '+emp+')':''), status:'bad', go:'projects'});
      }
    });
    const billedP = data.payments.filter(i=>!isArchived(i) && i.projectId===p.id).reduce((s,i)=>s+billedOf(i),0);
    const costsP = data.projectCosts.filter(e=>!isArchived(e) && e.projectId===p.id).reduce((s,e)=>s+(e.amount||0),0) + projectTimeCost(data, p.id);
    if(billedP>10000){
      const margin = (billedP-costsP)/billedP*100;
      if(margin<20) alerts.push({text:'هامش ربح مشروع '+(p.projectNo||'')+' '+p.name+' انخفض إلى '+margin.toFixed(0)+'% — راجع التكاليف ووقت الفريق', status:'soon', go:'analytics'});
    }
  });
  listQuarters().forEach(q=>{
    if(quarterEndDate(q) < todayISO()){
      const due = quarterDueDate(q);
      const dd = daysUntil(due);
      if(dd!==null && dd<=30) alerts.push({
        text:'إقرار ض.ق.م عن فترة '+quarterLabel(q)+' — '+(dd<0 ? ('تجاوز الاستحقاق بـ '+Math.abs(dd)+' يوم') : ('مستحق خلال '+dd+' يوم ('+due+')')),
        status: dd<0?'bad':'soon', go:'vat'});
    }
  });
  if(govOutstanding>0){
    alerts.push({text:'رسوم حكومية بقيمة '+money(govOutstanding)+' مدفوعة من خزينة المكتب ولم تُسترد من العملاء', status:'bad', go:'govFees'});
  }
  data.payments.filter(i=>!isArchived(i) && i.status!=='ملغاة' && i.method==='شيك' && i.chequeDueDate).forEach(i=>{
    const d = daysUntil(i.chequeDueDate);
    if(d!==null && d<=10){
      const p = data.projects.find(x=>x.id===i.projectId);
      alerts.push({text:'شيك مستلم من '+((p||{}).owner||(p||{}).name||'عميل')+' بقيمة '+money(i.amount*grossFactor(i))+' — '+(d<0?('تجاوز موعد صرفه بـ '+Math.abs(d)+' يوم'):('موعد صرفه المتوقع خلال '+d+' يوم ('+i.chequeDueDate+')')), status: d<0?'bad':'soon', go:'payments'});
    }
  });
  [...data.officeExpenses.map(e=>({...e, _src:'officeExpenses'})), ...data.projectCosts.map(e=>({...e, _src:'projectCosts'}))]
    .filter(e=>!isArchived(e) && e.account==='شيك' && e.chequeDueDate).forEach(e=>{
      const d = daysUntil(e.chequeDueDate);
      if(d!==null && d<=10){
        alerts.push({text:'شيك صادر رقم '+(e.chequeNo||'—')+' بقيمة '+money(e.amount)+' — '+(d<0?('تجاوز موعد صرفه بـ '+Math.abs(d)+' يوم'):('موعد صرفه المتوقع خلال '+d+' يوم ('+e.chequeDueDate+')')), status: d<0?'bad':'soon', go:e._src});
      }
    });
  // رواتب مستحقة لم تُصرف (موظفو خارج WPS) — الشهر السابق والحالي، متى بدأ صرف رواتب الشهر
  (()=>{
    const cur = currentYM(); const [cy,cm] = cur.split('-').map(Number);
    const prev = cm===1 ? (cy-1)+'-12' : cy+'-'+String(cm-1).padStart(2,'0');
    let tot = 0; const names = new Set();
    [prev, cur].forEach(m=>{
      if(!payrollPaidForMonth(data, m)) return;
      computePayroll(data, m).rows.filter(r=>!isWpsEmp(r.emp) && r.net>0).forEach(r=>{
        const rem = r.net - salaryPaidForEmp(data, r.emp.id, m, r.net);
        if(rem>0.009){ tot += rem; names.add(r.emp.name); }
      });
    });
    if(tot>0) alerts.push({text:'رواتب مستحقة لم تُصرف بقيمة '+money(tot)+' — '+[...names].join('، ')+' (خارج WPS)', status:'soon', go:'payroll'});
  })();
  const pendingExp = data.officeExpenses.filter(e=>!isArchived(e) && e.payStatus==='معلق');
  if(pendingExp.length>0){
    alerts.push({text:pendingExp.length+' مصروف مكتب معلق السداد بإجمالي '+money(pendingExp.reduce((s,e)=>s+expGross(e),0))+' — لم تُخصم من الخزينة بعد', status:'soon', go:'officeExpenses'});
  }
  data.recurringBills.filter(b=>!isArchived(b) && b.active!=='متوقف').forEach(b=>{
    const d = daysUntil(b.nextDueDate);
    if(d!==null && d<=(b.reminderDays||5)){
      alerts.push({text:'فاتورة "'+b.provider+'" ('+b.category+') بقيمة '+money(b.amount)+' — '+(d<0?('تجاوزت الاستحقاق بـ '+Math.abs(d)+' يوم'):(d===0?'مستحقة اليوم':('مستحقة خلال '+d+' يوم')))+' ('+b.nextDueDate+')', status: d<0?'bad':'soon', go:'recurringBills'});
    }
  });
  data.employees.filter(e=>!isArchived(e)).forEach(e=>{
    [['iqamaExpiry','إقامة'],['passportExpiry','جواز سفر'],['workCardExpiry','بطاقة عمل']].forEach(([field,label])=>{
      const d = daysUntil(e[field]);
      if(d!==null && d<=60) alerts.push({text:label+' '+e.name+' — '+expiryLabel(e[field]), status: d<0?'bad':'soon', go:'employees'});
    });
  });
    data.cars.forEach(c=>{
      const d = daysUntil(c.licenseExpiry);
      if(d!==null && d<=60) alerts.push({text:'رخصة سيارة '+c.model+' ('+c.plate+') — '+expiryLabel(c.licenseExpiry), status: d<0?'bad':'soon', go:'cars'});
    });
    return alerts;
  }, [data]);

  return (
    <div>
      <div className="grid grid-4" style={{marginBottom:18}}>
        <div className="card"><div className="kpi-label">الإيرادات الاستشارية <I.receipt style={{width:15,height:15,color:'var(--ink-faint)'}}/></div>
          <div className="kpi-value">{money(totalRevenue)}</div><div className="kpi-note">تصميم + إشراف · {data.payments.length} دفعة</div></div>
        <div className="card"><div className="kpi-label">إجمالي المصروفات <I.coin style={{width:15,height:15,color:'var(--ink-faint)'}}/></div>
          <div className="kpi-value">{money(totalExpenses)}</div><div className="kpi-note">مكتب + تكاليف مشاريع</div></div>
        <div className="card"><div className="kpi-label">أمانات معلقة الاسترداد <I.landmark style={{width:15,height:15,color:'var(--ink-faint)'}}/></div>
          <div className="kpi-value" style={{color:govOutstanding>0?'var(--rust)':'var(--ink)'}}>{money(govOutstanding)}</div><div className="kpi-note">رسوم حكومية لم يسددها العملاء</div></div>
        <div className="card"><div className="kpi-label">المشاريع الجارية <I.compass style={{width:15,height:15,color:'var(--ink-faint)'}}/></div>
          <div className="kpi-value">{activeProjects}</div><div className="kpi-note">من إجمالي {data.projects.length} مشروع</div></div>
      </div>

      <div className="grid grid-2">
        <div className="card">
          <div className="section-title"><h3>الإيرادات مقابل المصروفات — آخر 6 أشهر</h3><div className="rule"></div></div>
          <div className="bars">
            {chartData.map(d=>(
              <div className="bar-col" key={d.m}>
                <div className="bar-wrap">
                  <div className="bar rev" style={{height:(d.rev/maxVal*130)+'px'}} title={money(d.rev)}></div>
                  <div className="bar exp" style={{height:(d.exp/maxVal*130)+'px'}} title={money(d.exp)}></div>
                </div>
                <div className="bar-label">{monthNamesAr[parseInt(d.m.split('-')[1],10)-1]}</div>
                <div style={{fontSize:9.5, color:'var(--brass)', fontWeight:700, marginTop:2}}>{fmt(d.rev)}</div>
                <div style={{fontSize:9.5, color:'var(--ink-faint)', fontWeight:700}}>{fmt(d.exp)}</div>
              </div>
            ))}
          </div>
          <div className="legend">
            <span><i style={{background:'var(--brass)'}}></i> الإيرادات الاستشارية</span>
            <span><i style={{background:'var(--ink-faint)'}}></i> المصروفات</span>
          </div>
          <div style={{display:'flex', justifyContent:'space-between', marginTop:12, paddingTop:12, borderTop:'1px solid var(--line)', fontSize:12.5}}>
            <span>إجمالي الإيرادات (6 أشهر): <b style={{color:'var(--brass)'}}>{money(chartData.reduce((s,d)=>s+d.rev,0))}</b></span>
            <span>إجمالي المصروفات (6 أشهر): <b style={{color:'var(--ink-soft)'}}>{money(chartData.reduce((s,d)=>s+d.exp,0))}</b></span>
          </div>
        </div>

        <div className="card">
          <div className="section-title"><h3>أحدث قرارات المشاريع</h3><div className="rule"></div></div>
          {(data.decisions||[]).length===0 && <p style={{fontSize:12.5, color:'var(--ink-faint)'}}>لا قرارات مسجلة بعد — تُضاف من ملف المشروع أو باستيراد واتساب.</p>}
          {[...(data.decisions||[])].sort((a,b)=>(b.date||'').localeCompare(a.date||'')).slice(0,6).map(dc=>{
            const proj = data.projects.find(p=>p.id===dc.projectId)||{};
            const dd = daysSince(dc.date);
            const rel = dd===0?'اليوم':dd===1?'أمس':dd!==null?('منذ '+dd+' يوم'):'';
            return (
              <div className="alert-item" key={dc.id} onClick={()=>go('projects')} style={{cursor:'pointer'}}>
                <span><b style={{color:'var(--brass)'}}>{proj.projectNo||''}</b> {dc.description.slice(0,70)}{dc.description.length>70?'…':''}</span>
                <span style={{fontSize:10.5, color:'var(--ink-faint)', flexShrink:0}}>{rel}</span>
              </div>
            );
          })}
        </div>
      </div>

      <div className="grid grid-2" style={{marginTop:18}}>
        <div className="card">
          <div className="section-title"><h3>تنبيهات هامة</h3><div className="rule"></div><I.bell style={{width:16,height:16,color:'var(--brass)'}}/></div>
          {alerts.length===0 && <p style={{fontSize:13, color:'var(--ink-faint)'}}>لا توجد تنبيهات حالياً. كل شيء تحت السيطرة.</p>}
          {alerts.slice(0,8).map((a,idx)=>(
            <div className="alert-item" key={idx} onClick={()=>go(a.go)} style={{cursor:'pointer'}}>
              <span>{a.text}</span>
              <span className={"badge "+a.status}>{a.status==='bad'?'عاجل':'قريباً'}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

/* ================= شاشة الدخول ================= */
function LoginView({onLogin, sbRef}){
  const [mode, setMode] = useState('in'); // in | up
  const [email, setEmail] = useState('');
  const [pass, setPass] = useState('');
  const [name, setName] = useState('');
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState('');

  const submit = async ()=>{
    if(!email || !pass){ setMsg('أدخل البريد وكلمة المرور'); return; }
    setBusy(true); setMsg('');
    try{
      if(false){
      } else {
        const {error} = await sbRef.current.auth.signInWithPassword({email, password:pass});
        if(error) throw error;
        onLogin();
      }
    }catch(e){ setMsg(e.message==='Invalid login credentials' ? 'بيانات الدخول غير صحيحة' : (e.message||'حدث خطأ')); }
    setBusy(false);
  };

  return (
    <div style={{minHeight:'100vh', display:'flex', alignItems:'center', justifyContent:'center', background:'var(--ink)'}}>
      <div style={{background:'#fff', borderRadius:8, padding:'34px 38px', width:380, maxWidth:'92vw', boxShadow:'0 20px 60px rgba(0,0,0,.4)', borderTop:'4px solid var(--brass)'}}>
        <div style={{textAlign:'center', marginBottom:22}}>
          <img src={NITAQ_LOGO} alt="نطاق" style={{width:110, filter:'invert(1) brightness(0.15)'}} />
          <div style={{fontFamily:'Cairo', fontWeight:900, fontSize:15, color:'var(--ink)', marginTop:8}}>نظام نطاق ERP — النسخة السحابية</div>
        </div>
        {mode==='up' && (
          <div className="field" style={{marginBottom:12}}>
            <label>الاسم</label>
            <input value={name} onChange={e=>setName(e.target.value)} />
          </div>
        )}
        <div className="field" style={{marginBottom:12}}>
          <label>البريد الإلكتروني</label>
          <input type="email" value={email} onChange={e=>setEmail(e.target.value)} style={{direction:'ltr'}} />
        </div>
        <div className="field" style={{marginBottom:16}}>
          <label>كلمة المرور</label>
          <input type="password" value={pass} onChange={e=>setPass(e.target.value)} style={{direction:'ltr'}}
            onKeyDown={e=>{ if(e.key==='Enter') submit(); }} />
        </div>
        {msg && <p style={{fontSize:12, color:'var(--rust)', marginBottom:12}}>{msg}</p>}
        <button className="btn brass" style={{width:'100%', justifyContent:'center'}} disabled={busy} onClick={submit}>
          {busy ? '...' : (mode==='in' ? 'تسجيل الدخول' : 'إنشاء حساب')}
        </button>
        <p style={{fontSize:12,textAlign:"center",marginTop:14}}>حسابات معتمدة من الإدارة فقط؛ لا تُمنح صلاحيات الحسابات تلقائيًا.</p>
        <p style={{fontSize:10.5, textAlign:'center', marginTop:8, color:'var(--ink-faint)'}}>إتاحة الحسابات وتغيير الأدوار من الإدارة فقط؛ الدعوة الهندسية لا تمنح وصولًا للحسابات.</p>
      </div>
    </div>
  );
}

/* ================= إدارة المستخدمين والصلاحيات (للمالك) ================= */
function UsersView({sbRef, myId}){
  const [rows, setRows] = useState(null);
  const load = async ()=>{
    const {data, error} = await sbRef.current.from('nitaq_profiles').select('*').order('created_at');
    if(!error) setRows(data||[]);
  };
  useEffect(()=>{ load(); },[]);
  const setRole = async (user_id, role)=>{
    const {error} = await sbRef.current.from('nitaq_profiles').update({role}).eq('user_id', user_id);
    if(error) alert('تعذر التعديل: '+error.message); else load();
  };
  const ROLE_AR = {owner:'مالك — صلاحية كاملة', accountant:'محاسب — كل المالية', engineer:'مهندس — المشاريع والقرارات'};
  return (
    <div>
      <div className="card" style={{padding:0, maxWidth:760}}>
        <table>
          <thead><tr><th>الاسم</th><th>البريد</th><th>الدور</th></tr></thead>
          <tbody>
            {rows===null && <tr className="empty-row"><td colSpan={3}>جارٍ التحميل...</td></tr>}
            {rows && rows.length===0 && <tr className="empty-row"><td colSpan={3}>لا مستخدمين بعد</td></tr>}
            {rows && rows.map(r=>(
              <tr key={r.user_id}>
                <td>{r.name||'—'}{r.user_id===myId && <span className="badge neutral" style={{marginInlineStart:8}}>أنت</span>}</td>
                <td style={{direction:'ltr', textAlign:'right'}}>{r.email}</td>
                <td>
                  <select value={r.role} disabled={r.user_id===myId}
                    onChange={e=>setRole(r.user_id, e.target.value)}
                    style={{border:'1px solid var(--line-strong)', borderRadius:4, padding:'6px 10px', fontSize:12}}>
                    {Object.entries(ROLE_AR).map(([v,l])=><option key={v} value={v}>{l}</option>)}
                  </select>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <p style={{fontSize:12, color:'var(--ink-faint)', marginTop:12}}>* الصلاحيات مطبقة على مستوى قاعدة البيانات نفسها (RLS) — المهندس لا يمكنه قراءة البيانات المالية حتى تقنياً. ملاحظة: بيانات الموظفين (شاملة الرواتب الأساسية) مقروءة لكل الأدوار لأن الأسماء مطلوبة في ملفات المراحل — أخبرني إن أردت فصل الرواتب في جدول مستقل.</p>
    </div>
  );
}

/* ================= App ================= */
const VIEW_TITLES = {
  fcc:['مركز القيادة المالية','ماذا يجب أن يحدث اليوم؟ — قائمة إجراءات مولّدة تلقائياً من بيانات النظام'],
  dashboard:['لوحة التحكم','نظرة عامة على أداء المكتب المالي والإداري'],
  projects:['المشاريع','المشروع هو محور النظام — افتح ملف أي مشروع لإدارة كل تفاصيله'],
  contracts:['العقود','تصميم واعتماد · إشراف · تعديل مخططات · أعمال إضافية'],
  settings:['الإعدادات','مسار مجلدات المشاريع وبيانات الحساب البنكي والربط السحابي'],
  users:['المستخدمون والصلاحيات','مالك · محاسب · مهندس — الصلاحيات مطبقة على مستوى قاعدة البيانات'],
  audit:['سجل التدقيق','كل عملية إنشاء وتعديل وإلغاء وإصدار — بالمستخدم والوقت، غير قابل للتعديل'],
  payments:['الدفعات الاستشارية','دفعات مرحلة التصميم والاعتماد ودفعات الإشراف الشهري'],
  projectRevenue:['إيرادات المشاريع','الإيرادات الاستشارية المفوترة والمحصّلة لكل مشروع — بفلاتر النوع والحالة والحساب والفترة، قابلة للطباعة'],
  decisions:['القرارات والوقائع','السجل الرسمي لقرارات المشاريع — من واتساب والاجتماعات والموقع، بعد اعتمادها'],
  govFees:['الرسوم الحكومية','أمانات الدوائر: التخطيط والمساحة · سيوا · الاتصالات · الدفاع المدني · البلدية'],
  officeExpenses:['مصروفات المكتب','المصروفات العمومية والإدارية غير المرتبطة بمشروع'],
  projectCosts:['تكاليف المشاريع','التكاليف المباشرة المحمّلة على كل مشروع'],
  recurringBills:['الفواتير الدورية','اشتراكات وفواتير متكررة: اتصالات · إنترنت · كهرباء وماء (سيوا) · إيجار وغيرها — مع تنبيه قبل كل استحقاق'],
  treasury:['الخزينة والبنك','الأرصدة الفعلية وحركة النقدية — وارد وصادر'],
  dues:['الذمم — مدينون ودائنون','من يدين لك وما يستحق عليك في لحظة واحدة'],
  vat:['ضريبة القيمة المضافة','فترات ربع سنوية وفق شهادة التسجيل — TRN: '+COMPANY.trn],
  statement:['كشف حساب مشروع','كشف تفصيلي بالدفعات والأمانات يُعرض على المالك أو الاستشاري عند الطلب'],
  reports:['التقارير المالية','قائمة الدخل وربحية المشاريع وتقرير الأمانات'],
  analytics:['التحليلات الذكية','هوامش الربح · توقع التدفق النقدي · كشف الشواذ · اقتراحات الفوترة · التقرير الشهري AR/EN'],
  employees:['الموظفون','بيانات الموظفين والإقامات'],
  attendance:['الحضور والانصراف','تسجيل الحضور اليومي للموظفين'],
  leaves:['الإجازات','تسجيل إجازات الموظفين وتتبّع الرصيد السنوي'],
  timesheets:['تتبّع الوقت','ساعات عمل المهندسين على كل مشروع — تُحسب تكلفتها وتُحمّل على ربحية المشروع'],
  docAlerts:['تنبيهات الوثائق','كل وثائق الموظفين والسيارات القريبة من الانتهاء في مكان واحد'],
  overtime:['الأوفرتايم','تسجيل ساعات العمل الإضافية'],
  advances:['السلف والخصومات','متابعة سلف ومستحقات الموظفين'],
  payroll:['الرواتب','كشف رواتب الموظفين الشهري'],
  cars:['سيارات الشركة','متابعة سيارات الشركة ورخصها'],
};

function App(){
  const [data, setDataState] = useState(seedData());
  const [loaded, setLoaded] = useState(false);
  const [view, setView] = useState('dashboard');
  const saveTimer = useRef(null);
  const dataRef = useRef(data);
  const [persistStatus, setPersistStatus] = useState(NITAQ_PERSIST.status);
  const [syncState,setSyncState]=useState(NITAQ_SYNC.state);
  const syncAllowed=useRef(false);
  const bootstrapGeneration=useRef(0);
  const bootstrapTail=useRef(Promise.resolve());
  const authSubscription=useRef(null);
  const remoteDirty=useRef(false);
  useEffect(()=>NITAQ_SYNC.subscribe(setSyncState),[]);
  const hydrate=(next)=>{
    if(NITAQ_PERSIST.blocked)return false;
    try{NITAQ_PERSIST.validate(next);dataRef.current=next;NITAQ_PERSIST.changed(next);setDataState(next);return true;}
    catch(e){NITAQ_PERSIST.fail(e,'remote');return false;}
  };
  useEffect(()=>{const handle=e=>{if(syncAllowed.current)hydrate(recordsToData(e.detail));};window.addEventListener('nitaq-sync-snapshot',handle);return()=>window.removeEventListener('nitaq-sync-snapshot',handle);},[]);
  const persistQueue = useRef(Promise.resolve());
  const importBusy = useRef(false);
  useEffect(()=>NITAQ_PERSIST.subscribe(setPersistStatus),[]);
  const setData = (change)=>{
    if(NITAQ_PERSIST.blocked||(getSbConfig()&&!syncAllowed.current)) return false;
    try{
      const next=typeof change==='function'?change(dataRef.current):change;
      NITAQ_PERSIST.validate(next);
      if(next===dataRef.current)return true;
      dataRef.current=next;
      NITAQ_PERSIST.changed(next);
      setDataState(next);
      return true;
    }catch(e){NITAQ_PERSIST.fail(e,'data');return false;}
  };

  /* ---------- السحابة ---------- */
  const sbRef = useRef(null);
  const channelRef = useRef(null);
  const [cloud, setCloud] = useState({status: getSbConfig() ? 'init' : 'off', profile:null, msg:''});
  const [cloudEmpty, setCloudEmpty] = useState(false);
  const cloudReady = cloud.status==='ready';

  const applyRemote=(payload)=>{
    if(NITAQ_PERSIST.blocked)return;
    if(!NITAQ_SYNC.identity){remoteDirty.current=true;return;}
    try{NITAQ_SYNC.remote(payload);}catch(e){setCloud(c=>({...c,msg:'⚠ تعذر تحديث السجل؛ ستُعاد قراءة السحابة'}));remoteDirty.current=true;}
  };

  const runCloudBootstrap=async()=>{
    await NITAQ_PERSIST.localGate;if(NITAQ_PERSIST.blocked)return;
    const attempt=++bootstrapGeneration.current;syncAllowed.current=false;
    setCloud(c=>({...c,status:'loading',msg:''}));
    try{
      const sb=sbRef.current,cfg=getSbConfig();
      const userRes=await sb.auth.getUser();if(userRes.error)throw userRes.error;
      const user=userRes.data?.user;if(!user){setCloud({status:'login',profile:null,msg:''});return;}
      const profileResult=await sb.from('nitaq_profiles').select('*').eq('user_id',user.id).single();
      if(profileResult.error||!profileResult.data||!['owner','accountant','engineer'].includes(profileResult.data.role))throw Error('تعذر التحقق من ملف المستخدم وصلاحياته.');
      if(attempt!==bootstrapGeneration.current)return;
      if(channelRef.current)await sb.removeChannel(channelRef.current);
      const legacyKey='nitaq-sync:pre-client-upgrade:v1';
      const legacy=await NITAQ_PERSIST.readAux(legacyKey);
      if(legacy===null)await NITAQ_PERSIST.writeAux(legacyKey,JSON.stringify(dataRef.current));
      else NITAQ_PERSIST.validate(NITAQ_PERSIST.parse(legacy));
      remoteDirty.current=false;
      channelRef.current=sb.channel('nitaq-rec-'+user.id).on('postgres_changes',{event:'*',schema:'public',table:'nitaq_records'},applyRemote).subscribe();
      const rows=await NITAQ_SYNC.attach({client:createNitaqScopedTransport(sb,cfg,user.id),url:cfg.url,userId:user.id});
      if(attempt!==bootstrapGeneration.current)return;
      syncAllowed.current=true;hydrate(recordsToData(rows));
      setCloud({status:'ready',profile:profileResult.data,msg:'✓ تم التحقق من الاتصال'});
      setCloudEmpty(rows.length===0);setLoaded(true);
      if(profileResult.data.role==='engineer')setView('projects');
      if(remoteDirty.current){remoteDirty.current=false;await NITAQ_SYNC.refresh();}
      await NITAQ_SYNC.flush();
    }catch(e){if(attempt===bootstrapGeneration.current){syncAllowed.current=false;setCloud(c=>({...c,status:'error',msg:e.message||'تعذر تحميل السحابة كاملة'}));}}
  };
  const cloudBootstrap=()=>{const task=bootstrapTail.current.then(runCloudBootstrap);bootstrapTail.current=task.catch(()=>{});return task;};

  const connectCloud = async ()=>{
    await NITAQ_PERSIST.localGate;
    if(NITAQ_PERSIST.blocked) return;
    const cfg = getSbConfig();
    if(!cfg || !cfg.url || !cfg.key) return;
    setCloud(c=>({...c, status:'init', msg:''}));
    let lastErr = null;
    for(let attempt=0; attempt<3 && !window.supabase; attempt++){
      try{ await loadScript(SB_CDN); break; }
      catch(e){ lastErr = e; await new Promise(r=>setTimeout(r, 1200)); }
    }
    if(!window.supabase){
      setCloud(c=>({...c, status:'error', msg:'تعذر تحميل مكتبة السحابة — تحقق من الإنترنت أو اضغط إعادة المحاولة'}));
      return;
    }
    try{
      sbRef.current = window.supabase.createClient(cfg.url, cfg.key);
      const sessRes = await sbRef.current.auth.getSession();
      if(sessRes.data && sessRes.data.session) await cloudBootstrap();
      else setCloud(c=>({...c, status:'login'}));
      authSubscription.current?.unsubscribe?.();
      const authResult=sbRef.current.auth.onAuthStateChange((ev,session)=>{
        if(ev==='SIGNED_OUT'){++bootstrapGeneration.current;syncAllowed.current=false;setTimeout(()=>clearCloudSession().catch(e=>NITAQ_PERSIST.fail(e,'logout')),0);}
        else if(ev==='SIGNED_IN'&&session?.user?.id!==NITAQ_SYNC.identity?.userId){++bootstrapGeneration.current;syncAllowed.current=false;setCloud(c=>({...c,status:'loading'}));setTimeout(()=>cloudBootstrap(),0);}
      });
      authSubscription.current=authResult.data?.subscription;
    }catch(e){ setCloud(c=>({...c, status:'error', msg:'تعذر الاتصال بالسحابة — تحقق من الإنترنت أو اضغط إعادة المحاولة'})); }
  };

  useEffect(()=>{ connectCloud(); },[]);

  const cloudUpsert=(entity,rec)=>{
    if(NITAQ_PERSIST.blocked||!getSbConfig())return;
    if(!syncAllowed.current||!rec?.id){NITAQ_PERSIST.fail(Error('لم تجهز هوية المزامنة؛ نزّل نسخة إنقاذ.'),'sync');return;}
    try{NITAQ_SYNC.enqueue('upsert',String(rec.id),entity,rec).catch(()=>{});}catch(e){NITAQ_PERSIST.fail(e,'sync');}
  };
  const cloudDelete=(id)=>{
    if(NITAQ_PERSIST.blocked||!getSbConfig())return;
    const entity=NITAQ_SYNC.findEntity(id);
    if(!syncAllowed.current||!entity){NITAQ_PERSIST.fail(Error('تعذر تحديد سجل الحذف في السحابة؛ لم نرسل حذفًا غير مؤكد.'),'sync');return;}
    try{NITAQ_SYNC.enqueue('delete',String(id),entity,null).catch(()=>{});}catch(e){NITAQ_PERSIST.fail(e,'sync');}
  };
  const pushAllToCloud=()=>alert('رفع قاعدة محلية كاملة متوقف لحين مراجعة الاستيراد السحابي. لا تُرفع البيانات تلقائيًا لمجرد أن النتيجة فارغة.');
  const clearCloudSession=async()=>{
    ++bootstrapGeneration.current;syncAllowed.current=false;
    setCloud({status:'login',profile:null,msg:''});
    if(saveTimer.current)clearTimeout(saveTimer.current);
    const sb=sbRef.current;if(channelRef.current&&sb){await sb.removeChannel(channelRef.current);channelRef.current=null;}
    await NITAQ_SYNC.detach();await persistQueue.current;
    fileHandleRef.current=null;setFileLinked(false);
    const empty=recordsToData([]);hydrate(empty);
    await store.set('nitaq-data',JSON.stringify(empty));NITAQ_PERSIST.saved(NITAQ_PERSIST.revision);
  };
  const logout=async()=>{
    if(NITAQ_SYNC.state.pending&&!confirm('توجد عمليات لم تؤكدها السحابة. ستبقى محفوظة لهذا الحساب على هذا الجهاز. هل تريد تسجيل الخروج؟'))return;
    if(sbRef.current){const result=await sbRef.current.auth.signOut();if(result.error)alert(result.error.message);}
  };
  useEffect(()=>{
    const tick=()=>{if(syncAllowed.current&&!NITAQ_PERSIST.blocked){NITAQ_SYNC.flush().catch(e=>setCloud(c=>({...c,msg:e.message})));NITAQ_SYNC.refresh().catch(e=>setCloud(c=>({...c,msg:'⚠ تعذر تحديث السحابة؛ النسخة المعروضة محفوظة'})));}};
    window.addEventListener('online',tick);window.addEventListener('focus',tick);
    const timer=setInterval(tick,60000);
    return()=>{clearInterval(timer);window.removeEventListener('online',tick);window.removeEventListener('focus',tick);};
  },[]);
  const exportSyncQueue=()=>{
    const url=URL.createObjectURL(new Blob([NITAQ_SYNC.exportPending()],{type:'application/json'}));
    const a=document.createElement('a');a.href=url;a.download='nitaq-pending-sync-'+Date.now()+'.json';a.click();setTimeout(()=>URL.revokeObjectURL(url),30000);
  };

  const fileHandleRef = useRef(null);
  const [fileLinked, setFileLinked] = useState(false);
  const [saveState, setSaveState] = useState('');

  useEffect(()=>{
    (async()=>{
      try{
        const raw=await store.get('nitaq-data');
        const initial=raw===null?seedData():NITAQ_PERSIST.prepare(NITAQ_PERSIST.parse(raw));
        dataRef.current=initial;
        NITAQ_PERSIST.loaded(initial);
        setDataState(initial);
        setLoaded(true);
      }catch(e){NITAQ_PERSIST.fail(e,'read');}
      finally{NITAQ_PERSIST.finishLocal();}
    })();
  },[]);

  useEffect(()=>{
    if(!loaded||NITAQ_PERSIST.blocked)return;
    if(saveTimer.current)clearTimeout(saveTimer.current);
    const snapshot=data;
    const ticket=NITAQ_PERSIST.revision;
    saveTimer.current=setTimeout(()=>{
      persistQueue.current=persistQueue.current.then(async()=>{
        if(NITAQ_PERSIST.blocked)return;
        await store.set('nitaq-data',JSON.stringify(snapshot));
        if(fileHandleRef.current){
          const writable=await fileHandleRef.current.createWritable();
          await writable.write(JSON.stringify(snapshot,null,2));
          await writable.close();
          setSaveState('✓ محفوظ في الملف');
        }
        NITAQ_PERSIST.saved(ticket);
      }).catch(e=>{setSaveState('⚠ توقف الحفظ');NITAQ_PERSIST.fail(e,'save');});
    },500);
    return ()=>clearTimeout(saveTimer.current);
  },[data,loaded]);

  const replaceFromFile = async (prepared)=>{
    if(NITAQ_PERSIST.blocked||importBusy.current) return false;
    if(getSbConfig())throw Error('استبدال البيانات من ملف متوقف أثناء تفعيل Supabase لحماية النسخة المشتركة. الاسترجاع السحابي يتم بمسار منفصل؛ لم نغير بياناتك.');
    if(!confirm('سيتم استبدال البيانات المحلية بعد حفظ نسخة استرجاع تلقائية. عدد الملاحظات التاريخية: '+prepared.warnings.length+' (تُحفظ دون حذف). هل تريد المتابعة؟'))return false;
    importBusy.current=true;
    try{
      NITAQ_PERSIST.beginReplacement();
      if(saveTimer.current)clearTimeout(saveTimer.current);
      await persistQueue.current;
      const previous=JSON.parse(JSON.stringify(dataRef.current));
      await NITAQ_PERSIST.replaceStored(prepared.data,previous);
      dataRef.current=prepared.data;
      NITAQ_PERSIST.remember(prepared.data);
      setDataState(prepared.data);
      if(fileHandleRef.current){
        const writable=await fileHandleRef.current.createWritable();
        await writable.write(JSON.stringify(prepared.data,null,2));
        await writable.close();
      }
      NITAQ_PERSIST.finishReplacement(prepared.data);
      return true;
    }catch(e){NITAQ_PERSIST.fail(e,'import-failed');throw e;}
    finally{importBusy.current=false;}
  };

  const linkDataFile = async ()=>{
    if(NITAQ_PERSIST.blocked||importBusy.current) return;
    if(!window.showOpenFilePicker || !window.showSaveFilePicker){
      alert('ربط ملف بيانات متاح على Chrome وEdge على الكمبيوتر. استخدم النسخة الاحتياطية على الأجهزة الأخرى.');return;
    }
    const openExisting=confirm('موافق: استبدال البيانات المحلية من ملف موجود بعد حفظ نسخة استرجاع. إلغاء: إنشاء ملف حفظ جديد للبيانات الحالية.');
    try{
      let handle;
      if(openExisting){
        if(getSbConfig())throw Error('فتح ملف لاستبدال البيانات متوقف أثناء تفعيل Supabase. يمكنك إنشاء ملف حفظ جديد للبيانات الحالية.');
        const picked=await window.showOpenFilePicker({types:[{description:'Nitaq Data',accept:{'application/json':['.json']}}]});
        handle=picked[0];
        const file=await handle.getFile();
        if(file.size>NITAQ_PERSIST.maxImportBytes)throw Error('الملف أكبر من 20 ميجابايت.');
        const prepared=NITAQ_PERSIST.prepareImport(NITAQ_PERSIST.parse(await file.text()));
        if(!await replaceFromFile(prepared))return;
      }else{
        handle=await window.showSaveFilePicker({suggestedName:'nitaq-data.json',types:[{description:'Nitaq Data',accept:{'application/json':['.json']}}]});
      }
      if(NITAQ_PERSIST.blocked)return;
      if(handle.requestPermission&&await handle.requestPermission({mode:'readwrite'})!=='granted')throw Error('لم يتم منح صلاحية الكتابة؛ لم يتم ربط الملف.');
      fileHandleRef.current=handle;
      setFileLinked(true);
      NITAQ_PERSIST.changed(dataRef.current);
      const fileTicket=NITAQ_PERSIST.revision;
      persistQueue.current=persistQueue.current.then(async()=>{
        if(NITAQ_PERSIST.blocked)return;
        const snapshot=JSON.parse(JSON.stringify(dataRef.current));
        await store.set('nitaq-data',JSON.stringify(snapshot));
        const writable=await handle.createWritable();
        await writable.write(JSON.stringify(snapshot,null,2));await writable.close();
        NITAQ_PERSIST.saved(fileTicket);
        setSaveState('✓ تم حفظ البيانات الحالية في الملف المرتبط');
      }).catch(e=>NITAQ_PERSIST.fail(e,'file'));
      await persistQueue.current;
    }catch(e){if(e.name!=='AbortError')alert(e.message||'تعذر فتح الملف.');}
  };

  const configs = useMemo(()=>{const all=buildConfigs(data);for(const key of Object.keys(FINANCIAL_BUNDLE_RULES))if(all[key])all[key]={...all[key],entityKey:key};return all;}, [data]);

  // بناء قائمة القيم قبل/بعد كاملة (كل الحقول المتغيرة، بلا اقتصاص) للتوثيق الجنائي
  const AUDIT_SKIP = new Set(['_ts','docSnapshot','_financialCorrection']);
  const auditShort = (v)=>{
    if(v===undefined||v===null||v==='') return '—';
    if(typeof v==='object') return JSON.stringify(v).slice(0,120);
    return String(v).slice(0,120);
  };
  const buildChanges = (before, after)=>{
    const keys = new Set([...Object.keys(before||{}), ...Object.keys(after||{})]);
    const diffs = [];
    keys.forEach(k=>{
      if(AUDIT_SKIP.has(k)) return;
      const b=before?before[k]:undefined, a=after?after[k]:undefined;
      if(JSON.stringify(b)!==JSON.stringify(a)) diffs.push({field:k, before:auditShort(b), after:auditShort(a)});
    });
    return diffs;
  };
  const auditWrite = (action, entity, recordId, summary, changes)=>{
    if(NITAQ_PERSIST.blocked) return;
    if(entity==='auditLog') return;
    const rec = {
      id: uid(), _ts: Date.now(),
      at: new Date().toISOString().slice(0,16).replace('T',' '),
      user: (cloud.profile && cloud.profile.name) || 'مستخدم محلي',
      action, entity, recordId: String(recordId||''), summary: (summary||'').slice(0,300),
      changes: Array.isArray(changes) ? changes.slice(0,40) : undefined,
    };
    setData(d=>({...d, auditLog:[...(d.auditLog||[]), rec]}));
    cloudUpsert('auditLog', rec);
  };
  const describeRecord = (key, r)=>{
    if(!r) return '';
    const dd = dataRef.current;
    const projN = (id)=>{ const p=(dd.projects||[]).find(x=>x.id===id); return p?((p.projectNo?p.projectNo+' — ':'')+(p.name||'')):''; };
    const empN = (id)=>{ const e=(dd.employees||[]).find(x=>x.id===id); return e?e.name:((dd.staffDir||[]).find(s=>s.empId===id)||{}).name||''; };
    if(key==='payments') return (r.label || (r.phase==='إشراف'?'إشراف '+(r.month||''):r.phase) || '') + ' — ' + money(r.amount||0) + (r.projectId?' — '+projN(r.projectId):'');
    if(key==='projects') return (r.projectNo?r.projectNo+' — ':'')+(r.name||'');
    if(key==='contracts') return (r.type||r.category||'')+' — '+(r.description||'')+(r.projectId?' — '+projN(r.projectId):'');
    if(key==='govFees') return (r.department||'')+' — '+money(r.amount||0)+(r.projectId?' — '+projN(r.projectId):'');
    if(key==='officeExpenses') return (r.category||'مصروف')+(r.vendor?' — '+r.vendor:'')+' — '+money(r.amount||0)+(r.bankName?' — '+r.bankName:'')+(r.note?' — '+String(r.note).slice(0,40):'');
    if(key==='projectCosts') return (r.category||'تكلفة')+' — '+money(r.amount||0)+(r.projectId?' — '+projN(r.projectId):'');
    if(key==='treasury') return (r.type||r.kind||'حركة')+' — '+money(r.amount||0)+(r.account?' — '+r.account:'')+(r.note?' — '+String(r.note).slice(0,40):'');
    if(key==='otherIncome') return (r.category||'إيراد آخر')+' — '+money(r.amount||0)+(r.vatable==='خاضع'?' (خاضع)':' (معفى)')+(r.account?' — '+r.account:'');
    if(key==='employees') return (r.name||'')+(r.position?' — '+r.position:'')+(r.baseSalary?' — راتب '+money(r.baseSalary):'');
    if(key==='overtime') return (empN(r.employeeId)||'موظف')+' — '+(r.hours||0)+' ساعة'+(r.date?' — '+r.date:'');
    if(key==='advances') return (empN(r.employeeId)||'موظف')+' — '+(r.type||'')+' '+money(r.amount||0)+(r.mode==='مقسّط'?' (قسط '+money(r.monthlyInstallment||0)+')':'');
    if(key==='leaves') return (empN(r.employeeId)||'موظف')+' — '+(r.type||'')+' '+(r.days||0)+' يوم'+(r.fromDate?' من '+r.fromDate:'');
    if(key==='timesheets') return (empN(r.employeeId)||'مهندس')+' — '+(Number(r.hours)||0)+' ساعة'+(r.projectId?' على '+projN(r.projectId):'')+(r.phase?' ('+r.phase+')':'')+(r.task?' — '+String(r.task).slice(0,40):'');
    if(key==='cars') return (r.model||r.plate||'سيارة')+(r.plate&&r.model?' — '+r.plate:'');
    if(key==='recurringBills') return (r.provider||r.category||'فاتورة')+' — '+money(r.amount||0);
    if(key==='decisions') return (r.category||'قرار')+' — '+String(r.description||r.note||'').slice(0,50);
    return r.name || r.label || r.description || r.category || '';
  };
  const authorizeBundle=(key,before,after,kind='update')=>{
    const check=financialBundleControl(key,before,after,kind,dataRef.current);
    if(check.error){alert(check.error);return null;}
    if(!['owner','accountant'].includes(role)&&!(role==='engineer'&&check.engineerAllowed)){alert('هذا السجل المالي متاح للمالك والمحاسب؛ المهندس يسجل الرسوم غير المسددة فقط.');return null;}
    if(after?.kind==='رواتب'&&['officeExpenses','treasury'].includes(key)){
      if(after.amount<0||(key==='treasury'&&after.type!=='صرف')||(key==='officeExpenses'&&after.payStatus==='معلق')){alert('قيد صرف الرواتب يجب أن يكون صرفًا غير سالب، وليس قبضًا أو مبلغًا معلقًا.');return null;}
      if(!/^[0-9]{4}-(0[1-9]|1[0-2])$/.test(after.month||'')){alert('شهر الراتب مطلوب بصيغة صحيحة.');return null;}
      if([...(dataRef.current.officeExpenses||[]),...(dataRef.current.treasury||[])].some(x=>x.kind==='رواتب'&&x.month===after.month&&x.id!==after.id)){alert('يوجد صرف مسجل لهذا الشهر بالفعل؛ لا نكرر قيد الرواتب.');return null;}
    }
    if(after?.kind===SALARY_PART_KIND){
      if(key!=='officeExpenses'){alert('دفعة الراتب تُسجَّل كمصروف مكتب فقط.');return null;}
      if(!(typeof after.amount==='number'&&after.amount>0)||after.payStatus==='معلق'){alert('دفعة الراتب يجب أن تكون مبلغًا مدفوعًا أكبر من صفر.');return null;}
      if(!/^[0-9]{4}-(0[1-9]|1[0-2])$/.test(after.month||'')){alert('شهر الراتب مطلوب بصيغة صحيحة.');return null;}
      const cur=dataRef.current;const emp=(cur.employees||[]).find(e=>e.id===after.employeeId);
      if(!emp){alert('الموظف غير موجود.');return null;}
      if(isWpsEmp(emp)){alert('هذا الموظف مسجّل عبر WPS — يُصرف راتبه مع «صرف الرواتب». غيّري طريقة صرف راتبه من ملفه أولاً لو لزم.');return null;}
      if(!isArchived(after)){
        const row=computePayroll(cur,after.month).rows.find(r=>r.emp.id===emp.id);const net=row?row.net:0;
        const others=salaryPaymentsForEmp(cur,emp.id,after.month,net).filter(x=>x.id!==after.id);
        if(others.some(x=>x.legacy)){alert('رواتب هذا الشهر مسجّلة كصرف كامل بقيد قديم — لا يمكن إضافة دفعة.');return null;}
        const already=others.reduce((s,x)=>s+x.amount,0);
        if(already+after.amount>net+0.01){alert('المبلغ يتجاوز المتبقي من راتب '+emp.name+' ('+money(Math.max(0,net-already))+').');return null;}
      }
    }
    if(check.correction){
      if(role!=='owner'){alert('تصحيح البيانات المالية المسجلة متاح للمالك فقط بسبب جديد يسجل على الخادم.');return null;}
      const explicit=after.lastCorrectionAt&&after.lastCorrectionAt!==before?.lastCorrectionAt?after.lastCorrectionReason:(after.archived===true&&before?.archived!==true?after.archiveReason:null);
      const reason=typeof explicit==='string'&&explicit.trim()?explicit.trim():prompt('سبب تصحيح البيانات (3 إلى 500 حرف). هذا تصحيح إدخال موثق، وليس حذفًا لحركة فعلية أو رد أموال:');
      if(reason===null)return null;if(!reason||reason.trim().length<3||reason.trim().length>500){alert('أدخل سببًا واضحًا من 3 إلى 500 حرف.');return null;}
      return {...after,_financialCorrection:{id:uid(),kind:'data_correction',reason:reason.trim()},lastCorrectionReason:reason.trim(),lastCorrectionAt:new Date().toISOString()};
    }
    return after;
  };
  const mutate = (key) => ({
    add:(record)=>{
      if(FINANCIAL_BUNDLE_RULES[key]){record=authorizeBundle(key,null,record,'insert');if(!record)return false;}
      if(key==='payments'){const check=paymentControl(null,record);if(check.error){alert(check.error);return false;}}
      setData(d=>({...d, [key]:[...d[key], record]}));
      cloudUpsert(key, record);
      auditWrite('إنشاء', key, record.id, describeRecord(key, record), buildChanges(null, record));
    },
    update:(id, patch)=>{
      const cur = (dataRef.current[key]||[]).find(r=>r.id===id);
      let merged = cur ? {...cur, ...patch} : null;
      // تغيير المرتب: يُسأل عن شهر السريان ويُحفظ في سجل المرتب حتى لا تتغير الشهور القديمة
      if(key==='employees' && cur && merged && patch.salaryHistory===undefined){
        const changed = (Number(cur.baseSalary)||0)!==(Number(merged.baseSalary)||0) || (Number(cur.grossSalary)||0)!==(Number(merged.grossSalary)||0);
        if(changed){
          const ans = prompt('مرتب '+(cur.name||'الموظف')+' اتغيّر.\nمن أي شهر يبدأ المرتب الجديد؟ اكتبيه بالصيغة 2026-11\n(الشهور اللي قبله هتفضل بالمرتب القديم)', currentYM());
          if(ans===null) return false;
          const fromYM = ans.trim();
          if(!/^[0-9]{4}-(0[1-9]|1[0-2])$/.test(fromYM)){ alert('اكتبي الشهر بالصيغة 2026-11'); return false; }
          const paidAfter = [...new Set([...(dataRef.current.officeExpenses||[]),...(dataRef.current.treasury||[])].filter(x=>(x.kind==='رواتب'||x.kind===SALARY_PART_KIND) && (x.month||'')>=fromYM).map(x=>x.month))].sort();
          if(paidAfter.length && !confirm('تنبيه: رواتب '+paidAfter.map(fmtMonth).join('، ')+' مصروفة بالفعل بالمرتب القديم.\nتطبيق المرتب الجديد من '+fmtMonth(fromYM)+' هيغيّر كشف الشهور دي (وهيظهر فرق مستحق أو زيادة). متأكدة؟')) return false;
          merged = {...merged, salaryHistory: withSalaryChange(cur, merged, fromYM)};
        }
      }
      if(FINANCIAL_BUNDLE_RULES[key]){if(!cur)return false;merged=authorizeBundle(key,cur,merged);if(!merged)return false;patch=merged;}
      if(key==='payments'){
        if(!cur)return false;
        if(!['owner','accountant'].includes(role)){alert('حسابك لا يملك صلاحية تعديل الدفعات.');return false;}
        const check=paymentControl(cur,merged);
        if(check.error){alert(check.error);return false;}
        if(check.correction){
          if(role!=='owner'){alert('هذا التصحيح متاح للمالك فقط بسبب مسجل؛ التحصيل العادي متاح للمحاسب.');return false;}
          const supplied=(patch.lastCorrectionAt&&patch.lastCorrectionAt!==cur.lastCorrectionAt)?patch.lastCorrectionReason:(patch.archived===true?patch.archiveReason:null);
          const reason=typeof supplied==='string'&&supplied.trim()?supplied.trim():prompt('سبب تصحيح بيانات الدفعة (من 3 إلى 500 حرف). التصحيح يُسجل بالقيم قبل وبعد على الخادم. هذا المسار لا يمثل رد أموال فعليًا:');
          if(reason===null)return false;
          if(!reason||reason.trim().length<3||reason.trim().length>500){alert('أدخل سببًا واضحًا من 3 إلى 500 حرف.');return false;}
          if(check.newNet<check.oldNet&&!confirm('سيقل التحصيل المسجل من '+money(check.oldNet)+' إلى '+money(check.newNet)+' قبل الضريبة. أكّد أن هذا تصحيح إدخال، وليس رد أموال فعليًا. رد الأموال يحتاج حركة مالية مستقلة.'))return false;
          patch={...patch,lastCorrectionReason:reason.trim(),lastCorrectionAt:new Date().toISOString(),_financialCorrection:{id:uid(),kind:'data_correction',reason:reason.trim()}};
          merged={...cur,...patch};
        }
      }
      if(key==='contracts'&&cur?.archived===true&&merged&&merged.archived!==true&&merged.cancelled!==true){
        const problem=NITAQ_PERSIST.contractRestoreProblem(merged,dataRef.current);
        if(problem){alert(problem);return;}
      }
      setData(d=>({...d, [key]: d[key].map(r=> r.id===id ? {...r,...patch} : r)}));
      if(merged) cloudUpsert(key, merged);
      if(cur){
        let action = 'تعديل';
        if(patch.archived===true) action = 'أرشفة / إلغاء';
        else if(patch.archived===false) action = 'استرجاع من الأرشيف';
        else if((patch.invoiceNo && !cur.invoiceNo) || (patch.receiptNo && !cur.receiptNo)) action = 'إصدار مستند';
        const diffs = buildChanges(cur, merged);
        const summaryTxt = diffs.slice(0,4).map(d=> d.field+': '+d.before+' ← '+d.after).join(' · ');
        auditWrite(action, key, id, describeRecord(key, merged)+(summaryTxt?' | '+summaryTxt:''), diffs);
      }
    },
    del:(id)=>{
      if(FINANCIAL_BUNDLE_RULES[key]){alert(financialBundleControl(key,null,null,'delete').error);return false;}
      if(key==='payments'){alert(paymentControl(null,null,'delete').error);return false;}
      const cur = (dataRef.current[key]||[]).find(r=>r.id===id);
      setData(d=>({...d, [key]: d[key].filter(r=>r.id!==id)}));
      cloudDelete(id);
      auditWrite('حذف نهائي', key, id, describeRecord(key, cur), buildChanges(cur, null));
    },
  });

  const setAttendance = (empId, dateStr, status) => {
    if(NITAQ_PERSIST.blocked)return false;
    const oldMap={...((dataRef.current.attendance||{})[empId]||{})},map={...oldMap};
    if(status===null)delete map[dateStr];else map[dateStr]=status;
    const record=authorizeBundle('attendance',{map:oldMap},{id:'att-'+empId,empId,map});if(!record)return false;
    setData(d=>({...d,attendance:{...d.attendance,[empId]:map}}));cloudUpsert('attendance',record);
  };

  const importRef = useRef(null);
  const exportBackup = () => {
    const blob = new Blob([JSON.stringify(data, null, 2)], {type:'application/json'});
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = 'nitaq-backup-'+todayISO()+'.json';
    document.body.appendChild(a); a.click(); document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };
  const importBackup = async (e)=>{
    const file=e.target.files&&e.target.files[0];e.target.value='';
    if(!file||NITAQ_PERSIST.blocked||importBusy.current)return;
    try{
      if(getSbConfig())throw Error('استبدال البيانات من ملف متوقف أثناء تفعيل Supabase لحماية بيانات المكتب المشتركة. لم يتم تغيير البيانات.');
      if(file.size>NITAQ_PERSIST.maxImportBytes)throw Error('الملف أكبر من 20 ميجابايت.');
      const prepared=NITAQ_PERSIST.prepareImport(NITAQ_PERSIST.parse(await file.text()));
      if(await replaceFromFile(prepared))alert('تم الاستبدال والحفظ محليًا. نسخة ما قبل الاستبدال متاحة للتنزيل. لم تُرفع بيانات إلى Supabase.');
    }catch(error){alert(error.message||'فشل الاستيراد؛ راجع تنبيه الحماية.');}
  };

  const [jumpProject, setJumpProject] = useState(null);
  const fccUrgent = useMemo(()=>{
    const st = data.fccState||{};
    return buildFccItems(data).filter(it=>{ const s=st[it.key]; return it.pr==='high' && !(s&&(s.done||(s.snoozeUntil&&s.snoozeUntil>=todayISO()))); }).length;
  }, [data]);
  const role = cloud.profile ? cloud.profile.role : (getSbConfig()?'engineer':'owner');
  const ROLE_AR = {owner:'مالك', accountant:'محاسب', engineer:'مهندس'};
  const navAllowed = (key)=>{
    if(role==='engineer') return ENGINEER_VIEWS.includes(key);
    if(role==='accountant') return key!=='users';
    return true;
  };

  const urgentCount = (key) => {
    if(key==='employees') return data.employees.filter(e=> ['iqamaExpiry','passportExpiry','workCardExpiry'].some(f=>{const dd=daysUntil(e[f]); return dd!==null && dd<=60;})).length;
    if(key==='cars') return data.cars.filter(c=>{const dd=daysUntil(c.licenseExpiry); return dd!==null && dd<=60;}).length;
    if(key==='govFees') return data.govFees.filter(g=>!isArchived(g) && g.payerType!=='المالك مباشرة' && g.paidStatus==='مدفوع' && g.reimburseStatus!=='مسترد').length;
    if(key==='fcc') return fccUrgent;
    if(key==='dues') return data.govFees.filter(g=>!isArchived(g) && g.payerType!=='المالك مباشرة' && g.paidStatus!=='مدفوع').length;
    if(key==='payments') return data.payments.filter(i=>{ if(remainderOf(i)<=0) return false; const dd=daysUntil(i.dueDate); return dd!==null && dd<0; }).length;
    return 0;
  };

  const renderView = () => {
    if(!navAllowed(view)) return <ProjectsView data={data} configs={configs} mutate={mutate} role={role} />;
    if(view==='syncQueue') return <div className="card" dir="rtl">
      <h3>العمليات غير المؤكدة من السحابة ({syncState.pending})</h3>
      <p>التعارضات لا تُستبدل تلقائيًا. نزّل القائمة وراجع بيانات السحابة قبل تصحيح العملية.</p>
      <button className="btn" onClick={exportSyncQueue}>تنزيل العمليات للمراجعة</button>
      <button className="btn" onClick={()=>NITAQ_SYNC.retry().catch(e=>NITAQ_PERSIST.fail(e,'sync'))}>إعادة المحاولة</button>
      {syncState.jobs.map(j=><div key={j.token} style={{borderBottom:'1px solid #ddd',padding:12}}><b>{({auditLog:'سجل التعديلات',staffDir:'دليل الموظفين',fccState:'المتابعة'}[j.entity]||NAV.flatMap(g=>g.items).find(x=>x.key===j.entity)?.label||'عملية محفوظة')} — {j.data?.name||j.data?.label||j.id}</b><p>{j.status==='blocked'?'تحتاج مراجعة':'بانتظار التأكيد'}: {j.kind==='delete'?'حذف':'حفظ'}</p><p>{j.error?(/NITAQ_CONFLICT/.test(j.error.message)?'السجل تغيّر على جهاز آخر. احتفظنا بتعديلك للمراجعة دون استبدال بيانات المكتب.':j.error.code==='42501'?'حسابك لا يملك صلاحية تنفيذ هذه العملية.':'تعذر تأكيد العملية. احتفظنا بها للمراجعة أو إعادة المحاولة.'):''}</p></div>)}
    </div>;
    if(view==='fcc') return <FccView data={data} mutate={mutate} go={setView} setFcc={(m)=>{ setData(d=>({...d, fccState:m})); cloudUpsert('fccState', {id:'fccState', map:m}); }} />;
    if(view==='dashboard') return <Dashboard data={data} go={setView} />;
    if(view==='projects') return <ProjectsView data={data} configs={configs} mutate={mutate} jumpId={jumpProject} onJumpDone={()=>setJumpProject(null)} role={role} />;
    if(view==='settings') return <SettingsView data={data} setSettings={(s)=>{ setData(d=>({...d, settings:s})); cloudUpsert('settings', {id:'settings', ...s}); auditWrite('تعديل', 'settings', 'settings', 'تحديث إعدادات النظام (المسار/البيانات البنكية)'); }} />;
    if(view==='audit') return <AuditView data={data} />;
    if(view==='users') return cloud.status==='ready' ? <UsersView sbRef={sbRef} myId={cloud.profile&&cloud.profile.user_id} /> : <div className="card"><p style={{fontSize:13, margin:0}}>إدارة المستخدمين متاحة في الوضع السحابي فقط — فعّل Supabase من الإعدادات.</p></div>;
    if(view==='payments') return <PaymentsView data={data} configs={configs} mutate={mutate} role={role} />;
    if(view==='projectRevenue') return <ProjectRevenueView data={data} />;
    if(view==='revenue') return <RevenueHub data={data} configs={configs} mutate={mutate} />;
    if(view==='contracts' || view==='decisions') return <ProjectFilteredList entity={view} data={data} configs={configs} mutate={mutate} />;
    if(view==='officeExpenses') return <OfficeExpensesView data={data} configs={configs} mutate={mutate}
      saveBudgets={(budgets)=>{ setData(d=>{ const s={...(d.settings||{}), budgets}; cloudUpsert('settings', {id:'settings', ...s}); return {...d, settings:s}; }); auditWrite('تعديل', 'settings', 'settings', 'تحديث الموازنة الشهرية للمصروفات'); }} />;
    if(view==='recurringBills') return <RecurringBillsView data={data} configs={configs} mutate={mutate} />;
    if(view==='govFees') return <GovFeesView data={data} configs={configs} mutate={mutate} />;
    if(view==='vat') return <VatView data={data} />;
    if(view==='statement') return <StatementView data={data} />;
    if(view==='reports') return <ReportsView data={data} />;
    if(view==='analytics') return <AnalyticsView data={data} />;
    if(view==='payroll') return <PayrollView data={data} mutate={mutate} />;
    if(view==='treasury') return <TreasuryView data={data} configs={configs} mutate={mutate} />;
    if(view==='otherIncome') return <OtherIncomeView data={data} configs={configs} mutate={mutate} />;
    if(view==='dues') return <DuesView data={data} />;
    if(view==='attendance') return <AttendanceView data={data} setAttendance={setAttendance} />;
    if(view==='docAlerts') return <DocAlertsView data={data} />;
    if(view==='timesheets') return <TimesheetsView data={data} configs={configs} mutate={mutate} />;
    if(configs[view]){
      const m = mutate(view);
      return <EntityView config={configs[view]} records={data[view]} data={data}
        onAdd={m.add} onUpdate={m.update} onDelete={m.del} />;
    }
    return null;
  };

  const [title, subtitle] = VIEW_TITLES[view] || ['',''];

  if(!persistStatus.ready || persistStatus.locked) return (
    <div dir="rtl" style={{minHeight:'100vh',background:'#f5f2ec',padding:40,display:'grid',placeItems:'center'}}>
      <div role="alert" style={{maxWidth:650,background:'#fff',padding:28,border:'2px solid #9b4336',borderRadius:8}}>
        <h2>{persistStatus.kind==='import'?'جارٍ حفظ نسخة الاسترجاع':persistStatus.locked?'توقف التعديل لحماية البيانات':'جارٍ فحص البيانات'}</h2>
        <p>{persistStatus.message}</p>
        {persistStatus.locked && persistStatus.kind!=='import' && <>
          <p>نزّل نسخة الإنقاذ قبل إغلاق الصفحة. إذا تعذرت القراءة، يحتوي التنزيل على المحتوى التالف المتاح أو تقرير الخطأ؛ وليس نسخة كاملة من بيانات المكتب.</p>
          <button className="btn" onClick={NITAQ_PERSIST.rescue}>تنزيل نسخة إنقاذ</button>
          <button className="btn" onClick={exportSyncQueue}>تنزيل العمليات غير المتزامنة</button>
          <button className="btn" onClick={NITAQ_PERSIST.downloadPrevious}>تنزيل نسخة ما قبل الاستبدال</button>
          <button className="btn" style={{marginInlineStart:10}} onClick={()=>{if(confirm('هل حفظت نسخة الإنقاذ؟ إعادة الفتح تتخلص من التغييرات غير المحفوظة.'))window.location.reload();}}>إعادة فتح النظام</button>
        </>}
      </div>
    </div>
  );
  if(cloud.status==='error'&&getSbConfig()&&!syncAllowed.current) return <div dir="rtl" className="card" style={{margin:40}}><h2>لم نتمكن من فتح بيانات السحابة بأمان</h2><p>{cloud.msg}</p><button className="btn" onClick={connectCloud}>إعادة المحاولة</button></div>;
  if(cloud.status==='login') return <LoginView sbRef={sbRef} onLogin={cloudBootstrap} />;
  if(cloud.status==='init' || cloud.status==='loading') return (
    <div style={{minHeight:'100vh', display:'flex', alignItems:'center', justifyContent:'center', background:'var(--ink)', flexDirection:'column', gap:16}}>
      <img src={NITAQ_LOGO} alt="نطاق" style={{width:130}} />
      <div style={{color:'#C7D0DB', fontSize:13.5}}>جارٍ الاتصال بسحابة نطاق...</div>
    </div>
  );

  return (
    <div className="app">
      <div className="sidebar">
        <div className="brand" style={{textAlign:'center'}}>
          <img src={NITAQ_LOGO} alt="نطاق" style={{width:110, display:'block', margin:'0 auto 8px'}} />
          <p>الاستشارات الهندسية · الشارقة</p>
        </div>
        <nav className="nav">
          {NAV.map(group=>{
            const items = group.items.filter(item=>navAllowed(item.key));
            if(items.length===0) return null;
            return (
            <div key={group.group}>
              <div className="nav-group-label">{group.group}</div>
              {items.map(item=>{
                const Icon = item.icon;
                const count = urgentCount(item.key);
                return (
                  <div key={item.key} className={"nav-item "+(view===item.key?'active':'')} onClick={()=>setView(item.key)}>
                    <Icon/>
                    <span>{item.label}</span>
                    {count>0 && <span className="dot"></span>}
                  </div>
                );
              })}
            </div>
            );
          })}
        </nav>
        <div className="sidebar-foot">
          <div role="status" style={{fontSize:11,color:persistStatus.pending?'#f0c36c':'#9FD8CC',marginBottom:8}}>{persistStatus.message}</div>
          {cloud.status==='ready' && (
            <div style={{border:'1px solid var(--teal)', borderRadius:4, padding:'7px 10px', marginBottom:8, fontSize:11, color:'#9FD8CC', display:'flex', alignItems:'center', gap:6, flexWrap:'wrap'}}>
              <span>☁ {cloud.profile ? (cloud.profile.name||'') : ''} ({ROLE_AR[role]||role})</span>
              <span style={{marginInlineStart:'auto', fontSize:9.5, color:'#7FA8A0'}}>{cloud.msg?.startsWith("⚠")?cloud.msg:(syncState.message||cloud.msg)}</span>
              <span onClick={logout} style={{cursor:'pointer', textDecoration:'underline', fontSize:10}}>خروج</span>
            </div>
          )}
          {cloud.status==='error' && (
            <div style={{border:'1px solid var(--rust)', borderRadius:4, padding:'7px 10px', marginBottom:8, fontSize:10.5, color:'#E8A79A'}}>
              ⚠ السحابة: {cloud.msg} — النظام يعمل محلياً
              <div style={{marginTop:6}}>
                <span onClick={connectCloud} style={{cursor:'pointer', textDecoration:'underline', fontWeight:700, color:'#fff'}}>↻ إعادة محاولة الاتصال</span>
              </div>
            </div>
          )}
          {cloud.status==='ready' && syncState.pending>0 && <button className="btn small" onClick={()=>setView('syncQueue')}>مراجعة {syncState.pending} عملية غير متزامنة ({syncState.blocked} تحتاج مراجعة)</button>}
          {cloud.status==='ready' && cloudEmpty && (
            <p style={{fontSize:11}}>لا توجد سجلات متاحة لهذا الحساب. لم نرفع أي بيانات محلية تلقائيًا.</p>
          )}
          <button className="btn ghost small" style={{width:'100%', border:'1px solid '+(fileLinked?'var(--teal)':'var(--brass)'), color:fileLinked?'var(--teal)':'#EDEFEA', marginBottom:6, justifyContent:'center'}} onClick={linkDataFile}>
            {fileLinked ? '✓ الحفظ التلقائي في ملف مفعّل' : '🔗 ربط ملف بيانات (حفظ تلقائي)'}
          </button>
          {saveState && <div style={{fontSize:10, color:'#8794A6', textAlign:'center', marginBottom:6}}>{saveState}</div>}
          {role==='owner' && (
            <React.Fragment>
              <div style={{display:'flex', gap:6, marginBottom:6}}>
                <button className="btn ghost small" style={{flex:1, border:'1px dashed var(--line-strong)'}} onClick={exportBackup}>⬇ نسخة احتياطية</button>
                <button className="btn ghost small" style={{flex:1, border:'1px dashed var(--line-strong)'}} onClick={()=>importRef.current && importRef.current.click()}>⬆ استيراد</button>
                <input ref={importRef} type="file" accept="application/json,.json" style={{display:'none'}} onChange={importBackup} />
                <button className="btn ghost small" onClick={NITAQ_PERSIST.downloadPrevious}>نسخة ما قبل الاستبدال</button>
              </div>
              <button className="btn ghost small" style={{width:'100%', border:'1px dashed var(--brass)', color:'#D9C08F', marginBottom:8, justifyContent:'center'}}
                onClick={async ()=>{ try{ await exportExcelBackup(dataRef.current, configs); }catch(e){ alert(e.message); } }}>
                📊 تصدير Excel شامل (كل الأقسام)
              </button>
            </React.Fragment>
          )}
          نظام داخلي · بياناتك محفوظة تلقائياً
        </div>
      </div>

      <div className="main">
        <div className="topbar">
          <div>
            <h2>{title}</h2>
            <div className="sub">{subtitle}</div>
          </div>
          <div className="topbar-right" style={{display:'flex', gap:14, alignItems:'center', flexWrap:'wrap'}}>
            <GlobalSearch data={data} go={setView} navAllowed={navAllowed}
              jumpToProject={(id)=>{ setJumpProject(id); setView('projects'); }} />
            <span className="topbar-date">{new Date().toLocaleDateString('ar-AE', {weekday:'long', year:'numeric', month:'long', day:'numeric'})}</span>
          </div>
        </div>
        <div className="content">
          {renderView()}
        </div>
      </div>
    </div>
  );
}

ReactDOM.createRoot(document.getElementById('root')).render(<App/>);
